//! The module `Lower`, from `target/bootstrap/src/prismc/lower/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod model;
pub mod node_;

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
#[derive(Clone)]
pub enum Bn {
    BnLocal(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    BnHold(Text, crate::lower::model::OutTy),
    BnDyn(crate::lower::model::Ex, Array<crate::lower::node_::Read>, crate::lower::model::OutTy),
    BnEv(crate::lower::node_::EvRef, crate::lower::model::OutTy),
    BnParts(Array<Option<Bn>>),
    BnWidget(crate::syntax::Expr, Env, Env, Lx),
    BnLocalFn(crate::syntax::FnClause),
}

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone)]
pub struct Env {
    pub names: Map<Text, Bn>,
    pub spans: Map<Text, Vl>,
    pub uses: Map<Text, Text>,
}

/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Holding {
    ByRef,
    Owned,
    RcRef,
    RcOwned,
}

impl Show for Holding {
    fn show(&self, p: &mut Printer) {
        match self {
            Holding::ByRef => p.choice("ByRef", &[]),
            Holding::Owned => p.choice("Owned", &[]),
            Holding::RcRef => p.choice("RcRef", &[]),
            Holding::RcOwned => p.choice("RcOwned", &[]),
        }
    }
}

impl ToPod for Holding {
    fn to_pod(&self) -> Pod {
        match self {
            Holding::ByRef => Pod::Choice("ByRef".into(), vec![]),
            Holding::Owned => Pod::Choice("Owned".into(), vec![]),
            Holding::RcRef => Pod::Choice("RcRef".into(), vec![]),
            Holding::RcOwned => Pod::Choice("RcOwned".into(), vec![]),
        }
    }
}

impl FromPod for Holding {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "ByRef" && a.len() == 0 => Ok(Holding::ByRef),
            Pod::Choice(c, a) if &**c == "Owned" && a.len() == 0 => Ok(Holding::Owned),
            Pod::Choice(c, a) if &**c == "RcRef" && a.len() == 0 => Ok(Holding::RcRef),
            Pod::Choice(c, a) if &**c == "RcOwned" && a.len() == 0 => Ok(Holding::RcOwned),
            other => mismatch("a Holding", other),
        }
    }
}

/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Layer {
    LyPlain,
    LyDyn,
    LyEv,
    LyBlueprint,
}

impl Show for Layer {
    fn show(&self, p: &mut Printer) {
        match self {
            Layer::LyPlain => p.choice("LyPlain", &[]),
            Layer::LyDyn => p.choice("LyDyn", &[]),
            Layer::LyEv => p.choice("LyEv", &[]),
            Layer::LyBlueprint => p.choice("LyBlueprint", &[]),
        }
    }
}

impl ToPod for Layer {
    fn to_pod(&self) -> Pod {
        match self {
            Layer::LyPlain => Pod::Choice("LyPlain".into(), vec![]),
            Layer::LyDyn => Pod::Choice("LyDyn".into(), vec![]),
            Layer::LyEv => Pod::Choice("LyEv".into(), vec![]),
            Layer::LyBlueprint => Pod::Choice("LyBlueprint".into(), vec![]),
        }
    }
}

impl FromPod for Layer {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "LyPlain" && a.len() == 0 => Ok(Layer::LyPlain),
            Pod::Choice(c, a) if &**c == "LyDyn" && a.len() == 0 => Ok(Layer::LyDyn),
            Pod::Choice(c, a) if &**c == "LyEv" && a.len() == 0 => Ok(Layer::LyEv),
            Pod::Choice(c, a) if &**c == "LyBlueprint" && a.len() == 0 => Ok(Layer::LyBlueprint),
            other => mismatch("a Layer", other),
        }
    }
}

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lx {
    pub g: crate::check::env::G,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub apps: Map<Text, crate::check::typed::AppNote>,
    pub binders: Map<Text, crate::check::types::Ty>,
    pub impls: Map<Text, Array<crate::check::typed::ImplNote>>,
    pub file: Nat,
    pub home: Text,
    pub site: Text,
    pub rs_mods: Map<Text, Text>,
    pub rs_names: Map<Text, Text>,
    pub layouts: Map<Text, Array<bool>>,
    pub unbs: Array<Text>,
    pub notes: Array<Text>,
    pub globals: Map<Text, bool>,
    pub in_node: bool,
    pub unshrunk: Map<Text, bool>,
    pub gens: Map<Text, crate::check::typed::GenNote>,
    pub insts: Map<Text, Array<crate::check::typed::InstNote>>,
    pub quants: Map<Text, Text>,
    pub gen_of_q: Map<Text, crate::check::typed::GenNote>,
    pub use_insts: Map<Text, crate::check::typed::InstNote>,
    pub subst: Map<Text, crate::check::types::Ty>,
    pub csubst: Map<Text, crate::check::types::Col>,
}

impl Show for Lx {
    fn show(&self, p: &mut Printer) {
        p.record("Lx", &[("g", &self.g), ("tys", &self.tys), ("apps", &self.apps), ("binders", &self.binders), ("impls", &self.impls), ("file", &self.file), ("home", &self.home), ("site", &self.site), ("rs_mods", &self.rs_mods), ("rs_names", &self.rs_names), ("layouts", &self.layouts), ("unbs", &self.unbs), ("notes", &self.notes), ("globals", &self.globals), ("in_node", &self.in_node), ("unshrunk", &self.unshrunk), ("gens", &self.gens), ("insts", &self.insts), ("quants", &self.quants), ("gen_of_q", &self.gen_of_q), ("use_insts", &self.use_insts), ("subst", &self.subst), ("csubst", &self.csubst)]);
    }
}

impl ToPod for Lx {
    fn to_pod(&self) -> Pod {
        Pod::record("Lx", vec![("g", self.g.to_pod()), ("tys", self.tys.to_pod()), ("apps", self.apps.to_pod()), ("binders", self.binders.to_pod()), ("impls", self.impls.to_pod()), ("file", self.file.to_pod()), ("home", self.home.to_pod()), ("site", self.site.to_pod()), ("rs_mods", self.rs_mods.to_pod()), ("rs_names", self.rs_names.to_pod()), ("layouts", self.layouts.to_pod()), ("unbs", self.unbs.to_pod()), ("notes", self.notes.to_pod()), ("globals", self.globals.to_pod()), ("in_node", self.in_node.to_pod()), ("unshrunk", self.unshrunk.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("quants", self.quants.to_pod()), ("gen_of_q", self.gen_of_q.to_pod()), ("use_insts", self.use_insts.to_pod()), ("subst", self.subst.to_pod()), ("csubst", self.csubst.to_pod())])
    }
}

impl FromPod for Lx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lx { g: FromPod::from_pod(field(p, "g")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, file: FromPod::from_pod(field(p, "file")?)?, home: FromPod::from_pod(field(p, "home")?)?, site: FromPod::from_pod(field(p, "site")?)?, rs_mods: FromPod::from_pod(field(p, "rs_mods")?)?, rs_names: FromPod::from_pod(field(p, "rs_names")?)?, layouts: FromPod::from_pod(field(p, "layouts")?)?, unbs: FromPod::from_pod(field(p, "unbs")?)?, notes: FromPod::from_pod(field(p, "notes")?)?, globals: FromPod::from_pod(field(p, "globals")?)?, in_node: FromPod::from_pod(field(p, "in_node")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, quants: FromPod::from_pod(field(p, "quants")?)?, gen_of_q: FromPod::from_pod(field(p, "gen_of_q")?)?, use_insts: FromPod::from_pod(field(p, "use_insts")?)?, subst: FromPod::from_pod(field(p, "subst")?)?, csubst: FromPod::from_pod(field(p, "csubst")?)? })
    }
}

/// `PatOut`:
///
/// ```prism
/// type PatOut = record:
/// ```
#[derive(Clone)]
pub struct PatOut {
    pub pa: crate::lower::model::Pa,
    pub conds: Array<crate::lower::model::Cc>,
    pub binds: Array<(Text, Bn)>,
}

/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
#[derive(Clone)]
pub enum Vl {
    VlPlace(crate::lower::model::Ex, Holding, crate::lower::model::OutTy),
    VlOwned(crate::lower::model::Ex, crate::lower::model::OutTy),
}

impl ToPod for Vl {
    fn to_pod(&self) -> Pod {
        match self {
            Vl::VlPlace(a0, a1, a2) => Pod::Choice("VlPlace".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            Vl::VlOwned(a0, a1) => Pod::Choice("VlOwned".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for Vl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "VlPlace" && a.len() == 3 => Ok(Vl::VlPlace(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "VlOwned" && a.len() == 2 => Ok(Vl::VlOwned(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a Vl", other),
        }
    }
}

/// ```prism
/// PlaceKey: fn Lx, Range -> Text
/// ```
pub fn place_key(lx: &Lx, r: &crate::syntax::Range) -> Text {
    Text::from(format!("{}:{}:{}", &lx.file, &r.start, &r.end))
}

/// ```prism
/// TypeAt: fn Lx, Range -> Ty
/// ```
pub fn type_at(lx: &Lx, r: &crate::syntax::Range) -> crate::check::types::Ty {
    subst_ty(lx, &or(&get(&lx.tys, &place_key(lx, r)), &crate::check::types::Ty::TyErr))
}

/// ```prism
/// BinderTy: fn Lx, Range -> Ty
/// ```
pub fn binder_ty(lx: &Lx, r: &crate::syntax::Range) -> crate::check::types::Ty {
    match get(&lx.binders, &place_key(lx, r)) {
        Some(t) => subst_ty(lx, &t),
        None => type_at(lx, r),
    }
}

/// ```prism
/// SubstTy: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty(lx: &Lx, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    if (&len(&keys(&lx.subst)) == &Nat::from(0u32)) && (&len(&keys(&lx.csubst)) == &Nat::from(0u32)) {
        t.clone()
    } else {
        subst_ty_in(lx, t)
    }
}

/// ```prism
/// SubstTyIn: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_in(lx: &Lx, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyFlex(n) => or(&get(&lx.subst, &Text::from(format!("'{}", n))), t),
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), each(args, &(|a: &crate::check::types::Ty| subst_ty_in(lx, a)))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(inst_col(lx, c), each(ps, &(|p_: &crate::check::types::Ty| subst_ty_in(lx, p_))), Rc::new(subst_ty_in(lx, &**res))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(each(ts, &(|a: &crate::check::types::Ty| subst_ty_in(lx, a)))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(subst_ty_in(lx, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(subst_ty_in(lx, &**k)), Rc::new(subst_ty_in(lx, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_ty_in(lx, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(subst_ty_in(lx, &**i)), rw.clone()),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_ty_in(lx, &**o))),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_ty_in(lx, &**a))),
        other => other.clone(),
    }
}

/// ```prism
/// InstCol: fn Lx, Col -> Col
/// ```
pub fn inst_col(lx: &Lx, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(q) => or(&get(&lx.csubst, q), &crate::check::types::Col::CQ(q.clone())),
        c => c.clone(),
    }
}

/// ```prism
/// IsQuantCol: fn Lx, Col -> Bool
/// ```
pub fn is_quant_col(lx: &Lx, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CQ(q) => crate::check::env::has_key(&lx.quants, q),
        c => false,
    }
}

/// ```prism
/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub fn typed_tables(tp: &crate::check::typed::TProgram) -> (Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>) {
    let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::TyNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
    let apps = fold(&tp.apps, &Map::new(), &(|m: &Map<Text, crate::check::typed::AppNote>, n: &crate::check::typed::AppNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let bs = fold(&tp.binders, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::BinderNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
    let ims = fold(&tp.impls, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::ImplNote>>, n: &crate::check::typed::ImplNote| insert(m, &crate::check::typed::at_key(&n.at), &push(&or(&get(m, &crate::check::typed::at_key(&n.at)), &Array::new()), n))));
    (tys.clone(), apps.clone(), bs.clone(), ims.clone())
}

/// ```prism
/// let rustKeywords
/// ```
pub fn rust_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")])
}

/// ```prism
/// Base: fn Text -> Text
/// ```
pub fn base(name: &Text) -> Text {
    crate::syntax::lexer::drop_prefix(name, &crate::check::types::marks_of(name))
}

/// ```prism
/// Snake: fn Text -> Text
/// ```
pub fn snake(name: &Text) -> Text {
    let (out, _) = crate::syntax::lexer::fold_chars(&base(name), &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc, prev) = p0;
        let c = p1;
        {
            let sep = if crate::syntax::lexer::is_upper(&c) && (crate::syntax::lexer::is_lower(&prev) || crate::syntax::lexer::is_digit(&prev)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc, &sep, &lower_char(&c))), c.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    let plain = if &out == &Text::lit("") { Text::lit("x") } else { out.clone() };
    if crate::check::types::has_text(&rust_keywords(), &plain) {
        Text::from(format!("{}_", &plain))
    } else {
        plain.clone()
    }
}

/// ```prism
/// LowerChar: fn Text -> Text
/// ```
pub fn lower_char(c: &Text) -> Text {
    if crate::syntax::lexer::is_upper(c) { lower(c) } else { c.clone() }
}

/// ```prism
/// Camel: fn Text -> Text
/// ```
pub fn camel(name: &Text) -> Text {
    let b = base(name);
    let first_ = crate::syntax::lexer::head(&b);
    let fixed = if crate::syntax::lexer::is_lower(&first_) {
        Text::from(format!("{}{}", &upper(&first_), &crate::syntax::lexer::after_first(&b)))
    } else {
        b.clone()
    };
    if (&fixed == &Text::lit("Self")) || crate::check::types::has_text(&runtime_names(), &fixed) {
        Text::from(format!("{}_", &fixed))
    } else {
        fixed.clone()
    }
}

/// ```prism
/// let runtimeNames
/// ```
pub fn runtime_names() -> Array<Text> {
    Array::from(vec![Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")])
}

/// ```prism
/// RustModName: fn Text -> Text
/// ```
pub fn rust_mod_name(m: &Text) -> Text {
    if m == &Text::lit("") {
        Text::lit("program")
    } else {
        crate::syntax::lexer::join(&each(&split(m, &Text::lit(".")), &(|s: &Text| mod_segment(s))), &Text::lit("::"))
    }
}

/// ```prism
/// ModSegment: fn Text -> Text
/// ```
pub fn mod_segment(s: &Text) -> Text {
    let n = snake(s);
    if crate::check::types::has_text(&cpp_keywords(), &n) {
        Text::from(format!("{}_", &n))
    } else {
        n.clone()
    }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")])
}

/// ```prism
/// PathIn: fn Lx, Text, Text -> Text
/// ```
pub fn path_in(lx: &Lx, owner: &Text, name: &Text) -> Text {
    if owner == &lx.site {
        name.clone()
    } else {
        if owner == &Text::lit("Prelude") {
            prelude_path(lx, name)
        } else {
            Text::from(format!("crate::{}::{}", &or(&get(&lx.rs_mods, owner), &rust_mod_name(owner)), name))
        }
    }
}

/// ```prism
/// PreludePath: fn Lx, Text -> Text
/// ```
pub fn prelude_path(lx: &Lx, name: &Text) -> Text {
    if crate::check::env::has_key(&lx.globals, &Text::from(format!("{}.{}", &lx.site, name))) {
        Text::from(format!("crate::prelude::{}", name))
    } else {
        name.clone()
    }
}

/// ```prism
/// ValueNames: fn G -> (Text ==> Text)
/// ```
pub fn value_names(g: &crate::check::env::G) -> Map<Text, Text> {
    let lets = fold(&g.defs, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text(acc, &d.qk),
        _ => acc.clone(),
    }));
    let keys_ = crate::check::types::union_texts(&keys(&g.vals), &lets);
    let bases = fold(&keys_, &Map::new(), &(|m: &Map<Text, Array<Text>>, k: &Text| insert(m, &base_key(k), &push(&or(&get(m, &base_key(k)), &Array::new()), k))));
    fold(&keys_, &Map::new(), &(|m: &Map<Text, Text>, k: &Text| insert(m, k, &value_name(k, &len(&or(&get(&bases, &base_key(k)), &Array::new()))))))
}

/// ```prism
/// GlobalNames: fn G -> (Text ==> Bool)
/// ```
pub fn global_names(g: &crate::check::env::G) -> Map<Text, bool> {
    let names = value_names(g);
    fold(&keys(&names), &Map::new(), &(|m: &Map<Text, bool>, k: &Text| insert(m, &Text::from(format!("{}.{}", &owner_of(k), &or(&get(&names, k), &Text::lit("")))), &true)))
}

/// ```prism
/// LocalName: fn Lx, Text -> Text
/// ```
pub fn local_name(lx: &Lx, nkey: &Text) -> Text {
    let marks = crate::check::types::marks_of(nkey);
    let base_ = snake(nkey);
    let bare = crate::syntax::lexer::drop_prefix(nkey, &marks);
    let s0 = if crate::syntax::lexer::contains(&marks, &Text::lit("?")) {
        Text::from(format!("{}_opt", &base_))
    } else {
        if crate::syntax::lexer::contains(&marks, &Text::lit("~")) {
            Text::from(format!("{}_try", &base_))
        } else {
            base_.clone()
        }
    };
    let s1 = if crate::check::env::is_upper_text(&crate::syntax::lexer::head(&bare)) {
        Text::from(format!("{}_fn", &s0))
    } else {
        s0.clone()
    };
    if crate::check::env::has_key(&lx.globals, &Text::from(format!("{}.{}", &lx.site, &s1))) || crate::check::env::has_key(&lx.globals, &Text::from(format!("Prelude.{}", &s1))) {
        Text::from(format!("{}_", &s1))
    } else {
        s1.clone()
    }
}

/// ```prism
/// BaseKey: fn Text -> Text
/// ```
pub fn base_key(k: &Text) -> Text {
    let parts = split(k, &Text::lit("."));
    let last = or(&crate::syntax::lexer::last(&parts), k);
    Text::from(format!("{}.{}", &crate::syntax::lexer::join(&take(&parts, &crate::syntax::lexer::dec(&len(&parts))), &Text::lit(".")), &snake(&last)))
}

/// ```prism
/// ValueName: fn Text, Nat -> Text
/// ```
pub fn value_name(k: &Text, count: &Nat) -> Text {
    let last = crate::check::types::bare_name(k);
    let marks = crate::check::types::marks_of(&last);
    let base_ = snake(&last);
    if (count > &Nat::from(1u32)) && (&marks != &Text::lit("")) {
        Text::from(format!("{}_{}", &base_, &sigil_word(&crate::syntax::lexer::head(&marks))))
    } else {
        if (count > &Nat::from(1u32)) && !crate::check::env::is_upper_text(&crate::syntax::lexer::head(&last)) {
            Text::from(format!("{}_value", &base_))
        } else {
            base_.clone()
        }
    }
}

/// ```prism
/// SigilWord: fn Text -> Text
/// ```
pub fn sigil_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("?")) => Text::lit("opt"),
        c1_0 if (c1_0 == &Text::lit("~")) => Text::lit("try"),
        c2_0 if (c2_0 == &Text::lit("!")) => Text::lit("ev"),
        c3_0 if (c3_0 == &Text::lit("$")) => Text::lit("dyn"),
        c4_0 if (c4_0 == &Text::lit("@")) => Text::lit("widget"),
        c5_0 if (c5_0 == &Text::lit("&")) => Text::lit("ref"),
        other => Text::lit("x"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ValuePath: fn Lx, Text -> Text
/// ```
pub fn value_path(lx: &Lx, qk: &Text) -> Text {
    let owner = match get(&lx.g.vals, qk) {
        Some(v_) => v_.home.clone(),
        None => owner_of(qk),
    };
    path_in(lx, &owner, &or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk))))
}

/// ```prism
/// OwnerOf: fn Text -> Text
/// ```
pub fn owner_of(qk: &Text) -> Text {
    let parts = split(qk, &Text::lit("."));
    crate::syntax::lexer::join(&take(&parts, &crate::syntax::lexer::dec(&len(&parts))), &Text::lit("."))
}

/// ```prism
/// TagStruct: fn Text -> Text
/// ```
pub fn tag_struct(tn: &Text) -> Text {
    concat(&each(&split(tn, &Text::lit(".")), &(|p_: &Text| camel(p_))))
}

/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub fn out_ty_of(lx: &Lx, t: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    'm14301: {
        if let crate::check::types::Ty::TyCon(m14301_0_0, m14301_0_1) = t && (m14301_0_0 == &Text::lit("Nat")) && (m14301_0_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutNat;
        }
        if let crate::check::types::Ty::TyCon(m14301_1_0, m14301_1_1) = t && (m14301_1_0 == &Text::lit("Int")) && (m14301_1_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutInt;
        }
        if let crate::check::types::Ty::TyCon(m14301_2_0, m14301_2_1) = t && (m14301_2_0 == &Text::lit("U8")) && (m14301_2_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutU8;
        }
        if let crate::check::types::Ty::TyCon(m14301_3_0, m14301_3_1) = t && (m14301_3_0 == &Text::lit("Float")) && (m14301_3_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutFloat;
        }
        if let crate::check::types::Ty::TyCon(m14301_4_0, m14301_4_1) = t && (m14301_4_0 == &Text::lit("Bool")) && (m14301_4_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutBool;
        }
        if let crate::check::types::Ty::TyCon(m14301_5_0, m14301_5_1) = t && (m14301_5_0 == &Text::lit("Char")) && (m14301_5_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutChar;
        }
        if let crate::check::types::Ty::TyCon(m14301_6_0, m14301_6_1) = t && (m14301_6_0 == &Text::lit("Text")) && (m14301_6_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutText;
        }
        if let crate::check::types::Ty::TyCon(m14301_7_0, m14301_7_1) = t && (m14301_7_0 == &Text::lit("unit")) && (m14301_7_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyCon(m14301_8_0, m14301_8_1) = t && (m14301_8_0 == &Text::lit("Path")) && (m14301_8_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutPath;
        }
        if let crate::check::types::Ty::TyCon(m14301_9_0, m14301_9_1) = t && (m14301_9_0 == &Text::lit("Cursor")) && (m14301_9_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutCursor;
        }
        if let crate::check::types::Ty::TyCon(m14301_10_0, m14301_10_1) = t && (m14301_10_0 == &Text::lit("Duration")) && (m14301_10_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutDuration;
        }
        if let crate::check::types::Ty::TyCon(m14301_11_0, m14301_11_1) = t && (m14301_11_0 == &Text::lit("Prelude.Error")) && (m14301_11_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutError;
        }
        if let crate::check::types::Ty::TyCon(m14301_12_0, m14301_12_1) = t && (m14301_12_0 == &Text::lit("\0Self")) && (m14301_12_1.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new());
        }
        if let crate::check::types::Ty::TyCon(m14301_13_0, m14301_13_1) = t && (m14301_13_0 == &Text::lit("Buffer")) && (m14301_13_1.len() == 1) && let Some(a) = index(m14301_13_1, &Nat::from(0u32)) {
            break 'm14301 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx, &a)));
        }
        if let crate::check::types::Ty::TyCon(m14301_14_0, m14301_14_1) = t && (m14301_14_0 == &Text::lit("Table")) && (m14301_14_1.len() == 2) && let Some(k) = index(m14301_14_1, &Nat::from(0u32)) && let Some(v_) = index(m14301_14_1, &Nat::from(1u32)) {
            break 'm14301 crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of(lx, &k), out_ty_of(lx, &v_)]))));
        }
        if let crate::check::types::Ty::TyCon(m14301_15_0, m14301_15_1) = t && (m14301_15_0 == &Text::lit("\0Event")) && (m14301_15_1.len() == 1) && let Some(a) = index(m14301_15_1, &Nat::from(0u32)) {
            break 'm14301 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx, &a)));
        }
        if let crate::check::types::Ty::TyCon(n, args) = t {
            break 'm14301 named_ty(lx, n, &run_to_end(each_job(args.clone(), {
                let lx = lx.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyFn(c, ps, res) = t {
            break 'm14301 {
                let c2 = inst_col(lx, c);
                if &c2 == &crate::check::types::Col::CBound {
                    crate::lower::model::OutTy::OutFn(run_to_end(each_job(ps.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let p_ = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    })), Rc::new(out_ty_of(lx, &**res)))
                } else {
                    if is_quant_col(lx, &c2) {
                        crate::lower::model::OutTy::OutQuantified(or(&get(&lx.quants, &col_name(&c2)), &Text::lit("")))
                    } else {
                        crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params(lx, &each(ps, &(|p_: &crate::check::types::Ty| job_param(p_))))), Rc::new(out_ty_of(lx, &**res)))
                    }
                }
            };
        }
        if let crate::check::types::Ty::TyTuple(m14301_18_0) = t && (m14301_18_0.len() == 0) {
            break 'm14301 crate::lower::model::OutTy::OutUnit;
        }
        if let crate::check::types::Ty::TyTuple(ts) = t {
            break 'm14301 crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ts.clone(), {
                let lx = lx.clone();
                Rc::new(move |p0: crate::check::types::Ty| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
            })));
        }
        if let crate::check::types::Ty::TyArray(e) = t {
            break 'm14301 crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of(lx, &**e)));
        }
        if let crate::check::types::Ty::TyMap(k, v_) = t {
            break 'm14301 crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of(lx, &**k)), Rc::new(out_ty_of(lx, &**v_)));
        }
        if let crate::check::types::Ty::TySig(m14301_22_0, i) = t && (m14301_22_0 == &Text::lit("?")) {
            break 'm14301 crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m14301_23_0, i) = t && (m14301_23_0 == &Text::lit("~")) {
            break 'm14301 crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m14301_24_0, i) = t && (m14301_24_0 == &Text::lit("!")) {
            break 'm14301 crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m14301_25_0, i) = t && (m14301_25_0 == &Text::lit("$")) {
            break 'm14301 crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of(lx, &**i)));
        }
        if let crate::check::types::Ty::TySig(m14301_26_0, i) = t && (m14301_26_0 == &Text::lit("&")) {
            break 'm14301 out_ty_of(lx, &**i);
        }
        if let crate::check::types::Ty::TySig(_, i) = t {
            break 'm14301 out_ty_of(lx, &**i);
        }
        if let crate::check::types::Ty::TyQ(n) = t {
            break 'm14301 crate::lower::model::OutTy::OutGen(camel(n));
        }
        if let crate::check::types::Ty::TyRigid(n) = t {
            break 'm14301 crate::lower::model::OutTy::OutGen(camel(n));
        }
        if let crate::check::types::Ty::TyFlex(n) = t {
            break 'm14301 match get(&lx.subst, &Text::from(format!("'{}", n))) {
                Some(x) => out_ty_of(lx, &x),
                None => match get(&lx.quants, &Text::from(format!("'{}", n))) {
                    Some(b) => crate::lower::model::OutTy::OutQuantified(b.clone()),
                    None => crate::lower::model::OutTy::OutUnit,
                },
            };
        }
        if let crate::check::types::Ty::TyAny(_) = t {
            break 'm14301 crate::lower::model::OutTy::OutShowAny;
        }
        if let crate::check::types::Ty::TyElem(_, _) = t {
            break 'm14301 crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())));
        }
        if let crate::check::types::Ty::TyElemAny(_) = t {
            break 'm14301 crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new());
        }
        if let crate::check::types::Ty::TyAt(i, _) = t {
            break 'm14301 blueprint_ty();
        }
        if let crate::check::types::Ty::TyAssoc(_, _) = t {
            break 'm14301 crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type"));
        }
        if let crate::check::types::Ty::TyErr = t {
            break 'm14301 crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find"));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `OutTyOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OutTyOf: unbounded fn Lx, Ty -> OutTy
/// ```
pub struct OutTyOf {
    pub lx: Lx,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for OutTyOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let t = &self.t;
        'm14301: {
            if let crate::check::types::Ty::TyCon(m14301_0_0, m14301_0_1) = t && (m14301_0_0 == &Text::lit("Nat")) && (m14301_0_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNat);
            }
            if let crate::check::types::Ty::TyCon(m14301_1_0, m14301_1_1) = t && (m14301_1_0 == &Text::lit("Int")) && (m14301_1_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutInt);
            }
            if let crate::check::types::Ty::TyCon(m14301_2_0, m14301_2_1) = t && (m14301_2_0 == &Text::lit("U8")) && (m14301_2_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutU8);
            }
            if let crate::check::types::Ty::TyCon(m14301_3_0, m14301_3_1) = t && (m14301_3_0 == &Text::lit("Float")) && (m14301_3_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFloat);
            }
            if let crate::check::types::Ty::TyCon(m14301_4_0, m14301_4_1) = t && (m14301_4_0 == &Text::lit("Bool")) && (m14301_4_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutBool);
            }
            if let crate::check::types::Ty::TyCon(m14301_5_0, m14301_5_1) = t && (m14301_5_0 == &Text::lit("Char")) && (m14301_5_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutChar);
            }
            if let crate::check::types::Ty::TyCon(m14301_6_0, m14301_6_1) = t && (m14301_6_0 == &Text::lit("Text")) && (m14301_6_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutText);
            }
            if let crate::check::types::Ty::TyCon(m14301_7_0, m14301_7_1) = t && (m14301_7_0 == &Text::lit("unit")) && (m14301_7_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyCon(m14301_8_0, m14301_8_1) = t && (m14301_8_0 == &Text::lit("Path")) && (m14301_8_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPath);
            }
            if let crate::check::types::Ty::TyCon(m14301_9_0, m14301_9_1) = t && (m14301_9_0 == &Text::lit("Cursor")) && (m14301_9_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutCursor);
            }
            if let crate::check::types::Ty::TyCon(m14301_10_0, m14301_10_1) = t && (m14301_10_0 == &Text::lit("Duration")) && (m14301_10_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDuration);
            }
            if let crate::check::types::Ty::TyCon(m14301_11_0, m14301_11_1) = t && (m14301_11_0 == &Text::lit("Prelude.Error")) && (m14301_11_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutError);
            }
            if let crate::check::types::Ty::TyCon(m14301_12_0, m14301_12_1) = t && (m14301_12_0 == &Text::lit("\0Self")) && (m14301_12_1.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("Self"), Array::new()));
            }
            if let crate::check::types::Ty::TyCon(m14301_13_0, m14301_13_1) = t && (m14301_13_0 == &Text::lit("Buffer")) && (m14301_13_1.len() == 1) && let Some(a) = index(m14301_13_1, &Nat::from(0u32)) {
                break 'm14301 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), a.clone()), move |out_ty_of_14798: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_14798))))
                };
            }
            if let crate::check::types::Ty::TyCon(m14301_14_0, m14301_14_1) = t && (m14301_14_0 == &Text::lit("Table")) && (m14301_14_1.len() == 2) && let Some(k) = index(m14301_14_1, &Nat::from(0u32)) && let Some(v_) = index(m14301_14_1, &Nat::from(1u32)) {
                break 'm14301 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), k.clone()), move |out_ty_of_14864: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_14881: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(crate::lower::model::OutTy::OutTuple(Array::from(vec![out_ty_of_14864, out_ty_of_14881])))))))
                };
            }
            if let crate::check::types::Ty::TyCon(m14301_15_0, m14301_15_1) = t && (m14301_15_0 == &Text::lit("\0Event")) && (m14301_15_1.len() == 1) && let Some(a) = index(m14301_15_1, &Nat::from(0u32)) {
                break 'm14301 {
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), a.clone()), move |out_ty_of_14940: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_14940))))
                };
            }
            if let crate::check::types::Ty::TyCon(n, args) = t {
                break 'm14301 {
                    let args = args.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_value(each_job(args.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_14990: Array<crate::lower::model::OutTy>| prism_rtl::Turn::More(Rc::new(NamedTy { lx: lx.clone(), n: n.clone(), args: each_14990 })))
                };
            }
            if let crate::check::types::Ty::TyFn(c, ps, res) = t {
                break 'm14301 {
                    let c2 = inst_col(lx, c);
                    if &c2 == &crate::check::types::Col::CBound {
                        {
                            let lx = lx.clone();
                            let ps = ps.clone();
                            let res = (**res).clone();
                            call_value(each_job(ps.clone(), {
                                let lx = lx.clone();
                                Rc::new(move |p0: crate::check::types::Ty| {
                                    let lx = lx.clone();
                                    entered(once_job(move || {
                                        let p_ = p0;
                                        prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                            }), move |each_15271: Array<crate::lower::model::OutTy>| call_then(start_out_ty_of(lx.clone(), res.clone()), move |out_ty_of_15302: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutFn(each_15271, Rc::new(out_ty_of_15302)))))
                        }
                    } else {
                        if is_quant_col(lx, &c2) {
                            prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(or(&get(&lx.quants, &col_name(&c2)), &Text::lit(""))))
                        } else {
                            {
                                let lx = lx.clone();
                                let ps = ps.clone();
                                let res = (**res).clone();
                                call_then(start_rust_ty_of_params(lx.clone(), each(&ps, &(|p_: &crate::check::types::Ty| job_param(p_)))), move |rust_ty_of_params_15424: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), res.clone()), move |out_ty_of_15473: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params_15424), Rc::new(out_ty_of_15473)))))
                            }
                        }
                    }
                };
            }
            if let crate::check::types::Ty::TyTuple(m14301_18_0) = t && (m14301_18_0.len() == 0) {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit);
            }
            if let crate::check::types::Ty::TyTuple(ts) = t {
                break 'm14301 {
                    let lx = lx.clone();
                    let ts = ts.clone();
                    call_value(each_job(ts.clone(), {
                        let lx = lx.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                    }), move |each_15542: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_15542)))
                };
            }
            if let crate::check::types::Ty::TyArray(e) = t {
                break 'm14301 {
                    let e = (**e).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), e.clone()), move |out_ty_of_15596: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutArray(Rc::new(out_ty_of_15596))))
                };
            }
            if let crate::check::types::Ty::TyMap(k, v_) = t {
                break 'm14301 {
                    let k = (**k).clone();
                    let lx = lx.clone();
                    let v_ = (**v_).clone();
                    call_then(start_out_ty_of(lx.clone(), k.clone()), move |out_ty_of_15635: crate::lower::model::OutTy| call_then(start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_15652: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutMap(Rc::new(out_ty_of_15635), Rc::new(out_ty_of_15652)))))
                };
            }
            if let crate::check::types::Ty::TySig(m14301_22_0, i) = t && (m14301_22_0 == &Text::lit("?")) {
                break 'm14301 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_15693: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutOpt(Rc::new(out_ty_of_15693))))
                };
            }
            if let crate::check::types::Ty::TySig(m14301_23_0, i) = t && (m14301_23_0 == &Text::lit("~")) {
                break 'm14301 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_15734: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRes(Rc::new(out_ty_of_15734))))
                };
            }
            if let crate::check::types::Ty::TySig(m14301_24_0, i) = t && (m14301_24_0 == &Text::lit("!")) {
                break 'm14301 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_15777: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_15777))))
                };
            }
            if let crate::check::types::Ty::TySig(m14301_25_0, i) = t && (m14301_25_0 == &Text::lit("$")) {
                break 'm14301 {
                    let i = (**i).clone();
                    let lx = lx.clone();
                    call_then(start_out_ty_of(lx.clone(), i.clone()), move |out_ty_of_15818: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_15818))))
                };
            }
            if let crate::check::types::Ty::TySig(m14301_26_0, i) = t && (m14301_26_0 == &Text::lit("&")) {
                break 'm14301 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: (**i).clone() }));
            }
            if let crate::check::types::Ty::TySig(_, i) = t {
                break 'm14301 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: (**i).clone() }));
            }
            if let crate::check::types::Ty::TyQ(n) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(camel(n)));
            }
            if let crate::check::types::Ty::TyRigid(n) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutGen(camel(n)));
            }
            if let crate::check::types::Ty::TyFlex(n) = t {
                break 'm14301 match get(&lx.subst, &Text::from(format!("'{}", n))) {
                    Some(x) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: x.clone() })),
                    None => match get(&lx.quants, &Text::from(format!("'{}", n))) {
                        Some(b) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutQuantified(b.clone())),
                        None => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
                    },
                };
            }
            if let crate::check::types::Ty::TyAny(_) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutShowAny);
            }
            if let crate::check::types::Ty::TyElem(_, _) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutLive(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()))));
            }
            if let crate::check::types::Ty::TyElemAny(_) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()));
            }
            if let crate::check::types::Ty::TyAt(i, _) = t {
                break 'm14301 prism_rtl::Turn::Finished(blueprint_ty());
            }
            if let crate::check::types::Ty::TyAssoc(_, _) = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("an associated type")));
            }
            if let crate::check::types::Ty::TyErr = t {
                break 'm14301 prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnknown(Text::lit("a type the checker did not find")));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start OutTyOf, x`: what the function value is when passed to `@Run`.
pub fn start_out_ty_of(lx: Lx, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(OutTyOf { lx, t })
}

/// ```prism
/// let blueprintTy
/// ```
pub fn blueprint_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Blueprint"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))
}

/// ```prism
/// let elemTy
/// ```
pub fn elem_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new())
}

/// ```prism
/// let answerTy
/// ```
pub fn answer_ty_value() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())
}

/// ```prism
/// let hostOfTy
/// ```
pub fn host_of_ty() -> crate::lower::model::OutTy {
    crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::HostOf"), Array::from(vec![crate::lower::model::OutTy::OutNamed(Text::lit("crate::Elem"), Array::new()), crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new())]))))
}

/// ```prism
/// HasBlueprint: fn Ty -> Bool
/// ```
pub fn has_blueprint(t: &crate::check::types::Ty) -> bool {
    match t {
        crate::check::types::Ty::TyAt(_, _) => true,
        crate::check::types::Ty::TySig(_, i) => has_blueprint(&**i),
        _ => false,
    }
}

/// ```prism
/// EventParam: fn Ty -> Ty
/// ```
pub fn event_param(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TySig(m17324_0_0, i) if (m17324_0_0 == &Text::lit("!")) => crate::check::types::Ty::TyCon(Text::lit("\0Event"), Array::from(vec![peel(&**i)])),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// JobParam: fn Ty -> Ty
/// ```
pub fn job_param(ty0: &crate::check::types::Ty) -> crate::check::types::Ty {
    match ty0 {
        crate::check::types::Ty::TyFn(_, ps, r) => crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, ps.clone(), Rc::new((**r).clone())),
        t => t.clone(),
    }
}

/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub fn rust_ty_of_params(lx: &Lx, ps: &Array<crate::check::types::Ty>) -> crate::lower::model::OutTy {
    'm17887: {
        if let m17887_0 = ps && (m17887_0.len() == 1) && let Some(p_) = index(m17887_0, &Nat::from(0u32)) {
            break 'm17887 out_ty_of(lx, &p_);
        }
        crate::lower::model::OutTy::OutTuple(run_to_end(each_job(ps.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        })))
    }
}

/// The step machine of `RustTyOfParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTyOfParams: unbounded fn Lx, [Ty] -> OutTy
/// ```
pub struct RustTyOfParams {
    pub lx: Lx,
    pub ps: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for RustTyOfParams {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let ps = &self.ps;
        'm17887: {
            if let m17887_0 = ps && (m17887_0.len() == 1) && let Some(p_) = index(m17887_0, &Nat::from(0u32)) {
                break 'm17887 prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }));
            }
            {
                let lx = lx.clone();
                let ps = ps.clone();
                call_value(each_job(ps.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let p_ = p0;
                            prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: p_.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
                }), move |each_17947: Array<crate::lower::model::OutTy>| prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutTuple(each_17947)))
            }
        }
    }
}

/// `Start RustTyOfParams, x`: what the function value is when passed to `@Run`.
pub fn start_rust_ty_of_params(lx: Lx, ps: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(RustTyOfParams { lx, ps })
}

/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub fn named_ty(lx: &Lx, n: &Text, args: &Array<crate::lower::model::OutTy>) -> crate::lower::model::OutTy {
    match get(&lx.g.types, n) {
        Some(ti) => match &ti.body {
            crate::check::env::TyBody::BAlias(a) => out_ty_of(lx, a),
            crate::check::env::TyBody::BRowKind => if n == &Text::lit("Prelude.Fault") {
                crate::lower::model::OutTy::OutPod
            } else {
                crate::lower::model::OutTy::OutNamed(path_in(lx, &ti.home, &camel(&crate::check::types::bare_name(n))), Array::new())
            },
            _ => crate::lower::model::OutTy::OutNamed(path_in(lx, &ti.home, &camel(&crate::check::types::bare_name(n))), args.clone()),
        },
        None => if crate::check::env::has_key(&lx.g.families, n) {
            crate::lower::model::OutTy::OutPod
        } else {
            crate::lower::model::OutTy::OutNamed(camel(&crate::check::types::bare_name(n)), args.clone())
        },
    }
}

/// The step machine of `NamedTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedTy: unbounded fn Lx, Text, [OutTy] -> OutTy
/// ```
pub struct NamedTy {
    pub lx: Lx,
    pub n: Text,
    pub args: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for NamedTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let n = &self.n;
        let args = &self.args;
        match get(&lx.g.types, n) {
            Some(ti) => match &ti.body {
                crate::check::env::TyBody::BAlias(a) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: a.clone() })),
                crate::check::env::TyBody::BRowKind => if n == &Text::lit("Prelude.Fault") {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(path_in(lx, &ti.home, &camel(&crate::check::types::bare_name(n))), Array::new()))
                },
                _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(path_in(lx, &ti.home, &camel(&crate::check::types::bare_name(n))), args.clone())),
            },
            None => if crate::check::env::has_key(&lx.g.families, n) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod)
            } else {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutNamed(camel(&crate::check::types::bare_name(n)), args.clone()))
            },
        }
    }
}

/// `Start NamedTy, x`: what the function value is when passed to `@Run`.
pub fn start_named_ty(lx: Lx, n: Text, args: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(NamedTy { lx, n, args })
}

/// ```prism
/// Peel: fn Ty -> Ty
/// ```
pub fn peel(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TySig(m18685_0_0, i) if (m18685_0_0 == &Text::lit("$")) => peel(&**i),
        crate::check::types::Ty::TySig(m18685_1_0, i) if (m18685_1_0 == &Text::lit("!")) => peel(&**i),
        crate::check::types::Ty::TySig(m18685_2_0, i) if (m18685_2_0 == &Text::lit("&")) => peel(&**i),
        _ => t.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// OutOf: fn Ty -> Ty
/// ```
pub fn out_of(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyAt(i, _) => peel(&**i),
        _ => peel(t),
    }
}

/// ```prism
/// LayerOf: fn Ty -> Layer
/// ```
pub fn layer_of(t: &crate::check::types::Ty) -> Layer {
    match t {
        crate::check::types::Ty::TySig(m19201_0_0, _) if (m19201_0_0 == &Text::lit("$")) => Layer::LyDyn,
        crate::check::types::Ty::TySig(m19201_1_0, _) if (m19201_1_0 == &Text::lit("!")) => Layer::LyEv,
        crate::check::types::Ty::TySig(m19201_2_0, i) if (m19201_2_0 == &Text::lit("&")) => layer_of(&**i),
        crate::check::types::Ty::TyAt(_, _) => Layer::LyBlueprint,
        _ => Layer::LyPlain,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub fn layouts(g: &crate::check::env::G) -> Map<Text, Array<bool>> {
    run_to_end(fold_job(values(&g.ctors), Map::new(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
            let g = g.clone();
            entered(once_job(move || {
                let m = p0;
                let c = p1;
                call_value(each_job(c.args.clone(), {
                    let g = g.clone();
                    let c = c.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let g = g.clone();
                        let c = c.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: c.owner.clone(), seen: Array::new() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |each_19709: Array<bool>| prism_rtl::Turn::Finished(insert(&m, &c.name, &each_19709)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
    }))
}

/// The step machine of `Layouts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Layouts: unbounded fn G -> (Text ==> [Bool])
/// ```
pub struct Layouts {
    pub g: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, Array<bool>>> for Layouts {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<bool>>> {
        let g = &self.g;
        fold_job(values(&g.ctors), Map::new(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<bool>>, crate::check::env::CtorInfo)| {
                let g = g.clone();
                entered(once_job(move || {
                    let m = p0;
                    let c = p1;
                    call_value(each_job(c.args.clone(), {
                        let g = g.clone();
                        let c = c.clone();
                        Rc::new(move |p0: crate::check::types::Ty| {
                            let g = g.clone();
                            let c = c.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: c.owner.clone(), seen: Array::new() }))
                            }))
                        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |each_19709: Array<bool>| prism_rtl::Turn::Finished(insert(&m, &c.name, &each_19709)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<bool>>, crate::check::env::CtorInfo)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>>>
        }).cycle()
    }
}

/// `Start Layouts, x`: what the function value is when passed to `@Run`.
pub fn start_layouts(g: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, Array<bool>>>> {
    Rc::new(Layouts { g })
}

/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub fn reaches(g: &crate::check::env::G, t: &crate::check::types::Ty, target: &Text, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyCon(n, args) => if n == target {
            true
        } else {
            if crate::check::types::has_text(seen, n) {
                false
            } else {
                if run_to_end(fold_job(args.clone(), false, {
                    let g = g.clone();
                    let target = target.clone();
                    let seen = seen.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g = g.clone();
                        let target = target.clone();
                        let seen = seen.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                })) {
                    true
                } else {
                    match get(&g.types, n) {
                        Some(ti) => match &ti.body {
                            crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), false, {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                    let g = g.clone();
                                    let target = target.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        let (_, ft) = p1;
                                        prism_rtl::Turn::Finished(f || reaches(&g, &ft, &target, &push(&seen, &n)))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), false, {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                    let g = g.clone();
                                    let target = target.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    entered(once_job(move || {
                                        let f = p0;
                                        let (_, ats) = p1;
                                        prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                let g = g.clone();
                                                let target = target.clone();
                                                let seen = seen.clone();
                                                let n = n.clone();
                                                entered(once_job(move || {
                                                    let f2 = p0;
                                                    let at_ = p1;
                                                    prism_rtl::Turn::Finished(f2 || reaches(&g, &at_, &target, &push(&seen, &n)))
                                                }))
                                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                        })))
                                    }))
                                }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                            })),
                            crate::check::env::TyBody::BAlias(a) => reaches(g, a, target, &push(seen, n)),
                            _ => false,
                        },
                        None => false,
                    }
                }
            }
        },
        crate::check::types::Ty::TySig(m19839_1_0, i) if (m19839_1_0 == &Text::lit("?")) => reaches(g, &**i, target, seen),
        crate::check::types::Ty::TySig(m19839_2_0, i) if (m19839_2_0 == &Text::lit("~")) => reaches(g, &**i, target, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let g = g.clone();
            let target = target.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let target = target.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Reaches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Reaches: unbounded fn G, Ty, Text, [Text] -> Bool
/// ```
pub struct Reaches {
    pub g: crate::check::env::G,
    pub t: crate::check::types::Ty,
    pub target: Text,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for Reaches {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let g = &self.g;
        let t = &self.t;
        let target = &self.target;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(n, args) => if n == target {
                prism_rtl::Turn::Finished(true)
            } else {
                if crate::check::types::has_text(seen, n) {
                    prism_rtl::Turn::Finished(false)
                } else {
                    {
                        let args = args.clone();
                        let g = g.clone();
                        let n = n.clone();
                        let seen = seen.clone();
                        let target = target.clone();
                        call_value(fold_job(args.clone(), false, {
                            let g = g.clone();
                            let target = target.clone();
                            let seen = seen.clone();
                            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                let g = g.clone();
                                let target = target.clone();
                                let seen = seen.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let a = p1;
                                    prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                                }))
                            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                        }), move |fold_19953: bool| if fold_19953 {
                            prism_rtl::Turn::Finished(true)
                        } else {
                            match get(&g.types, &n) {
                                Some(ti) => match &ti.body {
                                    crate::check::env::TyBody::BRecord(fs) => fold_job(fs.clone(), false, {
                                        let g = g.clone();
                                        let target = target.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f = p0;
                                                let (_, ft) = p1;
                                                prism_rtl::Turn::Finished(f || reaches(&g, &ft, &target, &push(&seen, &n)))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BChoice(cs) => fold_job(cs.clone(), false, {
                                        let g = g.clone();
                                        let target = target.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                            let g = g.clone();
                                            let target = target.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f = p0;
                                                let (_, ats) = p1;
                                                prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                                    let g = g.clone();
                                                    let target = target.clone();
                                                    let seen = seen.clone();
                                                    let n = n.clone();
                                                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                        let g = g.clone();
                                                        let target = target.clone();
                                                        let seen = seen.clone();
                                                        let n = n.clone();
                                                        entered(once_job(move || {
                                                            let f2 = p0;
                                                            let at_ = p1;
                                                            prism_rtl::Turn::Finished(f2 || reaches(&g, &at_, &target, &push(&seen, &n)))
                                                        }))
                                                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                                })))
                                            }))
                                        }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                    }).cycle(),
                                    crate::check::env::TyBody::BAlias(a) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: a.clone(), target: target.clone(), seen: push(&seen, &n) })),
                                    _ => prism_rtl::Turn::Finished(false),
                                },
                                None => prism_rtl::Turn::Finished(false),
                            }
                        })
                    }
                }
            },
            crate::check::types::Ty::TySig(m19839_1_0, i) if (m19839_1_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: (**i).clone(), target: target.clone(), seen: seen.clone() })),
            crate::check::types::Ty::TySig(m19839_2_0, i) if (m19839_2_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(Reaches { g: g.clone(), t: (**i).clone(), target: target.clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let g = g.clone();
                let target = target.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g = g.clone();
                    let target = target.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(f || reaches(&g, &a, &target, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Reaches, x`: what the function value is when passed to `@Run`.
pub fn start_reaches(g: crate::check::env::G, t: crate::check::types::Ty, target: Text, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Reaches { g, t, target, seen })
}

/// ```prism
/// RcField: fn Lx, Text, Nat -> Bool
/// ```
pub fn rc_field(lx: &Lx, ctor: &Text, i: &Nat) -> bool {
    or(&index(&or(&get(&lx.layouts, ctor), &Array::new()), i), &false)
}

/// ```prism
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
/// ```
pub fn floaty(g: &crate::check::env::G, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyCon(m20943_0_0, m20943_0_1) if (m20943_0_0 == &Text::lit("Float")) && (m20943_0_1.len() == 0) => true,
        crate::check::types::Ty::TyCon(n, args) => if run_to_end(fold_job(args.clone(), false, {
            let g = g.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })) {
            true
        } else {
            if crate::check::types::has_text(seen, n) {
                false
            } else {
                match get(&g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), false, {
                            let g = g.clone();
                            let seen = seen.clone();
                            let n = n.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let g = g.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let (_, ft) = p1;
                                    prism_rtl::Turn::Finished(f || floaty(&g, &ft, &push(&seen, &n)))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), false, {
                            let g = g.clone();
                            let seen = seen.clone();
                            let n = n.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let g = g.clone();
                                let seen = seen.clone();
                                let n = n.clone();
                                entered(once_job(move || {
                                    let f = p0;
                                    let (_, ats) = p1;
                                    prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let g = g.clone();
                                            let seen = seen.clone();
                                            let n = n.clone();
                                            entered(once_job(move || {
                                                let f2 = p0;
                                                let at_ = p1;
                                                prism_rtl::Turn::Finished(f2 || floaty(&g, &at_, &push(&seen, &n)))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        _ => false,
                    },
                    None => false,
                }
            }
        },
        crate::check::types::Ty::TySig(_, i) => floaty(g, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), false, {
            let g = g.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let g = g.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let f = p0;
                    let a = p1;
                    prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => floaty(g, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => floaty(g, &**k, seen) || floaty(g, &**v_, seen),
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Floaty`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Floaty: unbounded fn G, Ty, [Text] -> Bool
/// ```
pub struct Floaty {
    pub g: crate::check::env::G,
    pub t: crate::check::types::Ty,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for Floaty {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let g = &self.g;
        let t = &self.t;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyCon(m20943_0_0, m20943_0_1) if (m20943_0_0 == &Text::lit("Float")) && (m20943_0_1.len() == 0) => prism_rtl::Turn::Finished(true),
            crate::check::types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let g = g.clone();
                let n = n.clone();
                let seen = seen.clone();
                call_value(fold_job(args.clone(), false, {
                    let g = g.clone();
                    let seen = seen.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let g = g.clone();
                        let seen = seen.clone();
                        entered(once_job(move || {
                            let f = p0;
                            let a = p1;
                            prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |fold_21012: bool| if fold_21012 {
                    prism_rtl::Turn::Finished(true)
                } else {
                    if crate::check::types::has_text(&seen, &n) {
                        prism_rtl::Turn::Finished(false)
                    } else {
                        match get(&g.types, &n) {
                            Some(ti) => match &ti.body {
                                crate::check::env::TyBody::BRecord(fs) => fold_job(fs.clone(), false, {
                                    let g = g.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        entered(once_job(move || {
                                            let f = p0;
                                            let (_, ft) = p1;
                                            prism_rtl::Turn::Finished(f || floaty(&g, &ft, &push(&seen, &n)))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle(),
                                crate::check::env::TyBody::BChoice(cs) => fold_job(cs.clone(), false, {
                                    let g = g.clone();
                                    let seen = seen.clone();
                                    let n = n.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let g = g.clone();
                                        let seen = seen.clone();
                                        let n = n.clone();
                                        entered(once_job(move || {
                                            let f = p0;
                                            let (_, ats) = p1;
                                            prism_rtl::Turn::Finished(f || run_to_end(fold_job(ats.clone(), false, {
                                                let g = g.clone();
                                                let seen = seen.clone();
                                                let n = n.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let g = g.clone();
                                                    let seen = seen.clone();
                                                    let n = n.clone();
                                                    entered(once_job(move || {
                                                        let f2 = p0;
                                                        let at_ = p1;
                                                        prism_rtl::Turn::Finished(f2 || floaty(&g, &at_, &push(&seen, &n)))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                }).cycle(),
                                _ => prism_rtl::Turn::Finished(false),
                            },
                            None => prism_rtl::Turn::Finished(false),
                        }
                    }
                })
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(Floaty { g: g.clone(), t: (**i).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), false, {
                let g = g.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let g = g.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let f = p0;
                        let a = p1;
                        prism_rtl::Turn::Finished(f || floaty(&g, &a, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(Floaty { g: g.clone(), t: (**e).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let g = g.clone();
                let k = (**k).clone();
                let seen = seen.clone();
                let v_ = (**v_).clone();
                call_then(start_floaty(g.clone(), k.clone(), seen.clone()), move |floaty_21612: bool| prism_rtl::Turn::Finished(floaty_21612 || floaty(&g, &v_, &seen)))
            },
            _ => prism_rtl::Turn::Finished(false),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Floaty, x`: what the function value is when passed to `@Run`.
pub fn start_floaty(g: crate::check::env::G, t: crate::check::types::Ty, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Floaty { g, t, seen })
}

/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub fn podable(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutFn(_, _) => false,
        crate::lower::model::OutTy::OutJobFn(_, _) => false,
        crate::lower::model::OutTy::OutJob(_) => false,
        crate::lower::model::OutTy::OutEvent(_) => false,
        crate::lower::model::OutTy::OutDyn(_) => false,
        crate::lower::model::OutTy::OutShowAny => false,
        crate::lower::model::OutTy::OutLive(_) => false,
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutGen(_) => true,
        crate::lower::model::OutTy::OutNamed(_, args) => run_to_end(fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok && podable(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutOpt(i) => podable(&**i),
        crate::lower::model::OutTy::OutRes(i) => podable(&**i),
        crate::lower::model::OutTy::OutRc(i) => podable(&**i),
        crate::lower::model::OutTy::OutTuple(ts) => run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok = p0;
            let a = p1;
            prism_rtl::Turn::Finished(ok && podable(&a))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutArray(e) => podable(&**e),
        crate::lower::model::OutTy::OutMap(k, v_) => podable(&**k) && podable(&**v_),
        _ => true,
    }
}

/// The step machine of `Podable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Podable: unbounded fn OutTy -> Bool
/// ```
pub struct Podable {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for Podable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutJob(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutEvent(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutDyn(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutShowAny => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutLive(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(true),
            crate::lower::model::OutTy::OutNamed(_, args) => fold_job(args.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok && podable(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutOpt(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRes(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutRc(i) => prism_rtl::Turn::More(Rc::new(Podable { t: (**i).clone() })),
            crate::lower::model::OutTy::OutTuple(ts) => fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok = p0;
                let a = p1;
                prism_rtl::Turn::Finished(ok && podable(&a))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutArray(e) => prism_rtl::Turn::More(Rc::new(Podable { t: (**e).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_podable(k.clone()), move |podable_22287: bool| prism_rtl::Turn::Finished(podable_22287 && podable(&v_)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start Podable, x`: what the function value is when passed to `@Run`.
pub fn start_podable(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(Podable { t })
}

/// ```prism
/// let emptyEnv
/// ```
pub fn empty_env() -> Env {
    Env { names: Map::new(), spans: Map::new(), uses: Map::new() }
}

/// ```prism
/// NameKeyAt: fn Lx, Env, SName, Range -> Text
/// ```
pub fn name_key_at(lx: &Lx, env: &Env, n: &crate::syntax::SName, span: &crate::syntax::Range) -> Text {
    match get(&lx.use_insts, &place_key(lx, span)) {
        Some(u) => or(&get(&env.uses, &Text::from(format!("{}#{}", &crate::check::env::sname_key(n), &show_text(&inst_at(lx, &u))))), &crate::check::env::sname_key(n)),
        None => crate::check::env::sname_key(n),
    }
}

/// ```prism
/// WithInstances: fn Env, [Text] -> [Text]
/// ```
pub fn with_instances(env: &Env, names: &Array<Text>) -> Array<Text> {
    fold(names, names, &(|acc: &Array<Text>, n: &Text| append(acc, &filter(&keys(&env.names), &(|k: &Text| crate::syntax::lexer::has_prefix(k, &Text::from(format!("{}#inst", n))))))))
}

/// ```prism
/// BindSpan: fn Env, Text, Vl -> Env
/// ```
pub fn bind_span(env: &Env, nkey: &Text, v_: &Vl) -> Env {
    let mut this: Env = env.clone();
    this.spans = insert(&this.spans, nkey, v_);
    this
}

/// ```prism
/// Bind: fn Env, Text, Bn -> Env
/// ```
pub fn bind(env: &Env, name: &Text, b: &Bn) -> Env {
    let mut this: Env = env.clone();
    this.names = insert(&this.names, name, b);
    this
}

/// ```prism
/// ValueTy: fn Vl -> OutTy
/// ```
pub fn value_ty(vl0: &Vl) -> crate::lower::model::OutTy {
    match vl0 {
        Vl::VlPlace(_, _, t) => t.clone(),
        Vl::VlOwned(_, t) => t.clone(),
    }
}

/// ```prism
/// LocalPlace: fn Ex, Holding, OutTy -> Vl
/// ```
pub fn local_place(x: &crate::lower::model::Ex, mode: &Holding, t: &crate::lower::model::OutTy) -> Vl {
    Vl::VlPlace(x.clone(), mode.clone(), t.clone())
}

/// ```prism
/// PlaceStem: fn Ex -> Text
/// ```
pub fn place_stem(x: &crate::lower::model::Ex) -> Text {
    match x {
        crate::lower::model::Ex::XVar(n) => n.clone(),
        crate::lower::model::Ex::XField(_, f) => f.clone(),
        crate::lower::model::Ex::XTarget(y) => place_stem(&**y),
        crate::lower::model::Ex::XPart(y, k) => Text::from(format!("{}_{}", &place_stem(&**y), k)),
        _ => Text::lit("place"),
    }
}

/// ```prism
/// OnSelf: fn Ex -> Bool
/// ```
pub fn on_self(x: &crate::lower::model::Ex) -> bool {
    'm25774: {
        if let crate::lower::model::Ex::XField(m25774_0_0, _) = x && let crate::lower::model::Ex::XSelf = &**m25774_0_0 {
            break 'm25774 true;
        }
        if let crate::lower::model::Ex::XField(y, _) = x {
            break 'm25774 on_self(&**y);
        }
        if let crate::lower::model::Ex::XPart(y, _) = x {
            break 'm25774 on_self(&**y);
        }
        if let crate::lower::model::Ex::XMethod(y, _, _) = x {
            break 'm25774 on_self(&**y);
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm25774 on_self(&**y);
        }
        false
    }
}

/// ```prism
/// ?ThroughParent: fn Ex -> ?Ex
/// ```
pub fn through_parent(x: &crate::lower::model::Ex) -> Option<crate::lower::model::Ex> {
    'm26178: {
        if let crate::lower::model::Ex::XField(m26178_0_0, m26178_0_1) = x && let crate::lower::model::Ex::XSelf = &**m26178_0_0 && (m26178_0_1 == &Text::lit("parent")) {
            break 'm26178 Some(crate::lower::model::Ex::XVar(Text::lit("parent")));
        }
        if let crate::lower::model::Ex::XField(y, f) = x {
            break 'm26178 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XField(Rc::new(z.clone()), f.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XPart(y, k) = x {
            break 'm26178 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XPart(Rc::new(z.clone()), k.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XMethod(y, m, xs) = x {
            break 'm26178 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XMethod(Rc::new(z.clone()), m.clone(), xs.clone())),
                None => None,
            };
        }
        if let crate::lower::model::Ex::XUpgrade(y) = x {
            break 'm26178 match through_parent(&**y) {
                Some(z) => Some(crate::lower::model::Ex::XUpgrade(Rc::new(z.clone()))),
                None => None,
            };
        }
        None
    }
}

/// ```prism
/// Own: fn Vl -> Ex
/// ```
pub fn own(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, Holding::RcOwned, _) => crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        Vl::VlPlace(x, mode, t) => if is_copy(t) {
            copy(&Vl::VlPlace(x.clone(), mode.clone(), t.clone()))
        } else {
            crate::lower::model::Ex::XClone(Rc::new(x.clone()))
        },
        Vl::VlOwned(e, _) => e.clone(),
    }
}

/// ```prism
/// Ref: fn Vl -> Ex
/// ```
pub fn ref_(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::ByRef, _) => x.clone(),
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, Holding::RcOwned, _) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        Vl::VlPlace(x, _, _) => crate::lower::model::Ex::XRef(Rc::new(x.clone())),
        Vl::VlOwned(e, _) => crate::lower::model::Ex::XRef(Rc::new(e.clone())),
    }
}

/// ```prism
/// Copy: fn Vl -> Ex
/// ```
pub fn copy(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::ByRef, _) => crate::lower::model::Ex::XDeref(Rc::new(x.clone())),
        Vl::VlPlace(x, Holding::RcRef, _) => crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))))),
        Vl::VlPlace(x, _, _) => x.clone(),
        Vl::VlOwned(e, _) => e.clone(),
    }
}

/// ```prism
/// IsCopy: fn OutTy -> Bool
/// ```
pub fn is_copy(t: &crate::lower::model::OutTy) -> bool {
    ((((t == &crate::lower::model::OutTy::OutBool) || (t == &crate::lower::model::OutTy::OutFloat)) || (t == &crate::lower::model::OutTy::OutU8)) || (t == &crate::lower::model::OutTy::OutChar)) || (t == &crate::lower::model::OutTy::OutUnit)
}

/// ```prism
/// AsBool: fn Vl -> Ex
/// ```
pub fn as_bool(v_: &Vl) -> crate::lower::model::Ex {
    copy(v_)
}

/// ```prism
/// Escape: fn Text -> Text
/// ```
pub fn escape(t: &Text) -> Text {
    crate::syntax::lexer::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished(char_escape(&c))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// CharEscape: fn Text -> Text
/// ```
pub fn char_escape(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("\\")) => Text::lit("\\\\"),
        c1_0 if (c1_0 == &Text::lit("\"")) => Text::lit("\\\""),
        c2_0 if (c2_0 == &Text::lit("\n")) => Text::lit("\\n"),
        c3_0 if (c3_0 == &Text::lit("\t")) => Text::lit("\\t"),
        c4_0 if (c4_0 == &Text::lit("\r")) => Text::lit("\\r"),
        c5_0 if (c5_0 == &Text::lit("\0")) => Text::lit("\\0"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Number: fn OutTy, Text, Bool -> Ex
/// ```
pub fn number(t: &crate::lower::model::OutTy, digits: &Text, neg: &bool) -> crate::lower::model::Ex {
    let clean = decimal_digits(&concat(&split(digits, &Text::lit("_"))));
    let signed = if *neg { Text::from(format!("-{}", &clean)) } else { clean.clone() };
    match t {
        crate::lower::model::OutTy::OutNat => crate::lower::model::Ex::XNat(clean.clone()),
        crate::lower::model::OutTy::OutInt => crate::lower::model::Ex::XInt(signed.clone()),
        crate::lower::model::OutTy::OutU8 => crate::lower::model::Ex::XByte(clean.clone()),
        crate::lower::model::OutTy::OutFloat => crate::lower::model::Ex::XFloat(if crate::syntax::lexer::contains(&clean, &Text::lit(".")) {
            signed.clone()
        } else {
            Text::from(format!("{}.0", &signed))
        }),
        _ => crate::lower::model::Ex::XInt(signed.clone()),
    }
}

/// ```prism
/// DecimalDigits: fn Text -> Text
/// ```
pub fn decimal_digits(d: &Text) -> Text {
    let r = if &crate::syntax::lexer::head(d) == &Text::lit("0") {
        crate::syntax::lexer::head(&crate::syntax::lexer::after_first(d))
    } else {
        Text::lit("")
    };
    let base_ = if &r == &Text::lit("x") {
        Nat::from(16u32)
    } else {
        if &r == &Text::lit("o") {
            Nat::from(8u32)
        } else {
            if &r == &Text::lit("b") { Nat::from(2u32) } else { Nat::from(10u32) }
        }
    };
    let ds = if &base_ == &Nat::from(10u32) {
        d.clone()
    } else {
        crate::syntax::lexer::after_first(&crate::syntax::lexer::after_first(d))
    };
    if (crate::syntax::lexer::contains(d, &Text::lit(".")) || (&crate::syntax::lexer::head(d) != &Text::lit("0"))) || (d == &Text::lit("0")) {
        d.clone()
    } else {
        Text::from(format!("{}", &crate::syntax::lexer::fold_chars(&ds, &Nat::from(0u32), &{
            let base_ = base_.clone();
            Rc::new(move |(p0, p1): (Nat, Text)| {
                let base_ = base_.clone();
                once_job(move || {
                    let n = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(&(&n * &base_) + &crate::syntax::lexer::hex_value(&c))
                })
            }) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>
        })))
    }
}

/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub fn literal_value(lx: &Lx, env: &Env, l: &crate::syntax::Literal, span: &crate::syntax::Range, neg: &bool) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, span)));
    match &l.kind {
        crate::syntax::LitKind::LInt(d) => Vl::VlOwned(number(&t, d, neg), t.clone()),
        crate::syntax::LitKind::LFloat(d) => Vl::VlOwned(crate::lower::model::Ex::XFloat(if *neg { Text::from(format!("-{}", d)) } else { d.clone() }), crate::lower::model::OutTy::OutFloat),
        crate::syntax::LitKind::LChar(c) => Vl::VlOwned(crate::lower::model::Ex::XChar(c.clone()), crate::lower::model::OutTy::OutChar),
        crate::syntax::LitKind::LDuration(d, u) => Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration),
        crate::syntax::LitKind::LText(segs) => text_value(lx, env, segs),
    }
}

/// The step machine of `LiteralValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiteralValue: unbounded fn Lx, Env, Literal, Range, Bool -> Vl
/// ```
pub struct LiteralValue {
    pub lx: Lx,
    pub env: Env,
    pub l: crate::syntax::Literal,
    pub span: crate::syntax::Range,
    pub neg: bool,
}

impl prism_rtl::Job<Vl> for LiteralValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let l = &self.l;
        let span = &self.span;
        let neg = &self.neg;
        let env = env.clone();
        let l = l.clone();
        let lx = lx.clone();
        let neg = *neg;
        let span = span.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &span))), move |out_ty_of_29573: crate::lower::model::OutTy| {
            let t = out_ty_of_29573;
            match &l.kind {
                crate::syntax::LitKind::LInt(d) => prism_rtl::Turn::Finished(Vl::VlOwned(number(&t, d, &neg), t.clone())),
                crate::syntax::LitKind::LFloat(d) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XFloat(if neg { Text::from(format!("-{}", d)) } else { d.clone() }), crate::lower::model::OutTy::OutFloat)),
                crate::syntax::LitKind::LChar(c) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XChar(c.clone()), crate::lower::model::OutTy::OutChar)),
                crate::syntax::LitKind::LDuration(d, u) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a Duration literal")), crate::lower::model::OutTy::OutDuration)),
                crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::More(Rc::new(TextValue { lx: lx.clone(), env: env.clone(), segs: segs.clone() })),
            }
        })
    }
}

/// `Start LiteralValue, x`: what the function value is when passed to `@Run`.
pub fn start_literal_value(lx: Lx, env: Env, l: crate::syntax::Literal, span: crate::syntax::Range, neg: bool) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(LiteralValue { lx, env, l, span, neg })
}

/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub fn text_value(lx: &Lx, env: &Env, segs: &Array<crate::syntax::TextSeg>) -> Vl {
    let plain = fold(segs, &true, &(|ok: &bool, s: &crate::syntax::TextSeg| *ok && is_plain_seg(s)));
    if plain {
        Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs, &(|s: &crate::syntax::TextSeg| plain_text(s))))), crate::lower::model::OutTy::OutText)
    } else {
        Vl::VlOwned(crate::lower::model::Ex::XFormat(run_to_end(each_job(segs.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::TextSeg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    prism_rtl::Turn::More(Rc::new(SegEx { lx: lx.clone(), env: env.clone(), text_seg2: s.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), crate::lower::model::OutTy::OutText)
    }
}

/// The step machine of `TextValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TextValue: unbounded fn Lx, Env, [TextSeg] -> Vl
/// ```
pub struct TextValue {
    pub lx: Lx,
    pub env: Env,
    pub segs: Array<crate::syntax::TextSeg>,
}

impl prism_rtl::Job<Vl> for TextValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let segs = &self.segs;
        let plain = fold(segs, &true, &(|ok: &bool, s: &crate::syntax::TextSeg| *ok && is_plain_seg(s)));
        if plain {
            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XText(concat(&each(segs, &(|s: &crate::syntax::TextSeg| plain_text(s))))), crate::lower::model::OutTy::OutText))
        } else {
            {
                let env = env.clone();
                let lx = lx.clone();
                let segs = segs.clone();
                call_value(each_job(segs.clone(), {
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::TextSeg| {
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let s = p0;
                            prism_rtl::Turn::More(Rc::new(SegEx { lx: lx.clone(), env: env.clone(), text_seg2: s.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }), move |each_30289: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XFormat(each_30289), crate::lower::model::OutTy::OutText)))
            }
        }
    }
}

/// `Start TextValue, x`: what the function value is when passed to `@Run`.
pub fn start_text_value(lx: Lx, env: Env, segs: Array<crate::syntax::TextSeg>) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(TextValue { lx, env, segs })
}

/// ```prism
/// IsPlainSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_seg(text_seg0: &crate::syntax::TextSeg) -> bool {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(_) => true,
        crate::syntax::TextSeg::SegPlaceholder(_) => false,
    }
}

/// ```prism
/// PlainText: fn TextSeg -> Text
/// ```
pub fn plain_text(text_seg0: &crate::syntax::TextSeg) -> Text {
    match text_seg0 {
        crate::syntax::TextSeg::SegPlain(t) => t.clone(),
        crate::syntax::TextSeg::SegPlaceholder(_) => Text::lit(""),
    }
}

/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub fn seg_ex(lx: &Lx, env: &Env, text_seg2: &crate::syntax::TextSeg) -> crate::lower::model::Ex {
    match text_seg2 {
        crate::syntax::TextSeg::SegPlain(t) => crate::lower::model::Ex::XText(t.clone()),
        crate::syntax::TextSeg::SegPlaceholder(e) => {
            let v_ = value_of(lx, env, e);
            shown_part(&v_)
        },
    }
}

/// The step machine of `SegEx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SegEx: unbounded fn Lx, Env, TextSeg -> Ex
/// ```
pub struct SegEx {
    pub lx: Lx,
    pub env: Env,
    pub text_seg2: crate::syntax::TextSeg,
}

impl prism_rtl::Job<crate::lower::model::Ex> for SegEx {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let text_seg2 = &self.text_seg2;
        match text_seg2 {
            crate::syntax::TextSeg::SegPlain(t) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XText(t.clone())),
            crate::syntax::TextSeg::SegPlaceholder(e) => {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_30688: Vl| {
                    let v_ = value_of_30688;
                    prism_rtl::Turn::Finished(shown_part(&v_))
                })
            },
        }
    }
}

/// `Start SegEx, x`: what the function value is when passed to `@Run`.
pub fn start_seg_ex(lx: Lx, env: Env, text_seg2: crate::syntax::TextSeg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(SegEx { lx, env, text_seg2 })
}

/// ```prism
/// ShownPart: fn Vl -> Ex
/// ```
pub fn shown_part(v_: &Vl) -> crate::lower::model::Ex {
    match value_ty(v_) {
        crate::lower::model::OutTy::OutText => ref_(v_),
        crate::lower::model::OutTy::OutNat => ref_(v_),
        crate::lower::model::OutTy::OutInt => ref_(v_),
        crate::lower::model::OutTy::OutU8 => ref_(v_),
        _ => crate::lower::model::Ex::XCall(Text::lit("show"), Array::from(vec![ref_(v_)])),
    }
}

/// ```prism
/// Refusal: fn Text -> Ex
/// ```
pub fn refusal(what: &Text) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XRefusal(what.clone())
}

/// ```prism
/// TryOf: fn Ex -> Ex
/// ```
pub fn try_of(x: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    if is_named_place(x) {
        refusal(&Text::from(format!("`?` of the place `{}`, which C++'s TRY would move out of (only a temporary may be tried)", &place_stem(x))))
    } else {
        crate::lower::model::Ex::XTry(Rc::new(x.clone()))
    }
}

/// ```prism
/// IsNamedPlace: fn Ex -> Bool
/// ```
pub fn is_named_place(x: &crate::lower::model::Ex) -> bool {
    match x {
        crate::lower::model::Ex::XVar(_) => true,
        crate::lower::model::Ex::XField(_, _) => true,
        crate::lower::model::Ex::XPart(_, _) => true,
        crate::lower::model::Ex::XTarget(_) => true,
        crate::lower::model::Ex::XRef(y) => is_named_place(&**y),
        crate::lower::model::Ex::XDeref(y) => is_named_place(&**y),
        _ => false,
    }
}

/// ```prism
/// let loweringRefusal
/// ```
pub fn lowering_refusal() -> Text {
    Text::lit("prismc does not lower ")
}

/// ```prism
/// RefusalDo: fn Text -> Do
/// ```
pub fn refusal_do(what: &Text) -> crate::lower::model::Do {
    crate::lower::model::Do::DoExpr(refusal(what))
}

/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_of(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> Vl {
    match get(&env.spans, &place_key(lx, &e.span)) {
        Some(v_) => v_.clone(),
        None => unbound_value_of(lx, env, e),
    }
}

/// The step machine of `ValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueOf {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Vl> for ValueOf {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match get(&env.spans, &place_key(lx, &e.span)) {
            Some(v_) => prism_rtl::Turn::Finished(v_.clone()),
            None => prism_rtl::Turn::More(Rc::new(UnboundValueOf { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        }
    }
}

/// `Start ValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_value_of(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(ValueOf { lx, env, e })
}

/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn unbound_value_of(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> Vl {
    if is_event_value(lx, env, e) {
        event_value_of(lx, env, e)
    } else {
        value_by_kind(lx, env, e)
    }
}

/// The step machine of `UnboundValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct UnboundValueOf {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Vl> for UnboundValueOf {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_is_event_value(lx.clone(), env.clone(), e.clone()), move |is_event_value_32663: bool| if is_event_value_32663 {
            prism_rtl::Turn::More(Rc::new(EventValueOf { lx: lx.clone(), env: env.clone(), e: e.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(ValueByKind { lx: lx.clone(), env: env.clone(), e: e.clone() }))
        })
    }
}

/// `Start UnboundValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_unbound_value_of(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(UnboundValueOf { lx, env, e })
}

/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_value(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(_) => false,
        crate::syntax::ExprKind::EGroup(_) => false,
        _ => ((&layer_of(&type_at(lx, &e.span)) == &Layer::LyEv) && !fold(&crate::lower::node_::operands(e), &false, &(|bound: &bool, c: &crate::syntax::Expr| *bound || crate::check::env::has_key(&env.spans, &place_key(lx, &c.span))))) && has_event_source(lx, env, e),
    }
}

/// The step machine of `IsEventValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventValue: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventValue {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventValue {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(_) => prism_rtl::Turn::Finished(false),
            crate::syntax::ExprKind::EGroup(_) => prism_rtl::Turn::Finished(false),
            _ => prism_rtl::Turn::Finished(((&layer_of(&type_at(lx, &e.span)) == &Layer::LyEv) && !fold(&crate::lower::node_::operands(e), &false, &(|bound: &bool, c: &crate::syntax::Expr| *bound || crate::check::env::has_key(&env.spans, &place_key(lx, &c.span))))) && has_event_source(lx, env, e)),
        }
    }
}

/// `Start IsEventValue, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_value(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventValue { lx, env, e })
}

/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn has_event_source(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> bool {
    run_to_end(fold_job(crate::lower::node_::operands(e), false, {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let found = p0;
                let c = p1;
                prism_rtl::Turn::Finished(found || is_event_source(&lx, &env, &c))
            }))
        }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
    }))
}

/// The step machine of `HasEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct HasEventSource {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for HasEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        fold_job(crate::lower::node_::operands(e), false, {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (bool, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let found = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(found || is_event_source(&lx, &env, &c))
                }))
            }) as Rc<dyn Fn((bool, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<bool>>>
        }).cycle()
    }
}

/// `Start HasEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_has_event_source(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasEventSource { lx, env, e })
}

/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub fn is_event_source(lx: &Lx, env: &Env, c: &crate::syntax::Expr) -> bool {
    if &layer_of(&type_at(lx, &c.span)) != &Layer::LyEv {
        false
    } else {
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                Some(Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => true,
                Some(Bn::BnEv(_, _)) => crate::check::env::has_key(&env.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n)))),
                _ => false,
            },
            crate::syntax::ExprKind::EGroup(x) => is_event_source(lx, env, &**x),
            _ => has_event_source(lx, env, c),
        }
    }
}

/// The step machine of `IsEventSource`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsEventSource: unbounded fn Lx, Env, Expr -> Bool
/// ```
pub struct IsEventSource {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::syntax::Expr,
}

impl prism_rtl::Job<bool> for IsEventSource {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        if &layer_of(&type_at(lx, &c.span)) != &Layer::LyEv {
            prism_rtl::Turn::Finished(false)
        } else {
            match &*c.kind {
                crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                    Some(Bn::BnLocal(_, _, crate::lower::model::OutTy::OutEvent(_))) => prism_rtl::Turn::Finished(true),
                    Some(Bn::BnEv(_, _)) => prism_rtl::Turn::Finished(crate::check::env::has_key(&env.names, &Text::from(format!("{}#port", &crate::check::env::sname_key(n))))),
                    _ => prism_rtl::Turn::Finished(false),
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(IsEventSource { lx: lx.clone(), env: env.clone(), c: (**x).clone() })),
                _ => prism_rtl::Turn::More(Rc::new(HasEventSource { lx: lx.clone(), env: env.clone(), e: c.clone() })),
            }
        }
    }
}

/// `Start IsEventSource, x`: what the function value is when passed to `@Run`.
pub fn start_is_event_source(lx: Lx, env: Env, c: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsEventSource { lx, env, c })
}

/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn event_value_of(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, &e.span)));
    let et = crate::lower::model::OutTy::OutEvent(Rc::new(t.clone()));
    let filtered_opt = match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => if &crate::lower::node_::callee_key(lx, &**c) == &Text::lit("Prelude.!Filter") {
            index(args, &Nat::from(0u32))
        } else {
            None
        },
        _ => None,
    };
    match &filtered_opt {
        Some(a) => Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(own(&value_of(lx, env, &a.value))), Text::lit("filter_some"), Array::new()), et.clone()),
        None => {
            let evs = filter(&crate::lower::node_::operands(e), &(|x: &crate::syntax::Expr| &layer_of(&type_at(lx, &x.span)) == &Layer::LyEv));
            'm34730: {
                if let m34730_0 = &evs && (m34730_0.len() == 1) && let Some(one) = index(m34730_0, &Nat::from(0u32)) {
                    break 'm34730 {
                        let src = own(&value_of(lx, env, &one));
                        let it = out_ty_of(lx, &peel(&type_at(lx, &one.span)));
                        let caps = filter(&with_instances(env, &read_names(&crate::check::typed::exprs_in(e))), &(|n: &Text| match get(&env.names, n) {
                            Some(Bn::BnLocal(_, _, _)) => true,
                            _ => false,
                        }));
                        let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
                            Some(Bn::BnLocal(rs, mode, ct)) => {
                                let local = Text::from(format!("{}_c", &place_stem(&rs)));
                                (push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), own(&local_place(&rs, &mode, &ct)))), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), Holding::Owned, ct.clone())))
                            },
                            _ => (acc.clone(), en.clone()),
                        }));
                        let env2 = bind_span(&env1, &place_key(lx, &one.span), &Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), Holding::ByRef, it.clone()));
                        let body = own(&value_by_kind(lx, &env2, e));
                        let mapped = crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))]));
                        Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))])))), et.clone())
                    };
                }
                Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et.clone())
            }
        },
    }
}

/// The step machine of `EventValueOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EventValueOf: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct EventValueOf {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Vl> for EventValueOf {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &e.span))), move |out_ty_of_34289: crate::lower::model::OutTy| {
            let t = out_ty_of_34289;
            let et = crate::lower::model::OutTy::OutEvent(Rc::new(t.clone()));
            let filtered_opt = match &*e.kind {
                crate::syntax::ExprKind::ECall(c, args, _, _) => if &crate::lower::node_::callee_key(&lx, &**c) == &Text::lit("Prelude.!Filter") {
                    index(args, &Nat::from(0u32))
                } else {
                    None
                },
                _ => None,
            };
            match &filtered_opt {
                Some(a) => {
                    let a = a.clone();
                    call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_34566: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(own(&value_of_34566)), Text::lit("filter_some"), Array::new()), et.clone())))
                },
                None => {
                    let evs = filter(&crate::lower::node_::operands(&e), &(|x: &crate::syntax::Expr| &layer_of(&type_at(&lx, &x.span)) == &Layer::LyEv));
                    'm34730: {
                        if let m34730_0 = &evs && (m34730_0.len() == 1) && let Some(one) = index(m34730_0, &Nat::from(0u32)) {
                            break 'm34730 call_then(start_value_of(lx.clone(), env.clone(), one.clone()), move |value_of_34801: Vl| {
                                let src = own(&value_of_34801);
                                call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &one.span))), move |out_ty_of_34852: crate::lower::model::OutTy| {
                                    let it = out_ty_of_34852;
                                    call_then(crate::check::typed::start_exprs_in(e.clone()), move |exprs_in_34963: Array<crate::syntax::Expr>| call_then(start_read_names(exprs_in_34963), move |read_names_34952: Array<Text>| {
                                        let caps = filter(&with_instances(&env, &read_names_34952), &(|n: &Text| match get(&env.names, n) {
                                            Some(Bn::BnLocal(_, _, _)) => true,
                                            _ => false,
                                        }));
                                        let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
                                            Some(Bn::BnLocal(rs, mode, ct)) => {
                                                let local = Text::from(format!("{}_c", &place_stem(&rs)));
                                                (push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), own(&local_place(&rs, &mode, &ct)))), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), Holding::Owned, ct.clone())))
                                            },
                                            _ => (acc.clone(), en.clone()),
                                        }));
                                        let env2 = bind_span(&env1, &place_key(&lx, &one.span), &Vl::VlPlace(crate::lower::model::Ex::XVar(Text::lit("y_ev")), Holding::ByRef, it.clone()));
                                        call_then(start_value_by_kind(lx.clone(), env2.clone(), e.clone()), move |value_by_kind_35659: Vl| {
                                            let body = own(&value_by_kind_35659);
                                            let mapped = crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))]));
                                            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(push(&dos, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("src_ev")), src.clone())), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("src_ev"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("y_ev"))), crate::lower::model::OutTy::OutRef(Rc::new(it.clone())))]), Rc::new(body.clone()))])))), et.clone()))
                                        })
                                    }))
                                })
                            });
                        }
                        prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("an event value of several events")), et.clone()))
                    }
                },
            }
        })
    }
}

/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
pub fn start_event_value_of(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(EventValueOf { lx, env, e })
}

/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub fn value_by_kind(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, &e.span)));
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => name_value(lx, env, n, &e.span),
        crate::syntax::ExprKind::ELit(l) => literal_value(lx, env, l, &e.span, &false),
        crate::syntax::ExprKind::EUnit(_) => Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
        crate::syntax::ExprKind::EBound(b) => match get(&env.names, b) {
            Some(Bn::BnLocal(rs, mode, bt)) => local_place(&rs, &mode, &bt),
            _ => Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b))), t.clone()),
        },
        crate::syntax::ExprKind::ENil(_) => Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()), t.clone()),
        crate::syntax::ExprKind::ETuple(es) => Vl::VlOwned(crate::lower::model::Ex::XTuple(run_to_end(each_job(es.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36646: Vl| prism_rtl::Turn::Finished(own(&value_of_36646)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t.clone()),
        crate::syntax::ExprKind::EArray(m36209_6_0) if (m36209_6_0.len() == 0) => Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t.clone()), t.clone()),
        crate::syntax::ExprKind::EArray(es) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(es.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Expr| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let x = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36818: Vl| prism_rtl::Turn::Finished(own(&value_of_36818)))
                }))
            }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t.clone()),
        crate::syntax::ExprKind::EMap(m36209_8_0) if (m36209_8_0.len() == 0) => Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t.clone()), t.clone()),
        crate::syntax::ExprKind::EMap(kvs) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(run_to_end(each_job(kvs.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let (k, v_) = p0;
                    call_then(start_value_of(lx.clone(), env.clone(), k.clone()), move |value_of_36999: Vl| call_then(start_value_of(lx.clone(), env.clone(), v_.clone()), move |value_of_37025: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![own(&value_of_36999), own(&value_of_37025)])))))
                }))
            }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        })))])), t.clone()),
        crate::syntax::ExprKind::EGroup(x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::ECall(c, args, _, _) => application(lx, env, &**c, args, &e.span),
        crate::syntax::ExprKind::EMethod(r, m, args) => application(lx, env, &crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, &append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r).clone(), span: r.span.clone() }]), args), &e.span),
        crate::syntax::ExprKind::EBinary(op, l, r) => binary_value(lx, env, op, &**l, &**r, &e.span),
        crate::syntax::ExprKind::EUnary(m36209_14_0, x) if (m36209_14_0 == &Text::lit("not")) => Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(as_bool(&value_of(lx, env, &**x)))), crate::lower::model::OutTy::OutBool),
        crate::syntax::ExprKind::EUnary(m36209_15_0, x) if (m36209_15_0 == &Text::lit("neg")) => match &*x.kind {
            crate::syntax::ExprKind::ELit(l) => literal_value(lx, env, l, &x.span, &true),
            _ => {
                let v_ = value_of(lx, env, &**x);
                if is_copy(&t) {
                    Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(copy(&v_))), t.clone())
                } else {
                    Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(ref_(&v_))), t.clone())
                }
            },
        },
        crate::syntax::ExprKind::EUnary(_, x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EFreeSigil(m36209_17_0, x) if (m36209_17_0 == &Text::lit("?")) => Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![own(&value_of(lx, env, &**x))])), t.clone()),
        crate::syntax::ExprKind::EFreeSigil(m36209_18_0, x) if (m36209_18_0 == &Text::lit("~")) => Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![own(&value_of(lx, env, &**x))])), t.clone()),
        crate::syntax::ExprKind::EFreeSigil(m36209_19_0, x) if (m36209_19_0 == &Text::lit("@")) => pure_blueprint(lx, env, &**x, &t),
        crate::syntax::ExprKind::EFreeSigil(_, x) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EField(r, _, name) => field_value(lx, env, &**r, &name.name),
        crate::syntax::ExprKind::EIndex(r, i) => index_value(lx, env, &**r, &**i, &t),
        crate::syntax::ExprKind::ELambda(ps_opt, body) => lambda_value(lx, env, e, &or(ps_opt, &Array::new()), &**body),
        crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => if_value(lx, env, &**c, then_b, else_b_opt, &t),
        crate::syntax::ExprKind::EMatch(s, arms) => match_value(lx, env, &**s, arms, &t, &e.span),
        crate::syntax::ExprKind::ETemplate(tp) => template_value(lx, env, tp),
        crate::syntax::ExprKind::ECast(x, _, _) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::ETypeArgs(x, _) => value_of(lx, env, &**x),
        crate::syntax::ExprKind::EGiven(b) => given_value(lx, env, b, &t, &e.span),
        crate::syntax::ExprKind::EUpdate(target, b) => update_value(lx, env, &**target, b, &t, &e.span),
        crate::syntax::ExprKind::EAny(x) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![own(&value_of(lx, env, &**x))])), crate::lower::model::OutTy::OutShowAny),
        _ => Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e.kind)))), t.clone()),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ValueByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
/// ```
pub struct ValueByKind {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Vl> for ValueByKind {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &e.span))), move |out_ty_of_36166: crate::lower::model::OutTy| {
            let t = out_ty_of_36166;
            match &*e.kind {
                crate::syntax::ExprKind::EName(n) => prism_rtl::Turn::More(Rc::new(NameValue { lx: lx.clone(), env: env.clone(), n: n.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx: lx.clone(), env: env.clone(), l: l.clone(), span: e.span.clone(), neg: false })),
                crate::syntax::ExprKind::EUnit(_) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit)),
                crate::syntax::ExprKind::EBound(b) => match get(&env.names, b) {
                    Some(Bn::BnLocal(rs, mode, bt)) => prism_rtl::Turn::Finished(local_place(&rs, &mode, &bt)),
                    _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("`{}` outside a `for`", b))), t.clone())),
                },
                crate::syntax::ExprKind::ENil(_) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XNone), t.clone()), t.clone())),
                crate::syntax::ExprKind::ETuple(es) => {
                    let es = es.clone();
                    call_value(each_job(es.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36646: Vl| prism_rtl::Turn::Finished(own(&value_of_36646)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_36627: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XTuple(each_36627), t.clone())))
                },
                crate::syntax::ExprKind::EArray(m36209_6_0) if (m36209_6_0.len() == 0) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Array::new"), Array::new())), t.clone()), t.clone())),
                crate::syntax::ExprKind::EArray(es) => {
                    let es = es.clone();
                    call_value(each_job(es.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Expr| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_36818: Vl| prism_rtl::Turn::Finished(own(&value_of_36818)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_36799: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Array::from"), Array::from(vec![crate::lower::model::Ex::XVec(each_36799)])), t.clone())))
                },
                crate::syntax::ExprKind::EMap(m36209_8_0) if (m36209_8_0.len() == 0) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Map::new"), Array::new())), t.clone()), t.clone())),
                crate::syntax::ExprKind::EMap(kvs) => {
                    let kvs = kvs.clone();
                    call_value(each_job(kvs.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: (crate::syntax::Expr, crate::syntax::Expr)| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let (k, v_) = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), k.clone()), move |value_of_36999: Vl| call_then(start_value_of(lx.clone(), env.clone(), v_.clone()), move |value_of_37025: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XTuple(Array::from(vec![own(&value_of_36999), own(&value_of_37025)])))))
                            }))
                        }) as Rc<dyn Fn((crate::syntax::Expr, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_36963: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("map_of"), Array::from(vec![crate::lower::model::Ex::XVec(each_36963)])), t.clone())))
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::ECall(c, args, _, _) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: (**c).clone(), args: args.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EMethod(r, m, args) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EName(m.clone())), span: m.span.clone() }, args: append(&Array::from(vec![crate::syntax::Arg { name: None, value: (**r).clone(), span: r.span.clone() }]), args), span: e.span.clone() })),
                crate::syntax::ExprKind::EBinary(op, l, r) => prism_rtl::Turn::More(Rc::new(BinaryValue { lx: lx.clone(), env: env.clone(), op: op.clone(), l: (**l).clone(), r: (**r).clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EUnary(m36209_14_0, x) if (m36209_14_0 == &Text::lit("not")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_37435: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(as_bool(&value_of_37435))), crate::lower::model::OutTy::OutBool)))
                },
                crate::syntax::ExprKind::EUnary(m36209_15_0, x) if (m36209_15_0 == &Text::lit("neg")) => match &*x.kind {
                    crate::syntax::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(LiteralValue { lx: lx.clone(), env: env.clone(), l: l.clone(), span: x.span.clone(), neg: true })),
                    _ => {
                        let x = (**x).clone();
                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_37610: Vl| {
                            let v_ = value_of_37610;
                            if is_copy(&t) {
                                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(copy(&v_))), t.clone()))
                            } else {
                                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XUnary(Text::lit("-"), Rc::new(ref_(&v_))), t.clone()))
                            }
                        })
                    },
                },
                crate::syntax::ExprKind::EUnary(_, x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EFreeSigil(m36209_17_0, x) if (m36209_17_0 == &Text::lit("?")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_37833: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![own(&value_of_37833)])), t.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m36209_18_0, x) if (m36209_18_0 == &Text::lit("~")) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_37914: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![own(&value_of_37914)])), t.clone())))
                },
                crate::syntax::ExprKind::EFreeSigil(m36209_19_0, x) if (m36209_19_0 == &Text::lit("@")) => prism_rtl::Turn::More(Rc::new(PureBlueprint { lx: lx.clone(), env: env.clone(), x: (**x).clone(), t: t.clone() })),
                crate::syntax::ExprKind::EFreeSigil(_, x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EField(r, _, name) => prism_rtl::Turn::More(Rc::new(FieldValue { lx: lx.clone(), env: env.clone(), r: (**r).clone(), name: name.name.clone() })),
                crate::syntax::ExprKind::EIndex(r, i) => prism_rtl::Turn::More(Rc::new(IndexValue { lx: lx.clone(), env: env.clone(), r: (**r).clone(), i: (**i).clone(), t: t.clone() })),
                crate::syntax::ExprKind::ELambda(ps_opt, body) => prism_rtl::Turn::More(Rc::new(LambdaValue { lx: lx.clone(), env: env.clone(), e: e.clone(), ps: or(ps_opt, &Array::new()), body: (**body).clone() })),
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(IfValue { lx: lx.clone(), env: env.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), t: t.clone() })),
                crate::syntax::ExprKind::EMatch(s, arms) => prism_rtl::Turn::More(Rc::new(MatchValue { lx: lx.clone(), env: env.clone(), s: (**s).clone(), arms: arms.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::ETemplate(tp) => prism_rtl::Turn::More(Rc::new(TemplateValue { lx: lx.clone(), env: env.clone(), tp: tp.clone() })),
                crate::syntax::ExprKind::ECast(x, _, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::ETypeArgs(x, _) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
                crate::syntax::ExprKind::EGiven(b) => prism_rtl::Turn::More(Rc::new(GivenValue { lx: lx.clone(), env: env.clone(), b: b.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EUpdate(target, b) => prism_rtl::Turn::More(Rc::new(UpdateValue { lx: lx.clone(), env: env.clone(), target: (**target).clone(), b: b.clone(), t: t.clone(), span: e.span.clone() })),
                crate::syntax::ExprKind::EAny(x) => {
                    let x = (**x).clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_38677: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![own(&value_of_38677)])), crate::lower::model::OutTy::OutShowAny)))
                },
                _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("{} as a value", &kind_words(&*e.kind)))), t.clone())),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
pub fn start_value_by_kind(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(ValueByKind { lx, env, e })
}

/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub fn pure_blueprint(lx: &Lx, env: &Env, x: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> Vl {
    let is_never = match &*x.kind {
        crate::syntax::ExprKind::EName(n) => {
            let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            &qk_opt == &Some(Text::lit("Prelude.never"))
        },
        _ => false,
    };
    if is_never {
        Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t.clone())
    } else {
        match get(&env.names, &Text::lit("#tag")) {
            None => Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known", &src_text(lx, &lx.file, &x.span)))), t.clone()),
            Some(Bn::BnLocal(crate::lower::model::Ex::XPath(variant), _, _)) => match layer_of(&type_at(lx, &x.span)) {
                Layer::LyEv => {
                    let wrapped = crate::lower::model::Ex::XMethod(Rc::new(own(&value_of(lx, env, x))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                    Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped.clone()])), t.clone())
                },
                Layer::LyDyn => match crate::lower::node_::dynamic_answer(lx, x) {
                    None => match &*x.kind {
                        crate::syntax::ExprKind::EFreeSigil(m40379_0_0, inner) if (m40379_0_0 == &Text::lit("$")) => plain_blueprint(lx, env, &**inner, &variant, t),
                        _ => Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier's dynamic answer of no known form", &src_text(lx, &lx.file, &x.span)))), t.clone()),
                        _ => unreachable!("no arm matched"),
                    },
                    Some(d) => dynamic_blueprint(lx, env, x, &d, &variant, t),
                },
                _ => plain_blueprint(lx, env, x, &variant, t),
            },
            _ => Vl::VlOwned(refusal(&Text::lit("a supplier's answer under a tag the arm does not name")), t.clone()),
        }
    }
}

/// The step machine of `PureBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
/// ```
pub struct PureBlueprint {
    pub lx: Lx,
    pub env: Env,
    pub x: crate::syntax::Expr,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for PureBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let t = &self.t;
        let is_never = match &*x.kind {
            crate::syntax::ExprKind::EName(n) => {
                let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                &qk_opt == &Some(Text::lit("Prelude.never"))
            },
            _ => false,
        };
        if is_never {
            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array::new()), t.clone()))
        } else {
            match get(&env.names, &Text::lit("#tag")) {
                None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("`@ {}` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known", &src_text(lx, &lx.file, &x.span)))), t.clone())),
                Some(Bn::BnLocal(crate::lower::model::Ex::XPath(variant), _, _)) => match layer_of(&type_at(lx, &x.span)) {
                    Layer::LyEv => {
                        let env = env.clone();
                        let lx = lx.clone();
                        let t = t.clone();
                        let x = x.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_40108: Vl| {
                            let wrapped = crate::lower::model::Ex::XMethod(Rc::new(own(&value_of_40108)), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(false, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))]), Rc::new(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("v"))))]))))]));
                            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::event_blueprint::<crate::Elem, _>"), Array::from(vec![wrapped.clone()])), t.clone()))
                        })
                    },
                    Layer::LyDyn => match crate::lower::node_::dynamic_answer(lx, x) {
                        None => match &*x.kind {
                            crate::syntax::ExprKind::EFreeSigil(m40379_0_0, inner) if (m40379_0_0 == &Text::lit("$")) => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx: lx.clone(), env: env.clone(), x: (**inner).clone(), variant: variant.clone(), t: t.clone() })),
                            _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier's dynamic answer of no known form", &src_text(lx, &lx.file, &x.span)))), t.clone())),
                            _ => unreachable!("no arm matched"),
                        },
                        Some(d) => prism_rtl::Turn::More(Rc::new(DynamicBlueprint { lx: lx.clone(), env: env.clone(), x: x.clone(), d: d.clone(), variant: variant.clone(), t: t.clone() })),
                    },
                    _ => prism_rtl::Turn::More(Rc::new(PlainBlueprint { lx: lx.clone(), env: env.clone(), x: x.clone(), variant: variant.clone(), t: t.clone() })),
                },
                _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a supplier's answer under a tag the arm does not name")), t.clone())),
            }
        }
    }
}

/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_pure_blueprint(lx: Lx, env: Env, x: crate::syntax::Expr, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PureBlueprint { lx, env, x, t })
}

/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub fn plain_blueprint(lx: &Lx, env: &Env, x: &crate::syntax::Expr, variant: &Text, t: &crate::lower::model::OutTy) -> Vl {
    Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![own(&value_of(lx, env, x))]))])), t.clone())
}

/// The step machine of `PlainBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
/// ```
pub struct PlainBlueprint {
    pub lx: Lx,
    pub env: Env,
    pub x: crate::syntax::Expr,
    pub variant: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for PlainBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let variant = &self.variant;
        let t = &self.t;
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        let variant = variant.clone();
        let x = x.clone();
        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_41027: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array::from(vec![crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![own(&value_of_41027)]))])), t.clone())))
    }
}

/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_plain_blueprint(lx: Lx, env: Env, x: crate::syntax::Expr, variant: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PlainBlueprint { lx, env, x, variant, t })
}

/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub fn dynamic_blueprint(lx: &Lx, env: &Env, x: &crate::syntax::Expr, d: &crate::syntax::Expr, variant: &Text, t: &crate::lower::model::OutTy) -> Vl {
    match (get(&env.names, &Text::from(format!("#dyn{}", &crate::lower::node_::dyn_key(x)))), get(&env.names, &Text::lit("#owner"))) {
        (Some(Bn::BnLocal(crate::lower::model::Ex::XVar(getter), _, dt)), Some(Bn::BnLocal(crate::lower::model::Ex::XVar(owner), _, _))) => {
            let at_build = own(&value_of(lx, &crate::lower::node_::init_env(env), d));
            let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
            let read = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
            let dynamic = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter)))))]))));
            Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic.clone()])), t.clone())
        },
        _ => Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)", &src_text(lx, &lx.file, &x.span)))), t.clone()),
    }
}

/// The step machine of `DynamicBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
/// ```
pub struct DynamicBlueprint {
    pub lx: Lx,
    pub env: Env,
    pub x: crate::syntax::Expr,
    pub d: crate::syntax::Expr,
    pub variant: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for DynamicBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let x = &self.x;
        let d = &self.d;
        let variant = &self.variant;
        let t = &self.t;
        match (get(&env.names, &Text::from(format!("#dyn{}", &crate::lower::node_::dyn_key(x)))), get(&env.names, &Text::lit("#owner"))) {
            (Some(Bn::BnLocal(crate::lower::model::Ex::XVar(getter), _, dt)), Some(Bn::BnLocal(crate::lower::model::Ex::XVar(owner), _, _))) => {
                let d = d.clone();
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                let variant = variant.clone();
                call_then(start_value_of(lx.clone(), crate::lower::node_::init_env(&env), d.clone()), move |value_of_41839: Vl| {
                    let at_build = own(&value_of_41839);
                    let arms = Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("owner"))])), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("owner"))), getter.clone(), Array::from(vec![crate::lower::model::Ex::XCx]))])) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaUnit(Text::lit("None")), conds: Array::new(), body: crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("at_build"))))])) }]);
                    let read = crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("cx"))), crate::lower::model::OutTy::OutRef(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Cx"), Array::new()))))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("link"))), Text::lit("owner"), Array::new())), arms.clone(), false, crate::lower::model::OutTy::OutNamed(Text::lit("crate::Answer"), Array::new()))));
                    let dynamic = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("link")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(owner.clone())))), crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("at_build")), at_build.clone())]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Dynamic::of"), Array::from(vec![read.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(Text::from(format!("{}_port", &getter)))))]))));
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array::from(vec![dynamic.clone()])), t.clone()))
                })
            },
            _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("`@ {}`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)", &src_text(lx, &lx.file, &x.span)))), t.clone())),
        }
    }
}

/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_dynamic_blueprint(lx: Lx, env: Env, x: crate::syntax::Expr, d: crate::syntax::Expr, variant: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(DynamicBlueprint { lx, env, x, d, variant, t })
}

/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub fn element_blueprint(lx: &Lx, env: &Env, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> Vl {
    match index(args, &Nat::from(0u32)) {
        Some(a) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![ref_(&value_of(lx, env, &a.value))])), t.clone()),
        None => Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t.clone()),
    }
}

/// The step machine of `ElementBlueprint`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
/// ```
pub struct ElementBlueprint {
    pub lx: Lx,
    pub env: Env,
    pub args: Array<crate::syntax::Arg>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for ElementBlueprint {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let args = &self.args;
        let t = &self.t;
        match index(args, &Nat::from(0u32)) {
            Some(a) => {
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_43122: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array::from(vec![ref_(&value_of_43122)])), t.clone())))
            },
            None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("`@Element` without its element")), t.clone())),
        }
    }
}

/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
pub fn start_element_blueprint(lx: Lx, env: Env, args: Array<crate::syntax::Arg>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(ElementBlueprint { lx, env, args, t })
}

/// ```prism
/// KindWords: fn ExprKind -> Text
/// ```
pub fn kind_words(k: &crate::syntax::ExprKind) -> Text {
    match k {
        crate::syntax::ExprKind::ESuffixed(op, _, _, _) => Text::from(format!("a suffixed `{}`", op)),
        crate::syntax::ExprKind::EFreeSigil(sg, _) => Text::from(format!("a free `{}`", sg)),
        crate::syntax::ExprKind::ETopicField(_) => Text::lit("a topic field (`&_.f` outside an `update`)"),
        crate::syntax::ExprKind::ETopicIndex(_) => Text::lit("a topic index"),
        crate::syntax::ExprKind::ENonEmpty(_) => Text::lit("a non-empty literal"),
        crate::syntax::ExprKind::EAbsent => Text::lit("an absent value"),
        crate::syntax::ExprKind::ERest => Text::lit("a `..` rest"),
        crate::syntax::ExprKind::ELambda(_, _) => Text::lit("a lambda"),
        crate::syntax::ExprKind::ERebuild(_, _) => Text::lit("a `rebuild` outside a widget block"),
        crate::syntax::ExprKind::EFor(_, _, _) => Text::lit("a `for` outside a widget block"),
        crate::syntax::ExprKind::EWidgetBlock(_) => Text::lit("a widget block"),
        crate::syntax::ExprKind::EMonad(_, _) => Text::lit("a monadic block"),
        crate::syntax::ExprKind::ELens(_) => Text::lit("a lens"),
        crate::syntax::ExprKind::EError => Text::lit("an expression the parser could not read"),
        _ => Text::lit("an expression"),
    }
}

/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub fn name_value(lx: &Lx, env: &Env, n: &crate::syntax::SName, span: &crate::syntax::Range) -> Vl {
    let nkey = name_key_at(lx, env, n, span);
    let t = out_ty_of(lx, &peel(&type_at(lx, span)));
    let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
    match &local_opt {
        Some(Bn::BnLocal(rs, mode, lt)) => local_place(rs, mode, lt),
        Some(Bn::BnHold(f, ht)) => Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht.clone()),
        Some(Bn::BnDyn(x, _, dt)) => Vl::VlOwned(x.clone(), dt.clone()),
        Some(Bn::BnEv(_, et)) => match get(&env.names, &Text::from(format!("{}#port", &nkey))) {
            Some(Bn::BnLocal(pf, _, _)) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf.clone()))])), crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of(lx, &peel(&peel(&type_at(lx, span))))))),
            _ => Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et.clone()),
        },
        Some(Bn::BnParts(_)) => Vl::VlOwned(refusal(&Text::lit("a tuple pattern's binding as a value")), t.clone()),
        Some(Bn::BnWidget(_, _, _, _)) => Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t.clone()),
        Some(Bn::BnLocalFn(_)) => Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t.clone()),
        None => {
            let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            match &qk_opt {
                Some(m45198_0) if (m45198_0 == &Text::lit("True")) => Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool),
                Some(m45198_1) if (m45198_1 == &Text::lit("False")) => Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool),
                Some(m45198_2) if (m45198_2 == &Text::lit("Prelude.never")) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t.clone()),
                Some(qk) => match get(&lx.g.tags, qk) {
                    Some(tg) if ((&tg.kind != &Text::lit("Prelude.Fault")) && (&why == &Text::lit("tag"))) => tag_value(lx, env, &tg, &Array::new()),
                    _ => global_value(lx, qk, span, &t),
                    _ => unreachable!("no arm matched"),
                },
                None => Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey))), t.clone()),
                _ => unreachable!("no arm matched"),
            }
        },
    }
}

/// The step machine of `NameValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
/// ```
pub struct NameValue {
    pub lx: Lx,
    pub env: Env,
    pub n: crate::syntax::SName,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for NameValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let span = &self.span;
        let nkey = name_key_at(lx, env, n, span);
        let env = env.clone();
        let lx = lx.clone();
        let n = n.clone();
        let span = span.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &span))), move |out_ty_of_44228: crate::lower::model::OutTy| {
            let t = out_ty_of_44228;
            let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
            match &local_opt {
                Some(Bn::BnLocal(rs, mode, lt)) => prism_rtl::Turn::Finished(local_place(rs, mode, lt)),
                Some(Bn::BnHold(f, ht)) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), Text::from(format!("{}", f)))), Text::lit("get"), Array::from(vec![crate::lower::model::Ex::XCx])), ht.clone())),
                Some(Bn::BnDyn(x, _, dt)) => prism_rtl::Turn::Finished(Vl::VlOwned(x.clone(), dt.clone())),
                Some(Bn::BnEv(_, et)) => match get(&env.names, &Text::from(format!("{}#port", &nkey))) {
                    Some(Bn::BnLocal(pf, _, _)) => call_then(start_out_ty_of(lx.clone(), peel(&peel(&type_at(&lx, &span)))), move |out_ty_of_44708: crate::lower::model::OutTy| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("prism_rtl::Event::of"), Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(pf.clone()))])), crate::lower::model::OutTy::OutEvent(Rc::new(out_ty_of_44708))))),
                    _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("an event read as a value")), et.clone())),
                },
                Some(Bn::BnParts(_)) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a tuple pattern's binding as a value")), t.clone())),
                Some(Bn::BnWidget(_, _, _, _)) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a widget parameter read as a plain value")), t.clone())),
                Some(Bn::BnLocalFn(_)) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a local function as a value")), t.clone())),
                None => {
                    let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, &n);
                    match &qk_opt {
                        Some(m45198_0) if (m45198_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBool(true), crate::lower::model::OutTy::OutBool)),
                        Some(m45198_1) if (m45198_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBool(false), crate::lower::model::OutTy::OutBool)),
                        Some(m45198_2) if (m45198_2 == &Text::lit("Prelude.never")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Event::never"), Array::new()), t.clone())),
                        Some(qk) => match get(&lx.g.tags, qk) {
                            Some(tg) if ((&tg.kind != &Text::lit("Prelude.Fault")) && (&why == &Text::lit("tag"))) => prism_rtl::Turn::More(Rc::new(TagValue { lx: lx.clone(), env: env.clone(), tg: tg.clone(), args: Array::new() })),
                            _ => prism_rtl::Turn::More(Rc::new(GlobalValue { lx: lx.clone(), qk: qk.clone(), span: span.clone(), t: t.clone() })),
                            _ => unreachable!("no arm matched"),
                        },
                        None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("the name {}, which nothing declares", &nkey))), t.clone())),
                        _ => unreachable!("no arm matched"),
                    }
                },
            }
        })
    }
}

/// `Start NameValue, x`: what the function value is when passed to `@Run`.
pub fn start_name_value(lx: Lx, env: Env, n: crate::syntax::SName, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(NameValue { lx, env, n, span })
}

/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub fn global_value(lx: &Lx, qk: &Text, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    match get(&lx.g.ctors, qk) {
        Some(c) => {
            let arity = if &len(&c.fields) > &Nat::from(0u32) { len(&c.fields) } else { len(&c.args) };
            match t {
                crate::lower::model::OutTy::OutFn(pts, _) => if &arity > &Nat::from(0u32) {
                    ctor_fn(lx, &c, pts, span, t, &false)
                } else {
                    ctor_app(lx, &empty_env(), &c, &Array::new(), span)
                },
                crate::lower::model::OutTy::OutJobFn(a, _) => {
                    let pts = match &**a {
                        crate::lower::model::OutTy::OutTuple(ts) => if &arity == &Nat::from(1u32) { Array::from(vec![(**a).clone()]) } else { ts.clone() },
                        _ => Array::from(vec![(**a).clone()]),
                    };
                    if &arity > &Nat::from(0u32) {
                        ctor_fn(lx, &c, &pts, span, t, &true)
                    } else {
                        ctor_app(lx, &empty_env(), &c, &Array::new(), span)
                    }
                },
                _ => ctor_app(lx, &empty_env(), &c, &Array::new(), span),
            }
        },
        None => match get(&lx.g.tags, qk) {
            Some(tg) => Vl::VlOwned(crate::lower::model::Ex::XStr(tg.name.clone()), t.clone()),
            None => if fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d)))) {
                Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(lx, qk), Array::new()), t.clone())
            } else {
                match get(&lx.g.vals, qk) {
                    Some(v_) => {
                        let is_let = fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d))));
                        if is_let {
                            Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(lx, qk), Array::new()), t.clone())
                        } else {
                            match t {
                                crate::lower::model::OutTy::OutJobFn(a, _) => {
                                    let (ps, ignore2) = scheme_parts(lx, qk);
                                    let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("a{}", i))));
                                    let pa = if &len(&ps) == &Nat::from(1u32) {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a).clone())
                                    } else {
                                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), (**a).clone())
                                    };
                                    let f = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx, qk), each(&names, &(|nm: &Text| crate::lower::model::Ex::XVar(nm.clone()))))]))));
                                    Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f.clone()]))), t.clone()), t.clone())
                                },
                                _ => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(value_path(lx, qk))])), t.clone()),
                            }
                        }
                    },
                    None => Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk))), t.clone()),
                }
            },
        },
    }
}

/// The step machine of `GlobalValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
/// ```
pub struct GlobalValue {
    pub lx: Lx,
    pub qk: Text,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for GlobalValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let qk = &self.qk;
        let span = &self.span;
        let t = &self.t;
        match get(&lx.g.ctors, qk) {
            Some(c) => {
                let arity = if &len(&c.fields) > &Nat::from(0u32) { len(&c.fields) } else { len(&c.args) };
                match t {
                    crate::lower::model::OutTy::OutFn(pts, _) => if &arity > &Nat::from(0u32) {
                        prism_rtl::Turn::More(Rc::new(CtorFn { lx: lx.clone(), c: c.clone(), pts: pts.clone(), span: span.clone(), t: t.clone(), job: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: empty_env(), c: c.clone(), args: Array::new(), span: span.clone() }))
                    },
                    crate::lower::model::OutTy::OutJobFn(a, _) => {
                        let pts = match &**a {
                            crate::lower::model::OutTy::OutTuple(ts) => if &arity == &Nat::from(1u32) { Array::from(vec![(**a).clone()]) } else { ts.clone() },
                            _ => Array::from(vec![(**a).clone()]),
                        };
                        if &arity > &Nat::from(0u32) {
                            prism_rtl::Turn::More(Rc::new(CtorFn { lx: lx.clone(), c: c.clone(), pts: pts.clone(), span: span.clone(), t: t.clone(), job: true }))
                        } else {
                            prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: empty_env(), c: c.clone(), args: Array::new(), span: span.clone() }))
                        }
                    },
                    _ => prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: empty_env(), c: c.clone(), args: Array::new(), span: span.clone() })),
                }
            },
            None => match get(&lx.g.tags, qk) {
                Some(tg) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XStr(tg.name.clone()), t.clone())),
                None => if fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d)))) {
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(lx, qk), Array::new()), t.clone()))
                } else {
                    match get(&lx.g.vals, qk) {
                        Some(v_) => {
                            let is_let = fold(&lx.g.defs, &false, &(|f: &bool, d: &crate::check::env::Def| *f || ((&d.qk == qk) && is_let_def(d))));
                            if is_let {
                                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(lx, qk), Array::new()), t.clone()))
                            } else {
                                match t {
                                    crate::lower::model::OutTy::OutJobFn(a, _) => {
                                        let (ps, ignore2) = scheme_parts(lx, qk);
                                        let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("a{}", i))));
                                        let pa = if &len(&ps) == &Nat::from(1u32) {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), (**a).clone())
                                        } else {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), (**a).clone())
                                        };
                                        let f = crate::lower::model::Ex::XClosure(false, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![crate::lower::model::Ex::XCall(start_path(lx, qk), each(&names, &(|nm: &Text| crate::lower::model::Ex::XVar(nm.clone()))))]))));
                                        prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![f.clone()]))), t.clone()), t.clone()))
                                    },
                                    _ => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XPath(value_path(lx, qk))])), t.clone())),
                                }
                            }
                        },
                        None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("the global {}", qk))), t.clone())),
                    }
                },
            },
        }
    }
}

/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
pub fn start_global_value(lx: Lx, qk: Text, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(GlobalValue { lx, qk, span, t })
}

/// ```prism
/// IsLetDef: fn Def -> Bool
/// ```
pub fn is_let_def(d: &crate::check::env::Def) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbLet(_) => true,
        _ => false,
    }
}

/// ```prism
/// StartPath: fn Lx, Text -> Text
/// ```
pub fn start_path(lx: &Lx, qk: &Text) -> Text {
    let owner = match get(&lx.g.vals, qk) {
        Some(v_) => v_.home.clone(),
        None => owner_of(qk),
    };
    path_in(lx, &owner, &Text::from(format!("start_{}", &or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk))))))
}

/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub fn application(lx: &Lx, env: &Env, callee: &crate::syntax::Expr, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, span)));
    match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => {
            let nkey = name_key_at(lx, env, n, &callee.span);
            let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
            match &local_opt {
                Some(Bn::BnLocalFn(c)) => inline_local_fn(lx, env, c, args, &t),
                Some(b) => {
                    let f = name_value(lx, env, n, &callee.span);
                    match value_ty(&f) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![start_call(&f, &start_args(lx, env, &f, args))])), t.clone()),
                        _ => Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(ref_(&f)), run_to_end(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }))), t.clone()),
                    }
                },
                None => {
                    let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                    match &qk_opt {
                        Some(qk) => match get(&lx.g.tags, qk) {
                            Some(tg) if (&why == &Text::lit("tag")) => tag_value(lx, env, &tg, args),
                            _ => if qk == &Text::lit("Prelude.@Element") {
                                element_blueprint(lx, env, args, &t)
                            } else {
                                global_call(lx, env, qk, args, span, &t)
                            },
                            _ => unreachable!("no arm matched"),
                        },
                        None => Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey))), t.clone()),
                    }
                },
            }
        },
        crate::syntax::ExprKind::EGroup(x) => application(lx, env, &**x, args, span),
        _ => {
            let f = value_of(lx, env, callee);
            match value_ty(&f) {
                crate::lower::model::OutTy::OutJobFn(_, _) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![start_call(&f, &start_args(lx, env, &f, args))])), t.clone()),
                _ => Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(ref_(&f)), run_to_end(each_job(args.clone(), {
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: crate::syntax::Arg| {
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }))), t.clone()),
            }
        },
    }
}

/// The step machine of `Application`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
/// ```
pub struct Application {
    pub lx: Lx,
    pub env: Env,
    pub callee: crate::syntax::Expr,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for Application {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let callee = &self.callee;
        let args = &self.args;
        let span = &self.span;
        let args = args.clone();
        let callee = callee.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &span))), move |out_ty_of_48099: crate::lower::model::OutTy| {
            let t = out_ty_of_48099;
            match &*callee.kind {
                crate::syntax::ExprKind::EName(n) => {
                    let nkey = name_key_at(&lx, &env, n, &callee.span);
                    let local_opt = if &len(&n.path_) == &Nat::from(1u32) { get(&env.names, &nkey) } else { None };
                    match &local_opt {
                        Some(Bn::BnLocalFn(c)) => prism_rtl::Turn::More(Rc::new(InlineLocalFn { lx: lx.clone(), env: env.clone(), c: c.clone(), args: args.clone(), t: t.clone() })),
                        Some(b) => {
                            let n = n.clone();
                            call_then(start_name_value(lx.clone(), env.clone(), n.clone(), callee.span.clone()), move |name_value_48448: Vl| {
                                let f = name_value_48448;
                                match value_ty(&f) {
                                    crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_48642: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![start_call(&f, &start_args_48642)])), t.clone()))),
                                    _ => call_value(each_job(args.clone(), {
                                        let lx = lx.clone();
                                        let env = env.clone();
                                        Rc::new(move |p0: crate::syntax::Arg| {
                                            let lx = lx.clone();
                                            let env = env.clone();
                                            entered(once_job(move || {
                                                let a = p0;
                                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                            }))
                                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |each_48738: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(ref_(&f)), each_48738), t.clone()))),
                                }
                            })
                        },
                        None => {
                            let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                            match &qk_opt {
                                Some(qk) => match get(&lx.g.tags, qk) {
                                    Some(tg) if (&why == &Text::lit("tag")) => prism_rtl::Turn::More(Rc::new(TagValue { lx: lx.clone(), env: env.clone(), tg: tg.clone(), args: args.clone() })),
                                    _ => if qk == &Text::lit("Prelude.@Element") {
                                        prism_rtl::Turn::More(Rc::new(ElementBlueprint { lx: lx.clone(), env: env.clone(), args: args.clone(), t: t.clone() }))
                                    } else {
                                        prism_rtl::Turn::More(Rc::new(GlobalCall { lx: lx.clone(), env: env.clone(), qk: qk.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                                    },
                                    _ => unreachable!("no arm matched"),
                                },
                                None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("a call of {}, which nothing declares", &nkey))), t.clone())),
                            }
                        },
                    }
                },
                crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Application { lx: lx.clone(), env: env.clone(), callee: (**x).clone(), args: args.clone(), span: span.clone() })),
                _ => call_then(start_value_of(lx.clone(), env.clone(), callee.clone()), move |value_of_49561: Vl| {
                    let f = value_of_49561;
                    match value_ty(&f) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => call_then(start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_49701: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![start_call(&f, &start_args_49701)])), t.clone()))),
                        _ => call_value(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        }), move |each_49789: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XApply(Rc::new(ref_(&f)), each_49789), t.clone()))),
                    }
                }),
            }
        })
    }
}

/// `Start Application, x`: what the function value is when passed to `@Run`.
pub fn start_application(lx: Lx, env: Env, callee: crate::syntax::Expr, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(Application { lx, env, callee, args, span })
}

/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub fn inline_local_fn(lx: &Lx, env: &Env, c: &crate::syntax::FnClause, args: &Array<crate::syntax::Arg>, t: &crate::lower::model::OutTy) -> Vl {
    let names = each(&c.params, &(|p_: &crate::syntax::Pattern_| plain_binder(lx, p_)));
    if fold(&names, &false, &(|bad: &bool, nm: &Text| *bad || (nm == &Text::lit("")))) {
        Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t.clone())
    } else {
        {
            let (dos, env2) = run_to_end(fold_job(crate::check::errors::range0(&len(&names)), (Array::new(), env.clone()), {
                let names = names.clone();
                let lx = lx.clone();
                let c = c.clone();
                let args = args.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), Nat)| {
                    let names = names.clone();
                    let lx = lx.clone();
                    let c = c.clone();
                    let args = args.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (acc, en) = p0;
                        let i = p1;
                        {
                            let nm = or(&index(&names, &i), &Text::lit(""));
                            let rs = Text::from(format!("{}_{}", &local_name(&lx, &nm), &c.span.start));
                            let v_ = match index(&args, &i) {
                                Some(a) => value_of(&lx, &env, &a.value),
                                None => Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                            };
                            let bt = value_ty(&v_);
                            prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), own(&v_))), bind(&en, &nm, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))))
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
            }));
            Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(fn_body_value(lx, &env2, &c.body))), t.clone())
        }
    }
}

/// The step machine of `InlineLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
/// ```
pub struct InlineLocalFn {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::syntax::FnClause,
    pub args: Array<crate::syntax::Arg>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for InlineLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let t = &self.t;
        let names = each(&c.params, &(|p_: &crate::syntax::Pattern_| plain_binder(lx, p_)));
        if fold(&names, &false, &(|bad: &bool, nm: &Text| *bad || (nm == &Text::lit("")))) {
            prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::lit("a local function whose parameters are not names")), t.clone()))
        } else {
            {
                let args = args.clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                call_value(fold_job(crate::check::errors::range0(&len(&names)), (Array::new(), env.clone()), {
                    let names = names.clone();
                    let lx = lx.clone();
                    let c = c.clone();
                    let args = args.clone();
                    let env = env.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), Nat)| {
                        let names = names.clone();
                        let lx = lx.clone();
                        let c = c.clone();
                        let args = args.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let (acc, en) = p0;
                            let i = p1;
                            {
                                let nm = or(&index(&names, &i), &Text::lit(""));
                                let rs = Text::from(format!("{}_{}", &local_name(&lx, &nm), &c.span.start));
                                let v_ = match index(&args, &i) {
                                    Some(a) => value_of(&lx, &env, &a.value),
                                    None => Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit),
                                };
                                let bt = value_ty(&v_);
                                prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), own(&v_))), bind(&en, &nm, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))))
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
                }), move |fold_50375: (Array<crate::lower::model::Do>, Env)| {
                    let (dos, env2) = fold_50375;
                    call_then(start_fn_body_value(lx.clone(), env2.clone(), c.body.clone()), move |fn_body_value_50821: crate::lower::model::Ex| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(fn_body_value_50821)), t.clone())))
                })
            }
        }
    }
}

/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_inline_local_fn(lx: Lx, env: Env, c: crate::syntax::FnClause, args: Array<crate::syntax::Arg>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(InlineLocalFn { lx, env, c, args, t })
}

/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match get(&env.spans, &place_key(lx, &e.span)) {
        Some(v_) => ref_(&v_),
        None => argument_by_kind(lx, env, e),
    }
}

/// The step machine of `Argument`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Argument: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Argument {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Argument {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match get(&env.spans, &place_key(lx, &e.span)) {
            Some(v_) => prism_rtl::Turn::Finished(ref_(&v_)),
            None => prism_rtl::Turn::More(Rc::new(ArgumentByKind { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        }
    }
}

/// `Start Argument, x`: what the function value is when passed to `@Run`.
pub fn start_argument(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Argument { lx, env, e })
}

/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn argument_by_kind(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::ELambda(ps_opt, body) => crate::lower::model::Ex::XRef(Rc::new(lambda_arg(lx, env, &or(ps_opt, &Array::new()), &**body, &lambda_param_tys(lx, e, &len(&or(ps_opt, &Array::new())))))),
        crate::syntax::ExprKind::EGroup(x) => argument(lx, env, &**x),
        crate::syntax::ExprKind::EName(n) => {
            let t = type_at(lx, &e.span);
            match peel(&t) {
                crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                    let local_opt = if &len(&n.path_) == &Nat::from(1u32) {
                        get(&env.names, &name_key_at(lx, env, n, &e.span))
                    } else {
                        None
                    };
                    match &local_opt {
                        Some(_) => closure_ref(&value_of(lx, env, e)),
                        None => {
                            let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                            match &qk_opt {
                                Some(qk) => if crate::check::env::has_key(&lx.g.ctors, qk) {
                                    closure_ref(&value_of(lx, env, e))
                                } else {
                                    crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(value_path(lx, qk))))
                                },
                                None => ref_(&value_of(lx, env, e)),
                            }
                        },
                    }
                },
                _ => ref_(&value_of(lx, env, e)),
            }
        },
        _ => ref_(&value_of(lx, env, e)),
    }
}

/// The step machine of `ArgumentByKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct ArgumentByKind {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ArgumentByKind {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                let ps_opt = ps_opt.clone();
                let body = (**body).clone();
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_lambda_param_tys(lx.clone(), e.clone(), len(&or(&ps_opt, &Array::new()))), move |lambda_param_tys_51259: Array<crate::lower::model::OutTy>| call_then(start_lambda_arg(lx.clone(), env.clone(), or(&ps_opt, &Array::new()), body.clone(), lambda_param_tys_51259), move |lambda_arg_51217: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(lambda_arg_51217)))))
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            crate::syntax::ExprKind::EName(n) => {
                let t = type_at(lx, &e.span);
                match peel(&t) {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => {
                        let local_opt = if &len(&n.path_) == &Nat::from(1u32) {
                            get(&env.names, &name_key_at(lx, env, n, &e.span))
                        } else {
                            None
                        };
                        match &local_opt {
                            Some(_) => {
                                let e = e.clone();
                                let env = env.clone();
                                let lx = lx.clone();
                                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_51621: Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_51621)))
                            },
                            None => {
                                let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                                match &qk_opt {
                                    Some(qk) => if crate::check::env::has_key(&lx.g.ctors, qk) {
                                        {
                                            let e = e.clone();
                                            let env = env.clone();
                                            let lx = lx.clone();
                                            call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_51849: Vl| prism_rtl::Turn::Finished(closure_ref(&value_of_51849)))
                                        }
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XPath(value_path(lx, qk)))))
                                    },
                                    None => {
                                        let e = e.clone();
                                        let env = env.clone();
                                        let lx = lx.clone();
                                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_51945: Vl| prism_rtl::Turn::Finished(ref_(&value_of_51945)))
                                    },
                                }
                            },
                        }
                    },
                    _ => {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_51993: Vl| prism_rtl::Turn::Finished(ref_(&value_of_51993)))
                    },
                }
            },
            _ => {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_52033: Vl| prism_rtl::Turn::Finished(ref_(&value_of_52033)))
            },
        }
    }
}

/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
pub fn start_argument_by_kind(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ArgumentByKind { lx, env, e })
}

/// ```prism
/// ClosureRef: fn Vl -> Ex
/// ```
pub fn closure_ref(vl0: &Vl) -> crate::lower::model::Ex {
    match vl0 {
        Vl::VlPlace(x, Holding::ByRef, t) => x.clone(),
        Vl::VlPlace(x, _, t) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
        Vl::VlOwned(x, t) => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(x.clone())))),
    }
}

/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub fn tag_value(lx: &Lx, env: &Env, tg: &crate::check::env::TagInfo, args: &Array<crate::syntax::Arg>) -> Vl {
    let (variant, struct_path) = tag_paths(lx, tg);
    let t = crate::lower::model::OutTy::OutNamed(kind_path(lx, &tg.kind), Array::new());
    match &tg.kind {
        m52784_0 if (m52784_0 == &Text::lit("Element")) => Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg.name))), t.clone()),
        m52784_1 if (m52784_1 == &Text::lit("Prelude.Fault")) => Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg.name))), t.clone()),
        _ => {
            let named = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
            let fields = run_to_end(each_job(crate::check::errors::range0(&len(&tg.fields)), {
                let tg = tg.clone();
                let named = named;
                let args = args.clone();
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: Nat| {
                    let tg = tg.clone();
                    let named = named;
                    let args = args.clone();
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let (fname, _) = or(&index(&tg.fields, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            let arg_opt = if named {
                                crate::lower::node_::tag_arg(&args, &fname)
                            } else {
                                match index(&args, &i) {
                                    Some(a) => Some(a.value.clone()),
                                    None => None,
                                }
                            };
                            let v_ = match &arg_opt {
                                Some(x) => own(&value_of(&lx, &env, x)),
                                None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                            };
                            prism_rtl::Turn::Finished((snake(&fname), v_.clone()))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
            }));
            Vl::VlOwned(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), fields.clone())])), t.clone())
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
/// ```
pub struct TagValue {
    pub lx: Lx,
    pub env: Env,
    pub tg: crate::check::env::TagInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Vl> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let tg = &self.tg;
        let args = &self.args;
        let (variant, struct_path) = tag_paths(lx, tg);
        let t = crate::lower::model::OutTy::OutNamed(kind_path(lx, &tg.kind), Array::new());
        match &tg.kind {
            m52784_0 if (m52784_0 == &Text::lit("Element")) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("an element as a plain value ({}): a live element comes from its host", &tg.name))), t.clone())),
            m52784_1 if (m52784_1 == &Text::lit("Prelude.Fault")) => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("a fault kind applied ({})", &tg.name))), t.clone())),
            _ => {
                let named = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
                let args = args.clone();
                let env = env.clone();
                let lx = lx.clone();
                let tg = tg.clone();
                call_value(each_job(crate::check::errors::range0(&len(&tg.fields)), {
                    let tg = tg.clone();
                    let named = named;
                    let args = args.clone();
                    let lx = lx.clone();
                    let env = env.clone();
                    Rc::new(move |p0: Nat| {
                        let tg = tg.clone();
                        let named = named;
                        let args = args.clone();
                        let lx = lx.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let (fname, _) = or(&index(&tg.fields, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                let arg_opt = if named {
                                    crate::lower::node_::tag_arg(&args, &fname)
                                } else {
                                    match index(&args, &i) {
                                        Some(a) => Some(a.value.clone()),
                                        None => None,
                                    }
                                };
                                let v_ = match &arg_opt {
                                    Some(x) => own(&value_of(&lx, &env, x)),
                                    None => crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new()),
                                };
                                prism_rtl::Turn::Finished((snake(&fname), v_.clone()))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::Ex)>>>
                }), move |each_53110: Array<(Text, crate::lower::model::Ex)>| {
                    let fields = each_53110;
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCtor(variant.clone(), Array::from(vec![crate::lower::model::Ex::XRecord(struct_path.clone(), fields.clone())])), t.clone()))
                })
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(lx: Lx, env: Env, tg: crate::check::env::TagInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(TagValue { lx, env, tg, args })
}

/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn global_call(lx: &Lx, env: &Env, qk: &Text, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    match get(&lx.g.ctors, qk) {
        Some(c) => ctor_app(lx, env, &c, args, span),
        None => match get(&lx.g.vals, qk) {
            Some(v_) => if &v_.sort == &Text::lit("method") {
                method_call(lx, env, &v_, args, span, t)
            } else {
                if &v_.home == &Text::lit("Prelude") {
                    prelude_call(lx, env, qk, args, span, t)
                } else {
                    Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(lx, qk), args_for(lx, env, &v_, args)), t.clone())
                }
            },
            None => Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk))), t.clone()),
        },
    }
}

/// The step machine of `GlobalCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct GlobalCall {
    pub lx: Lx,
    pub env: Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for GlobalCall {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        match get(&lx.g.ctors, qk) {
            Some(c) => prism_rtl::Turn::More(Rc::new(CtorApp { lx: lx.clone(), env: env.clone(), c: c.clone(), args: args.clone(), span: span.clone() })),
            None => match get(&lx.g.vals, qk) {
                Some(v_) => if &v_.sort == &Text::lit("method") {
                    prism_rtl::Turn::More(Rc::new(MethodCall { lx: lx.clone(), env: env.clone(), v_: v_.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                } else {
                    if &v_.home == &Text::lit("Prelude") {
                        prism_rtl::Turn::More(Rc::new(PreludeCall { lx: lx.clone(), env: env.clone(), qk: qk.clone(), args: args.clone(), span: span.clone(), t: t.clone() }))
                    } else {
                        {
                            let args = args.clone();
                            let env = env.clone();
                            let lx = lx.clone();
                            let qk = qk.clone();
                            let t = t.clone();
                            call_then(start_args_for(lx.clone(), env.clone(), v_.clone(), args.clone()), move |args_for_54150: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(value_path(&lx, &qk), args_for_54150), t.clone())))
                        }
                    }
                },
                None => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("a call of {}", qk))), t.clone())),
            },
        }
    }
}

/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
pub fn start_global_call(lx: Lx, env: Env, qk: Text, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(GlobalCall { lx, env, qk, args, span, t })
}

/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub fn args_for(lx: &Lx, env: &Env, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let ps = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, xs, _) => xs.clone(),
        _ => Array::new(),
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let ps = ps.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    let is_try = match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TySig(m54716_0_0, _) if (&m54716_0_0 == &Text::lit("~")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let is_error = match peel(&type_at(&lx, &a.value.span)) {
                        crate::check::types::Ty::TyCon(m54833_0_0, _) if (&m54833_0_0 == &Text::lit("Prelude.Error")) => true,
                        _ => false,
                        _ => unreachable!("no arm matched"),
                    };
                    let to_unbounded = match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                        crate::check::types::Ty::TyFn(_, _, _) => true,
                        _ => false,
                    };
                    if is_try && is_error {
                        call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_55182: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![own(&value_of_55182)]))))))
                    } else {
                        if to_unbounded {
                            call_then(start_as_job_value(lx.clone(), env.clone(), a.value.clone()), move |as_job_value_55247: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_55247))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `ArgsFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
/// ```
pub struct ArgsFor {
    pub lx: Lx,
    pub env: Env,
    pub v_: crate::check::env::ValInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for ArgsFor {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let v_ = &self.v_;
        let args = &self.args;
        let ps = match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, xs, _) => xs.clone(),
            _ => Array::new(),
        };
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let ps = ps.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        let is_try = match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TySig(m54716_0_0, _) if (&m54716_0_0 == &Text::lit("~")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let is_error = match peel(&type_at(&lx, &a.value.span)) {
                            crate::check::types::Ty::TyCon(m54833_0_0, _) if (&m54833_0_0 == &Text::lit("Prelude.Error")) => true,
                            _ => false,
                            _ => unreachable!("no arm matched"),
                        };
                        let to_unbounded = match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
                            crate::check::types::Ty::TyFn(_, _, _) => true,
                            _ => false,
                        };
                        if is_try && is_error {
                            call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_55182: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![own(&value_of_55182)]))))))
                        } else {
                            if to_unbounded {
                                call_then(start_as_job_value(lx.clone(), env.clone(), a.value.clone()), move |as_job_value_55247: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XRef(Rc::new(as_job_value_55247))))
                            } else {
                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
pub fn start_args_for(lx: Lx, env: Env, v_: crate::check::env::ValInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(ArgsFor { lx, env, v_, args })
}

/// ```prism
/// let dummyExpr
/// ```
pub fn dummy_expr() -> crate::syntax::Expr {
    crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub fn ctor_app(lx: &Lx, env: &Env, c: &crate::check::env::CtorInfo, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, span)));
    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
    let ty_path = path_in(lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
    let vals = ctor_args(lx, env, c, args);
    match &c.owner {
        m55864_0 if (m55864_0 == &Text::lit("Bool")) => Vl::VlOwned(crate::lower::model::Ex::XBool(&c.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool),
        m55864_1 if (m55864_1 == &Text::lit("Prelude.Error")) => {
            let kind = or(&index(&vals, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
            let msg = or(&index(&vals, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
            let made = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind.clone(), msg.clone()]));
            match &t {
                crate::lower::model::OutTy::OutRes(_) => Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made.clone()])), t.clone()),
                _ => Vl::VlOwned(made.clone(), crate::lower::model::OutTy::OutError),
            }
        },
        _ => match &owner.body {
            crate::check::env::TyBody::BRecord(fs) => if &len(&c.fields) == &Nat::from(0u32) {
                Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path.clone()), t.clone())
            } else {
                Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&c.fields)), &(|i: &Nat| (snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&vals, i), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t.clone())
            },
            crate::check::env::TyBody::BChoice(cases) => {
                let is_unit_type = ((&len(cases) == &Nat::from(1u32)) && (&len(&c.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c.name));
                let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
                let path_ = if is_unit_type || is_newtype {
                    ty_path.clone()
                } else {
                    Text::from(format!("{}::{}", &ty_path, &camel(&crate::check::types::bare_name(&c.name))))
                };
                if &len(&c.args) == &Nat::from(0u32) {
                    Vl::VlOwned(crate::lower::model::Ex::XPath(path_.clone()), t.clone())
                } else {
                    Vl::VlOwned(crate::lower::model::Ex::XCtor(path_.clone(), vals.clone()), t.clone())
                }
            },
            _ => Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c.owner))), t.clone()),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
/// ```
pub struct CtorApp {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::check::env::CtorInfo,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let args = args.clone();
        let c = c.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &span))), move |out_ty_of_55663: crate::lower::model::OutTy| {
            let t = out_ty_of_55663;
            let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
            let ty_path = path_in(&lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
            call_then(start_ctor_args(lx.clone(), env.clone(), c.clone(), args.clone()), move |ctor_args_55834: Array<crate::lower::model::Ex>| {
                let vals = ctor_args_55834;
                match &c.owner {
                    m55864_0 if (m55864_0 == &Text::lit("Bool")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBool(&c.name == &Text::lit("True")), crate::lower::model::OutTy::OutBool)),
                    m55864_1 if (m55864_1 == &Text::lit("Prelude.Error")) => {
                        let kind = or(&index(&vals, &Nat::from(0u32)), &crate::lower::model::Ex::XStr(Text::lit("")));
                        let msg = or(&index(&vals, &Nat::from(1u32)), &crate::lower::model::Ex::XText(Text::lit("")));
                        let made = crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![kind.clone(), msg.clone()]));
                        match &t {
                            crate::lower::model::OutTy::OutRes(_) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![made.clone()])), t.clone())),
                            _ => prism_rtl::Turn::Finished(Vl::VlOwned(made.clone(), crate::lower::model::OutTy::OutError)),
                        }
                    },
                    _ => match &owner.body {
                        crate::check::env::TyBody::BRecord(fs) => if &len(&c.fields) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XPath(ty_path.clone()), t.clone()))
                        } else {
                            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&c.fields)), &(|i: &Nat| (snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&vals, i), &crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())))))), t.clone()))
                        },
                        crate::check::env::TyBody::BChoice(cases) => {
                            let is_unit_type = ((&len(cases) == &Nat::from(1u32)) && (&len(&c.args) == &Nat::from(0u32))) && crate::check::env::is_lower_text(&crate::check::types::bare_name(&c.name));
                            let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
                            let path_ = if is_unit_type || is_newtype {
                                ty_path.clone()
                            } else {
                                Text::from(format!("{}::{}", &ty_path, &camel(&crate::check::types::bare_name(&c.name))))
                            };
                            if &len(&c.args) == &Nat::from(0u32) {
                                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XPath(path_.clone()), t.clone()))
                            } else {
                                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCtor(path_.clone(), vals.clone()), t.clone()))
                            }
                        },
                        _ => prism_rtl::Turn::Finished(Vl::VlOwned(refusal(&Text::from(format!("a constructor of {}", &c.owner))), t.clone())),
                    },
                    _ => unreachable!("no arm matched"),
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(lx: Lx, env: Env, c: crate::check::env::CtorInfo, args: Array<crate::syntax::Arg>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(CtorApp { lx, env, c, args, span })
}

/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub fn ctor_fn(lx: &Lx, c: &crate::check::env::CtorInfo, pts: &Array<crate::lower::model::OutTy>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy, job: &bool) -> Vl {
    let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
    let fakes = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
    let env = fold(&crate::check::errors::range0(&len(pts)), &empty_env(), &(|en: &Env, i: &Nat| bind_span(en, &place_key(lx, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i }), &Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names, i), &Text::lit("a"))), if *job { Holding::Owned } else { Holding::ByRef }, or(&index(pts, i), &crate::lower::model::OutTy::OutUnit)))));
    let made = own(&ctor_app(lx, &env, c, &fakes, span));
    if *job {
        {
            let a = match t {
                crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            let pa = if &len(pts) == &Nat::from(1u32) {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
            } else {
                crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
            };
            Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made.clone()]))))]))))]))), t.clone()), t.clone())
        }
    } else {
        {
            let pas = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names, i), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(pts, i), &crate::lower::model::OutTy::OutUnit))))));
            Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(made.clone()))])), t.clone())
        }
    }
}

/// The step machine of `CtorFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
/// ```
pub struct CtorFn {
    pub lx: Lx,
    pub c: crate::check::env::CtorInfo,
    pub pts: Array<crate::lower::model::OutTy>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
    pub job: bool,
}

impl prism_rtl::Job<Vl> for CtorFn {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let c = &self.c;
        let pts = &self.pts;
        let span = &self.span;
        let t = &self.t;
        let job = &self.job;
        let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
        let fakes = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| crate::syntax::Arg { name: None, value: crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EAbsent), span: crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }));
        let env = fold(&crate::check::errors::range0(&len(pts)), &empty_env(), &(|en: &Env, i: &Nat| bind_span(en, &place_key(lx, &crate::syntax::Range { start: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i, end: &Nat::from_int(Int::from(4000000000i64)).unwrap() + i }), &Vl::VlPlace(crate::lower::model::Ex::XVar(or(&index(&names, i), &Text::lit("a"))), if *job { Holding::Owned } else { Holding::ByRef }, or(&index(pts, i), &crate::lower::model::OutTy::OutUnit)))));
        let c = c.clone();
        let job = *job;
        let lx = lx.clone();
        let pts = pts.clone();
        let span = span.clone();
        let t = t.clone();
        call_then(start_ctor_app(lx.clone(), env.clone(), c.clone(), fakes.clone(), span.clone()), move |ctor_app_57982: Vl| {
            let made = own(&ctor_app_57982);
            if job {
                {
                    let a = match &t {
                        crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                        _ => crate::lower::model::OutTy::OutUnit,
                    };
                    let pa = if &len(&pts) == &Nat::from(1u32) {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
                    } else {
                        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
                    };
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![made.clone()]))))]))))]))), t.clone()), t.clone()))
                }
            } else {
                {
                    let pas = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(or(&index(&names, i), &Text::lit("a")))), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(made.clone()))])), t.clone()))
                }
            }
        })
    }
}

/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_fn(lx: Lx, c: crate::check::env::CtorInfo, pts: Array<crate::lower::model::OutTy>, span: crate::syntax::Range, t: crate::lower::model::OutTy, job: bool) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(CtorFn { lx, c, pts, span, t, job })
}

/// ```prism
/// IsNamedArg: fn Arg -> Bool
/// ```
pub fn is_named_arg(a: &crate::syntax::Arg) -> bool {
    match &a.name {
        Some(_) => true,
        None => false,
    }
}

/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub fn ctor_args(lx: &Lx, env: &Env, c: &crate::check::env::CtorInfo, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let named = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
    let ordered = if named {
        each(&c.fields, &(|f: &Text| fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
            Some(n) => if &n.name == f { Some(a.value.clone()) } else { found_opt.clone() },
            None => found_opt.clone(),
        }))))
    } else {
        each(args, &(|a: &crate::syntax::Arg| Some(a.value.clone())))
    };
    run_to_end(each_job(crate::check::errors::range0(&len(&ordered)), {
        let ordered = ordered.clone();
        let lx = lx.clone();
        let env = env.clone();
        let c = c.clone();
        Rc::new(move |p0: Nat| {
            let ordered = ordered.clone();
            let lx = lx.clone();
            let env = env.clone();
            let c = c.clone();
            entered(once_job(move || {
                let i = p0;
                match index(&ordered, &i) {
                    Some(Some(x)) => call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_59247: Vl| {
                        let v_ = own(&value_of_59247);
                        if (&c.owner == &Text::lit("Prelude.Error")) && (&i == &Nat::from(0u32)) {
                            prism_rtl::Turn::Finished(v_.clone())
                        } else {
                            if rc_field(&lx, &c.name, &i) {
                                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_.clone()])))
                            } else {
                                prism_rtl::Turn::Finished(v_.clone())
                            }
                        }
                    }),
                    _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `CtorArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
/// ```
pub struct CtorArgs {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::check::env::CtorInfo,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for CtorArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let args = &self.args;
        let named = fold(args, &false, &(|f: &bool, a: &crate::syntax::Arg| *f || is_named_arg(a)));
        let ordered = if named {
            each(&c.fields, &(|f: &Text| fold(args, &None, &(|found_opt: &Option<crate::syntax::Expr>, a: &crate::syntax::Arg| match &a.name {
                Some(n) => if &n.name == f { Some(a.value.clone()) } else { found_opt.clone() },
                None => found_opt.clone(),
            }))))
        } else {
            each(args, &(|a: &crate::syntax::Arg| Some(a.value.clone())))
        };
        each_job(crate::check::errors::range0(&len(&ordered)), {
            let ordered = ordered.clone();
            let lx = lx.clone();
            let env = env.clone();
            let c = c.clone();
            Rc::new(move |p0: Nat| {
                let ordered = ordered.clone();
                let lx = lx.clone();
                let env = env.clone();
                let c = c.clone();
                entered(once_job(move || {
                    let i = p0;
                    match index(&ordered, &i) {
                        Some(Some(x)) => call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_59247: Vl| {
                            let v_ = own(&value_of_59247);
                            if (&c.owner == &Text::lit("Prelude.Error")) && (&i == &Nat::from(0u32)) {
                                prism_rtl::Turn::Finished(v_.clone())
                            } else {
                                if rc_field(&lx, &c.name, &i) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![v_.clone()])))
                                } else {
                                    prism_rtl::Turn::Finished(v_.clone())
                                }
                            }
                        }),
                        _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCall(Text::lit("Default::default"), Array::new())),
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_args(lx: Lx, env: Env, c: crate::check::env::CtorInfo, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(CtorArgs { lx, env, c, args })
}

/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub fn method_call(lx: &Lx, env: &Env, v_: &crate::check::env::ValInfo, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    let cls = or(&index(&each(&v_.scheme.bounds, &(|(_, c): &(Text, Text)| c.clone())), &Nat::from(0u32)), &Text::lit(""));
    let m = crate::check::types::bare_name(&v_.qk);
    let vals = run_to_end(each_job(args.clone(), {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: crate::syntax::Arg| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let a = p0;
                prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<Vl>>>
    }));
    if crate::syntax::lexer::has_prefix(&cls, &Text::lit("Prelude.")) {
        prelude_method(lx, &cls, &m, &vals, span, t)
    } else {
        {
            let tr = or(&get(&lx.g.traits, &cls), &dummy_trait_info());
            let path_ = path_in(lx, &tr.home, &Text::from(format!("{}::{}", &camel(&crate::check::types::bare_name(&cls)), &snake(&m))));
            Vl::VlOwned(crate::lower::model::Ex::XCall(path_.clone(), run_to_end(each_job(args.clone(), {
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }))), t.clone())
        }
    }
}

/// The step machine of `MethodCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
/// ```
pub struct MethodCall {
    pub lx: Lx,
    pub env: Env,
    pub v_: crate::check::env::ValInfo,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for MethodCall {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let v_ = &self.v_;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        let cls = or(&index(&each(&v_.scheme.bounds, &(|(_, c): &(Text, Text)| c.clone())), &Nat::from(0u32)), &Text::lit(""));
        let m = crate::check::types::bare_name(&v_.qk);
        let args = args.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(each_job(args.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<Vl>>>
        }), move |each_59865: Array<Vl>| {
            let vals = each_59865;
            if crate::syntax::lexer::has_prefix(&cls, &Text::lit("Prelude.")) {
                prism_rtl::Turn::More(Rc::new(PreludeMethod { lx: lx.clone(), cls: cls.clone(), m: m.clone(), vals: vals.clone(), span: span.clone(), t: t.clone() }))
            } else {
                {
                    let tr = or(&get(&lx.g.traits, &cls), &dummy_trait_info());
                    let path_ = path_in(&lx, &tr.home, &Text::from(format!("{}::{}", &camel(&crate::check::types::bare_name(&cls)), &snake(&m))));
                    call_value(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_60150: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(path_.clone(), each_60150), t.clone())))
                }
            }
        })
    }
}

/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
pub fn start_method_call(lx: Lx, env: Env, v_: crate::check::env::ValInfo, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(MethodCall { lx, env, v_, args, span, t })
}

/// ```prism
/// let dummyTraitInfo
/// ```
pub fn dummy_trait_info() -> crate::check::env::TraitInfo {
    crate::check::env::TraitInfo { name: Text::lit(""), home: Text::lit(""), param: Text::lit("a"), supers: Array::new(), methods: Array::new(), defaults: Array::new(), assocs: Array::new(), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub fn prelude_method(lx: &Lx, cls: &Text, m: &Text, vals: &Array<Vl>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    let a = or(&index(vals, &Nat::from(0u32)), &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    let b = or(&index(vals, &Nat::from(1u32)), &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    match m {
        m60569_0 if (m60569_0 == &Text::lit("Show")) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![ref_(&a)])), crate::lower::model::OutTy::OutText),
        m60569_1 if (m60569_1 == &Text::lit("Compare")) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![ref_(&a), ref_(&b)])), t.clone()),
        m60569_2 if (m60569_2 == &Text::lit("Children")) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![ref_(&a)])), t.clone()),
        _ => op_value(lx, m, &a, &b, span, t),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `PreludeMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
/// ```
pub struct PreludeMethod {
    pub lx: Lx,
    pub cls: Text,
    pub m: Text,
    pub vals: Array<Vl>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for PreludeMethod {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let cls = &self.cls;
        let m = &self.m;
        let vals = &self.vals;
        let span = &self.span;
        let t = &self.t;
        let a = or(&index(vals, &Nat::from(0u32)), &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        let b = or(&index(vals, &Nat::from(1u32)), &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
        match m {
            m60569_0 if (m60569_0 == &Text::lit("Show")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![ref_(&a)])), crate::lower::model::OutTy::OutText)),
            m60569_1 if (m60569_1 == &Text::lit("Compare")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("compare"), Array::from(vec![ref_(&a), ref_(&b)])), t.clone())),
            m60569_2 if (m60569_2 == &Text::lit("Children")) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("children"), Array::from(vec![ref_(&a)])), t.clone())),
            _ => prism_rtl::Turn::Finished(op_value(lx, m, &a, &b, span, t)),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_method(lx: Lx, cls: Text, m: Text, vals: Array<Vl>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PreludeMethod { lx, cls, m, vals, span, t })
}

/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub fn binary_value(lx: &Lx, env: &Env, op: &Text, l: &crate::syntax::Expr, r: &crate::syntax::Expr, span: &crate::syntax::Range) -> Vl {
    let t = out_ty_of(lx, &peel(&type_at(lx, span)));
    match op {
        m60997_0 if (m60997_0 == &Text::lit("and")) => Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(as_bool(&value_of(lx, env, l))), Rc::new(as_bool(&value_of(lx, env, r)))), crate::lower::model::OutTy::OutBool),
        m60997_1 if (m60997_1 == &Text::lit("or")) => Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(as_bool(&value_of(lx, env, l))), Rc::new(as_bool(&value_of(lx, env, r)))), crate::lower::model::OutTy::OutBool),
        m60997_2 if (m60997_2 == &Text::lit("on")) => value_of(lx, env, l),
        _ => op_value(lx, op, &value_of(lx, env, l), &value_of(lx, env, r), span, &t),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BinaryValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
/// ```
pub struct BinaryValue {
    pub lx: Lx,
    pub env: Env,
    pub op: Text,
    pub l: crate::syntax::Expr,
    pub r: crate::syntax::Expr,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for BinaryValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let op = &self.op;
        let l = &self.l;
        let r = &self.r;
        let span = &self.span;
        let env = env.clone();
        let l = l.clone();
        let lx = lx.clone();
        let op = op.clone();
        let r = r.clone();
        let span = span.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &span))), move |out_ty_of_60956: crate::lower::model::OutTy| {
            let t = out_ty_of_60956;
            match &op {
                m60997_0 if (m60997_0 == &Text::lit("and")) => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_61051: Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_61082: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(as_bool(&value_of_61051)), Rc::new(as_bool(&value_of_61082))), crate::lower::model::OutTy::OutBool)))),
                m60997_1 if (m60997_1 == &Text::lit("or")) => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_61156: Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_61187: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("||"), Rc::new(as_bool(&value_of_61156)), Rc::new(as_bool(&value_of_61187))), crate::lower::model::OutTy::OutBool)))),
                m60997_2 if (m60997_2 == &Text::lit("on")) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: l.clone() })),
                _ => call_then(start_value_of(lx.clone(), env.clone(), l.clone()), move |value_of_61453: Vl| call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_61475: Vl| prism_rtl::Turn::Finished(op_value(&lx, &op, &value_of_61453, &value_of_61475, &span, &t)))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
pub fn start_binary_value(lx: Lx, env: Env, op: Text, l: crate::syntax::Expr, r: crate::syntax::Expr, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(BinaryValue { lx, env, op, l, r, span })
}

/// ```prism
/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
/// ```
pub fn op_value(lx: &Lx, op: &Text, a: &Vl, b: &Vl, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    let at_ = value_ty(a);
    let generic = match &at_ {
        crate::lower::model::OutTy::OutGen(_) => true,
        _ => false,
    };
    if crate::check::types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">=")]), op) {
        Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(ref_(a)), Rc::new(ref_(b))), crate::lower::model::OutTy::OutBool)
    } else {
        if op == &Text::lit("mod") {
            Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(ref_(a)), Text::lit("modulo"), Array::from(vec![ref_(b)])), t.clone())
        } else {
            if generic {
                Vl::VlOwned(crate::lower::model::Ex::XCall(Text::from(format!("Num::{}", &num_method(op))), Array::from(vec![ref_(a), ref_(b)])), t.clone())
            } else {
                if op == &Text::lit("/") {
                    if &at_ == &crate::lower::model::OutTy::OutFloat {
                        Vl::VlOwned(crate::lower::model::Ex::XBin(Text::lit("/"), Rc::new(copy(a)), Rc::new(copy(b))), t.clone())
                    } else {
                        Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(ref_(a)), Text::lit("div"), Array::from(vec![ref_(b)])), t.clone())
                    }
                } else {
                    if op == &Text::lit("-?") {
                        if &at_ == &crate::lower::model::OutTy::OutNat {
                            Vl::VlOwned(crate::lower::model::Ex::XMethod(Rc::new(ref_(a)), Text::lit("checked_sub"), Array::from(vec![ref_(b)])), t.clone())
                        } else {
                            Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("-"), Rc::new(ref_(a)), Rc::new(ref_(b)))])), t.clone())
                        }
                    } else {
                        if op == &Text::lit("+?") {
                            Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("+"), Rc::new(ref_(a)), Rc::new(ref_(b)))])), t.clone())
                        } else {
                            if op == &Text::lit("*?") {
                                Vl::VlOwned(crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XBin(Text::lit("*"), Rc::new(ref_(a)), Rc::new(ref_(b)))])), t.clone())
                            } else {
                                if is_copy(&at_) {
                                    Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(copy(a)), Rc::new(copy(b))), t.clone())
                                } else {
                                    Vl::VlOwned(crate::lower::model::Ex::XBin(op.clone(), Rc::new(ref_(a)), Rc::new(ref_(b))), t.clone())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// NumMethod: fn Text -> Text
/// ```
pub fn num_method(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("+")) => Text::lit("add"),
        c1_0 if (c1_0 == &Text::lit("-")) => Text::lit("sub"),
        c2_0 if (c2_0 == &Text::lit("*")) => Text::lit("mul"),
        c3_0 if (c3_0 == &Text::lit("/")) => Text::lit("div_opt"),
        c4_0 if (c4_0 == &Text::lit("+?")) => Text::lit("add_opt"),
        c5_0 if (c5_0 == &Text::lit("-?")) => Text::lit("sub_opt"),
        c6_0 if (c6_0 == &Text::lit("*?")) => Text::lit("mul_opt"),
        other => Text::lit("add"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub fn prelude_call(lx: &Lx, env: &Env, qk: &Text, args: &Array<crate::syntax::Arg>, span: &crate::syntax::Range, t: &crate::lower::model::OutTy) -> Vl {
    let name = or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk)));
    let first_ = match index(args, &Nat::from(0u32)) {
        Some(a) => out_ty_of(lx, &peel(&type_at(lx, &a.value.span))),
        None => crate::lower::model::OutTy::OutUnit,
    };
    let variant = prelude_variant(&name, &first_);
    match prelude_job(lx, env, &variant, args) {
        Some(job) => Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job.clone()])), t.clone()),
        None => Vl::VlOwned(crate::lower::model::Ex::XCall(prelude_path(lx, &variant), run_to_end(each_job(args.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: crate::syntax::Arg| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                }))
            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }))), t.clone()),
    }
}

/// The step machine of `PreludeCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
/// ```
pub struct PreludeCall {
    pub lx: Lx,
    pub env: Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub span: crate::syntax::Range,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for PreludeCall {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let span = &self.span;
        let t = &self.t;
        let name = or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk)));
        let first_ = match index(args, &Nat::from(0u32)) {
            Some(a) => out_ty_of(lx, &peel(&type_at(lx, &a.value.span))),
            None => crate::lower::model::OutTy::OutUnit,
        };
        let variant = prelude_variant(&name, &first_);
        let args = args.clone();
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        call_then(start_prelude_job(lx.clone(), env.clone(), variant.clone(), args.clone()), move |prelude_job_63485: Option<crate::lower::model::Ex>| match prelude_job_63485 {
            Some(job) => prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(Text::lit("run_to_end"), Array::from(vec![job.clone()])), t.clone())),
            None => call_value(each_job(args.clone(), {
                let lx = lx.clone();
                let env = env.clone();
                Rc::new(move |p0: crate::syntax::Arg| {
                    let lx = lx.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let a = p0;
                        prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |each_63633: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(prelude_path(&lx, &variant), each_63633), t.clone()))),
        })
    }
}

/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_call(lx: Lx, env: Env, qk: Text, args: Array<crate::syntax::Arg>, span: crate::syntax::Range, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PreludeCall { lx, env, qk, args, span, t })
}

/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub fn prelude_job(lx: &Lx, env: &Env, variant: &Text, args: &Array<crate::syntax::Arg>) -> Option<crate::lower::model::Ex> {
    if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant) {
        {
            let last = or(&index(args, &crate::syntax::lexer::dec(&len(args))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
            match out_ty_of(lx, &peel(&type_at(lx, &last.value.span))) {
                crate::lower::model::OutTy::OutJobFn(_, _) => {
                    let front_ = run_to_end(each_job(take(args, &crate::syntax::lexer::dec(&len(args))), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_64499: Vl| prism_rtl::Turn::Finished(own(&value_of_64499)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }));
                    Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", variant)), push(&front_, &as_job_value(lx, env, &last.value))))
                },
                _ => None,
            }
        }
    } else {
        None
    }
}

/// The step machine of `PreludeJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
/// ```
pub struct PreludeJob {
    pub lx: Lx,
    pub env: Env,
    pub variant: Text,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJob {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let variant = &self.variant;
        let args = &self.args;
        if crate::check::types::has_text(&Array::from(vec![Text::lit("fold"), Text::lit("fold_map"), Text::lit("each"), Text::lit("each_map"), Text::lit("filter"), Text::lit("filter_map")]), variant) {
            {
                let last = or(&index(args, &crate::syntax::lexer::dec(&len(args))), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                let args = args.clone();
                let env = env.clone();
                let lx = lx.clone();
                let variant = variant.clone();
                call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &last.value.span))), move |out_ty_of_64339: crate::lower::model::OutTy| match out_ty_of_64339 {
                    crate::lower::model::OutTy::OutJobFn(_, _) => call_value(each_job(take(&args, &crate::syntax::lexer::dec(&len(&args))), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_64499: Vl| prism_rtl::Turn::Finished(own(&value_of_64499)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }), move |each_64453: Array<crate::lower::model::Ex>| {
                        let front_ = each_64453;
                        prism_rtl::Turn::Finished(Some(crate::lower::model::Ex::XCall(Text::from(format!("{}_job", &variant)), push(&front_, &as_job_value(&lx, &env, &last.value)))))
                    }),
                    _ => prism_rtl::Turn::Finished(None),
                })
            }
        } else {
            prism_rtl::Turn::Finished(None)
        }
    }
}

/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job(lx: Lx, env: Env, variant: Text, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJob { lx, env, variant, args })
}

/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub fn prelude_job_call(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> Option<crate::lower::model::Ex> {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => match &*c.kind {
            crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                None
            } else {
                {
                    let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                    match &qk_opt {
                        Some(qk) => match get(&lx.g.vals, qk) {
                            Some(v_) => if &v_.home == &Text::lit("Prelude") {
                                {
                                    let name = or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk)));
                                    let first_ = match index(args, &Nat::from(0u32)) {
                                        Some(a) => out_ty_of(lx, &peel(&type_at(lx, &a.value.span))),
                                        None => crate::lower::model::OutTy::OutUnit,
                                    };
                                    prelude_job(lx, env, &prelude_variant(&name, &first_), args)
                                }
                            } else {
                                None
                            },
                            None => None,
                        },
                        None => None,
                    }
                }
            },
            _ => None,
        },
        _ => None,
    }
}

/// The step machine of `PreludeJobCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
/// ```
pub struct PreludeJobCall {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<crate::lower::model::Ex>> for PreludeJobCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => match &*c.kind {
                crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                    prism_rtl::Turn::Finished(None)
                } else {
                    {
                        let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                        match &qk_opt {
                            Some(qk) => match get(&lx.g.vals, qk) {
                                Some(v_) => if &v_.home == &Text::lit("Prelude") {
                                    {
                                        let name = or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk)));
                                        let first_ = match index(args, &Nat::from(0u32)) {
                                            Some(a) => out_ty_of(lx, &peel(&type_at(lx, &a.value.span))),
                                            None => crate::lower::model::OutTy::OutUnit,
                                        };
                                        prism_rtl::Turn::More(Rc::new(PreludeJob { lx: lx.clone(), env: env.clone(), variant: prelude_variant(&name, &first_), args: args.clone() }))
                                    }
                                } else {
                                    prism_rtl::Turn::Finished(None)
                                },
                                None => prism_rtl::Turn::Finished(None),
                            },
                            None => prism_rtl::Turn::Finished(None),
                        }
                    }
                },
                _ => prism_rtl::Turn::Finished(None),
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
pub fn start_prelude_job_call(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<crate::lower::model::Ex>>> {
    Rc::new(PreludeJobCall { lx, env, e })
}

/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn as_job_value(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::EGroup(x) => as_job_value(lx, env, &**x),
        _ => {
            let target = match peel(&type_at(lx, &e.span)) {
                crate::check::types::Ty::TyFn(_, ps, r) => crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params(lx, &ps)), Rc::new(out_ty_of(lx, &*r))),
                other => out_ty_of(lx, &other),
            };
            let a = match &target {
                crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                _ => crate::lower::model::OutTy::OutUnit,
            };
            match &*e.kind {
                crate::syntax::ExprKind::ELambda(ps_opt, body) => own(&job_lambda(lx, env, &or(ps_opt, &Array::new()), &**body, &target, &a, &enters_lambda(lx, e))),
                _ => {
                    let v_ = value_of(lx, env, e);
                    match value_ty(&v_) {
                        crate::lower::model::OutTy::OutFn(pts, _) => wrap_as_job(&own(&v_), &pts, &target, &a),
                        _ => own(&v_),
                    }
                },
            }
        },
    }
}

/// The step machine of `AsJobValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct AsJobValue {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for AsJobValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            _ => {
                let target = match peel(&type_at(lx, &e.span)) {
                    crate::check::types::Ty::TyFn(_, ps, r) => crate::lower::model::OutTy::OutJobFn(Rc::new(rust_ty_of_params(lx, &ps)), Rc::new(out_ty_of(lx, &*r))),
                    other => out_ty_of(lx, &other),
                };
                let a = match &target {
                    crate::lower::model::OutTy::OutJobFn(x, _) => (**x).clone(),
                    _ => crate::lower::model::OutTy::OutUnit,
                };
                match &*e.kind {
                    crate::syntax::ExprKind::ELambda(ps_opt, body) => {
                        let ps_opt = ps_opt.clone();
                        let body = (**body).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_job_lambda(lx.clone(), env.clone(), or(&ps_opt, &Array::new()), body.clone(), target.clone(), a.clone(), enters_lambda(&lx, &e)), move |job_lambda_66388: Vl| prism_rtl::Turn::Finished(own(&job_lambda_66388)))
                    },
                    _ => {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_66509: Vl| {
                            let v_ = value_of_66509;
                            match value_ty(&v_) {
                                crate::lower::model::OutTy::OutFn(pts, _) => prism_rtl::Turn::Finished(wrap_as_job(&own(&v_), &pts, &target, &a)),
                                _ => prism_rtl::Turn::Finished(own(&v_)),
                            }
                        })
                    },
                }
            },
        }
    }
}

/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
pub fn start_as_job_value(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(AsJobValue { lx, env, e })
}

/// ```prism
/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
/// ```
pub fn wrap_as_job(f: &crate::lower::model::Ex, pts: &Array<crate::lower::model::OutTy>, target: &crate::lower::model::OutTy, a: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let names = each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| Text::from(format!("a{}", i))));
    let pa = if &len(pts) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("a0"))), a.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
    };
    let call = crate::lower::model::Ex::XApply(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f"))), each(&names, &(|nm: &Text| crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XVar(nm.clone()))))));
    let body = crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(Text::lit("f")))))]), Rc::new(crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![call.clone()]))))]))));
    crate::lower::model::Ex::XBlock(Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(Text::lit("f")), f.clone())]), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(body.clone()))]))), target.clone())))
}

/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub fn named_args_owned(lx: &Lx, env: &Env, qk: &Text, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let (ps, _) = scheme_parts(lx, qk);
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let ps = ps.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_67812: Vl| prism_rtl::Turn::Finished(own(&value_of_67812))),
                        crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_67935: Vl| prism_rtl::Turn::Finished(own(&value_of_67935))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `NamedArgsOwned`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
/// ```
pub struct NamedArgsOwned {
    pub lx: Lx,
    pub env: Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for NamedArgsOwned {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let (ps, _) = scheme_parts(lx, qk);
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let ps = ps.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let ps = ps.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match peel(&or(&index(&ps, &i), &crate::check::types::Ty::TyErr)) {
                            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_67812: Vl| prism_rtl::Turn::Finished(own(&value_of_67812))),
                            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_67935: Vl| prism_rtl::Turn::Finished(own(&value_of_67935))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
pub fn start_named_args_owned(lx: Lx, env: Env, qk: Text, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(NamedArgsOwned { lx, env, qk, args })
}

/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub fn start_args(lx: &Lx, env: &Env, f: &Vl, args: &Array<crate::syntax::Arg>) -> Array<crate::lower::model::Ex> {
    let pts = 'm68147: {
        let scrutinee = &value_ty(f);
        if let crate::lower::model::OutTy::OutJobFn(m68147_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts) = &**m68147_0_0 {
            break 'm68147 if &len(args) == &Nat::from(1u32) {
                Array::from(vec![crate::lower::model::OutTy::OutTuple(ts.clone())])
            } else {
                ts.clone()
            };
        }
        if let crate::lower::model::OutTy::OutJobFn(a, _) = scrutinee {
            break 'm68147 Array::from(vec![(**a).clone()]);
        }
        Array::new()
    };
    run_to_end(each_job(crate::check::errors::range0(&len(args)), {
        let args = args.clone();
        let pts = pts.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let args = args.clone();
            let pts = pts.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                    match or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnit) {
                        crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_68558: Vl| prism_rtl::Turn::Finished(own(&value_of_68558))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `StartArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
/// ```
pub struct StartArgs {
    pub lx: Lx,
    pub env: Env,
    pub f: Vl,
    pub args: Array<crate::syntax::Arg>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for StartArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let f = &self.f;
        let args = &self.args;
        let pts = 'm68147: {
            let scrutinee = &value_ty(f);
            if let crate::lower::model::OutTy::OutJobFn(m68147_0_0, _) = scrutinee && let crate::lower::model::OutTy::OutTuple(ts) = &**m68147_0_0 {
                break 'm68147 if &len(args) == &Nat::from(1u32) {
                    Array::from(vec![crate::lower::model::OutTy::OutTuple(ts.clone())])
                } else {
                    ts.clone()
                };
            }
            if let crate::lower::model::OutTy::OutJobFn(a, _) = scrutinee {
                break 'm68147 Array::from(vec![(**a).clone()]);
            }
            Array::new()
        };
        each_job(crate::check::errors::range0(&len(args)), {
            let args = args.clone();
            let pts = pts.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let args = args.clone();
                let pts = pts.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&args, &i), &crate::syntax::Arg { name: None, value: dummy_expr(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } });
                        match or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnit) {
                            crate::lower::model::OutTy::OutJobFn(_, _) => prism_rtl::Turn::More(Rc::new(AsJobValue { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            _ => call_then(start_value_of(lx.clone(), env.clone(), a.value.clone()), move |value_of_68558: Vl| prism_rtl::Turn::Finished(own(&value_of_68558))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
pub fn start_start_args(lx: Lx, env: Env, f: Vl, args: Array<crate::syntax::Arg>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(StartArgs { lx, env, f, args })
}

/// ```prism
/// PreludeVariant: fn Text, OutTy -> Text
/// ```
pub fn prelude_variant(name: &Text, first_: &crate::lower::model::OutTy) -> Text {
    match first_ {
        crate::lower::model::OutTy::OutText => if name == &Text::lit("len") { Text::lit("len_text") } else { name.clone() },
        crate::lower::model::OutTy::OutMap(_, _) => if crate::check::types::has_text(&Array::from(vec![Text::lit("len"), Text::lit("fold"), Text::lit("each"), Text::lit("filter")]), name) {
            Text::from(format!("{}_map", name))
        } else {
            name.clone()
        },
        _ => name.clone(),
    }
}

/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub fn field_value(lx: &Lx, env: &Env, r: &crate::syntax::Expr, name: &Text) -> Vl {
    let rv = value_of(lx, env, r);
    let rty = peel(&type_at(lx, &r.span));
    let (ft, rc) = field_info(lx, &rty, name);
    let f = snake(name);
    let mode = if rc { Holding::RcOwned } else { Holding::Owned };
    match &rv {
        Vl::VlPlace(x, _, _) => Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone()),
        Vl::VlOwned(x, _) => Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone()),
    }
}

/// The step machine of `FieldValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
/// ```
pub struct FieldValue {
    pub lx: Lx,
    pub env: Env,
    pub r: crate::syntax::Expr,
    pub name: Text,
}

impl prism_rtl::Job<Vl> for FieldValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let r = &self.r;
        let name = &self.name;
        let env = env.clone();
        let lx = lx.clone();
        let name = name.clone();
        let r = r.clone();
        call_then(start_value_of(lx.clone(), env.clone(), r.clone()), move |value_of_69053: Vl| {
            let rv = value_of_69053;
            let rty = peel(&type_at(&lx, &r.span));
            call_then(start_field_info(lx.clone(), rty.clone(), name.clone()), move |field_info_69132: (crate::lower::model::OutTy, bool)| {
                let (ft, rc) = field_info_69132;
                let f = snake(&name);
                let mode = if rc { Holding::RcOwned } else { Holding::Owned };
                match &rv {
                    Vl::VlPlace(x, _, _) => prism_rtl::Turn::Finished(Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone())),
                    Vl::VlOwned(x, _) => prism_rtl::Turn::Finished(Vl::VlPlace(crate::lower::model::Ex::XField(Rc::new(x.clone()), f.clone()), mode.clone(), ft.clone())),
                }
            })
        })
    }
}

/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
pub fn start_field_value(lx: Lx, env: Env, r: crate::syntax::Expr, name: Text) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(FieldValue { lx, env, r, name })
}

/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub fn field_info(lx: &Lx, rty: &crate::check::types::Ty, name: &Text) -> (crate::lower::model::OutTy, bool) {
    match rty {
        crate::check::types::Ty::TyCon(n, args) => match get(&lx.g.ctors, n) {
            Some(c) => {
                let fix_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|found_opt: &Option<Nat>, i: &Nat| if &or(&index(&c.fields, i), &Text::lit("")) == name {
                    Some(i.clone())
                } else {
                    found_opt.clone()
                }));
                match &fix_opt {
                    Some(i) => {
                        let ft = or(&index(&c.args, i), &crate::check::types::Ty::TyErr);
                        let inst = instantiated(&ft, &c.params, args);
                        (out_ty_of(lx, &inst), rc_field(lx, &c.name, i))
                    },
                    None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false),
                }
            },
            None => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false),
        },
        _ => (crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name))), false),
    }
}

/// The step machine of `FieldInfo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
/// ```
pub struct FieldInfo {
    pub lx: Lx,
    pub rty: crate::check::types::Ty,
    pub name: Text,
}

impl prism_rtl::Job<(crate::lower::model::OutTy, bool)> for FieldInfo {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::model::OutTy, bool)> {
        let lx = &self.lx;
        let rty = &self.rty;
        let name = &self.name;
        match rty {
            crate::check::types::Ty::TyCon(n, args) => match get(&lx.g.ctors, n) {
                Some(c) => {
                    let fix_opt = fold(&crate::check::errors::range0(&len(&c.fields)), &None, &(|found_opt: &Option<Nat>, i: &Nat| if &or(&index(&c.fields, i), &Text::lit("")) == name {
                        Some(i.clone())
                    } else {
                        found_opt.clone()
                    }));
                    match &fix_opt {
                        Some(i) => {
                            let ft = or(&index(&c.args, i), &crate::check::types::Ty::TyErr);
                            let args = args.clone();
                            let i = i.clone();
                            let lx = lx.clone();
                            let name = name.clone();
                            call_then(start_instantiated(ft.clone(), c.params.clone(), args.clone()), move |instantiated_69820: crate::check::types::Ty| {
                                let inst = instantiated_69820;
                                call_then(start_out_ty_of(lx.clone(), inst.clone()), move |out_ty_of_69875: crate::lower::model::OutTy| prism_rtl::Turn::Finished((out_ty_of_69875, rc_field(&lx, &c.name, &i))))
                            })
                        },
                        None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false)),
                    }
                },
                None => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {}", name))), false)),
            },
            _ => prism_rtl::Turn::Finished((crate::lower::model::OutTy::OutUnknown(Text::from(format!("a field {} of a non-record", name))), false)),
        }
    }
}

/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
pub fn start_field_info(lx: Lx, rty: crate::check::types::Ty, name: Text) -> Rc<dyn prism_rtl::Job<(crate::lower::model::OutTy, bool)>> {
    Rc::new(FieldInfo { lx, rty, name })
}

/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub fn instantiated(t: &crate::check::types::Ty, params: &Array<Text>, args: &Array<crate::check::types::Ty>) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyQ(q) => {
            let hit_opt = fold(&crate::check::errors::range0(&len(params)), &None, &(|found_opt: &Option<crate::check::types::Ty>, i: &Nat| if &or(&index(params, i), &Text::lit("")) == q {
                index(args, i)
            } else {
                found_opt.clone()
            }));
            or(&hit_opt, t)
        },
        crate::check::types::Ty::TyCon(n, xs) => crate::check::types::Ty::TyCon(n.clone(), run_to_end(each_job(xs.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(c.clone(), run_to_end(each_job(ps.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        })), Rc::new(instantiated(&**res, params, args))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let params = params.clone();
            let args = args.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let params = params.clone();
                let args = args.clone();
                entered(once_job(move || {
                    let x = p0;
                    prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
        }))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(instantiated(&**e, params, args))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(instantiated(&**k, params, args)), Rc::new(instantiated(&**v_, params, args))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(instantiated(&**i, params, args))),
        _ => t.clone(),
    }
}

/// The step machine of `Instantiated`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
/// ```
pub struct Instantiated {
    pub t: crate::check::types::Ty,
    pub params: Array<Text>,
    pub args: Array<crate::check::types::Ty>,
}

impl prism_rtl::Job<crate::check::types::Ty> for Instantiated {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t = &self.t;
        let params = &self.params;
        let args = &self.args;
        match t {
            crate::check::types::Ty::TyQ(q) => {
                let hit_opt = fold(&crate::check::errors::range0(&len(params)), &None, &(|found_opt: &Option<crate::check::types::Ty>, i: &Nat| if &or(&index(params, i), &Text::lit("")) == q {
                    index(args, i)
                } else {
                    found_opt.clone()
                }));
                prism_rtl::Turn::Finished(or(&hit_opt, t))
            },
            crate::check::types::Ty::TyCon(n, xs) => {
                let args = args.clone();
                let n = n.clone();
                let params = params.clone();
                let xs = xs.clone();
                call_value(each_job(xs.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_70455: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyCon(n.clone(), each_70455)))
            },
            crate::check::types::Ty::TyFn(c, ps, res) => {
                let args = args.clone();
                let c = c.clone();
                let params = params.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_70529: Array<crate::check::types::Ty>| call_then(start_instantiated(res.clone(), params.clone(), args.clone()), move |instantiated_70575: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyFn(c.clone(), each_70529, Rc::new(instantiated_70575)))))
            },
            crate::check::types::Ty::TyTuple(ts) => {
                let args = args.clone();
                let params = params.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let params = params.clone();
                    let args = args.clone();
                    Rc::new(move |p0: crate::check::types::Ty| {
                        let params = params.clone();
                        let args = args.clone();
                        entered(once_job(move || {
                            let x = p0;
                            prism_rtl::Turn::More(Rc::new(Instantiated { t: x.clone(), params: params.clone(), args: args.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>>>
                }), move |each_70632: Array<crate::check::types::Ty>| prism_rtl::Turn::Finished(crate::check::types::Ty::TyTuple(each_70632)))
            },
            crate::check::types::Ty::TyArray(e) => {
                let args = args.clone();
                let e = (**e).clone();
                let params = params.clone();
                call_then(start_instantiated(e.clone(), params.clone(), args.clone()), move |instantiated_70700: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyArray(Rc::new(instantiated_70700))))
            },
            crate::check::types::Ty::TyMap(k, v_) => {
                let args = args.clone();
                let k = (**k).clone();
                let params = params.clone();
                let v_ = (**v_).clone();
                call_then(start_instantiated(k.clone(), params.clone(), args.clone()), move |instantiated_70753: crate::check::types::Ty| call_then(start_instantiated(v_.clone(), params.clone(), args.clone()), move |instantiated_70785: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TyMap(Rc::new(instantiated_70753), Rc::new(instantiated_70785)))))
            },
            crate::check::types::Ty::TySig(s, i) => {
                let args = args.clone();
                let i = (**i).clone();
                let params = params.clone();
                let s = s.clone();
                call_then(start_instantiated(i.clone(), params.clone(), args.clone()), move |instantiated_70841: crate::check::types::Ty| prism_rtl::Turn::Finished(crate::check::types::Ty::TySig(s.clone(), Rc::new(instantiated_70841))))
            },
            _ => prism_rtl::Turn::Finished(t.clone()),
        }
    }
}

/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
pub fn start_instantiated(t: crate::check::types::Ty, params: Array<Text>, args: Array<crate::check::types::Ty>) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(Instantiated { t, params, args })
}

/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub fn index_value(lx: &Lx, env: &Env, r: &crate::syntax::Expr, i: &crate::syntax::Expr, t: &crate::lower::model::OutTy) -> Vl {
    let rt = out_ty_of(lx, &peel(&type_at(lx, &r.span)));
    let f = match &rt {
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
        _ => Text::lit("index"),
    };
    Vl::VlOwned(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![argument(lx, env, r), argument(lx, env, i)])), crate::lower::model::OutTy::OutOpt(Rc::new(t.clone())))
}

/// The step machine of `IndexValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
/// ```
pub struct IndexValue {
    pub lx: Lx,
    pub env: Env,
    pub r: crate::syntax::Expr,
    pub i: crate::syntax::Expr,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for IndexValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let r = &self.r;
        let i = &self.i;
        let t = &self.t;
        let env = env.clone();
        let i = i.clone();
        let lx = lx.clone();
        let r = r.clone();
        let t = t.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &r.span))), move |out_ty_of_71084: crate::lower::model::OutTy| {
            let rt = out_ty_of_71084;
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("get"),
                _ => Text::lit("index"),
            };
            call_then(start_argument(lx.clone(), env.clone(), r.clone()), move |argument_71234: crate::lower::model::Ex| call_then(start_argument(lx.clone(), env.clone(), i.clone()), move |argument_71257: crate::lower::model::Ex| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![argument_71234, argument_71257])), crate::lower::model::OutTy::OutOpt(Rc::new(t.clone()))))))
        })
    }
}

/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
pub fn start_index_value(lx: Lx, env: Env, r: crate::syntax::Expr, i: crate::syntax::Expr, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(IndexValue { lx, env, r, i, t })
}

/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub fn read_names(es: &Array<crate::syntax::Expr>) -> Array<Text> {
    fold(es, &Array::new(), &(|acc: &Array<Text>, x: &crate::syntax::Expr| match &*x.kind {
        crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
            crate::check::types::add_text(acc, &crate::check::env::sname_key(n))
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `ReadNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReadNames: unbounded fn [Expr] -> [Text]
/// ```
pub struct ReadNames {
    pub es: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<Text>> for ReadNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let es = &self.es;
        prism_rtl::Turn::Finished(fold(es, &Array::new(), &(|acc: &Array<Text>, x: &crate::syntax::Expr| match &*x.kind {
            crate::syntax::ExprKind::EName(n) => if &len(&n.path_) == &Nat::from(1u32) {
                crate::check::types::add_text(acc, &crate::check::env::sname_key(n))
            } else {
                acc.clone()
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
pub fn start_read_names(es: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReadNames { es })
}

/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub fn lambda_exprs(lambda_body0: &crate::syntax::LambdaBody) -> Array<crate::syntax::Expr> {
    match lambda_body0 {
        crate::syntax::LambdaBody::LbExpr(x) => crate::check::typed::exprs_in(&**x),
        crate::syntax::LambdaBody::LbBlock(b) => crate::check::typed::block_exprs(b),
    }
}

/// The step machine of `LambdaExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
/// ```
pub struct LambdaExprs {
    pub lambda_body0: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Array<crate::syntax::Expr>> for LambdaExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::syntax::Expr>> {
        let lambda_body0 = &self.lambda_body0;
        match lambda_body0 {
            crate::syntax::LambdaBody::LbExpr(x) => prism_rtl::Turn::More(Rc::new(crate::check::typed::ExprsIn { e: (**x).clone() })),
            crate::syntax::LambdaBody::LbBlock(b) => prism_rtl::Turn::More(Rc::new(crate::check::typed::BlockExprs { b: b.clone() })),
        }
    }
}

/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_exprs(lambda_body0: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>> {
    Rc::new(LambdaExprs { lambda_body0 })
}

/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub fn lambda_value(lx: &Lx, env: &Env, e: &crate::syntax::Expr, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody) -> Vl {
    let ft = out_ty_of(lx, &peel(&type_at(lx, &e.span)));
    match &ft {
        crate::lower::model::OutTy::OutJobFn(a, _) => job_lambda(lx, env, ps, body, &ft, &**a, &enters_lambda(lx, e)),
        _ => plain_lambda(lx, env, ps, body, &ft),
    }
}

/// The step machine of `LambdaValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
/// ```
pub struct LambdaValue {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Vl> for LambdaValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let ps = &self.ps;
        let body = &self.body;
        let body = body.clone();
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &e.span))), move |out_ty_of_71924: crate::lower::model::OutTy| {
            let ft = out_ty_of_71924;
            match &ft {
                crate::lower::model::OutTy::OutJobFn(a, _) => prism_rtl::Turn::More(Rc::new(JobLambda { lx: lx.clone(), env: env.clone(), ps: ps.clone(), body: body.clone(), ft: ft.clone(), a: (**a).clone(), enter: enters_lambda(&lx, &e) })),
                _ => prism_rtl::Turn::More(Rc::new(PlainLambda { lx: lx.clone(), env: env.clone(), ps: ps.clone(), body: body.clone(), ft: ft.clone() })),
            }
        })
    }
}

/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_value(lx: Lx, env: Env, e: crate::syntax::Expr, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(LambdaValue { lx, env, e, ps, body })
}

/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub fn plain_lambda(lx: &Lx, env: &Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, ft: &crate::lower::model::OutTy) -> Vl {
    let pts = match ft {
        crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
        _ => Array::new(),
    };
    let read = with_instances(env, &read_names(&lambda_exprs(body)));
    let caps0 = filter(&read, &(|n: &Text| match get(&env.names, n) {
        Some(Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let caps = append(&append(&caps0, &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#port", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n)))), &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#init", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n))));
    let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
        Some(Bn::BnLocal(rs, mode, ct)) => {
            let local = place_stem(&rs);
            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), own(&local_place(&rs, &mode, &ct)));
            (push(acc, &d), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), Holding::Owned, ct.clone())))
        },
        _ => (acc.clone(), en.clone()),
    }));
    let (pas, env2) = closure_params(lx, &env1, ps, &pts, &true);
    let v_ = lambda_body_value(lx, &env2, body);
    Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas.clone(), Rc::new(own(&v_)))])))), ft.clone())
}

/// The step machine of `PlainLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
/// ```
pub struct PlainLambda {
    pub lx: Lx,
    pub env: Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub ft: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for PlainLambda {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let ft = &self.ft;
        let pts = match ft {
            crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
            _ => Array::new(),
        };
        let body = body.clone();
        let env = env.clone();
        let ft = ft.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(start_lambda_exprs(body.clone()), move |lambda_exprs_72347: Array<crate::syntax::Expr>| call_then(start_read_names(lambda_exprs_72347), move |read_names_72336: Array<Text>| {
            let read = with_instances(&env, &read_names_72336);
            let caps0 = filter(&read, &(|n: &Text| match get(&env.names, n) {
                Some(Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let caps = append(&append(&caps0, &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#port", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n)))), &filter(&each(&read, &(|n: &Text| Text::from(format!("{}#init", n)))), &(|n: &Text| crate::check::env::has_key(&env.names, n))));
            let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
                Some(Bn::BnLocal(rs, mode, ct)) => {
                    let local = place_stem(&rs);
                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(local.clone()), own(&local_place(&rs, &mode, &ct)));
                    (push(acc, &d), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(local.clone()), Holding::Owned, ct.clone())))
                },
                _ => (acc.clone(), en.clone()),
            }));
            call_then(start_closure_params(lx.clone(), env1.clone(), ps.clone(), pts.clone(), true), move |closure_params_73230: (Array<crate::lower::model::Pa>, Env)| {
                let (pas, env2) = closure_params_73230;
                call_then(start_lambda_body_value(lx.clone(), env2.clone(), body.clone()), move |lambda_body_value_73280: Vl| {
                    let v_ = lambda_body_value_73280;
                    prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, pas.clone(), Rc::new(own(&v_)))])))), ft.clone()))
                })
            })
        }))
    }
}

/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
pub fn start_plain_lambda(lx: Lx, env: Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, ft: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PlainLambda { lx, env, ps, body, ft })
}

/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub fn lambda_param_tys(lx: &Lx, e: &crate::syntax::Expr, n: &Nat) -> Array<crate::lower::model::OutTy> {
    let ts = match out_ty_of(lx, &peel(&type_at(lx, &e.span))) {
        crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
        crate::lower::model::OutTy::OutJobFn(a, _) => match &*a {
            crate::lower::model::OutTy::OutTuple(xs) => if n == &Nat::from(1u32) { Array::from(vec![(*a).clone()]) } else { xs.clone() },
            _ => Array::from(vec![(*a).clone()]),
        },
        _ => Array::new(),
    };
    if (&len(&ts) == n) && run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
        let ok = p0;
        let t = p1;
        prism_rtl::Turn::Finished(ok && is_known_ty(&t))
    }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
        ts.clone()
    } else {
        Array::new()
    }
}

/// The step machine of `LambdaParamTys`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
/// ```
pub struct LambdaParamTys {
    pub lx: Lx,
    pub e: crate::syntax::Expr,
    pub n: Nat,
}

impl prism_rtl::Job<Array<crate::lower::model::OutTy>> for LambdaParamTys {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::OutTy>> {
        let lx = &self.lx;
        let e = &self.e;
        let n = &self.n;
        let e = e.clone();
        let lx = lx.clone();
        let n = n.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &e.span))), move |out_ty_of_73684: crate::lower::model::OutTy| {
            let ts = match out_ty_of_73684 {
                crate::lower::model::OutTy::OutFn(xs, _) => xs.clone(),
                crate::lower::model::OutTy::OutJobFn(a, _) => match &*a {
                    crate::lower::model::OutTy::OutTuple(xs) => if &n == &Nat::from(1u32) { Array::from(vec![(*a).clone()]) } else { xs.clone() },
                    _ => Array::from(vec![(*a).clone()]),
                },
                _ => Array::new(),
            };
            if (&len(&ts) == &n) && run_to_end(fold_job(ts.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok = p0;
                let t = p1;
                prism_rtl::Turn::Finished(ok && is_known_ty(&t))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) {
                prism_rtl::Turn::Finished(ts.clone())
            } else {
                prism_rtl::Turn::Finished(Array::new())
            }
        })
    }
}

/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_param_tys(lx: Lx, e: crate::syntax::Expr, n: Nat) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::OutTy>>> {
    Rc::new(LambdaParamTys { lx, e, n })
}

/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub fn is_known_ty(t: &crate::lower::model::OutTy) -> bool {
    match t {
        crate::lower::model::OutTy::OutUnknown(_) => false,
        crate::lower::model::OutTy::OutOpt(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutRes(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutArray(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutRc(x) => is_known_ty(&**x),
        crate::lower::model::OutTy::OutMap(k, v_) => is_known_ty(&**k) && is_known_ty(&**v_),
        crate::lower::model::OutTy::OutTuple(xs) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutNamed(_, xs) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)),
        crate::lower::model::OutTy::OutFn(xs, r) => run_to_end(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
            let ok = p0;
            let x = p1;
            prism_rtl::Turn::Finished(ok && is_known_ty(&x))
        }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>)) && is_known_ty(&**r),
        crate::lower::model::OutTy::OutJobFn(a, b) => is_known_ty(&**a) && is_known_ty(&**b),
        _ => true,
    }
}

/// The step machine of `IsKnownTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsKnownTy: unbounded fn OutTy -> Bool
/// ```
pub struct IsKnownTy {
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<bool> for IsKnownTy {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let t = &self.t;
        match t {
            crate::lower::model::OutTy::OutUnknown(_) => prism_rtl::Turn::Finished(false),
            crate::lower::model::OutTy::OutOpt(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutRes(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutArray(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutRc(x) => prism_rtl::Turn::More(Rc::new(IsKnownTy { t: (**x).clone() })),
            crate::lower::model::OutTy::OutMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_is_known_ty(k.clone()), move |is_known_ty_74194: bool| prism_rtl::Turn::Finished(is_known_ty_74194 && is_known_ty(&v_)))
            },
            crate::lower::model::OutTy::OutTuple(xs) => fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok && is_known_ty(&x))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutNamed(_, xs) => fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                let ok = p0;
                let x = p1;
                prism_rtl::Turn::Finished(ok && is_known_ty(&x))
            }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>).cycle(),
            crate::lower::model::OutTy::OutFn(xs, r) => {
                let r = (**r).clone();
                let xs = xs.clone();
                call_value(fold_job(xs.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::OutTy)| entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && is_known_ty(&x))
                }))) as Rc<dyn Fn((bool, crate::lower::model::OutTy)) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_74369: bool| prism_rtl::Turn::Finished(fold_74369 && is_known_ty(&r)))
            },
            crate::lower::model::OutTy::OutJobFn(a, b) => {
                let a = (**a).clone();
                let b = (**b).clone();
                call_then(start_is_known_ty(a.clone()), move |is_known_ty_74449: bool| prism_rtl::Turn::Finished(is_known_ty_74449 && is_known_ty(&b)))
            },
            _ => prism_rtl::Turn::Finished(true),
        }
    }
}

/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
pub fn start_is_known_ty(t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsKnownTy { t })
}

/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub fn job_lambda(lx: &Lx, env: &Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, ft: &crate::lower::model::OutTy, a: &crate::lower::model::OutTy, enter: &bool) -> Vl {
    let caps = filter(&with_instances(env, &read_names(&lambda_exprs(body))), &(|n: &Text| match get(&env.names, n) {
        Some(Bn::BnLocal(_, _, _)) => true,
        _ => false,
    }));
    let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
        Some(Bn::BnLocal(rs, mode, ct)) => {
            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(&rs)), own(&local_place(&rs, &mode, &ct)));
            (push(acc, &d), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(&rs)), Holding::Owned, ct.clone())))
        },
        _ => (acc.clone(), en.clone()),
    }));
    let again = fold(&caps, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, n: &Text| match get(&env1.names, n) {
        Some(Bn::BnLocal(rs, _, ct)) => push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(&rs)), own(&local_place(&rs, &Holding::Owned, &ct)))),
        _ => acc.clone(),
    }));
    let pts = match a {
        crate::lower::model::OutTy::OutTuple(ts) => if &len(ps) == &Nat::from(1u32) { Array::from(vec![a.clone()]) } else { ts.clone() },
        _ => Array::from(vec![a.clone()]),
    };
    let env1b = only_captured(&env1, &caps);
    let pos = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let ps = ps.clone();
        let lx = lx.clone();
        Rc::new(move |p0: Nat| {
            let ps = ps.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let p_ = or(&index(&ps, &i), &dummy_pat());
                    prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: p_.clone(), ty: binder_ty_of_pattern(&lx, &p_), mode: Holding::Owned, fresh: Text::from(format!("p{}_", &i)) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
    }));
    let unpack = fold(&crate::check::errors::range0(&len(&pos)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| match index(&pos, i) {
        Some(po) => append(&push(acc, &crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i))))), &each(&po.conds, &(|c: &crate::lower::model::Cc| cond_as_let(c)))),
        None => acc.clone(),
    }));
    let pos2 = each(&crate::check::errors::range0(&len(&pos)), &(|i: &Nat| match index(&pos, i) {
        Some(po) => match &*or(&index(ps, i), &dummy_pat()).kind {
            crate::syntax::PatternKind::PName(_) => {
                let mut this: PatOut = po.clone();
                this.binds = each(&this.binds, &(|(n, b): &(Text, Bn)| match b {
                    Bn::BnLocal(rs, mode, bt) => (n.clone(), Bn::BnLocal(rs.clone(), mode.clone(), or(&index(&pts, i), bt))),
                    _ => (n.clone(), b.clone()),
                }));
                this
            },
            _ => po.clone(),
        },
        None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }));
    let env2 = fold(&pos2, &env1b, &(|en: &Env, po: &PatOut| bind_all(en, &po.binds)));
    let names = each(&crate::check::errors::range0(&len(ps)), &(|i: &Nat| Text::from(format!("p{}", i))));
    let pa = if &len(ps) == &Nat::from(1u32) {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a.clone())
    } else {
        crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
    };
    let tail0 = match body {
        crate::syntax::LambdaBody::LbExpr(x) => tail(lx, &env2, &**x),
        crate::syntax::LambdaBody::LbBlock(bl) => tail_block(lx, &env2, bl),
    };
    let tail_ = if &len(&unpack) == &Nat::from(0u32) {
        tail0.clone()
    } else {
        crate::lower::model::Ex::XBlock(unpack.clone(), Rc::new(tail0.clone()))
    };
    let job0 = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail_.clone()))]));
    let job = if *enter {
        crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0.clone()]))
    } else {
        job0.clone()
    };
    let call = if &len(&again) == &Nat::from(0u32) {
        job.clone()
    } else {
        crate::lower::model::Ex::XBlock(again.clone(), Rc::new(job.clone()))
    };
    Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(call.clone()))]))), ft.clone()))), ft.clone())
}

/// The step machine of `JobLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
/// ```
pub struct JobLambda {
    pub lx: Lx,
    pub env: Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub ft: crate::lower::model::OutTy,
    pub a: crate::lower::model::OutTy,
    pub enter: bool,
}

impl prism_rtl::Job<Vl> for JobLambda {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let ft = &self.ft;
        let a = &self.a;
        let enter = &self.enter;
        let a = a.clone();
        let body = body.clone();
        let enter = *enter;
        let env = env.clone();
        let ft = ft.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        call_then(start_lambda_exprs(body.clone()), move |lambda_exprs_75327: Array<crate::syntax::Expr>| call_then(start_read_names(lambda_exprs_75327), move |read_names_75316: Array<Text>| {
            let caps = filter(&with_instances(&env, &read_names_75316), &(|n: &Text| match get(&env.names, n) {
                Some(Bn::BnLocal(_, _, _)) => true,
                _ => false,
            }));
            let (dos, env1) = fold(&caps, &(Array::new(), env.clone()), &(|(acc, en): &(Array<crate::lower::model::Do>, Env), n: &Text| match get(&env.names, n) {
                Some(Bn::BnLocal(rs, mode, ct)) => {
                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(&rs)), own(&local_place(&rs, &mode, &ct)));
                    (push(acc, &d), bind(en, n, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(&rs)), Holding::Owned, ct.clone())))
                },
                _ => (acc.clone(), en.clone()),
            }));
            let again = fold(&caps, &Array::new(), &(|acc: &Array<crate::lower::model::Do>, n: &Text| match get(&env1.names, n) {
                Some(Bn::BnLocal(rs, _, ct)) => push(acc, &crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(&rs)), own(&local_place(&rs, &Holding::Owned, &ct)))),
                _ => acc.clone(),
            }));
            let pts = match &a {
                crate::lower::model::OutTy::OutTuple(ts) => if &len(&ps) == &Nat::from(1u32) { Array::from(vec![a.clone()]) } else { ts.clone() },
                _ => Array::from(vec![a.clone()]),
            };
            let env1b = only_captured(&env1, &caps);
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let ps = ps.clone();
                let lx = lx.clone();
                Rc::new(move |p0: Nat| {
                    let ps = ps.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let p_ = or(&index(&ps, &i), &dummy_pat());
                            prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: p_.clone(), ty: binder_ty_of_pattern(&lx, &p_), mode: Holding::Owned, fresh: Text::from(format!("p{}_", &i)) }))
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }), move |each_76355: Array<PatOut>| {
                let pos = each_76355;
                let unpack = fold(&crate::check::errors::range0(&len(&pos)), &Array::new(), &(|acc: &Array<crate::lower::model::Do>, i: &Nat| match index(&pos, i) {
                    Some(po) => append(&push(acc, &crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XVar(Text::from(format!("p{}", i))))), &each(&po.conds, &(|c: &crate::lower::model::Cc| cond_as_let(c)))),
                    None => acc.clone(),
                }));
                let pos2 = each(&crate::check::errors::range0(&len(&pos)), &(|i: &Nat| match index(&pos, i) {
                    Some(po) => match &*or(&index(&ps, i), &dummy_pat()).kind {
                        crate::syntax::PatternKind::PName(_) => {
                            let mut this: PatOut = po.clone();
                            this.binds = each(&this.binds, &(|(n, b): &(Text, Bn)| match b {
                                Bn::BnLocal(rs, mode, bt) => (n.clone(), Bn::BnLocal(rs.clone(), mode.clone(), or(&index(&pts, i), bt))),
                                _ => (n.clone(), b.clone()),
                            }));
                            this
                        },
                        _ => po.clone(),
                    },
                    None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
                }));
                let env2 = fold(&pos2, &env1b, &(|en: &Env, po: &PatOut| bind_all(en, &po.binds)));
                let names = each(&crate::check::errors::range0(&len(&ps)), &(|i: &Nat| Text::from(format!("p{}", i))));
                let pa = if &len(&ps) == &Nat::from(1u32) {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(Text::lit("p0"))), a.clone())
                } else {
                    crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaTuple(each(&names, &(|nm: &Text| crate::lower::model::Pa::PaBind(nm.clone()))))), a.clone())
                };
                let tail0 = match &body {
                    crate::syntax::LambdaBody::LbExpr(x) => tail(&lx, &env2, &**x),
                    crate::syntax::LambdaBody::LbBlock(bl) => tail_block(&lx, &env2, bl),
                };
                let tail_ = if &len(&unpack) == &Nat::from(0u32) {
                    tail0.clone()
                } else {
                    crate::lower::model::Ex::XBlock(unpack.clone(), Rc::new(tail0.clone()))
                };
                let job0 = crate::lower::model::Ex::XCall(Text::lit("once_job"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::new(), Rc::new(tail_.clone()))]));
                let job = if enter {
                    crate::lower::model::Ex::XCall(Text::lit("entered"), Array::from(vec![job0.clone()]))
                } else {
                    job0.clone()
                };
                let call = if &len(&again) == &Nat::from(0u32) {
                    job.clone()
                } else {
                    crate::lower::model::Ex::XBlock(again.clone(), Rc::new(job.clone()))
                };
                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCast(Rc::new(crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![pa.clone()]), Rc::new(call.clone()))]))), ft.clone()))), ft.clone()))
            })
        }))
    }
}

/// `Start JobLambda, x`: what the function value is when passed to `@Run`.
pub fn start_job_lambda(lx: Lx, env: Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, ft: crate::lower::model::OutTy, a: crate::lower::model::OutTy, enter: bool) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(JobLambda { lx, env, ps, body, ft, a, enter })
}

/// ```prism
/// EntersLambda: fn Lx, Expr -> Bool
/// ```
pub fn enters_lambda(lx: &Lx, e: &crate::syntax::Expr) -> bool {
    match peel(&type_at(lx, &e.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
        crate::check::types::Ty::TyFn(_, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// OnlyCaptured: fn Env, [Text] -> Env
/// ```
pub fn only_captured(env: &Env, caps: &Array<Text>) -> Env {
    let mut this: Env = env.clone();
    this.names = fold(&keys(&env.names), &Map::new(), &(|m: &Map<Text, Bn>, k: &Text| match get(&env.names, k) {
        Some(Bn::BnLocal(rs, mode, t)) => if crate::check::types::has_text(caps, k) || (&mode == &Holding::Owned) {
            insert(m, k, &Bn::BnLocal(rs.clone(), mode.clone(), t.clone()))
        } else {
            m.clone()
        },
        Some(b) => insert(m, k, &b),
        None => m.clone(),
    }));
    this
}

/// ```prism
/// CondAsLet: fn Cc -> Do
/// ```
pub fn cond_as_let(cc0: &crate::lower::model::Cc) -> crate::lower::model::Do {
    match cc0 {
        crate::lower::model::Cc::CcLet(pa, x) => crate::lower::model::Do::DoLet(pa.clone(), x.clone()),
        crate::lower::model::Cc::CcIf(x) => crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XUnit),
    }
}

/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub fn lambda_arg(lx: &Lx, env: &Env, ps: &Array<crate::syntax::Pattern_>, body: &crate::syntax::LambdaBody, pts: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let (pas, env2) = closure_params(lx, env, ps, pts, &(&len(pts) > &Nat::from(0u32)));
    let v_ = lambda_body_value(lx, &env2, body);
    crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(own(&v_)))
}

/// The step machine of `LambdaArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaArg: unbounded fn Lx, Env, [Pattern], LambdaBody, [OutTy] -> Ex
/// ```
pub struct LambdaArg {
    pub lx: Lx,
    pub env: Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub body: crate::syntax::LambdaBody,
    pub pts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for LambdaArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let body = &self.body;
        let pts = &self.pts;
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let ps = ps.clone();
        let pts = pts.clone();
        call_then(start_closure_params(lx.clone(), env.clone(), ps.clone(), pts.clone(), &len(&pts) > &Nat::from(0u32)), move |closure_params_79095: (Array<crate::lower::model::Pa>, Env)| {
            let (pas, env2) = closure_params_79095;
            call_then(start_lambda_body_value(lx.clone(), env2.clone(), body.clone()), move |lambda_body_value_79153: Vl| {
                let v_ = lambda_body_value_79153;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XClosure(false, pas.clone(), Rc::new(own(&v_))))
            })
        })
    }
}

/// `Start LambdaArg, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_arg(lx: Lx, env: Env, ps: Array<crate::syntax::Pattern_>, body: crate::syntax::LambdaBody, pts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(LambdaArg { lx, env, ps, body, pts })
}

/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub fn lambda_body_value(lx: &Lx, env: &Env, lambda_body2: &crate::syntax::LambdaBody) -> Vl {
    match lambda_body2 {
        crate::syntax::LambdaBody::LbExpr(x) => value_of(lx, env, &**x),
        crate::syntax::LambdaBody::LbBlock(b) => block_value(lx, env, b),
    }
}

/// The step machine of `LambdaBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LambdaBodyValue: unbounded fn Lx, Env, LambdaBody -> Vl
/// ```
pub struct LambdaBodyValue {
    pub lx: Lx,
    pub env: Env,
    pub lambda_body2: crate::syntax::LambdaBody,
}

impl prism_rtl::Job<Vl> for LambdaBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let lambda_body2 = &self.lambda_body2;
        match lambda_body2 {
            crate::syntax::LambdaBody::LbExpr(x) => prism_rtl::Turn::More(Rc::new(ValueOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            crate::syntax::LambdaBody::LbBlock(b) => prism_rtl::Turn::More(Rc::new(BlockValue { lx: lx.clone(), env: env.clone(), b: b.clone() })),
        }
    }
}

/// `Start LambdaBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_lambda_body_value(lx: Lx, env: Env, lambda_body2: crate::syntax::LambdaBody) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(LambdaBodyValue { lx, env, lambda_body2 })
}

/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub fn closure_params(lx: &Lx, env: &Env, ps: &Array<crate::syntax::Pattern_>, pts: &Array<crate::lower::model::OutTy>, typed: &bool) -> (Array<crate::lower::model::Pa>, Env) {
    run_to_end(fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), env.clone()), {
        let ps = ps.clone();
        let lx = lx.clone();
        let typed = *typed;
        let pts = pts.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, Env), Nat)| {
            let ps = ps.clone();
            let lx = lx.clone();
            let typed = typed;
            let pts = pts.clone();
            entered(once_job(move || {
                let (acc, en) = p0;
                let i = p1;
                match index(&ps, &i) {
                    Some(p_) => call_then(start_rust_pat(lx.clone(), p_.clone(), binder_ty_of_pattern(&lx, &p_), Holding::ByRef, Text::from(format!("a{}", &p_.span.start))), move |rust_pat_79716: PatOut| {
                        let po = rust_pat_79716;
                        let en2 = bind_all(&en, &po.binds);
                        let pa = if typed {
                            crate::lower::model::Pa::PaTyped(Rc::new(po.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                        } else {
                            po.pa.clone()
                        };
                        prism_rtl::Turn::Finished((push(&acc, &pa), en2.clone()))
                    }),
                    None => prism_rtl::Turn::Finished((acc.clone(), en.clone())),
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, Env)>>>
    }))
}

/// The step machine of `ClosureParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClosureParams: unbounded fn Lx, Env, [Pattern], [OutTy], Bool -> (([Pa], Env))
/// ```
pub struct ClosureParams {
    pub lx: Lx,
    pub env: Env,
    pub ps: Array<crate::syntax::Pattern_>,
    pub pts: Array<crate::lower::model::OutTy>,
    pub typed: bool,
}

impl prism_rtl::Job<(Array<crate::lower::model::Pa>, Env)> for ClosureParams {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Pa>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let ps = &self.ps;
        let pts = &self.pts;
        let typed = &self.typed;
        fold_job(crate::check::errors::range0(&len(ps)), (Array::new(), env.clone()), {
            let ps = ps.clone();
            let lx = lx.clone();
            let typed = *typed;
            let pts = pts.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Pa>, Env), Nat)| {
                let ps = ps.clone();
                let lx = lx.clone();
                let typed = typed;
                let pts = pts.clone();
                entered(once_job(move || {
                    let (acc, en) = p0;
                    let i = p1;
                    match index(&ps, &i) {
                        Some(p_) => call_then(start_rust_pat(lx.clone(), p_.clone(), binder_ty_of_pattern(&lx, &p_), Holding::ByRef, Text::from(format!("a{}", &p_.span.start))), move |rust_pat_79716: PatOut| {
                            let po = rust_pat_79716;
                            let en2 = bind_all(&en, &po.binds);
                            let pa = if typed {
                                crate::lower::model::Pa::PaTyped(Rc::new(po.pa.clone()), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, &i), &crate::lower::model::OutTy::OutUnknown(Text::lit("a parameter"))))))
                            } else {
                                po.pa.clone()
                            };
                            prism_rtl::Turn::Finished((push(&acc, &pa), en2.clone()))
                        }),
                        None => prism_rtl::Turn::Finished((acc.clone(), en.clone())),
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Pa>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, Env)>>>
        }).cycle()
    }
}

/// `Start ClosureParams, x`: what the function value is when passed to `@Run`.
pub fn start_closure_params(lx: Lx, env: Env, ps: Array<crate::syntax::Pattern_>, pts: Array<crate::lower::model::OutTy>, typed: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Pa>, Env)>> {
    Rc::new(ClosureParams { lx, env, ps, pts, typed })
}

/// ```prism
/// BindAll: fn Env, [((Text, Bn))] -> Env
/// ```
pub fn bind_all(env: &Env, bs: &Array<(Text, Bn)>) -> Env {
    fold(bs, env, &(|en: &Env, (n, b): &(Text, Bn)| bind(en, n, b)))
}

/// ```prism
/// BinderTyOfPattern: fn Lx, Pattern -> Ty
/// ```
pub fn binder_ty_of_pattern(lx: &Lx, p_: &crate::syntax::Pattern_) -> crate::check::types::Ty {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => binder_ty(lx, &n.span),
        _ => type_at(lx, &p_.span),
    }
}

/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub fn if_value(lx: &Lx, env: &Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, t: &crate::lower::model::OutTy) -> Vl {
    let else_v = match else_b_opt {
        Some(b) => crate::lower::node_::own_as(t, &block_value(lx, env, b)),
        None => crate::lower::model::Ex::XUnit,
    };
    match c {
        crate::syntax::Cond::CondExpr(x) => Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(lx, env, &**x))), Rc::new(crate::lower::node_::own_as(t, &block_value(lx, env, then_b))), Rc::new(else_v.clone())), t.clone()),
        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
            let sv = value_of(lx, env, &**x);
            let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::ByRef, &Text::from(format!("c{}", &x.span.start)));
            let env2 = bind_all(env, &po.binds);
            let guard = match &**g_opt {
                Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of(lx, &env2, ge)))]),
                None => Array::new(),
            };
            let arm = crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::node_::own_as(t, &block_value(lx, &env2, then_b)) };
            let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v.clone() };
            arms_value(&ref_(&sv), &Array::from(vec![arm.clone(), other.clone()]), &Text::from(format!("c{}", &x.span.start)), t)
        },
    }
}

/// The step machine of `IfValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfValue: unbounded fn Lx, Env, Cond, Block, ?Block, OutTy -> Vl
/// ```
pub struct IfValue {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<Vl> for IfValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let t = &self.t;
        let else_v = match else_b_opt {
            Some(b) => crate::lower::node_::own_as(t, &block_value(lx, env, b)),
            None => crate::lower::model::Ex::XUnit,
        };
        match c {
            crate::syntax::Cond::CondExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let t = t.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_80622: Vl| call_then(start_block_value(lx.clone(), env.clone(), then_b.clone()), move |block_value_80655: Vl| prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of_80622)), Rc::new(crate::lower::node_::own_as(&t, &block_value_80655)), Rc::new(else_v.clone())), t.clone()))))
            },
            crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                let g_opt = (**g_opt).clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_80742: Vl| {
                    let sv = value_of_80742;
                    call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::ByRef, Text::from(format!("c{}", &x.span.start))), move |rust_pat_80782: PatOut| {
                        let po = rust_pat_80782;
                        let env2 = bind_all(&env, &po.binds);
                        let guard = match &g_opt {
                            Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of(&lx, &env2, ge)))]),
                            None => Array::new(),
                        };
                        call_then(start_block_value(lx.clone(), env2.clone(), then_b.clone()), move |block_value_81097: Vl| {
                            let arm = crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: crate::lower::node_::own_as(&t, &block_value_81097) };
                            let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_v.clone() };
                            prism_rtl::Turn::Finished(arms_value(&ref_(&sv), &Array::from(vec![arm.clone(), other.clone()]), &Text::from(format!("c{}", &x.span.start)), &t))
                        })
                    })
                })
            },
        }
    }
}

/// `Start IfValue, x`: what the function value is when passed to `@Run`.
pub fn start_if_value(lx: Lx, env: Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(IfValue { lx, env, c, then_b, else_b_opt, t })
}

/// ```prism
/// ArmsValue: fn Ex, [XArm], Text, OutTy -> Vl
/// ```
pub fn arms_value(scrut: &crate::lower::model::Ex, arms: &Array<crate::lower::model::XArm>, label: &Text, t: &crate::lower::model::OutTy) -> Vl {
    let chain = fold(arms, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || fold(&a.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
    let guarded = fold(arms, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32))));
    if chain {
        Vl::VlOwned(crate::lower::model::Ex::XChain(label.clone(), Rc::new(scrut.clone()), arms.clone(), t.clone()), t.clone())
    } else {
        Vl::VlOwned(crate::lower::model::Ex::XMatch(Rc::new(scrut.clone()), arms.clone(), guarded, t.clone()), t.clone())
    }
}

/// ```prism
/// IsLetCond: fn Cc -> Bool
/// ```
pub fn is_let_cond(cc0: &crate::lower::model::Cc) -> bool {
    match cc0 {
        crate::lower::model::Cc::CcLet(_, _) => true,
        crate::lower::model::Cc::CcIf(_) => false,
    }
}

/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub fn match_value(lx: &Lx, env: &Env, s: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> Vl {
    let sv = value_of(lx, env, s);
    let sty = type_at(lx, &s.span);
    let label = Text::from(format!("m{}", &span.start));
    let by_ref = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let lx = lx.clone();
        let arms = arms.clone();
        let sty = sty.clone();
        let label = label.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
    }));
    let chain = fold(&by_ref, &false, &(|f: &bool, po: &PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
    let owned = match &sv {
        Vl::VlOwned(_, _) => !chain,
        _ => false,
    };
    let pats = if owned {
        run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            Rc::new(move |p0: Nat| {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
        }))
    } else {
        by_ref.clone()
    };
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let pats = pats.clone();
        let env = env.clone();
        let lx = lx.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let pats = pats.clone();
            let env = env.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &dummy_arm());
                    let po = or(&index(&pats, &i), &PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2 = bind_all(&env, &po.binds);
                    let guard = match &arm.guard {
                        Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of(&lx, &env2, ge)))]),
                        None => Array::new(),
                    };
                    call_then(start_block_value(lx.clone(), env2.clone(), arm.body.clone()), move |block_value_82989: Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: own(&block_value_82989) }))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut = if owned { own(&sv) } else { ref_(&sv) };
    arms_value(&scrut, &xarms, &label, t)
}

/// The step machine of `MatchValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchValue: unbounded fn Lx, Env, Expr, [Arm], OutTy, Range -> Vl
/// ```
pub struct MatchValue {
    pub lx: Lx,
    pub env: Env,
    pub s: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for MatchValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let arms = &self.arms;
        let t = &self.t;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let s = s.clone();
        let span = span.clone();
        let t = t.clone();
        call_then(start_value_of(lx.clone(), env.clone(), s.clone()), move |value_of_82074: Vl| {
            let sv = value_of_82074;
            let sty = type_at(&lx, &s.span);
            let label = Text::from(format!("m{}", &span.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let arms = arms.clone();
                    let sty = sty.clone();
                    let label = label.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }), move |each_82173: Array<PatOut>| {
                let by_ref = each_82173;
                let chain = fold(&by_ref, &false, &(|f: &bool, po: &PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
                let owned = match &sv {
                    Vl::VlOwned(_, _) => !chain,
                    _ => false,
                };
                let pats = if owned {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms)), {
                        let lx = lx.clone();
                        let arms = arms.clone();
                        let sty = sty.clone();
                        let label = label.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let arms = arms.clone();
                            let sty = sty.clone();
                            let label = label.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                    }))
                } else {
                    by_ref.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                    let arms = arms.clone();
                    let pats = pats.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    Rc::new(move |p0: Nat| {
                        let arms = arms.clone();
                        let pats = pats.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let arm = or(&index(&arms, &i), &dummy_arm());
                                let po = or(&index(&pats, &i), &PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2 = bind_all(&env, &po.binds);
                                let guard = match &arm.guard {
                                    Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of(&lx, &env2, ge)))]),
                                    None => Array::new(),
                                };
                                call_then(start_block_value(lx.clone(), env2.clone(), arm.body.clone()), move |block_value_82989: Vl| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard), body: own(&block_value_82989) }))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_82619: Array<crate::lower::model::XArm>| {
                    let xarms = each_82619;
                    let scrut = if owned { own(&sv) } else { ref_(&sv) };
                    prism_rtl::Turn::Finished(arms_value(&scrut, &xarms, &label, &t))
                })
            })
        })
    }
}

/// `Start MatchValue, x`: what the function value is when passed to `@Run`.
pub fn start_match_value(lx: Lx, env: Env, s: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(MatchValue { lx, env, s, arms, t, span })
}

/// ```prism
/// let dummyArm
/// ```
pub fn dummy_arm() -> crate::syntax::Arm {
    crate::syntax::Arm { pattern: None, guard: None, body: crate::syntax::Block { stmts: Array::new(), inline: true, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }, span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn arm_pat(lx: &Lx, opt1: &Option<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    match opt1 {
        Some(p_) => rust_pat(lx, p_, ty, mode, fresh),
        None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() },
    }
}

/// The step machine of `ArmPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmPat: unbounded fn Lx, ?Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct ArmPat {
    pub lx: Lx,
    pub opt1: Option<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for ArmPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let opt1 = &self.opt1;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        match opt1 {
            Some(p_) => prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() }),
        }
    }
}

/// `Start ArmPat, x`: what the function value is when passed to `@Run`.
pub fn start_arm_pat(lx: Lx, opt1: Option<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ArmPat { lx, opt1, ty, mode, fresh })
}

/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn block_value(lx: &Lx, env: &Env, b: &crate::syntax::Block) -> Vl {
    if is_given_block(&b.stmts) {
        given_value(lx, env, b, &block_ty(lx, b), &b.span)
    } else {
        plain_block_value(lx, env, b)
    }
}

/// The step machine of `BlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct BlockValue {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<Vl> for BlockValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        if is_given_block(&b.stmts) {
            {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_block_ty(lx.clone(), b.clone()), move |block_ty_83716: crate::lower::model::OutTy| prism_rtl::Turn::More(Rc::new(GivenValue { lx: lx.clone(), env: env.clone(), b: b.clone(), t: block_ty_83716, span: b.span.clone() })))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(PlainBlockValue { lx: lx.clone(), env: env.clone(), b: b.clone() }))
        }
    }
}

/// `Start BlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_block_value(lx: Lx, env: Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(BlockValue { lx, env, b })
}

/// ```prism
/// IsGivenBlock: fn [Stmt] -> Bool
/// ```
pub fn is_given_block(stmts: &Array<crate::syntax::Stmt>) -> bool {
    fold(stmts, &false, &(|f: &bool, s: &crate::syntax::Stmt| *f || is_guardish(s)))
}

/// ```prism
/// IsGuardish: fn Stmt -> Bool
/// ```
pub fn is_guardish(s: &crate::syntax::Stmt) -> bool {
    match &s.kind {
        crate::syntax::StmtKind::SBind(_, _, None) => true,
        crate::syntax::StmtKind::SRequire(_) => true,
        crate::syntax::StmtKind::SForbid(_) => true,
        _ => false,
    }
}

/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub fn block_ty(lx: &Lx, b: &crate::syntax::Block) -> crate::lower::model::OutTy {
    match &or(&index(&b.stmts, &crate::syntax::lexer::dec(&len(&b.stmts))), &dummy_stmt_l()).kind {
        crate::syntax::StmtKind::SExpr(x) => out_ty_of(lx, &peel(&type_at(lx, &x.span))),
        _ => crate::lower::model::OutTy::OutUnit,
    }
}

/// The step machine of `BlockTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockTy: unbounded fn Lx, Block -> OutTy
/// ```
pub struct BlockTy {
    pub lx: Lx,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for BlockTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let b = &self.b;
        match &or(&index(&b.stmts, &crate::syntax::lexer::dec(&len(&b.stmts))), &dummy_stmt_l()).kind {
            crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&type_at(lx, &x.span)) })),
            _ => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutUnit),
        }
    }
}

/// `Start BlockTy, x`: what the function value is when passed to `@Run`.
pub fn start_block_ty(lx: Lx, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(BlockTy { lx, b })
}

/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub fn plain_block_value(lx: &Lx, env: &Env, b: &crate::syntax::Block) -> Vl {
    let n = len(&b.stmts);
    let (dos, env2, last_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
        let b = b.clone();
        let n = n.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)| {
            let b = b.clone();
            let n = n.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let (acc, en, lv_opt) = p0;
                let i = p1;
                {
                    let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                    if &(&i + &Nat::from(1u32)) == &n {
                        match &s.kind {
                            crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x)))),
                            _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_84758: (Array<crate::lower::model::Do>, Env)| {
                                let (more, en2) = block_stmt_84758;
                                prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), None))
                            }),
                        }
                    } else {
                        call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_84873: (Array<crate::lower::model::Do>, Env)| {
                            let (more, en2) = block_stmt_84873;
                            prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env, Option<Vl>)>>>
    }));
    let last = or(&last_opt, &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
    if &len(&dos) == &Nat::from(0u32) {
        last.clone()
    } else {
        Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(own(&last))), value_ty(&last))
    }
}

/// The step machine of `PlainBlockValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainBlockValue: unbounded fn Lx, Env, Block -> Vl
/// ```
pub struct PlainBlockValue {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<Vl> for PlainBlockValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
            let b = b.clone();
            let n = n.clone();
            let lx = lx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)| {
                let b = b.clone();
                let n = n.clone();
                let lx = lx.clone();
                entered(once_job(move || {
                    let (acc, en, lv_opt) = p0;
                    let i = p1;
                    {
                        let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                        if &(&i + &Nat::from(1u32)) == &n {
                            match &s.kind {
                                crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x)))),
                                _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_84758: (Array<crate::lower::model::Do>, Env)| {
                                    let (more, en2) = block_stmt_84758;
                                    prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), None))
                                }),
                            }
                        } else {
                            call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_84873: (Array<crate::lower::model::Do>, Env)| {
                                let (more, en2) = block_stmt_84873;
                                prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env, Option<Vl>)>>>
        }), move |fold_84504: (Array<crate::lower::model::Do>, Env, Option<Vl>)| {
            let (dos, env2, last_opt) = fold_84504;
            let last = or(&last_opt, &Vl::VlOwned(crate::lower::model::Ex::XUnit, crate::lower::model::OutTy::OutUnit));
            if &len(&dos) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished(last.clone())
            } else {
                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(own(&last))), value_ty(&last)))
            }
        })
    }
}

/// `Start PlainBlockValue, x`: what the function value is when passed to `@Run`.
pub fn start_plain_block_value(lx: Lx, env: Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(PlainBlockValue { lx, env, b })
}

/// ```prism
/// let dummyStmtL
/// ```
pub fn dummy_stmt_l() -> crate::syntax::Stmt {
    crate::syntax::Stmt { kind: crate::syntax::StmtKind::SExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn block_stmt(lx: &Lx, env: &Env, s: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, Env) {
    match &s.kind {
        crate::syntax::StmtKind::SLet(p_, _, x) => match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => match get(&lx.gens, &place_key(lx, &n.span)) {
                Some(gn) => generic_let(lx, env, n, &gn, x),
                None => plain_let(lx, env, s, p_, x),
            },
            _ => plain_let(lx, env, s, p_, x),
        },
        crate::syntax::StmtKind::SExpr(x) => (Array::from(vec![crate::lower::model::Do::DoExpr(own(&value_of(lx, env, x)))]), env.clone()),
        crate::syntax::StmtKind::SSignature(_) => (Array::new(), env.clone()),
        crate::syntax::StmtKind::SFn(f) => (Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f.name))))]), env.clone()),
        _ => (Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env.clone()),
    }
}

/// The step machine of `BlockStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct BlockStmt {
    pub lx: Lx,
    pub env: Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, Env)> for BlockStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SLet(p_, _, x) => match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => match get(&lx.gens, &place_key(lx, &n.span)) {
                    Some(gn) => prism_rtl::Turn::More(Rc::new(GenericLet { lx: lx.clone(), env: env.clone(), n: n.clone(), gn: gn.clone(), x: x.clone() })),
                    None => prism_rtl::Turn::More(Rc::new(PlainLet { lx: lx.clone(), env: env.clone(), s: s.clone(), p_: p_.clone(), x: x.clone() })),
                },
                _ => prism_rtl::Turn::More(Rc::new(PlainLet { lx: lx.clone(), env: env.clone(), s: s.clone(), p_: p_.clone(), x: x.clone() })),
            },
            crate::syntax::StmtKind::SExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_85581: Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(own(&value_of_85581))]), env.clone())))
            },
            crate::syntax::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((Array::new(), env.clone())),
            crate::syntax::StmtKind::SFn(f) => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::from(format!("a local function {}: not lowered yet", &crate::check::env::def_name_text(&f.name))))]), env.clone())),
            _ => prism_rtl::Turn::Finished((Array::from(vec![refusal_do(&Text::lit("a statement this back end does not lower yet"))]), env.clone())),
        }
    }
}

/// `Start BlockStmt, x`: what the function value is when passed to `@Run`.
pub fn start_block_stmt(lx: Lx, env: Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>> {
    Rc::new(BlockStmt { lx, env, s })
}

/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub fn generic_let(lx: &Lx, env: &Env, n: &crate::syntax::SName, gn: &crate::check::typed::GenNote, x: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, Env) {
    let nkey = crate::check::env::sname_key(n);
    let distinct = instantiations(lx, gn);
    let one = &len(&distinct) == &Nat::from(1u32);
    let rs = local_name(lx, &nkey);
    run_to_end(fold_job(crate::check::errors::range0(&len(&distinct)), (Array::new(), env.clone()), {
        let distinct = distinct.clone();
        let lx = lx.clone();
        let one = one;
        let rs = rs.clone();
        let nkey = nkey.clone();
        let n = n.clone();
        let env = env.clone();
        let x = x.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), Nat)| {
            let distinct = distinct.clone();
            let lx = lx.clone();
            let one = one;
            let rs = rs.clone();
            let nkey = nkey.clone();
            let n = n.clone();
            let env = env.clone();
            let x = x.clone();
            entered(once_job(move || {
                let (dos, en) = p0;
                let k = p1;
                {
                    let (tys, cols) = or(&index(&distinct, &k), &(Array::new(), Array::new()));
                    let lxk = at_instance(&lx, &(tys.clone(), cols.clone()));
                    let rk = if one { rs.clone() } else { Text::from(format!("{}_{}", &rs, &k)) };
                    let bkey = if &k == &Nat::from(0u32) {
                        nkey.clone()
                    } else {
                        Text::from(format!("{}#inst{}", &nkey, &k))
                    };
                    call_then(start_out_ty_of(lxk.clone(), peel(&binder_ty(&lxk, &n.span))), move |out_ty_of_86743: crate::lower::model::OutTy| {
                        let bt = out_ty_of_86743;
                        call_then(start_value_of(lxk.clone(), env.clone(), x.clone()), move |value_of_86802: Vl| {
                            let v_ = value_of_86802;
                            let en1 = bind(&en, &bkey, &Bn::BnLocal(crate::lower::model::Ex::XVar(rk.clone()), Holding::Owned, bt.clone()));
                            let en2 = {
                                let mut this: Env = en1.clone();
                                this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey, &show_text(&(tys.clone(), cols.clone())))), &bkey);
                                this
                            };
                            let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk.clone()), own(&v_));
                            prism_rtl::Turn::Finished((push(&dos, &d), en2.clone()))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
    }))
}

/// The step machine of `GenericLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenericLet: unbounded fn Lx, Env, SName, GenNote, Expr -> (([Do], Env))
/// ```
pub struct GenericLet {
    pub lx: Lx,
    pub env: Env,
    pub n: crate::syntax::SName,
    pub gn: crate::check::typed::GenNote,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, Env)> for GenericLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let gn = &self.gn;
        let x = &self.x;
        let nkey = crate::check::env::sname_key(n);
        let env = env.clone();
        let gn = gn.clone();
        let lx = lx.clone();
        let n = n.clone();
        let x = x.clone();
        call_then(start_instantiations(lx.clone(), gn.clone()), move |instantiations_86362: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| {
            let distinct = instantiations_86362;
            let one = &len(&distinct) == &Nat::from(1u32);
            let rs = local_name(&lx, &nkey);
            fold_job(crate::check::errors::range0(&len(&distinct)), (Array::new(), env.clone()), {
                let distinct = distinct.clone();
                let lx = lx.clone();
                let one = one;
                let rs = rs.clone();
                let nkey = nkey.clone();
                let n = n.clone();
                let env = env.clone();
                let x = x.clone();
                Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), Nat)| {
                    let distinct = distinct.clone();
                    let lx = lx.clone();
                    let one = one;
                    let rs = rs.clone();
                    let nkey = nkey.clone();
                    let n = n.clone();
                    let env = env.clone();
                    let x = x.clone();
                    entered(once_job(move || {
                        let (dos, en) = p0;
                        let k = p1;
                        {
                            let (tys, cols) = or(&index(&distinct, &k), &(Array::new(), Array::new()));
                            let lxk = at_instance(&lx, &(tys.clone(), cols.clone()));
                            let rk = if one { rs.clone() } else { Text::from(format!("{}_{}", &rs, &k)) };
                            let bkey = if &k == &Nat::from(0u32) {
                                nkey.clone()
                            } else {
                                Text::from(format!("{}#inst{}", &nkey, &k))
                            };
                            call_then(start_out_ty_of(lxk.clone(), peel(&binder_ty(&lxk, &n.span))), move |out_ty_of_86743: crate::lower::model::OutTy| {
                                let bt = out_ty_of_86743;
                                call_then(start_value_of(lxk.clone(), env.clone(), x.clone()), move |value_of_86802: Vl| {
                                    let v_ = value_of_86802;
                                    let en1 = bind(&en, &bkey, &Bn::BnLocal(crate::lower::model::Ex::XVar(rk.clone()), Holding::Owned, bt.clone()));
                                    let en2 = {
                                        let mut this: Env = en1.clone();
                                        this.uses = insert(&this.uses, &Text::from(format!("{}#{}", &nkey, &show_text(&(tys.clone(), cols.clone())))), &bkey);
                                        this
                                    };
                                    let d = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rk.clone()), own(&v_));
                                    prism_rtl::Turn::Finished((push(&dos, &d), en2.clone()))
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
            }).cycle()
        })
    }
}

/// `Start GenericLet, x`: what the function value is when passed to `@Run`.
pub fn start_generic_let(lx: Lx, env: Env, n: crate::syntax::SName, gn: crate::check::typed::GenNote, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>> {
    Rc::new(GenericLet { lx, env, n, gn, x })
}

/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn instantiations(lx: &Lx, gn: &crate::check::typed::GenNote) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    run_to_end(fold_job(or(&get(&lx.insts, &gen_key(gn)), &Array::new()), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let u = p1;
                call_then(start_expanded(lx.clone(), inst_at(&lx, &u)), move |expanded_87467: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_87467, &acc, &(|a: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a, &false, &(|seen: &bool, j: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen || (&show_text(j) == &show_text(i)))) {
                    a.clone()
                } else {
                    push(a, i)
                }))))
            }))
        }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
    }))
}

/// The step machine of `Instantiations`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Instantiations: unbounded fn Lx, GenNote -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Instantiations {
    pub lx: Lx,
    pub gn: crate::check::typed::GenNote,
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Instantiations {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx = &self.lx;
        let gn = &self.gn;
        fold_job(or(&get(&lx.insts, &gen_key(gn)), &Array::new()), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let u = p1;
                    call_then(start_expanded(lx.clone(), inst_at(&lx, &u)), move |expanded_87467: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(fold(&expanded_87467, &acc, &(|a: &Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| if fold(a, &false, &(|seen: &bool, j: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)| *seen || (&show_text(j) == &show_text(i)))) {
                        a.clone()
                    } else {
                        push(a, i)
                    }))))
                }))
            }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, crate::check::typed::InstNote)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
        }).cycle()
    }
}

/// `Start Instantiations, x`: what the function value is when passed to `@Run`.
pub fn start_instantiations(lx: Lx, gn: crate::check::typed::GenNote) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Instantiations { lx, gn })
}

/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub fn expanded(lx: &Lx, i: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)> {
    match open_q(lx, i) {
        None => Array::from(vec![i.clone()]),
        Some(q) => match get(&lx.gen_of_q, &q) {
            Some(g) => run_to_end(fold_job(instantiations(lx, &g), Array::new(), {
                let lx = lx.clone();
                let i = i.clone();
                Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                    let lx = lx.clone();
                    let i = i.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let gi = p1;
                        {
                            let lx2 = at_instance(&lx, &gi);
                            call_then(start_expanded(lx2.clone(), subst_inst(&lx2, &i)), move |expanded_87900: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc, &expanded_87900)))
                        }
                    }))
                }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
            })),
            None => Array::from(vec![i.clone()]),
        },
    }
}

/// The step machine of `Expanded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expanded: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> [(([((Text, Ty))], [((Text, Col))]))]
/// ```
pub struct Expanded {
    pub lx: Lx,
    pub i: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> for Expanded {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>> {
        let lx = &self.lx;
        let i = &self.i;
        let i = i.clone();
        let lx = lx.clone();
        call_then(start_open_q(lx.clone(), i.clone()), move |open_q_87718: Option<Text>| match open_q_87718 {
            None => prism_rtl::Turn::Finished(Array::from(vec![i.clone()])),
            Some(q) => match get(&lx.gen_of_q, &q) {
                Some(g) => call_then(start_instantiations(lx.clone(), g.clone()), move |instantiations_87795: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| fold_job(instantiations_87795, Array::new(), {
                    let lx = lx.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))| {
                        let lx = lx.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let gi = p1;
                            {
                                let lx2 = at_instance(&lx, &gi);
                                call_then(start_expanded(lx2.clone(), subst_inst(&lx2, &i)), move |expanded_87900: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| prism_rtl::Turn::Finished(append(&acc, &expanded_87900)))
                            }
                        }))
                    }) as Rc<dyn Fn((Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>, (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>))) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>>>
                }).cycle()),
                None => prism_rtl::Turn::Finished(Array::from(vec![i.clone()])),
            },
        })
    }
}

/// `Start Expanded, x`: what the function value is when passed to `@Run`.
pub fn start_expanded(lx: Lx, i: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>>> {
    Rc::new(Expanded { lx, i })
}

/// ```prism
/// SubstInst: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn subst_inst(lx: &Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    match arg1 {
        (tys, cols) => {
            let tys2 = each(tys, &(|(q, t): &(Text, crate::check::types::Ty)| (q.clone(), subst_ty(lx, t))));
            let cols2 = each(cols, &(|(q, c): &(Text, crate::check::types::Col)| (q.clone(), inst_col(lx, c))));
            (tys2.clone(), cols2.clone())
        },
    }
}

/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub fn open_q(lx: &Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Option<Text> {
    match arg1 {
        (tys, cols) => {
            let from_cols = fold(cols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(Text, crate::check::types::Col)| append(acc, &open_cols(lx, c))));
            let all = run_to_end(fold_job(tys.clone(), from_cols.clone(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let (_, t) = p1;
                        call_then(start_open_ty_qs(lx.clone(), t.clone()), move |open_ty_qs_88581: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_88581)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }));
            index(&all, &Nat::from(0u32))
        },
    }
}

/// The step machine of `OpenQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?OpenQ: unbounded fn Lx, (([((Text, Ty))], [((Text, Col))])) -> ?Text
/// ```
pub struct OpenQ {
    pub lx: Lx,
    pub arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>),
}

impl prism_rtl::Job<Option<Text>> for OpenQ {
    fn cycle(&self) -> prism_rtl::Turn<Option<Text>> {
        let lx = &self.lx;
        let arg1 = &self.arg1;
        match arg1 {
            (tys, cols) => {
                let from_cols = fold(cols, &Array::new(), &(|acc: &Array<Text>, (_, c): &(Text, crate::check::types::Col)| append(acc, &open_cols(lx, c))));
                let lx = lx.clone();
                let tys = tys.clone();
                call_value(fold_job(tys.clone(), from_cols.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, (Text, crate::check::types::Ty))| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let (_, t) = p1;
                            call_then(start_open_ty_qs(lx.clone(), t.clone()), move |open_ty_qs_88581: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_88581)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }), move |fold_88526: Array<Text>| {
                    let all = fold_88526;
                    prism_rtl::Turn::Finished(index(&all, &Nat::from(0u32)))
                })
            },
        }
    }
}

/// `Start OpenQ, x`: what the function value is when passed to `@Run`.
pub fn start_open_q(lx: Lx, arg1: (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Rc<dyn prism_rtl::Job<Option<Text>>> {
    Rc::new(OpenQ { lx, arg1 })
}

/// ```prism
/// OpenCols: fn Lx, Col -> [Text]
/// ```
pub fn open_cols(lx: &Lx, col1: &crate::check::types::Col) -> Array<Text> {
    match col1 {
        crate::check::types::Col::CQ(q) => if crate::check::env::has_key(&lx.gen_of_q, q) && !crate::check::env::has_key(&lx.csubst, q) {
            Array::from(vec![q.clone()])
        } else {
            Array::new()
        },
        c => Array::new(),
    }
}

/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub fn open_ty_qs(lx: &Lx, t: &crate::check::types::Ty) -> Array<Text> {
    match t {
        crate::check::types::Ty::TyFlex(n) => if crate::check::env::has_key(&lx.gen_of_q, &Text::from(format!("'{}", n))) && !crate::check::env::has_key(&lx.subst, &Text::from(format!("'{}", n))) {
            Array::from(vec![Text::from(format!("'{}", n))])
        } else {
            Array::new()
        },
        crate::check::types::Ty::TyFn(c, ps, res) => run_to_end(fold_job(push(ps, &**res), open_cols(lx, c), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89017: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89017)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyCon(_, args) => run_to_end(fold_job(args.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89097: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89097)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let x = p1;
                    call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89167: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89167)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        })),
        crate::check::types::Ty::TyArray(e) => open_ty_qs(lx, &**e),
        crate::check::types::Ty::TyMap(k, v_) => append(&open_ty_qs(lx, &**k), &open_ty_qs(lx, &**v_)),
        crate::check::types::Ty::TySig(_, i) => open_ty_qs(lx, &**i),
        crate::check::types::Ty::TyAt(i, _) => open_ty_qs(lx, &**i),
        crate::check::types::Ty::TyElem(_, o) => open_ty_qs(lx, &**o),
        crate::check::types::Ty::TyAssoc(_, a) => open_ty_qs(lx, &**a),
        _ => Array::new(),
    }
}

/// The step machine of `OpenTyQs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OpenTyQs: unbounded fn Lx, Ty -> [Text]
/// ```
pub struct OpenTyQs {
    pub lx: Lx,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<Array<Text>> for OpenTyQs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let t = &self.t;
        match t {
            crate::check::types::Ty::TyFlex(n) => if crate::check::env::has_key(&lx.gen_of_q, &Text::from(format!("'{}", n))) && !crate::check::env::has_key(&lx.subst, &Text::from(format!("'{}", n))) {
                prism_rtl::Turn::Finished(Array::from(vec![Text::from(format!("'{}", n))]))
            } else {
                prism_rtl::Turn::Finished(Array::new())
            },
            crate::check::types::Ty::TyFn(c, ps, res) => fold_job(push(ps, &**res), open_cols(lx, c), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89017: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89017)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyCon(_, args) => fold_job(args.clone(), Array::new(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89097: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89097)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), Array::new(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let x = p1;
                        call_then(start_open_ty_qs(lx.clone(), x.clone()), move |open_ty_qs_89167: Array<Text>| prism_rtl::Turn::Finished(append(&acc, &open_ty_qs_89167)))
                    }))
                }) as Rc<dyn Fn((Array<Text>, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**e).clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let lx = lx.clone();
                let v_ = (**v_).clone();
                call_then(start_open_ty_qs(lx.clone(), k.clone()), move |open_ty_qs_89237: Array<Text>| call_then(start_open_ty_qs(lx.clone(), v_.clone()), move |open_ty_qs_89255: Array<Text>| prism_rtl::Turn::Finished(append(&open_ty_qs_89237, &open_ty_qs_89255))))
            },
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**i).clone() })),
            crate::check::types::Ty::TyAt(i, _) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**i).clone() })),
            crate::check::types::Ty::TyElem(_, o) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**o).clone() })),
            crate::check::types::Ty::TyAssoc(_, a) => prism_rtl::Turn::More(Rc::new(OpenTyQs { lx: lx.clone(), t: (**a).clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OpenTyQs, x`: what the function value is when passed to `@Run`.
pub fn start_open_ty_qs(lx: Lx, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(OpenTyQs { lx, t })
}

/// ```prism
/// AtInstance: fn Lx, (([((Text, Ty))], [((Text, Col))])) -> Lx
/// ```
pub fn at_instance(lx: &Lx, arg1: &(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)) -> Lx {
    match arg1 {
        (tys, cols) => {
            let mut this: Lx = lx.clone();
            this.subst = fold(tys, &this.subst, &(|m: &Map<Text, crate::check::types::Ty>, (q, t): &(Text, crate::check::types::Ty)| insert(m, q, t)));
            this.csubst = fold(cols, &this.csubst, &(|m: &Map<Text, crate::check::types::Col>, (q, c): &(Text, crate::check::types::Col)| insert(m, q, c)));
            this
        },
    }
}

/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub fn widget_let_lx(lx: &Lx, span: &crate::syntax::Range) -> Lx {
    match get(&lx.gens, &place_key(lx, span)) {
        Some(gn) => 'm90076: {
            let scrutinee = &instantiations(lx, &gn);
            if let m90076_0 = scrutinee && (m90076_0.len() == 1) && let Some(i) = index(m90076_0, &Nat::from(0u32)) {
                break 'm90076 at_instance(lx, &i);
            }
            lx.clone()
        },
        None => lx.clone(),
    }
}

/// The step machine of `WidgetLetLx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WidgetLetLx: unbounded fn Lx, Range -> Lx
/// ```
pub struct WidgetLetLx {
    pub lx: Lx,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Lx> for WidgetLetLx {
    fn cycle(&self) -> prism_rtl::Turn<Lx> {
        let lx = &self.lx;
        let span = &self.span;
        match get(&lx.gens, &place_key(lx, span)) {
            Some(gn) => {
                let lx = lx.clone();
                call_then(start_instantiations(lx.clone(), gn.clone()), move |instantiations_90082: Array<(Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>)>| 'm90076: {
                    if let m90076_0 = &instantiations_90082 && (m90076_0.len() == 1) && let Some(i) = index(m90076_0, &Nat::from(0u32)) {
                        break 'm90076 prism_rtl::Turn::Finished(at_instance(&lx, &i));
                    }
                    prism_rtl::Turn::Finished(lx.clone())
                })
            },
            None => prism_rtl::Turn::Finished(lx.clone()),
        }
    }
}

/// `Start WidgetLetLx, x`: what the function value is when passed to `@Run`.
pub fn start_widget_let_lx(lx: Lx, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Lx>> {
    Rc::new(WidgetLetLx { lx, span })
}

/// ```prism
/// InstAt: fn Lx, InstNote -> (([((Text, Ty))], [((Text, Col))]))
/// ```
pub fn inst_at(lx: &Lx, u: &crate::check::typed::InstNote) -> (Array<(Text, crate::check::types::Ty)>, Array<(Text, crate::check::types::Col)>) {
    let tys = each(&u.tys, &(|(q, t): &(Text, crate::check::types::Ty)| (q.clone(), subst_ty(lx, t))));
    let cols = each(&u.cols, &(|(q, c): &(Text, crate::check::types::Col)| (q.clone(), inst_col(lx, c))));
    (tys.clone(), cols.clone())
}

/// ```prism
/// GenKey: fn GenNote -> Text
/// ```
pub fn gen_key(gn: &crate::check::typed::GenNote) -> Text {
    or(&index(&append(&gn.tys, &gn.cols), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// InstKey: fn InstNote -> Text
/// ```
pub fn inst_key(u: &crate::check::typed::InstNote) -> Text {
    or(&index(&append(&each(&u.tys, &(|(q, _): &(Text, crate::check::types::Ty)| q.clone())), &each(&u.cols, &(|(q, _): &(Text, crate::check::types::Col)| q.clone()))), &Nat::from(0u32)), &Text::lit(""))
}

/// ```prism
/// ColName: fn Col -> Text
/// ```
pub fn col_name(col0: &crate::check::types::Col) -> Text {
    match col0 {
        crate::check::types::Col::CQ(q) => q.clone(),
        c => Text::lit(""),
    }
}

/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub fn plain_let(lx: &Lx, env: &Env, s: &crate::syntax::Stmt, p_: &crate::syntax::Pattern_, x: &crate::syntax::Expr) -> (Array<crate::lower::model::Do>, Env) {
    let v_ = value_of(lx, env, x);
    let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("l{}", &s.span.start)));
    (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), own(&v_))]), bind_all(env, &po.binds))
}

/// The step machine of `PlainLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainLet: unbounded fn Lx, Env, Stmt, Pattern, Expr -> (([Do], Env))
/// ```
pub struct PlainLet {
    pub lx: Lx,
    pub env: Env,
    pub s: crate::syntax::Stmt,
    pub p_: crate::syntax::Pattern_,
    pub x: crate::syntax::Expr,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, Env)> for PlainLet {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let p_ = &self.p_;
        let x = &self.x;
        let env = env.clone();
        let lx = lx.clone();
        let p_ = p_.clone();
        let s = s.clone();
        let x = x.clone();
        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_90867: Vl| {
            let v_ = value_of_90867;
            call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_90903: PatOut| {
                let po = rust_pat_90903;
                prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), own(&v_))]), bind_all(&env, &po.binds)))
            })
        })
    }
}

/// `Start PlainLet, x`: what the function value is when passed to `@Run`.
pub fn start_plain_let(lx: Lx, env: Env, s: crate::syntax::Stmt, p_: crate::syntax::Pattern_, x: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>> {
    Rc::new(PlainLet { lx, env, s, p_, x })
}

/// ```prism
/// PatOnly: fn Pa -> PatOut
/// ```
pub fn pat_only(pa: &crate::lower::model::Pa) -> PatOut {
    PatOut { pa: pa.clone(), conds: Array::new(), binds: Array::new() }
}

/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn rust_pat(lx: &Lx, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let nkey = crate::check::env::sname_key(n);
            let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            let is_ctor = match &qk_opt {
                Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && ((crate::check::env::is_upper_text(&base(&nkey)) || (&len(&n.path_) > &Nat::from(1u32))) || is_unit_ctor(lx, qk)),
                None => false,
            };
            let tagged_opt = match &qk_opt {
                Some(qk) => get(&lx.g.tags, qk),
                None => None,
            };
            if is_ctor {
                ctor_pat(lx, n, &Array::new(), ty, mode, fresh)
            } else {
                if (&why == &Text::lit("tag")) && (&tagged_opt != &None) {
                    tag_pat(lx, &or(&tagged_opt, &dummy_tag_info()), &Array::new(), &true, ty, mode, fresh)
                } else {
                    {
                        let rs = local_name(lx, &nkey);
                        let bt = out_ty_of(lx, &peel(&binder_ty(lx, &n.span)));
                        PatOut { pa: crate::lower::model::Pa::PaBind(rs.clone()), conds: Array::new(), binds: Array::from(vec![(nkey.clone(), Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), mode.clone(), bt.clone()))]) }
                    }
                }
            }
        },
        crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PUnit => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PNil => pat_only(&crate::lower::model::Pa::PaUnit(Text::lit("None"))),
        crate::syntax::PatternKind::PLit(l) => lit_pat(lx, l, ty, mode, fresh, &false),
        crate::syntax::PatternKind::PNeg(l) => lit_pat(lx, l, ty, mode, fresh, &true),
        crate::syntax::PatternKind::PSigil(m91829_6_0, q) if (m91829_6_0 == &Text::lit("?")) => wrap_pat(lx, &Text::lit("Some"), &**q, &inner_ty(ty), mode, fresh),
        crate::syntax::PatternKind::PSigil(m91829_7_0, q) if (m91829_7_0 == &Text::lit("~")) => wrap_pat(lx, &Text::lit("Ok"), &**q, &inner_ty(ty), mode, fresh),
        crate::syntax::PatternKind::PSigil(_, q) => rust_pat(lx, &**q, ty, mode, fresh),
        crate::syntax::PatternKind::PGroup(q) => rust_pat(lx, &**q, ty, mode, fresh),
        crate::syntax::PatternKind::PCtor(n, ps) => ctor_pat(lx, n, ps, ty, mode, fresh),
        crate::syntax::PatternKind::PRecord(n, fps, rest) => record_pat(lx, n, fps, rest, ty, mode, fresh),
        crate::syntax::PatternKind::PTuple(ps) => {
            let ts = match peel(ty) {
                crate::check::types::Ty::TyTuple(xs) => xs.clone(),
                _ => Array::new(),
            };
            let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                let lx = lx.clone();
                let ps = ps.clone();
                let ts = ts.clone();
                let mode = mode.clone();
                let fresh = fresh.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let ts = ts.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: or(&index(&ts, &i), &crate::check::types::Ty::TyErr), mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }));
            PatOut { pa: crate::lower::model::Pa::PaTuple(each(&subs, &(|o: &PatOut| o.pa.clone()))), conds: fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds))), binds: fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds))) }
        },
        crate::syntax::PatternKind::PArray(ps) => array_pat(lx, ps, ty, mode, fresh),
        crate::syntax::PatternKind::PFamily(q) => family_pat(lx, q, ty, fresh),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustPat: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct RustPat {
    pub lx: Lx,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for RustPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        match &*p_.kind {
            crate::syntax::PatternKind::PName(n) => {
                let nkey = crate::check::env::sname_key(n);
                let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                let is_ctor = match &qk_opt {
                    Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && ((crate::check::env::is_upper_text(&base(&nkey)) || (&len(&n.path_) > &Nat::from(1u32))) || is_unit_ctor(lx, qk)),
                    None => false,
                };
                let tagged_opt = match &qk_opt {
                    Some(qk) => get(&lx.g.tags, qk),
                    None => None,
                };
                if is_ctor {
                    prism_rtl::Turn::More(Rc::new(CtorPat { lx: lx.clone(), n: n.clone(), ps: Array::new(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
                } else {
                    if (&why == &Text::lit("tag")) && (&tagged_opt != &None) {
                        prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: or(&tagged_opt, &dummy_tag_info()), fps: Array::new(), rest: true, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
                    } else {
                        {
                            let rs = local_name(lx, &nkey);
                            let lx = lx.clone();
                            let mode = mode.clone();
                            let n = n.clone();
                            call_then(start_out_ty_of(lx.clone(), peel(&binder_ty(&lx, &n.span))), move |out_ty_of_92447: crate::lower::model::OutTy| {
                                let bt = out_ty_of_92447;
                                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(rs.clone()), conds: Array::new(), binds: Array::from(vec![(nkey.clone(), Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), mode.clone(), bt.clone()))]) })
                            })
                        }
                    }
                }
            },
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PUnit => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PNil => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaUnit(Text::lit("None")))),
            crate::syntax::PatternKind::PLit(l) => prism_rtl::Turn::More(Rc::new(LitPat { lx: lx.clone(), l: l.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), neg: false })),
            crate::syntax::PatternKind::PNeg(l) => prism_rtl::Turn::More(Rc::new(LitPat { lx: lx.clone(), l: l.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), neg: true })),
            crate::syntax::PatternKind::PSigil(m91829_6_0, q) if (m91829_6_0 == &Text::lit("?")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx: lx.clone(), ctor: Text::lit("Some"), q: (**q).clone(), inner: inner_ty(ty), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PSigil(m91829_7_0, q) if (m91829_7_0 == &Text::lit("~")) => prism_rtl::Turn::More(Rc::new(WrapPat { lx: lx.clone(), ctor: Text::lit("Ok"), q: (**q).clone(), inner: inner_ty(ty), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PSigil(_, q) => prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: (**q).clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: (**q).clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PCtor(n, ps) => prism_rtl::Turn::More(Rc::new(CtorPat { lx: lx.clone(), n: n.clone(), ps: ps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PRecord(n, fps, rest) => prism_rtl::Turn::More(Rc::new(RecordPat { lx: lx.clone(), n: n.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PTuple(ps) => {
                let ts = match peel(ty) {
                    crate::check::types::Ty::TyTuple(xs) => xs.clone(),
                    _ => Array::new(),
                };
                let fresh = fresh.clone();
                let lx = lx.clone();
                let mode = mode.clone();
                let ps = ps.clone();
                call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let ts = ts.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    Rc::new(move |p0: Nat| {
                        let lx = lx.clone();
                        let ps = ps.clone();
                        let ts = ts.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        entered(once_job(move || {
                            let i = p0;
                            prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: or(&index(&ts, &i), &crate::check::types::Ty::TyErr), mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) }))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }), move |each_93246: Array<PatOut>| {
                    let subs = each_93246;
                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaTuple(each(&subs, &(|o: &PatOut| o.pa.clone()))), conds: fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds))), binds: fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds))) })
                })
            },
            crate::syntax::PatternKind::PArray(ps) => prism_rtl::Turn::More(Rc::new(ArrayPat { lx: lx.clone(), ps: ps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
            crate::syntax::PatternKind::PFamily(q) => prism_rtl::Turn::More(Rc::new(FamilyPat { lx: lx.clone(), q: q.clone(), ty: ty.clone(), fresh: fresh.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start RustPat, x`: what the function value is when passed to `@Run`.
pub fn start_rust_pat(lx: Lx, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RustPat { lx, p_, ty, mode, fresh })
}

/// ```prism
/// let dummyPat
/// ```
pub fn dummy_pat() -> crate::syntax::Pattern_ {
    crate::syntax::Pattern_ { kind: Rc::new(crate::syntax::PatternKind::PIgnore), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// InnerTy: fn Ty -> Ty
/// ```
pub fn inner_ty(t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match peel(t) {
        crate::check::types::Ty::TySig(m93705_0_0, i) if (&m93705_0_0 == &Text::lit("?")) => (*i).clone(),
        crate::check::types::Ty::TySig(m93705_1_0, i) if (&m93705_1_0 == &Text::lit("~")) => (*i).clone(),
        _ => crate::check::types::Ty::TyErr,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IsUnitCtor: fn Lx, Text -> Bool
/// ```
pub fn is_unit_ctor(lx: &Lx, qk: &Text) -> bool {
    match get(&lx.g.ctors, qk) {
        Some(c) => 'm93958: {
            let scrutinee = &or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info()).body;
            if let crate::check::env::TyBody::BChoice(m93958_0_0) = scrutinee && (m93958_0_0.len() == 1) && let Some((_, m93958_0_0_0_1)) = index(m93958_0_0, &Nat::from(0u32)) && ((&m93958_0_0_0_1).len() == 0) {
                break 'm93958 crate::check::env::is_lower_text(&crate::check::types::bare_name(qk));
            }
            false
        },
        None => false,
    }
}

/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn wrap_pat(lx: &Lx, ctor: &Text, q: &crate::syntax::Pattern_, inner: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let o = rust_pat(lx, q, inner, mode, fresh);
    let mut this: PatOut = o.clone();
    this.pa = crate::lower::model::Pa::PaCtor(ctor.clone(), Array::from(vec![this.pa.clone()]));
    this
}

/// The step machine of `WrapPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WrapPat: unbounded fn Lx, Text, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct WrapPat {
    pub lx: Lx,
    pub ctor: Text,
    pub q: crate::syntax::Pattern_,
    pub inner: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for WrapPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let ctor = &self.ctor;
        let q = &self.q;
        let inner = &self.inner;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let ctor = ctor.clone();
        let fresh = fresh.clone();
        let inner = inner.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let q = q.clone();
        call_then(start_rust_pat(lx.clone(), q.clone(), inner.clone(), mode.clone(), fresh.clone()), move |rust_pat_94238: PatOut| {
            let o = rust_pat_94238;
            prism_rtl::Turn::Finished({
                let mut this: PatOut = o.clone();
                this.pa = crate::lower::model::Pa::PaCtor(ctor.clone(), Array::from(vec![this.pa.clone()]));
                this
            })
        })
    }
}

/// `Start WrapPat, x`: what the function value is when passed to `@Run`.
pub fn start_wrap_pat(lx: Lx, ctor: Text, q: crate::syntax::Pattern_, inner: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(WrapPat { lx, ctor, q, inner, mode, fresh })
}

/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub fn lit_pat(lx: &Lx, l: &crate::syntax::Literal, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text, neg: &bool) -> PatOut {
    let t = out_ty_of(lx, &peel(ty));
    match &l.kind {
        crate::syntax::LitKind::LChar(c) => pat_only(&crate::lower::model::Pa::PaChar(c.clone())),
        _ => {
            let lit = match &l.kind {
                crate::syntax::LitKind::LInt(d) => if (((&t == &crate::lower::model::OutTy::OutNat) || (&t == &crate::lower::model::OutTy::OutInt)) || (&t == &crate::lower::model::OutTy::OutU8)) || (&t == &crate::lower::model::OutTy::OutFloat) {
                    Vl::VlOwned(number(&t, d, neg), t.clone())
                } else {
                    literal_value(lx, &empty_env(), l, &l.span, neg)
                },
                _ => literal_value(lx, &empty_env(), l, &l.span, neg),
            };
            let lv = Vl::VlOwned(own(&lit), t.clone());
            let b = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &t);
            PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(ref_(&b)), Rc::new(ref_(&lv))))]), binds: Array::new() }
        },
    }
}

/// The step machine of `LitPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LitPat: unbounded fn Lx, Literal, Ty, Holding, Text, Bool -> PatOut
/// ```
pub struct LitPat {
    pub lx: Lx,
    pub l: crate::syntax::Literal,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
    pub neg: bool,
}

impl prism_rtl::Job<PatOut> for LitPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let l = &self.l;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let neg = &self.neg;
        let fresh = fresh.clone();
        let l = l.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let neg = *neg;
        let ty = ty.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&ty)), move |out_ty_of_94550: crate::lower::model::OutTy| {
            let t = out_ty_of_94550;
            match &l.kind {
                crate::syntax::LitKind::LChar(c) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaChar(c.clone()))),
                _ => {
                    let lit = match &l.kind {
                        crate::syntax::LitKind::LInt(d) => if (((&t == &crate::lower::model::OutTy::OutNat) || (&t == &crate::lower::model::OutTy::OutInt)) || (&t == &crate::lower::model::OutTy::OutU8)) || (&t == &crate::lower::model::OutTy::OutFloat) {
                            Vl::VlOwned(number(&t, d, &neg), t.clone())
                        } else {
                            literal_value(&lx, &empty_env(), &l, &l.span, &neg)
                        },
                        _ => literal_value(&lx, &empty_env(), &l, &l.span, &neg),
                    };
                    let lv = Vl::VlOwned(own(&lit), t.clone());
                    let b = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &mode, &t);
                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(ref_(&b)), Rc::new(ref_(&lv))))]), binds: Array::new() })
                },
            }
        })
    }
}

/// `Start LitPat, x`: what the function value is when passed to `@Run`.
pub fn start_lit_pat(lx: Lx, l: crate::syntax::Literal, ty: crate::check::types::Ty, mode: Holding, fresh: Text, neg: bool) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LitPat { lx, l, ty, mode, fresh, neg })
}

/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn ctor_pat(lx: &Lx, n: &crate::syntax::SName, ps: &Array<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
    match &qk_opt {
        Some(m95593_0) if (m95593_0 == &Text::lit("True")) => pat_only(&crate::lower::model::Pa::PaBool(true)),
        Some(m95593_1) if (m95593_1 == &Text::lit("False")) => pat_only(&crate::lower::model::Pa::PaBool(false)),
        Some(qk) => match get(&lx.g.ctors, qk) {
            Some(c) => {
                let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
                let ty_path = path_in(lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
                let args = match peel(ty) {
                    crate::check::types::Ty::TyCon(_, xs) => xs.clone(),
                    _ => Array::new(),
                };
                let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
                    let lx = lx.clone();
                    let c = c.clone();
                    let ps = ps.clone();
                    let args = args.clone();
                    let mode = mode.clone();
                    let fresh = fresh.clone();
                    Rc::new(move |p0: Nat| {
                        let lx = lx.clone();
                        let c = c.clone();
                        let ps = ps.clone();
                        let args = args.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        entered(once_job(move || {
                            let i = p0;
                            call_then(start_instantiated(or(&index(&c.args, &i), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_96097: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx: lx.clone(), c: c.clone(), i: i.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: instantiated_96097, mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) })))
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                }));
                let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds)));
                let pas = each(&subs, &(|o: &PatOut| o.pa.clone()));
                match &owner.body {
                    crate::check::env::TyBody::BRecord(fs) => PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&pas)), &(|i: &Nat| (snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&pas, i), &crate::lower::model::Pa::PaWild)))), &len(&pas) < &len(&c.fields)), conds: conds.clone(), binds: binds.clone() },
                    _ => {
                        let is_unit_type = (&len(&c.args) == &Nat::from(0u32)) && is_unit_ctor(lx, qk);
                        let is_newtype = (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner)) && match &owner.body {
                            crate::check::env::TyBody::BChoice(cases) => &len(cases) == &Nat::from(1u32),
                            _ => false,
                        };
                        let path_ = if is_unit_type || is_newtype {
                            ty_path.clone()
                        } else {
                            Text::from(format!("{}::{}", &ty_path, &camel(&crate::check::types::bare_name(&c.name))))
                        };
                        if &len(&c.args) == &Nat::from(0u32) {
                            PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() }
                        } else {
                            PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), pas.clone()), conds: conds.clone(), binds: binds.clone() }
                        }
                    },
                }
            },
            None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern of {}", qk))))]), binds: Array::new() },
        },
        None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::lit("a pattern of an unknown constructor")))]), binds: Array::new() },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `CtorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorPat: unbounded fn Lx, SName, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct CtorPat {
    pub lx: Lx,
    pub n: crate::syntax::SName,
    pub ps: Array<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for CtorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let n = &self.n;
        let ps = &self.ps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
        match &qk_opt {
            Some(m95593_0) if (m95593_0 == &Text::lit("True")) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaBool(true))),
            Some(m95593_1) if (m95593_1 == &Text::lit("False")) => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaBool(false))),
            Some(qk) => match get(&lx.g.ctors, qk) {
                Some(c) => {
                    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
                    let ty_path = path_in(lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
                    let args = match peel(ty) {
                        crate::check::types::Ty::TyCon(_, xs) => xs.clone(),
                        _ => Array::new(),
                    };
                    let fresh = fresh.clone();
                    let lx = lx.clone();
                    let mode = mode.clone();
                    let ps = ps.clone();
                    let qk = qk.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                        let lx = lx.clone();
                        let c = c.clone();
                        let ps = ps.clone();
                        let args = args.clone();
                        let mode = mode.clone();
                        let fresh = fresh.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let c = c.clone();
                            let ps = ps.clone();
                            let args = args.clone();
                            let mode = mode.clone();
                            let fresh = fresh.clone();
                            entered(once_job(move || {
                                let i = p0;
                                call_then(start_instantiated(or(&index(&c.args, &i), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_96097: crate::check::types::Ty| prism_rtl::Turn::More(Rc::new(SubPat { lx: lx.clone(), c: c.clone(), i: i.clone(), p_: or(&index(&ps, &i), &dummy_pat()), ty: instantiated_96097, mode: mode.clone(), fresh: Text::from(format!("{}_{}", &fresh, &i)) })))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                    }), move |each_96028: Array<PatOut>| {
                        let subs = each_96028;
                        let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                        let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds)));
                        let pas = each(&subs, &(|o: &PatOut| o.pa.clone()));
                        match &owner.body {
                            crate::check::env::TyBody::BRecord(fs) => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&crate::check::errors::range0(&len(&pas)), &(|i: &Nat| (snake(&or(&index(&c.fields, i), &Text::lit(""))), or(&index(&pas, i), &crate::lower::model::Pa::PaWild)))), &len(&pas) < &len(&c.fields)), conds: conds.clone(), binds: binds.clone() }),
                            _ => {
                                let is_unit_type = (&len(&c.args) == &Nat::from(0u32)) && is_unit_ctor(&lx, &qk);
                                let is_newtype = (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner)) && match &owner.body {
                                    crate::check::env::TyBody::BChoice(cases) => &len(cases) == &Nat::from(1u32),
                                    _ => false,
                                };
                                let path_ = if is_unit_type || is_newtype {
                                    ty_path.clone()
                                } else {
                                    Text::from(format!("{}::{}", &ty_path, &camel(&crate::check::types::bare_name(&c.name))))
                                };
                                if &len(&c.args) == &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() })
                                } else {
                                    prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), pas.clone()), conds: conds.clone(), binds: binds.clone() })
                                }
                            },
                        }
                    })
                },
                None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern of {}", qk))))]), binds: Array::new() }),
            },
            None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::lit("a pattern of an unknown constructor")))]), binds: Array::new() }),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start CtorPat, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_pat(lx: Lx, n: crate::syntax::SName, ps: Array<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(CtorPat { lx, n, ps, ty, mode, fresh })
}

/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn sub_pat(lx: &Lx, c: &crate::check::env::CtorInfo, i: &Nat, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    if !rc_field(lx, &c.name, i) {
        rust_pat(lx, p_, ty, mode, fresh)
    } else {
        {
            let rc_mode = if mode == &Holding::Owned { Holding::RcOwned } else { Holding::RcRef };
            match &*p_.kind {
                crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
                crate::syntax::PatternKind::PName(n) => {
                    let o = rust_pat(lx, p_, ty, &rc_mode, fresh);
                    match &o.pa {
                        crate::lower::model::Pa::PaBind(_) => o.clone(),
                        _ => behind_rc(lx, p_, ty, &rc_mode, fresh),
                    }
                },
                _ => behind_rc(lx, p_, ty, &rc_mode, fresh),
            }
        }
    }
}

/// The step machine of `SubPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubPat: unbounded fn Lx, CtorInfo, Nat, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct SubPat {
    pub lx: Lx,
    pub c: crate::check::env::CtorInfo,
    pub i: Nat,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for SubPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let c = &self.c;
        let i = &self.i;
        let p_ = &self.p_;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        if !rc_field(lx, &c.name, i) {
            prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
        } else {
            {
                let rc_mode = if mode == &Holding::Owned { Holding::RcOwned } else { Holding::RcRef };
                match &*p_.kind {
                    crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
                    crate::syntax::PatternKind::PName(n) => {
                        let fresh = fresh.clone();
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let ty = ty.clone();
                        call_then(start_rust_pat(lx.clone(), p_.clone(), ty.clone(), rc_mode.clone(), fresh.clone()), move |rust_pat_97991: PatOut| {
                            let o = rust_pat_97991;
                            match &o.pa {
                                crate::lower::model::Pa::PaBind(_) => prism_rtl::Turn::Finished(o.clone()),
                                _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), rc_mode: rc_mode.clone(), fresh: fresh.clone() })),
                            }
                        })
                    },
                    _ => prism_rtl::Turn::More(Rc::new(BehindRc { lx: lx.clone(), p_: p_.clone(), ty: ty.clone(), rc_mode: rc_mode.clone(), fresh: fresh.clone() })),
                }
            }
        }
    }
}

/// `Start SubPat, x`: what the function value is when passed to `@Run`.
pub fn start_sub_pat(lx: Lx, c: crate::check::env::CtorInfo, i: Nat, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(SubPat { lx, c, i, p_, ty, mode, fresh })
}

/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub fn behind_rc(lx: &Lx, p_: &crate::syntax::Pattern_, ty: &crate::check::types::Ty, rc_mode: &Holding, fresh: &Text) -> PatOut {
    let inner = rust_pat(lx, p_, ty, &Holding::ByRef, &Text::from(format!("{}_r", fresh)));
    let place = ref_(&local_place(&crate::lower::model::Ex::XVar(fresh.clone()), rc_mode, &crate::lower::model::OutTy::OutUnknown(Text::lit("a payload"))));
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner.pa.clone(), place.clone())]), &inner.conds), binds: inner.binds.clone() }
}

/// The step machine of `BehindRc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BehindRc: unbounded fn Lx, Pattern, Ty, Holding, Text -> PatOut
/// ```
pub struct BehindRc {
    pub lx: Lx,
    pub p_: crate::syntax::Pattern_,
    pub ty: crate::check::types::Ty,
    pub rc_mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for BehindRc {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let ty = &self.ty;
        let rc_mode = &self.rc_mode;
        let fresh = &self.fresh;
        let fresh = fresh.clone();
        let lx = lx.clone();
        let p_ = p_.clone();
        let rc_mode = rc_mode.clone();
        let ty = ty.clone();
        call_then(start_rust_pat(lx.clone(), p_.clone(), ty.clone(), Holding::ByRef, Text::from(format!("{}_r", &fresh))), move |rust_pat_98330: PatOut| {
            let inner = rust_pat_98330;
            let place = ref_(&local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &rc_mode, &crate::lower::model::OutTy::OutUnknown(Text::lit("a payload"))));
            prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(inner.pa.clone(), place.clone())]), &inner.conds), binds: inner.binds.clone() })
        })
    }
}

/// `Start BehindRc, x`: what the function value is when passed to `@Run`.
pub fn start_behind_rc(lx: Lx, p_: crate::syntax::Pattern_, ty: crate::check::types::Ty, rc_mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(BehindRc { lx, p_, ty, rc_mode, fresh })
}

/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn record_pat(lx: &Lx, n: &crate::syntax::SName, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
    let qk = or(&qk_opt, &Text::lit(""));
    if &qk == &Text::lit("Prelude.Error") {
        error_pat(lx, fps, ty, mode, fresh)
    } else {
        if (&why == &Text::lit("tag")) && crate::check::env::has_key(&lx.g.tags, &qk) {
            tag_pat(lx, &or(&get(&lx.g.tags, &qk), &dummy_tag_info()), fps, rest, ty, mode, fresh)
        } else {
            match get(&lx.g.ctors, &qk) {
                Some(c) => {
                    let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
                    let ty_path = path_in(lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
                    match &owner.body {
                        crate::check::env::TyBody::BChoice(cases) if (&len(fps) == &Nat::from(0u32)) => rest_case_pat(&c, cases, &ty_path),
                        _ => fields_pat(lx, &c, fps, rest, ty, mode, fresh, &ty_path),
                        _ => unreachable!("no arm matched"),
                    }
                },
                None => match get(&lx.g.tags, &qk) {
                    Some(tg) => tag_pat(lx, &tg, fps, rest, ty, mode, fresh),
                    None => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern of {}", &qk))))]), binds: Array::new() },
                },
            }
        }
    }
}

/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RecordPat: unbounded fn Lx, SName, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct RecordPat {
    pub lx: Lx,
    pub n: crate::syntax::SName,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for RecordPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let n = &self.n;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
        let qk = or(&qk_opt, &Text::lit(""));
        if &qk == &Text::lit("Prelude.Error") {
            prism_rtl::Turn::More(Rc::new(ErrorPat { lx: lx.clone(), fps: fps.clone(), ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
        } else {
            if (&why == &Text::lit("tag")) && crate::check::env::has_key(&lx.g.tags, &qk) {
                prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: or(&get(&lx.g.tags, &qk), &dummy_tag_info()), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() }))
            } else {
                match get(&lx.g.ctors, &qk) {
                    Some(c) => {
                        let owner = or(&get(&lx.g.types, &c.owner), &crate::check::env::dummy_ty_info());
                        let ty_path = path_in(lx, &owner.home, &camel(&crate::check::types::bare_name(&c.owner)));
                        match &owner.body {
                            crate::check::env::TyBody::BChoice(cases) if (&len(fps) == &Nat::from(0u32)) => prism_rtl::Turn::Finished(rest_case_pat(&c, cases, &ty_path)),
                            _ => prism_rtl::Turn::More(Rc::new(FieldsPat { lx: lx.clone(), c: c.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone(), ty_path: ty_path.clone() })),
                            _ => unreachable!("no arm matched"),
                        }
                    },
                    None => match get(&lx.g.tags, &qk) {
                        Some(tg) => prism_rtl::Turn::More(Rc::new(TagPat { lx: lx.clone(), tg: tg.clone(), fps: fps.clone(), rest: *rest, ty: ty.clone(), mode: mode.clone(), fresh: fresh.clone() })),
                        None => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern of {}", &qk))))]), binds: Array::new() }),
                    },
                }
            }
        }
    }
}

/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
pub fn start_record_pat(lx: Lx, n: crate::syntax::SName, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(RecordPat { lx, n, fps, rest, ty, mode, fresh })
}

/// ```prism
/// RestCasePat: fn CtorInfo, [((Text, [Ty]))], Text -> PatOut
/// ```
pub fn rest_case_pat(c: &crate::check::env::CtorInfo, cases: &Array<(Text, Array<crate::check::types::Ty>)>, ty_path: &Text) -> PatOut {
    let is_newtype = (&len(cases) == &Nat::from(1u32)) && (&crate::check::types::bare_name(&c.name) == &crate::check::types::bare_name(&c.owner));
    let path_ = if is_newtype {
        ty_path.clone()
    } else {
        Text::from(format!("{}::{}", ty_path, &camel(&crate::check::types::bare_name(&c.name))))
    };
    if &len(&c.args) == &Nat::from(0u32) {
        PatOut { pa: crate::lower::model::Pa::PaUnit(path_.clone()), conds: Array::new(), binds: Array::new() }
    } else {
        PatOut { pa: crate::lower::model::Pa::PaCtor(path_.clone(), each(&c.args, &(|_: &crate::check::types::Ty| crate::lower::model::Pa::PaWild))), conds: Array::new(), binds: Array::new() }
    }
}

/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub fn fields_pat(lx: &Lx, c: &crate::check::env::CtorInfo, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text, ty_path: &Text) -> PatOut {
    let args = match peel(ty) {
        crate::check::types::Ty::TyCon(_, xs) => xs.clone(),
        _ => Array::new(),
    };
    let subs = run_to_end(each_job(crate::check::errors::range0(&len(fps)), {
        let fps = fps.clone();
        let c = c.clone();
        let lx = lx.clone();
        let args = args.clone();
        let mode = mode.clone();
        let fresh = fresh.clone();
        Rc::new(move |p0: Nat| {
            let fps = fps.clone();
            let c = c.clone();
            let lx = lx.clone();
            let args = args.clone();
            let mode = mode.clone();
            let fresh = fresh.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let fp = or(&index(&fps, &i), &dummy_field_pat());
                    let fname = match &fp.name {
                        Some(id) => id.name.clone(),
                        None => or(&index(&c.fields, &i), &Text::lit("")),
                    };
                    let fix = fold(&crate::check::errors::range0(&len(&c.fields)), &i, &(|found: &Nat, j: &Nat| if &or(&index(&c.fields, j), &Text::lit("")) == &fname {
                        j.clone()
                    } else {
                        found.clone()
                    }));
                    call_then(start_instantiated(or(&index(&c.args, &fix), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_100837: crate::check::types::Ty| call_then(start_sub_pat(lx.clone(), c.clone(), fix.clone(), fp.pattern.clone(), instantiated_100837, mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |sub_pat_100805: PatOut| prism_rtl::Turn::Finished((snake(&fname), sub_pat_100805))))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
    }));
    let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Text, PatOut)| append(acc, &o.conds)));
    let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Text, PatOut)| append(acc, &o.binds)));
    PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&subs, &(|(f, o): &(Text, PatOut)| (f.clone(), o.pa.clone()))), *rest || (&len(&subs) < &len(&c.fields))), conds: conds.clone(), binds: binds.clone() }
}

/// The step machine of `FieldsPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldsPat: unbounded fn Lx, CtorInfo, [FieldPat], Bool, Ty, Holding, Text, Text -> PatOut
/// ```
pub struct FieldsPat {
    pub lx: Lx,
    pub c: crate::check::env::CtorInfo,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
    pub ty_path: Text,
}

impl prism_rtl::Job<PatOut> for FieldsPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let c = &self.c;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let ty_path = &self.ty_path;
        let args = match peel(ty) {
            crate::check::types::Ty::TyCon(_, xs) => xs.clone(),
            _ => Array::new(),
        };
        let c = c.clone();
        let fps = fps.clone();
        let fresh = fresh.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let rest = *rest;
        let ty_path = ty_path.clone();
        call_value(each_job(crate::check::errors::range0(&len(&fps)), {
            let fps = fps.clone();
            let c = c.clone();
            let lx = lx.clone();
            let args = args.clone();
            let mode = mode.clone();
            let fresh = fresh.clone();
            Rc::new(move |p0: Nat| {
                let fps = fps.clone();
                let c = c.clone();
                let lx = lx.clone();
                let args = args.clone();
                let mode = mode.clone();
                let fresh = fresh.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let fp = or(&index(&fps, &i), &dummy_field_pat());
                        let fname = match &fp.name {
                            Some(id) => id.name.clone(),
                            None => or(&index(&c.fields, &i), &Text::lit("")),
                        };
                        let fix = fold(&crate::check::errors::range0(&len(&c.fields)), &i, &(|found: &Nat, j: &Nat| if &or(&index(&c.fields, j), &Text::lit("")) == &fname {
                            j.clone()
                        } else {
                            found.clone()
                        }));
                        call_then(start_instantiated(or(&index(&c.args, &fix), &crate::check::types::Ty::TyErr), c.params.clone(), args.clone()), move |instantiated_100837: crate::check::types::Ty| call_then(start_sub_pat(lx.clone(), c.clone(), fix.clone(), fp.pattern.clone(), instantiated_100837, mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |sub_pat_100805: PatOut| prism_rtl::Turn::Finished((snake(&fname), sub_pat_100805))))
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, PatOut)>>>
        }), move |each_100452: Array<(Text, PatOut)>| {
            let subs = each_100452;
            let conds = fold(&subs, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Text, PatOut)| append(acc, &o.conds)));
            let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Text, PatOut)| append(acc, &o.binds)));
            prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaRecord(ty_path.clone(), each(&subs, &(|(f, o): &(Text, PatOut)| (f.clone(), o.pa.clone()))), rest || (&len(&subs) < &len(&c.fields))), conds: conds.clone(), binds: binds.clone() })
        })
    }
}

/// `Start FieldsPat, x`: what the function value is when passed to `@Run`.
pub fn start_fields_pat(lx: Lx, c: crate::check::env::CtorInfo, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: Holding, fresh: Text, ty_path: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FieldsPat { lx, c, fps, rest, ty, mode, fresh, ty_path })
}

/// ```prism
/// let dummyFieldPat
/// ```
pub fn dummy_field_pat() -> crate::syntax::FieldPat {
    crate::syntax::FieldPat { name: None, pattern: dummy_pat(), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// let dummyTagInfo
/// ```
pub fn dummy_tag_info() -> crate::check::env::TagInfo {
    crate::check::env::TagInfo { name: Text::lit(""), family: Text::lit(""), kind: Text::lit(""), out: crate::check::types::Ty::TyErr, qs: Array::new(), rqs: Array::new(), bounds: Array::new(), fields: Array::new(), home: Text::lit(""), file: Nat::from(0u32), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLive: fn Ty -> Bool
/// ```
pub fn is_live(t: &crate::check::types::Ty) -> bool {
    match peel(t) {
        crate::check::types::Ty::TyElem(_, _) => true,
        _ => false,
    }
}

/// ```prism
/// TagFieldName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn tag_field_name(fp: &crate::syntax::FieldPat, names: &Array<Text>, i: &Nat) -> Text {
    match &fp.name {
        Some(id) => id.name.clone(),
        None => match &*fp.pattern.kind {
            crate::syntax::PatternKind::PName(n) => if crate::check::types::has_text(names, &crate::check::env::sname_key(n)) {
                crate::check::env::sname_key(n)
            } else {
                or(&index(names, i), &Text::lit(""))
            },
            _ => or(&index(names, i), &Text::lit("")),
        },
    }
}

/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub fn tag_pat(lx: &Lx, tg: &crate::check::env::TagInfo, fps: &Array<crate::syntax::FieldPat>, rest: &bool, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let (variant, struct_path) = tag_paths(lx, tg);
    let live = is_live(ty);
    let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
    let sub_mode = if live { Holding::ByRef } else { mode.clone() };
    let parts = run_to_end(each_job(crate::check::errors::range0(&len(fps)), {
        let fps = fps.clone();
        let names = names.clone();
        let tg = tg.clone();
        let live = live;
        let lx = lx.clone();
        let variant = variant.clone();
        let fresh = fresh.clone();
        let sub_mode = sub_mode.clone();
        Rc::new(move |p0: Nat| {
            let fps = fps.clone();
            let names = names.clone();
            let tg = tg.clone();
            let live = live;
            let lx = lx.clone();
            let variant = variant.clone();
            let fresh = fresh.clone();
            let sub_mode = sub_mode.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let fp = or(&index(&fps, &i), &dummy_field_pat());
                    let fname = tag_field_name(&fp, &names, &i);
                    let ft = fold(&tg.fields, &crate::check::types::Ty::TyErr, &(|found: &crate::check::types::Ty, (f, t): &(Text, crate::check::types::Ty)| if f == &fname { t.clone() } else { found.clone() }));
                    match layer_of(&ft) {
                        Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("an event field in an element pattern ({}.{})", &tg.name, &fname))))]), binds: Array::new() })),
                        Layer::LyDyn if live => call_then(start_live_field_pat(lx.clone(), fp.pattern.clone(), variant.clone(), fname.clone(), ft.clone(), fresh.clone()), move |live_field_pat_103212: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_103212))),
                        _ => call_then(start_rust_pat(lx.clone(), fp.pattern.clone(), peel(&ft), sub_mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_103317: PatOut| {
                            let o = rust_pat_103317;
                            prism_rtl::Turn::Finished((Some(snake(&fname)), o.clone()))
                        }),
                        _ => unreachable!("no arm matched"),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
    }));
    let field_pas = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Pa)>, (f_opt, o): &(Option<Text>, PatOut)| match f_opt {
        Some(f) => push(acc, &(f.clone(), o.pa.clone())),
        None => acc.clone(),
    }));
    let conds = fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.conds)));
    let binds = fold(&parts, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.binds)));
    let level = crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path.clone(), field_pas.clone(), true)]));
    let tagged = push(&binds, &(Text::lit("#tag"), Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::answer_variant(tg)), Holding::Owned, crate::lower::model::OutTy::OutUnit)));
    if live {
        PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(level.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity")))))]), &conds), binds: tagged.clone() }
    } else {
        PatOut { pa: level.clone(), conds: conds.clone(), binds: binds.clone() }
    }
}

/// The step machine of `TagPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagPat: unbounded fn Lx, TagInfo, [FieldPat], Bool, Ty, Holding, Text -> PatOut
/// ```
pub struct TagPat {
    pub lx: Lx,
    pub tg: crate::check::env::TagInfo,
    pub fps: Array<crate::syntax::FieldPat>,
    pub rest: bool,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for TagPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let tg = &self.tg;
        let fps = &self.fps;
        let rest = &self.rest;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let (variant, struct_path) = tag_paths(lx, tg);
        let live = is_live(ty);
        let names = each(&tg.fields, &(|(f, _): &(Text, crate::check::types::Ty)| f.clone()));
        let sub_mode = if live { Holding::ByRef } else { mode.clone() };
        let fps = fps.clone();
        let fresh = fresh.clone();
        let lx = lx.clone();
        let tg = tg.clone();
        call_value(each_job(crate::check::errors::range0(&len(&fps)), {
            let fps = fps.clone();
            let names = names.clone();
            let tg = tg.clone();
            let live = live;
            let lx = lx.clone();
            let variant = variant.clone();
            let fresh = fresh.clone();
            let sub_mode = sub_mode.clone();
            Rc::new(move |p0: Nat| {
                let fps = fps.clone();
                let names = names.clone();
                let tg = tg.clone();
                let live = live;
                let lx = lx.clone();
                let variant = variant.clone();
                let fresh = fresh.clone();
                let sub_mode = sub_mode.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let fp = or(&index(&fps, &i), &dummy_field_pat());
                        let fname = tag_field_name(&fp, &names, &i);
                        let ft = fold(&tg.fields, &crate::check::types::Ty::TyErr, &(|found: &crate::check::types::Ty, (f, t): &(Text, crate::check::types::Ty)| if f == &fname { t.clone() } else { found.clone() }));
                        match layer_of(&ft) {
                            Layer::LyEv => prism_rtl::Turn::Finished((None, PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("an event field in an element pattern ({}.{})", &tg.name, &fname))))]), binds: Array::new() })),
                            Layer::LyDyn if live => call_then(start_live_field_pat(lx.clone(), fp.pattern.clone(), variant.clone(), fname.clone(), ft.clone(), fresh.clone()), move |live_field_pat_103212: PatOut| prism_rtl::Turn::Finished((None, live_field_pat_103212))),
                            _ => call_then(start_rust_pat(lx.clone(), fp.pattern.clone(), peel(&ft), sub_mode.clone(), Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_103317: PatOut| {
                                let o = rust_pat_103317;
                                prism_rtl::Turn::Finished((Some(snake(&fname)), o.clone()))
                            }),
                            _ => unreachable!("no arm matched"),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Option<Text>, PatOut)>>>
        }), move |each_102801: Array<(Option<Text>, PatOut)>| {
            let parts = each_102801;
            let field_pas = fold(&parts, &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Pa)>, (f_opt, o): &(Option<Text>, PatOut)| match f_opt {
                Some(f) => push(acc, &(f.clone(), o.pa.clone())),
                None => acc.clone(),
            }));
            let conds = fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.conds)));
            let binds = fold(&parts, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Option<Text>, PatOut)| append(acc, &o.binds)));
            let level = crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaRecord(struct_path.clone(), field_pas.clone(), true)]));
            let tagged = push(&binds, &(Text::lit("#tag"), Bn::BnLocal(crate::lower::model::Ex::XPath(crate::lower::node_::answer_variant(&tg)), Holding::Owned, crate::lower::model::OutTy::OutUnit)));
            if live {
                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: append(&Array::from(vec![crate::lower::model::Cc::CcLet(level.clone(), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity")))))]), &conds), binds: tagged.clone() })
            } else {
                prism_rtl::Turn::Finished(PatOut { pa: level.clone(), conds: conds.clone(), binds: binds.clone() })
            }
        })
    }
}

/// `Start TagPat, x`: what the function value is when passed to `@Run`.
pub fn start_tag_pat(lx: Lx, tg: crate::check::env::TagInfo, fps: Array<crate::syntax::FieldPat>, rest: bool, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(TagPat { lx, tg, fps, rest, ty, mode, fresh })
}

/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
/// ```
pub fn live_field_pat(lx: &Lx, p_: &crate::syntax::Pattern_, variant: &Text, fname: &Text, ft: &crate::check::types::Ty, fresh: &Text) -> PatOut {
    match &*p_.kind {
        crate::syntax::PatternKind::PIgnore => pat_only(&crate::lower::model::Pa::PaWild),
        crate::syntax::PatternKind::PName(n) => {
            let rs = if lx.in_node {
                live_projection(fresh, variant, fname, &out_ty_of(lx, &peel(ft)))
            } else {
                refusal(&Text::from(format!("a live element's `$` field ({}) in a plain function, which has no read point (gap LE)", fname)))
            };
            PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::from(vec![(crate::check::env::sname_key(n), Bn::BnLocal(rs.clone(), Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of(lx, &peel(ft))))))]) }
        },
        crate::syntax::PatternKind::PGroup(q) => live_field_pat(lx, &**q, variant, fname, ft, fresh),
        _ => PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern inside a live element's `$` field ({})", fname))))]), binds: Array::new() },
    }
}

/// The step machine of `LiveFieldPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LiveFieldPat: unbounded fn Lx, Pattern, Text, Text, Ty, Text -> PatOut
/// ```
pub struct LiveFieldPat {
    pub lx: Lx,
    pub p_: crate::syntax::Pattern_,
    pub variant: Text,
    pub fname: Text,
    pub ft: crate::check::types::Ty,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for LiveFieldPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let p_ = &self.p_;
        let variant = &self.variant;
        let fname = &self.fname;
        let ft = &self.ft;
        let fresh = &self.fresh;
        match &*p_.kind {
            crate::syntax::PatternKind::PIgnore => prism_rtl::Turn::Finished(pat_only(&crate::lower::model::Pa::PaWild)),
            crate::syntax::PatternKind::PName(n) => {
                let rs = if lx.in_node {
                    live_projection(fresh, variant, fname, &out_ty_of(lx, &peel(ft)))
                } else {
                    refusal(&Text::from(format!("a live element's `$` field ({}) in a plain function, which has no read point (gap LE)", fname)))
                };
                let ft = ft.clone();
                let lx = lx.clone();
                let n = n.clone();
                call_then(start_out_ty_of(lx.clone(), peel(&ft)), move |out_ty_of_104929: crate::lower::model::OutTy| prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::from(vec![(crate::check::env::sname_key(&n), Bn::BnLocal(rs.clone(), Holding::Owned, crate::lower::model::OutTy::OutDyn(Rc::new(out_ty_of_104929))))]) }))
            },
            crate::syntax::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(LiveFieldPat { lx: lx.clone(), p_: (**q).clone(), variant: variant.clone(), fname: fname.clone(), ft: ft.clone(), fresh: fresh.clone() })),
            _ => prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::from(vec![crate::lower::model::Cc::CcIf(refusal(&Text::from(format!("a pattern inside a live element's `$` field ({})", fname))))]), binds: Array::new() }),
        }
    }
}

/// `Start LiveFieldPat, x`: what the function value is when passed to `@Run`.
pub fn start_live_field_pat(lx: Lx, p_: crate::syntax::Pattern_, variant: Text, fname: Text, ft: crate::check::types::Ty, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(LiveFieldPat { lx, p_, variant, fname, ft, fresh })
}

/// ```prism
/// LiveProjection: fn Text, Text, Text, OutTy -> Ex
/// ```
pub fn live_projection(fresh: &Text, variant: &Text, fname: &Text, ft: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let arm = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(variant.clone(), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("x"))])), conds: Array::new(), body: crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(Text::lit("x"))), snake(fname)))) };
    let other = crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: crate::lower::model::Ex::XUnreachable };
    crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("level"))), Text::lit("map"), Array::from(vec![crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("l"))]), Rc::new(crate::lower::model::Ex::XMatch(Rc::new(crate::lower::model::Ex::XVar(Text::lit("l"))), Array::from(vec![arm.clone(), other.clone()]), false, ft.clone())))]))
}

/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub fn family_pat(lx: &Lx, q: &crate::syntax::QualName, ty: &crate::check::types::Ty, fresh: &Text) -> PatOut {
    let fam = crate::check::env::dotted(&filter(&q.path_, &(|x: &Text| x != &Text::lit("*"))));
    let kind = match peel(ty) {
        crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
        crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
        crate::check::types::Ty::TyCon(k, _) => k.clone(),
        _ => Text::lit(""),
    };
    let tags = filter(&kind_tags(lx, &kind, &keys(&lx.rs_mods)), &(|tg: &crate::check::env::TagInfo| &tg.family == &fam));
    let place = if is_live(ty) {
        crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity"))
    } else {
        crate::lower::model::Ex::XVar(fresh.clone())
    };
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place.clone()), each(&tags, &(|tg: &crate::check::env::TagInfo| variant_of(lx, tg)))))]), binds: Array::new() }
}

/// The step machine of `FamilyPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FamilyPat: unbounded fn Lx, QualName, Ty, Text -> PatOut
/// ```
pub struct FamilyPat {
    pub lx: Lx,
    pub q: crate::syntax::QualName,
    pub ty: crate::check::types::Ty,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for FamilyPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let q = &self.q;
        let ty = &self.ty;
        let fresh = &self.fresh;
        let fam = crate::check::env::dotted(&filter(&q.path_, &(|x: &Text| x != &Text::lit("*"))));
        let kind = match peel(ty) {
            crate::check::types::Ty::TyElem(_, _) => Text::lit("Element"),
            crate::check::types::Ty::TyElemAny(_) => Text::lit("Element"),
            crate::check::types::Ty::TyCon(k, _) => k.clone(),
            _ => Text::lit(""),
        };
        let tags = filter(&kind_tags(lx, &kind, &keys(&lx.rs_mods)), &(|tg: &crate::check::env::TagInfo| &tg.family == &fam));
        let place = if is_live(ty) {
            crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("identity"))
        } else {
            crate::lower::model::Ex::XVar(fresh.clone())
        };
        prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XIsCase(Rc::new(place.clone()), each(&tags, &(|tg: &crate::check::env::TagInfo| variant_of(lx, tg)))))]), binds: Array::new() })
    }
}

/// `Start FamilyPat, x`: what the function value is when passed to `@Run`.
pub fn start_family_pat(lx: Lx, q: crate::syntax::QualName, ty: crate::check::types::Ty, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(FamilyPat { lx, q, ty, fresh })
}

/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub fn error_pat(lx: &Lx, fps: &Array<crate::syntax::FieldPat>, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let e = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &crate::lower::model::OutTy::OutError);
    let parts = each(fps, &(|fp: &crate::syntax::FieldPat| {
        let fname = match &fp.name {
            Some(id) => id.name.clone(),
            None => Text::lit(""),
        };
        match &fname {
            m106544_0 if (m106544_0 == &Text::lit("kind")) => match &*fp.pattern.kind {
                crate::syntax::PatternKind::PName(k) => {
                    let (kq_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, k);
                    match &kq_opt {
                        Some(kq) => if crate::check::env::has_key(&lx.g.tags, kq) {
                            (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind"))))))), Rc::new(crate::lower::model::Ex::XStr(kq.clone()))))]), Array::new())
                        } else {
                            (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), Holding::Owned, crate::lower::model::OutTy::OutText))]))
                        },
                        None => (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    }
                },
                _ => (Array::new(), Array::new()),
            },
            m106544_1 if (m106544_1 == &Text::lit("message")) => match &*fp.pattern.kind {
                crate::syntax::PatternKind::PName(m) => (Array::new(), Array::from(vec![(crate::check::env::sname_key(m), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("message")), Holding::Owned, crate::lower::model::OutTy::OutText))])),
                _ => (Array::new(), Array::new()),
            },
            _ => (Array::new(), Array::new()),
            _ => unreachable!("no arm matched"),
        }
    }));
    let wrapped = match peel(ty) {
        crate::check::types::Ty::TySig(m107381_0_0, _) if (&m107381_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh.clone())])),
        _ => crate::lower::model::Pa::PaBind(fresh.clone()),
        _ => unreachable!("no arm matched"),
    };
    PatOut { pa: wrapped.clone(), conds: fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (cs, _): &(Array<crate::lower::model::Cc>, Array<(Text, Bn)>)| append(acc, cs))), binds: fold(&parts, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, bs): &(Array<crate::lower::model::Cc>, Array<(Text, Bn)>)| append(acc, bs))) }
}

/// The step machine of `ErrorPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ErrorPat: unbounded fn Lx, [FieldPat], Ty, Holding, Text -> PatOut
/// ```
pub struct ErrorPat {
    pub lx: Lx,
    pub fps: Array<crate::syntax::FieldPat>,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for ErrorPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let fps = &self.fps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let e = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &crate::lower::model::OutTy::OutError);
        let parts = each(fps, &(|fp: &crate::syntax::FieldPat| {
            let fname = match &fp.name {
                Some(id) => id.name.clone(),
                None => Text::lit(""),
            };
            match &fname {
                m106544_0 if (m106544_0 == &Text::lit("kind")) => match &*fp.pattern.kind {
                    crate::syntax::PatternKind::PName(k) => {
                        let (kq_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, k);
                        match &kq_opt {
                            Some(kq) => if crate::check::env::has_key(&lx.g.tags, kq) {
                                (Array::from(vec![crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind"))))))), Rc::new(crate::lower::model::Ex::XStr(kq.clone()))))]), Array::new())
                            } else {
                                (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), Holding::Owned, crate::lower::model::OutTy::OutText))]))
                            },
                            None => (Array::new(), Array::from(vec![(crate::check::env::sname_key(k), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("kind")), Holding::Owned, crate::lower::model::OutTy::OutText))])),
                        }
                    },
                    _ => (Array::new(), Array::new()),
                },
                m106544_1 if (m106544_1 == &Text::lit("message")) => match &*fp.pattern.kind {
                    crate::syntax::PatternKind::PName(m) => (Array::new(), Array::from(vec![(crate::check::env::sname_key(m), Bn::BnLocal(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XVar(fresh.clone())), Text::lit("message")), Holding::Owned, crate::lower::model::OutTy::OutText))])),
                    _ => (Array::new(), Array::new()),
                },
                _ => (Array::new(), Array::new()),
                _ => unreachable!("no arm matched"),
            }
        }));
        let wrapped = match peel(ty) {
            crate::check::types::Ty::TySig(m107381_0_0, _) if (&m107381_0_0 == &Text::lit("~")) => crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(fresh.clone())])),
            _ => crate::lower::model::Pa::PaBind(fresh.clone()),
            _ => unreachable!("no arm matched"),
        };
        prism_rtl::Turn::Finished(PatOut { pa: wrapped.clone(), conds: fold(&parts, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, (cs, _): &(Array<crate::lower::model::Cc>, Array<(Text, Bn)>)| append(acc, cs))), binds: fold(&parts, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, bs): &(Array<crate::lower::model::Cc>, Array<(Text, Bn)>)| append(acc, bs))) })
    }
}

/// `Start ErrorPat, x`: what the function value is when passed to `@Run`.
pub fn start_error_pat(lx: Lx, fps: Array<crate::syntax::FieldPat>, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ErrorPat { lx, fps, ty, mode, fresh })
}

/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub fn array_pat(lx: &Lx, ps: &Array<crate::syntax::Pattern_>, ty: &crate::check::types::Ty, mode: &Holding, fresh: &Text) -> PatOut {
    let et = match peel(ty) {
        crate::check::types::Ty::TyArray(x) => (*x).clone(),
        _ => crate::check::types::Ty::TyErr,
    };
    let arr = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), mode, &out_ty_of(lx, &peel(ty)));
    let len_cond = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(ref_(&arr)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(len(ps)))));
    let subs = run_to_end(each_job(crate::check::errors::range0(&len(ps)), {
        let lx = lx.clone();
        let ps = ps.clone();
        let et = et.clone();
        let fresh = fresh.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let ps = ps.clone();
            let et = et.clone();
            let fresh = fresh.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(start_rust_pat(lx.clone(), or(&index(&ps, &i), &dummy_pat()), et.clone(), Holding::Owned, Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_108078: PatOut| prism_rtl::Turn::Finished((i.clone(), rust_pat_108078)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
    }));
    let conds = fold(&subs, &Array::from(vec![len_cond.clone()]), &(|acc: &Array<crate::lower::model::Cc>, (i, o): &(Nat, PatOut)| append(&push(acc, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o.pa.clone()])), crate::lower::model::Ex::XCall(Text::lit("index"), Array::from(vec![ref_(&arr), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i)))))])))), &o.conds)));
    let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Nat, PatOut)| append(acc, &o.binds)));
    PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: conds.clone(), binds: binds.clone() }
}

/// The step machine of `ArrayPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArrayPat: unbounded fn Lx, [Pattern], Ty, Holding, Text -> PatOut
/// ```
pub struct ArrayPat {
    pub lx: Lx,
    pub ps: Array<crate::syntax::Pattern_>,
    pub ty: crate::check::types::Ty,
    pub mode: Holding,
    pub fresh: Text,
}

impl prism_rtl::Job<PatOut> for ArrayPat {
    fn cycle(&self) -> prism_rtl::Turn<PatOut> {
        let lx = &self.lx;
        let ps = &self.ps;
        let ty = &self.ty;
        let mode = &self.mode;
        let fresh = &self.fresh;
        let et = match peel(ty) {
            crate::check::types::Ty::TyArray(x) => (*x).clone(),
            _ => crate::check::types::Ty::TyErr,
        };
        let fresh = fresh.clone();
        let lx = lx.clone();
        let mode = mode.clone();
        let ps = ps.clone();
        let ty = ty.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&ty)), move |out_ty_of_107917: crate::lower::model::OutTy| {
            let arr = local_place(&crate::lower::model::Ex::XVar(fresh.clone()), &mode, &out_ty_of_107917);
            let len_cond = crate::lower::model::Cc::CcIf(crate::lower::model::Ex::XBin(Text::lit("=="), Rc::new(crate::lower::model::Ex::XMethod(Rc::new(ref_(&arr)), Text::lit("len"), Array::new())), Rc::new(crate::lower::model::Ex::XIndex(len(&ps)))));
            call_value(each_job(crate::check::errors::range0(&len(&ps)), {
                let lx = lx.clone();
                let ps = ps.clone();
                let et = et.clone();
                let fresh = fresh.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let ps = ps.clone();
                    let et = et.clone();
                    let fresh = fresh.clone();
                    entered(once_job(move || {
                        let i = p0;
                        call_then(start_rust_pat(lx.clone(), or(&index(&ps, &i), &dummy_pat()), et.clone(), Holding::Owned, Text::from(format!("{}_{}", &fresh, &i))), move |rust_pat_108078: PatOut| prism_rtl::Turn::Finished((i.clone(), rust_pat_108078)))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Nat, PatOut)>>>
            }), move |each_108043: Array<(Nat, PatOut)>| {
                let subs = each_108043;
                let conds = fold(&subs, &Array::from(vec![len_cond.clone()]), &(|acc: &Array<crate::lower::model::Cc>, (i, o): &(Nat, PatOut)| append(&push(acc, &crate::lower::model::Cc::CcLet(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![o.pa.clone()])), crate::lower::model::Ex::XCall(Text::lit("index"), Array::from(vec![ref_(&arr), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XNat(Text::from(format!("{}", i)))))])))), &o.conds)));
                let binds = fold(&subs, &Array::new(), &(|acc: &Array<(Text, Bn)>, (_, o): &(Nat, PatOut)| append(acc, &o.binds)));
                prism_rtl::Turn::Finished(PatOut { pa: crate::lower::model::Pa::PaBind(fresh.clone()), conds: conds.clone(), binds: binds.clone() })
            })
        })
    }
}

/// `Start ArrayPat, x`: what the function value is when passed to `@Run`.
pub fn start_array_pat(lx: Lx, ps: Array<crate::syntax::Pattern_>, ty: crate::check::types::Ty, mode: Holding, fresh: Text) -> Rc<dyn prism_rtl::Job<PatOut>> {
    Rc::new(ArrayPat { lx, ps, ty, mode, fresh })
}

/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub fn template_value(lx: &Lx, env: &Env, tp: &crate::syntax::Template) -> Vl {
    let start = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
    let dos = run_to_end(fold_job(tp.parts.clone(), start.clone(), {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let acc = p0;
                let part = p1;
                call_then(start_template_part_dos(lx.clone(), env.clone(), part.clone()), move |template_part_dos_109192: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_109192)))
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
    }));
    Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText)
}

/// The step machine of `TemplateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateValue: unbounded fn Lx, Env, Template -> Vl
/// ```
pub struct TemplateValue {
    pub lx: Lx,
    pub env: Env,
    pub tp: crate::syntax::Template,
}

impl prism_rtl::Job<Vl> for TemplateValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let tp = &self.tp;
        let start = Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]);
        let env = env.clone();
        let lx = lx.clone();
        let tp = tp.clone();
        call_value(fold_job(tp.parts.clone(), start.clone(), {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let part = p1;
                    call_then(start_template_part_dos(lx.clone(), env.clone(), part.clone()), move |template_part_dos_109192: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_109192)))
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
        }), move |fold_109144: Array<crate::lower::model::Do>| {
            let dos = fold_109144;
            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))])))), crate::lower::model::OutTy::OutText))
        })
    }
}

/// `Start TemplateValue, x`: what the function value is when passed to `@Run`.
pub fn start_template_value(lx: Lx, env: Env, tp: crate::syntax::Template) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(TemplateValue { lx, env, tp })
}

/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub fn template_part_dos(lx: &Lx, env: &Env, part: &crate::syntax::TemplatePart) -> Array<crate::lower::model::Do> {
    match part {
        crate::syntax::TemplatePart::TpText(t) => Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t.clone())])))]),
        crate::syntax::TemplatePart::TpPlaceholder(x, col_opt) => {
            let v_ = value_of(lx, env, x);
            let column = match col_opt {
                Some(c) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c.clone())])),
                None => crate::lower::model::Ex::XNone,
            };
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), column.clone()])))])
        },
        crate::syntax::TemplatePart::TpBlock(b) => {
            let v_ = block_value(lx, env, b);
            if &value_ty(&v_) == &crate::lower::model::OutTy::OutUnit {
                Array::from(vec![crate::lower::model::Do::DoExpr(own(&v_))])
            } else {
                Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), crate::lower::model::Ex::XNone])))])
            }
        },
        crate::syntax::TemplatePart::TpCall(n, args, parts_opt, _) => {
            let plain = crate::syntax::SName { sigils: crate::syntax::lexer::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
            let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            let (qk2_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, &plain);
            let callee = match &qk_opt {
                Some(q) => value_path(lx, q),
                None => match &qk2_opt {
                    Some(q) => value_path(lx, q),
                    None => snake(&crate::check::env::sname_key(n)),
                },
            };
            let body = match parts_opt {
                Some(ps) => {
                    let inner = run_to_end(fold_job(ps.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let p_ = p1;
                                call_then(start_template_part_dos(lx.clone(), env.clone(), p_.clone()), move |template_part_dos_110502: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_110502)))
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                    }));
                    Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                },
                None => Array::new(),
            };
            let passed = match &qk_opt {
                Some(q) => template_args(lx, env, q, args, &body),
                None => match &qk2_opt {
                    Some(q) => template_args(lx, env, q, args, &body),
                    None => append(&run_to_end(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env = env.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let a = p0;
                                prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })), &body),
                },
            };
            let call = crate::lower::model::Ex::XCall(callee.clone(), passed.clone());
            Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call.clone())), crate::lower::model::Ex::XNone])))])
        },
    }
}

/// The step machine of `TemplatePartDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartDos: unbounded fn Lx, Env, TemplatePart -> [Do]
/// ```
pub struct TemplatePartDos {
    pub lx: Lx,
    pub env: Env,
    pub part: crate::syntax::TemplatePart,
}

impl prism_rtl::Job<Array<crate::lower::model::Do>> for TemplatePartDos {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Do>> {
        let lx = &self.lx;
        let env = &self.env;
        let part = &self.part;
        match part {
            crate::syntax::TemplatePart::TpText(t) => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out"))), Text::lit("push_str"), Array::from(vec![crate::lower::model::Ex::XStr(t.clone())])))])),
            crate::syntax::TemplatePart::TpPlaceholder(x, col_opt) => {
                let col_opt = col_opt.clone();
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_109522: Vl| {
                    let v_ = value_of_109522;
                    let column = match &col_opt {
                        Some(c) => crate::lower::model::Ex::XCtor(Text::lit("Some"), Array::from(vec![crate::lower::model::Ex::XIndex(c.clone())])),
                        None => crate::lower::model::Ex::XNone,
                    };
                    prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), column.clone()])))]))
                })
            },
            crate::syntax::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_block_value(lx.clone(), env.clone(), b.clone()), move |block_value_109756: Vl| {
                    let v_ = block_value_109756;
                    if &value_ty(&v_) == &crate::lower::model::OutTy::OutUnit {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(own(&v_))]))
                    } else {
                        prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), shown_text(&v_), crate::lower::model::Ex::XNone])))]))
                    }
                })
            },
            crate::syntax::TemplatePart::TpCall(n, args, parts_opt, _) => {
                let plain = crate::syntax::SName { sigils: crate::syntax::lexer::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
                let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                let (qk2_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, &plain);
                let callee = match &qk_opt {
                    Some(q) => value_path(lx, q),
                    None => match &qk2_opt {
                        Some(q) => value_path(lx, q),
                        None => snake(&crate::check::env::sname_key(n)),
                    },
                };
                let body = match parts_opt {
                    Some(ps) => {
                        let inner = run_to_end(fold_job(ps.clone(), Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaMut(Text::lit("out")), crate::lower::model::Ex::XCall(Text::lit("String::new"), Array::new()))]), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Do>, crate::syntax::TemplatePart)| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let p_ = p1;
                                    call_then(start_template_part_dos(lx.clone(), env.clone(), p_.clone()), move |template_part_dos_110502: Array<crate::lower::model::Do>| prism_rtl::Turn::Finished(append(&acc, &template_part_dos_110502)))
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Do>, crate::syntax::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>>>
                        }));
                        Array::from(vec![crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XBlock(inner.clone(), Rc::new(crate::lower::model::Ex::XCall(Text::lit("Text::from"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("out"))]))))))])
                    },
                    None => Array::new(),
                };
                let passed = match &qk_opt {
                    Some(q) => template_args(lx, env, q, args, &body),
                    None => match &qk2_opt {
                        Some(q) => template_args(lx, env, q, args, &body),
                        None => append(&run_to_end(each_job(args.clone(), {
                            let lx = lx.clone();
                            let env = env.clone();
                            Rc::new(move |p0: crate::syntax::Arg| {
                                let lx = lx.clone();
                                let env = env.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() }))
                                }))
                            }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        })), &body),
                    },
                };
                let call = crate::lower::model::Ex::XCall(callee.clone(), passed.clone());
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(Text::lit("place"), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(crate::lower::model::Ex::XVar(Text::lit("out")))), crate::lower::model::Ex::XRef(Rc::new(call.clone())), crate::lower::model::Ex::XNone])))]))
            },
        }
    }
}

/// `Start TemplatePartDos, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_dos(lx: Lx, env: Env, part: crate::syntax::TemplatePart) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Do>>> {
    Rc::new(TemplatePartDos { lx, env, part })
}

/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub fn template_args(lx: &Lx, env: &Env, qk: &Text, args: &Array<crate::syntax::Arg>, body: &Array<crate::lower::model::Ex>) -> Array<crate::lower::model::Ex> {
    let clauses = clauses_of(&lx.g, qk);
    let arity = len(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params);
    run_to_end(each_job(crate::check::errors::range0(&arity), {
        let body = body.clone();
        let arity = arity.clone();
        let clauses = clauses.clone();
        let args = args.clone();
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let body = body.clone();
            let arity = arity.clone();
            let clauses = clauses.clone();
            let args = args.clone();
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let j = p0;
                if (&len(&body) > &Nat::from(0u32)) && (&(&j + &Nat::from(1u32)) == &arity) {
                    prism_rtl::Turn::Finished(or(&index(&body, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                } else {
                    match attr_at(&clauses, &j, &args) {
                        Some(a) => prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                        None => prism_rtl::Turn::Finished(refusal(&Text::from(format!("a template call that fills no argument at place {}", &j)))),
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }))
}

/// The step machine of `TemplateArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateArgs: unbounded fn Lx, Env, Text, [Arg], [Ex] -> [Ex]
/// ```
pub struct TemplateArgs {
    pub lx: Lx,
    pub env: Env,
    pub qk: Text,
    pub args: Array<crate::syntax::Arg>,
    pub body: Array<crate::lower::model::Ex>,
}

impl prism_rtl::Job<Array<crate::lower::model::Ex>> for TemplateArgs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Ex>> {
        let lx = &self.lx;
        let env = &self.env;
        let qk = &self.qk;
        let args = &self.args;
        let body = &self.body;
        let clauses = clauses_of(&lx.g, qk);
        let arity = len(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params);
        each_job(crate::check::errors::range0(&arity), {
            let body = body.clone();
            let arity = arity.clone();
            let clauses = clauses.clone();
            let args = args.clone();
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |p0: Nat| {
                let body = body.clone();
                let arity = arity.clone();
                let clauses = clauses.clone();
                let args = args.clone();
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let j = p0;
                    if (&len(&body) > &Nat::from(0u32)) && (&(&j + &Nat::from(1u32)) == &arity) {
                        prism_rtl::Turn::Finished(or(&index(&body, &Nat::from(0u32)), &crate::lower::model::Ex::XUnit))
                    } else {
                        match attr_at(&clauses, &j, &args) {
                            Some(a) => prism_rtl::Turn::More(Rc::new(Argument { lx: lx.clone(), env: env.clone(), e: a.value.clone() })),
                            None => prism_rtl::Turn::Finished(refusal(&Text::from(format!("a template call that fills no argument at place {}", &j)))),
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }).cycle()
    }
}

/// `Start TemplateArgs, x`: what the function value is when passed to `@Run`.
pub fn start_template_args(lx: Lx, env: Env, qk: Text, args: Array<crate::syntax::Arg>, body: Array<crate::lower::model::Ex>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Ex>>> {
    Rc::new(TemplateArgs { lx, env, qk, args, body })
}

/// ```prism
/// ?AttrAt: fn [FnClause], Nat, [Arg] -> ?Arg
/// ```
pub fn attr_at(clauses: &Array<crate::syntax::FnClause>, j: &Nat, args: &Array<crate::syntax::Arg>) -> Option<crate::syntax::Arg> {
    let names = fold(clauses, &Array::new(), &(|acc: &Array<Text>, c: &crate::syntax::FnClause| match index(&c.params, j) {
        Some(p_) => match place_name(&p_) {
            Some(n) => crate::check::types::add_text(acc, &n),
            None => acc.clone(),
        },
        None => acc.clone(),
    }));
    fold(args, &None, &(|found_opt: &Option<crate::syntax::Arg>, a: &crate::syntax::Arg| match &a.name {
        Some(n) => if crate::check::types::has_text(&names, &n.name) {
            Some(a.clone())
        } else {
            found_opt.clone()
        },
        None => found_opt.clone(),
    }))
}

/// ```prism
/// ?PlaceName: fn Pattern -> ?Text
/// ```
pub fn place_name(p_: &crate::syntax::Pattern_) -> Option<Text> {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => Some(crate::check::env::dotted(&n.path_)),
        crate::syntax::PatternKind::PGroup(q) => place_name(&**q),
        _ => None,
    }
}

/// ```prism
/// ShownText: fn Vl -> Ex
/// ```
pub fn shown_text(v_: &Vl) -> crate::lower::model::Ex {
    match value_ty(v_) {
        crate::lower::model::OutTy::OutText => ref_(v_),
        _ => crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XCall(Text::lit("show_text"), Array::from(vec![ref_(v_)])))),
    }
}

/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub fn given_value(lx: &Lx, env: &Env, b: &crate::syntax::Block, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> Vl {
    let label = Text::from(format!("'g{}", &span.start));
    let is_try = match t {
        crate::lower::model::OutTy::OutRes(_) => true,
        _ => false,
    };
    let n = len(&b.stmts);
    let (dos, env2, last_opt) = run_to_end(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
        let b = b.clone();
        let is_try = is_try;
        let lx = lx.clone();
        let label = label.clone();
        let n = n.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)| {
            let b = b.clone();
            let is_try = is_try;
            let lx = lx.clone();
            let label = label.clone();
            let n = n.clone();
            entered(once_job(move || {
                let (acc, en, lv_opt) = p0;
                let i = p1;
                {
                    let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                    let fail = if is_try {
                        crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx, &s.span))]))]))
                    } else {
                        crate::lower::model::Ex::XNone
                    };
                    match &s.kind {
                        crate::syntax::StmtKind::SBind(p_, x, None) => {
                            let p_ = p_.clone();
                            let x = x.clone();
                            call_then(start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_113436: Vl| {
                                let v_ = value_of_113436;
                                call_then(start_rust_pat(lx.clone(), p_.clone(), inner_ty(&type_at(&lx, &x.span)), Holding::Owned, Text::from(format!("g{}", &s.span.start))), move |rust_pat_113479: PatOut| {
                                    let po = rust_pat_113479;
                                    call_then(start_out_ty_of(lx.clone(), inner_ty(&type_at(&lx, &x.span))), move |out_ty_of_113621: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc, &given_bind(&is_try, &po.pa, &own(&v_), &label, &out_ty_of_113621)), bind_all(&en, &po.binds), lv_opt.clone())))
                                })
                            })
                        },
                        crate::syntax::StmtKind::SRequire(c) => {
                            let c = c.clone();
                            call_then(start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_113762: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(as_bool(&value_of_113762))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                        },
                        crate::syntax::StmtKind::SForbid(c) => {
                            let c = c.clone();
                            call_then(start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_113886: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(as_bool(&value_of_113886), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                        },
                        crate::syntax::StmtKind::SExpr(x) => if &(&i + &Nat::from(1u32)) == &n {
                            prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x))))
                        } else {
                            {
                                let x = x.clone();
                                call_then(start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_114094: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoExpr(own(&value_of_114094))), en.clone(), lv_opt.clone())))
                            }
                        },
                        _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_114186: (Array<crate::lower::model::Do>, Env)| {
                            let (more, en2) = block_stmt_114186;
                            prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                        }),
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env, Option<Vl>)>>>
    }));
    let last = or(&last_opt, &Vl::VlOwned(crate::lower::model::Ex::XNone, t.clone()));
    Vl::VlOwned(crate::lower::model::Ex::XLabeled(label.clone(), dos.clone(), Rc::new(own(&last)), t.clone()), t.clone())
}

/// The step machine of `GivenValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GivenValue: unbounded fn Lx, Env, Block, OutTy, Range -> Vl
/// ```
pub struct GivenValue {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for GivenValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let t = &self.t;
        let span = &self.span;
        let label = Text::from(format!("'g{}", &span.start));
        let is_try = match t {
            crate::lower::model::OutTy::OutRes(_) => true,
            _ => false,
        };
        let n = len(&b.stmts);
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let t = t.clone();
        call_value(fold_job(crate::check::errors::range0(&n), (Array::new(), env.clone(), None), {
            let b = b.clone();
            let is_try = is_try;
            let lx = lx.clone();
            let label = label.clone();
            let n = n.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)| {
                let b = b.clone();
                let is_try = is_try;
                let lx = lx.clone();
                let label = label.clone();
                let n = n.clone();
                entered(once_job(move || {
                    let (acc, en, lv_opt) = p0;
                    let i = p1;
                    {
                        let s = or(&index(&b.stmts, &i), &dummy_stmt_l());
                        let fail = if is_try {
                            crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Error::new"), Array::from(vec![crate::lower::model::Ex::XStr(Text::lit("Prelude.Unmet")), crate::lower::model::Ex::XStr(source_text(&lx, &s.span))]))]))
                        } else {
                            crate::lower::model::Ex::XNone
                        };
                        match &s.kind {
                            crate::syntax::StmtKind::SBind(p_, x, None) => {
                                let p_ = p_.clone();
                                let x = x.clone();
                                call_then(start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_113436: Vl| {
                                    let v_ = value_of_113436;
                                    call_then(start_rust_pat(lx.clone(), p_.clone(), inner_ty(&type_at(&lx, &x.span)), Holding::Owned, Text::from(format!("g{}", &s.span.start))), move |rust_pat_113479: PatOut| {
                                        let po = rust_pat_113479;
                                        call_then(start_out_ty_of(lx.clone(), inner_ty(&type_at(&lx, &x.span))), move |out_ty_of_113621: crate::lower::model::OutTy| prism_rtl::Turn::Finished((push(&acc, &given_bind(&is_try, &po.pa, &own(&v_), &label, &out_ty_of_113621)), bind_all(&en, &po.binds), lv_opt.clone())))
                                    })
                                })
                            },
                            crate::syntax::StmtKind::SRequire(c) => {
                                let c = c.clone();
                                call_then(start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_113762: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(as_bool(&value_of_113762))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                            },
                            crate::syntax::StmtKind::SForbid(c) => {
                                let c = c.clone();
                                call_then(start_value_of(lx.clone(), en.clone(), c.clone()), move |value_of_113886: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoIf(as_bool(&value_of_113886), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XBreak(label.clone(), Rc::new(fail.clone())))]), Array::new())), en.clone(), lv_opt.clone())))
                            },
                            crate::syntax::StmtKind::SExpr(x) => if &(&i + &Nat::from(1u32)) == &n {
                                prism_rtl::Turn::Finished((acc.clone(), en.clone(), Some(value_of(&lx, &en, x))))
                            } else {
                                {
                                    let x = x.clone();
                                    call_then(start_value_of(lx.clone(), en.clone(), x.clone()), move |value_of_114094: Vl| prism_rtl::Turn::Finished((push(&acc, &crate::lower::model::Do::DoExpr(own(&value_of_114094))), en.clone(), lv_opt.clone())))
                                }
                            },
                            _ => call_then(start_block_stmt(lx.clone(), en.clone(), s.clone()), move |block_stmt_114186: (Array<crate::lower::model::Do>, Env)| {
                                let (more, en2) = block_stmt_114186;
                                prism_rtl::Turn::Finished((append(&acc, &more), en2.clone(), lv_opt.clone()))
                            }),
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env, Option<Vl>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env, Option<Vl>)>>>
        }), move |fold_113120: (Array<crate::lower::model::Do>, Env, Option<Vl>)| {
            let (dos, env2, last_opt) = fold_113120;
            let last = or(&last_opt, &Vl::VlOwned(crate::lower::model::Ex::XNone, t.clone()));
            prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XLabeled(label.clone(), dos.clone(), Rc::new(own(&last)), t.clone()), t.clone()))
        })
    }
}

/// `Start GivenValue, x`: what the function value is when passed to `@Run`.
pub fn start_given_value(lx: Lx, env: Env, b: crate::syntax::Block, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(GivenValue { lx, env, b, t, span })
}

/// ```prism
/// GivenBind: fn Bool, Pa, Ex, Text, OutTy -> Do
/// ```
pub fn given_bind(is_try: &bool, pa: &crate::lower::model::Pa, x: &crate::lower::model::Ex, label: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::Do {
    if *is_try {
        crate::lower::model::Do::DoLet(pa.clone(), crate::lower::model::Ex::XMatch(Rc::new(x.clone()), Array::from(vec![crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("v"))])), conds: Array::new(), body: crate::lower::model::Ex::XVar(Text::lit("v")) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Pa::PaBind(Text::lit("e"))])), conds: Array::new(), body: crate::lower::model::Ex::XBreak(label.clone(), Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("e"))])))) }]), false, t.clone()))
    } else {
        crate::lower::model::Do::DoLetElse(crate::lower::model::Pa::PaCtor(Text::lit("Some"), Array::from(vec![pa.clone()])), x.clone(), crate::lower::model::Ex::XBreak(label.clone(), Rc::new(crate::lower::model::Ex::XNone)))
    }
}

/// ```prism
/// SourceText: fn Lx, Range -> Text
/// ```
pub fn source_text(lx: &Lx, r: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, r),
        None => Text::lit(""),
    }
}

/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub fn update_value(lx: &Lx, env: &Env, target: &crate::syntax::Expr, b: &crate::syntax::Block, t: &crate::lower::model::OutTy, span: &crate::syntax::Range) -> Vl {
    let tv = value_of(lx, env, target);
    let env1 = bind(env, &Text::lit("&_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), Holding::Owned, t.clone()));
    let (dos, _) = upd_stmts(lx, &env1, &b.stmts);
    Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), own(&tv))]), &dos), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t.clone())
}

/// The step machine of `UpdateValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdateValue: unbounded fn Lx, Env, Expr, Block, OutTy, Range -> Vl
/// ```
pub struct UpdateValue {
    pub lx: Lx,
    pub env: Env,
    pub target: crate::syntax::Expr,
    pub b: crate::syntax::Block,
    pub t: crate::lower::model::OutTy,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<Vl> for UpdateValue {
    fn cycle(&self) -> prism_rtl::Turn<Vl> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let b = &self.b;
        let t = &self.t;
        let span = &self.span;
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let t = t.clone();
        let target = target.clone();
        call_then(start_value_of(lx.clone(), env.clone(), target.clone()), move |value_of_115385: Vl| {
            let tv = value_of_115385;
            let env1 = bind(&env, &Text::lit("&_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), Holding::Owned, t.clone()));
            call_then(start_upd_stmts(lx.clone(), env1.clone(), b.stmts.clone()), move |upd_stmts_115500: (Array<crate::lower::model::Do>, Env)| {
                let (dos, _) = upd_stmts_115500;
                prism_rtl::Turn::Finished(Vl::VlOwned(crate::lower::model::Ex::XBlock(append(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), own(&tv))]), &dos), Rc::new(crate::lower::model::Ex::XVar(Text::lit("this")))), t.clone()))
            })
        })
    }
}

/// `Start UpdateValue, x`: what the function value is when passed to `@Run`.
pub fn start_update_value(lx: Lx, env: Env, target: crate::syntax::Expr, b: crate::syntax::Block, t: crate::lower::model::OutTy, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Vl>> {
    Rc::new(UpdateValue { lx, env, target, b, t, span })
}

/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub fn upd_stmts(lx: &Lx, env: &Env, stmts: &Array<crate::syntax::Stmt>) -> (Array<crate::lower::model::Do>, Env) {
    run_to_end(fold_job(stmts.clone(), (Array::new(), env.clone()), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), crate::syntax::Stmt)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (acc, en) = p0;
                let s = p1;
                call_then(start_upd_stmt(lx.clone(), en.clone(), s.clone()), move |upd_stmt_115785: (Array<crate::lower::model::Do>, Env)| {
                    let (more, en2) = upd_stmt_115785;
                    prism_rtl::Turn::Finished((append(&acc, &more), en2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
    }))
}

/// The step machine of `UpdStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmts: unbounded fn Lx, Env, [Stmt] -> (([Do], Env))
/// ```
pub struct UpdStmts {
    pub lx: Lx,
    pub env: Env,
    pub stmts: Array<crate::syntax::Stmt>,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, Env)> for UpdStmts {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let stmts = &self.stmts;
        fold_job(stmts.clone(), (Array::new(), env.clone()), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): ((Array<crate::lower::model::Do>, Env), crate::syntax::Stmt)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let (acc, en) = p0;
                    let s = p1;
                    call_then(start_upd_stmt(lx.clone(), en.clone(), s.clone()), move |upd_stmt_115785: (Array<crate::lower::model::Do>, Env)| {
                        let (more, en2) = upd_stmt_115785;
                        prism_rtl::Turn::Finished((append(&acc, &more), en2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::lower::model::Do>, Env), crate::syntax::Stmt)) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>>>
        }).cycle()
    }
}

/// `Start UpdStmts, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmts(lx: Lx, env: Env, stmts: Array<crate::syntax::Stmt>) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>> {
    Rc::new(UpdStmts { lx, env, stmts })
}

/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub fn upd_stmt(lx: &Lx, env: &Env, s: &crate::syntax::Stmt) -> (Array<crate::lower::model::Do>, Env) {
    match &s.kind {
        crate::syntax::StmtKind::SSet(target, value) => {
            let v_ = own(&value_of(lx, env, value));
            (Array::from(vec![assign(lx, env, target, &v_)]), env.clone())
        },
        crate::syntax::StmtKind::SAccum(target, op, value) => {
            let cur = place_of(lx, env, target);
            let tt = out_ty_of(lx, &peel(&type_at(lx, &target.span)));
            let rv = value_of(lx, env, value);
            let bin = crate::syntax::lexer::head(op);
            let next = op_value(lx, &bin, &Vl::VlPlace(cur.clone(), Holding::Owned, tt.clone()), &rv, &s.span, &tt);
            (Array::from(vec![assign(lx, env, target, &own(&next))]), env.clone())
        },
        crate::syntax::StmtKind::SLet(p_, _, x) => {
            let v_ = own(&value_of(lx, env, x));
            match &*p_.kind {
                crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                    {
                        let rs = local_name(lx, &crate::check::env::sname_key(n));
                        let bt = out_ty_of(lx, &peel(&binder_ty(lx, &n.span)));
                        let pa = if is_known_ty(&bt) {
                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))), bt.clone())
                        } else {
                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))
                        };
                        (Array::from(vec![crate::lower::model::Do::DoLet(pa.clone(), v_.clone())]), bind(env, &crate::check::env::sname_key(n), &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone())))
                    }
                } else {
                    block_stmt(lx, env, s)
                },
                _ => block_stmt(lx, env, s),
            }
        },
        crate::syntax::StmtKind::SWhile(c, body) => {
            let (inner, _) = upd_stmts(lx, env, &body.stmts);
            match c {
                crate::syntax::Cond::CondExpr(x) => (Array::from(vec![crate::lower::model::Do::DoWhile(as_bool(&value_of(lx, env, &**x)), inner.clone())]), env.clone()),
                crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                    let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("w{}", &s.span.start)));
                    let env_b = bind_all(env, &po.binds);
                    let (inner2, _) = upd_stmts(lx, &env_b, &body.stmts);
                    let conds = append(&po.conds, &guard_conds(lx, &env_b, &**g_opt));
                    let tests = fold(&conds, &Array::new(), &(|acc: &Array<crate::lower::model::Ex>, c: &crate::lower::model::Cc| match c {
                        crate::lower::model::Cc::CcIf(t) => push(acc, t),
                        _ => acc.clone(),
                    }));
                    let lets = fold(&conds, &false, &(|f: &bool, c: &crate::lower::model::Cc| *f || is_let_cond(c)));
                    let stop = if &len(&tests) == &Nat::from(0u32) {
                        Array::new()
                    } else {
                        Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                    };
                    let body2 = if lets {
                        Array::from(vec![refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                    } else {
                        append(&stop, &inner2)
                    };
                    (Array::from(vec![crate::lower::model::Do::DoWhileLet(po.pa.clone(), own(&value_of(lx, env, &**x)), body2.clone())]), env.clone())
                },
            }
        },
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => (Array::from(vec![upd_if(lx, env, &**c, then_b, else_b_opt)]), env.clone()),
            crate::syntax::ExprKind::EMatch(scrut, arms) => (Array::from(vec![upd_match(lx, env, &**scrut, arms)]), env.clone()),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => (Array::from(vec![upd_for(lx, env, binders_opt, &**source, body, &x.span)]), env.clone()),
            _ => (Array::from(vec![crate::lower::model::Do::DoExpr(own(&value_of(lx, env, x)))]), env.clone()),
        },
        _ => block_stmt(lx, env, s),
    }
}

/// The step machine of `UpdStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdStmt: unbounded fn Lx, Env, Stmt -> (([Do], Env))
/// ```
pub struct UpdStmt {
    pub lx: Lx,
    pub env: Env,
    pub s: crate::syntax::Stmt,
}

impl prism_rtl::Job<(Array<crate::lower::model::Do>, Env)> for UpdStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::lower::model::Do>, Env)> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        match &s.kind {
            crate::syntax::StmtKind::SSet(target, value) => {
                let env = env.clone();
                let lx = lx.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(start_value_of(lx.clone(), env.clone(), value.clone()), move |value_of_115972: Vl| {
                    let v_ = own(&value_of_115972);
                    call_then(start_assign(lx.clone(), env.clone(), target.clone(), v_.clone()), move |assign_116009: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_116009]), env.clone())))
                })
            },
            crate::syntax::StmtKind::SAccum(target, op, value) => {
                let env = env.clone();
                let lx = lx.clone();
                let op = op.clone();
                let s = s.clone();
                let target = target.clone();
                let value = value.clone();
                call_then(start_place_of(lx.clone(), env.clone(), target.clone()), move |place_of_116093: crate::lower::model::Ex| {
                    let cur = place_of_116093;
                    call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &target.span))), move |out_ty_of_116134: crate::lower::model::OutTy| {
                        let tt = out_ty_of_116134;
                        call_then(start_value_of(lx.clone(), env.clone(), value.clone()), move |value_of_116195: Vl| {
                            let rv = value_of_116195;
                            let bin = crate::syntax::lexer::head(&op);
                            let next = op_value(&lx, &bin, &Vl::VlPlace(cur.clone(), Holding::Owned, tt.clone()), &rv, &s.span, &tt);
                            call_then(start_assign(lx.clone(), env.clone(), target.clone(), own(&next)), move |assign_116334: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![assign_116334]), env.clone())))
                        })
                    })
                })
            },
            crate::syntax::StmtKind::SLet(p_, _, x) => {
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let s = s.clone();
                let x = x.clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_116423: Vl| {
                    let v_ = own(&value_of_116423);
                    match &*p_.kind {
                        crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                            {
                                let rs = local_name(&lx, &crate::check::env::sname_key(n));
                                let n = n.clone();
                                call_then(start_out_ty_of(lx.clone(), peel(&binder_ty(&lx, &n.span))), move |out_ty_of_116617: crate::lower::model::OutTy| {
                                    let bt = out_ty_of_116617;
                                    call_then(start_is_known_ty(bt.clone()), move |is_known_ty_116690: bool| {
                                        let pa = if is_known_ty_116690 {
                                            crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))), bt.clone())
                                        } else {
                                            crate::lower::model::Pa::PaMut(Text::from(format!("{}", &rs)))
                                        };
                                        prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoLet(pa.clone(), v_.clone())]), bind(&env, &crate::check::env::sname_key(&n), &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))))
                                    })
                                })
                            }
                        } else {
                            prism_rtl::Turn::More(Rc::new(BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() }))
                        },
                        _ => prism_rtl::Turn::More(Rc::new(BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() })),
                    }
                })
            },
            crate::syntax::StmtKind::SWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                let s = s.clone();
                call_then(start_upd_stmts(lx.clone(), env.clone(), body.stmts.clone()), move |upd_stmts_116989: (Array<crate::lower::model::Do>, Env)| {
                    let (inner, _) = upd_stmts_116989;
                    match &c {
                        crate::syntax::Cond::CondExpr(x) => {
                            let x = (**x).clone();
                            call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_117081: Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhile(as_bool(&value_of_117081), inner.clone())]), env.clone())))
                        },
                        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                            let g_opt = (**g_opt).clone();
                            let p_ = p_.clone();
                            let x = (**x).clone();
                            call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::Owned, Text::from(format!("w{}", &s.span.start))), move |rust_pat_117175: PatOut| {
                                let po = rust_pat_117175;
                                let env_b = bind_all(&env, &po.binds);
                                call_then(start_upd_stmts(lx.clone(), env_b.clone(), body.stmts.clone()), move |upd_stmts_117326: (Array<crate::lower::model::Do>, Env)| {
                                    let (inner2, _) = upd_stmts_117326;
                                    call_then(start_guard_conds(lx.clone(), env_b.clone(), g_opt.clone()), move |guard_conds_117584: Array<crate::lower::model::Cc>| {
                                        let conds = append(&po.conds, &guard_conds_117584);
                                        let tests = fold(&conds, &Array::new(), &(|acc: &Array<crate::lower::model::Ex>, c: &crate::lower::model::Cc| match c {
                                            crate::lower::model::Cc::CcIf(t) => push(acc, t),
                                            _ => acc.clone(),
                                        }));
                                        let lets = fold(&conds, &false, &(|f: &bool, c: &crate::lower::model::Cc| *f || is_let_cond(c)));
                                        let stop = if &len(&tests) == &Nat::from(0u32) {
                                            Array::new()
                                        } else {
                                            Array::from(vec![crate::lower::model::Do::DoIf(crate::lower::model::Ex::XUnary(Text::lit("!"), Rc::new(all_of(&tests))), Array::from(vec![crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XVar(Text::lit("break")))]), Array::new())])
                                        };
                                        let body2 = if lets {
                                            Array::from(vec![refusal_do(&Text::lit("a `while` whose pattern matches through an `Rc`"))])
                                        } else {
                                            append(&stop, &inner2)
                                        };
                                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_118123: Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoWhileLet(po.pa.clone(), own(&value_of_118123), body2.clone())]), env.clone())))
                                    })
                                })
                            })
                        },
                    }
                })
            },
            crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => {
                    let else_b_opt = else_b_opt.clone();
                    let c = (**c).clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let then_b = then_b.clone();
                    call_then(start_upd_if(lx.clone(), env.clone(), c.clone(), then_b.clone(), else_b_opt.clone()), move |upd_if_118223: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_if_118223]), env.clone())))
                },
                crate::syntax::ExprKind::EMatch(scrut, arms) => {
                    let arms = arms.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let scrut = (**scrut).clone();
                    call_then(start_upd_match(lx.clone(), env.clone(), scrut.clone(), arms.clone()), move |upd_match_118298: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_match_118298]), env.clone())))
                },
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => {
                    let binders_opt = binders_opt.clone();
                    let body = body.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let source = (**source).clone();
                    let x = x.clone();
                    call_then(start_upd_for(lx.clone(), env.clone(), binders_opt.clone(), source.clone(), body.clone(), x.span.clone()), move |upd_for_118380: crate::lower::model::Do| prism_rtl::Turn::Finished((Array::from(vec![upd_for_118380]), env.clone())))
                },
                _ => {
                    let env = env.clone();
                    let lx = lx.clone();
                    let x = x.clone();
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_118473: Vl| prism_rtl::Turn::Finished((Array::from(vec![crate::lower::model::Do::DoExpr(own(&value_of_118473))]), env.clone())))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(BlockStmt { lx: lx.clone(), env: env.clone(), s: s.clone() })),
        }
    }
}

/// `Start UpdStmt, x`: what the function value is when passed to `@Run`.
pub fn start_upd_stmt(lx: Lx, env: Env, s: crate::syntax::Stmt) -> Rc<dyn prism_rtl::Job<(Array<crate::lower::model::Do>, Env)>> {
    Rc::new(UpdStmt { lx, env, s })
}

/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub fn upd_for(lx: &Lx, env: &Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range) -> crate::lower::model::Do {
    let sty = peel(&type_at(lx, &source.span));
    match ref_binder(binders_opt) {
        Some(n) => if is_ref_path(source) {
            upd_for_refs(lx, env, &n, source, body, span, &sty)
        } else {
            upd_for_values(lx, env, binders_opt, source, body, span, &sty)
        },
        None => upd_for_values(lx, env, binders_opt, source, body, span, &sty),
    }
}

/// The step machine of `UpdFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdFor: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range -> Do
/// ```
pub struct UpdFor {
    pub lx: Lx,
    pub env: Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdFor {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = peel(&type_at(lx, &source.span));
        match ref_binder(binders_opt) {
            Some(n) => if is_ref_path(source) {
                prism_rtl::Turn::More(Rc::new(UpdForRefs { lx: lx.clone(), env: env.clone(), n: n.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(UpdForValues { lx: lx.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() }))
            },
            None => prism_rtl::Turn::More(Rc::new(UpdForValues { lx: lx.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: source.clone(), body: body.clone(), span: span.clone(), sty: sty.clone() })),
        }
    }
}

/// `Start UpdFor, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for(lx: Lx, env: Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdFor { lx, env, binders_opt, source, body, span })
}

/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_refs(lx: &Lx, env: &Env, n: &crate::syntax::SName, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, sty: &crate::check::types::Ty) -> crate::lower::model::Do {
    match sty {
        crate::check::types::Ty::TyArray(v_) => {
            let key_name = Text::from(format!("k{}", &span.start));
            let ref_name = Text::from(format!("r{}", &span.start));
            let env1 = bind(&bind(&bind(env, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(n), &Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name.clone()))), Holding::Owned, out_ty_of(lx, &**v_)));
            let (dos, _) = upd_stmts(lx, &env1, &body.stmts);
            let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(ref_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of(lx, env, source)), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head.clone()]), &dos))
        },
        _ => refusal_do(&Text::lit("a `for` by reference over what is not an array")),
    }
}

/// The step machine of `UpdForRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForRefs: unbounded fn Lx, Env, SName, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForRefs {
    pub lx: Lx,
    pub env: Env,
    pub n: crate::syntax::SName,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub sty: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForRefs {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let n = &self.n;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = &self.sty;
        match sty {
            crate::check::types::Ty::TyArray(v_) => {
                let key_name = Text::from(format!("k{}", &span.start));
                let ref_name = Text::from(format!("r{}", &span.start));
                let body = body.clone();
                let env = env.clone();
                let lx = lx.clone();
                let n = n.clone();
                let source = source.clone();
                let span = span.clone();
                let v_ = (**v_).clone();
                call_then(start_out_ty_of(lx.clone(), v_.clone()), move |out_ty_of_119833: crate::lower::model::OutTy| {
                    let env1 = bind(&bind(&bind(&env, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, crate::lower::model::OutTy::OutNat)), &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, crate::lower::model::OutTy::OutNat)), &crate::check::env::sname_key(&n), &Bn::BnLocal(crate::lower::model::Ex::XTarget(Rc::new(crate::lower::model::Ex::XVar(ref_name.clone()))), Holding::Owned, out_ty_of_119833));
                    call_then(start_upd_stmts(lx.clone(), env1.clone(), body.stmts.clone()), move |upd_stmts_119879: (Array<crate::lower::model::Do>, Env)| {
                        let (dos, _) = upd_stmts_119879;
                        let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
                        call_then(start_place_of(lx.clone(), env.clone(), source.clone()), move |place_of_120088: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(ref_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(place_of_120088), Text::lit("iter_mut"), Array::new())), Text::lit("enumerate"), Array::new()), append(&Array::from(vec![head.clone()]), &dos))))
                    })
                })
            },
            _ => prism_rtl::Turn::Finished(refusal_do(&Text::lit("a `for` by reference over what is not an array"))),
        }
    }
}

/// `Start UpdForRefs, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_refs(lx: Lx, env: Env, n: crate::syntax::SName, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, sty: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForRefs { lx, env, n, source, body, span, sty })
}

/// ```prism
/// ?RefBinder: fn ?ForBinders -> ?SName
/// ```
pub fn ref_binder(opt0: &Option<crate::syntax::ForBinders>) -> Option<crate::syntax::SName> {
    match opt0 {
        Some(fb) => match &fb.second {
            None => match &*fb.first.kind {
                crate::syntax::PatternKind::PName(n) => if crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")) {
                    Some(n.clone())
                } else {
                    None
                },
                _ => None,
            },
            _ => None,
        },
        None => None,
    }
}

/// ```prism
/// IsRefPath: fn Expr -> Bool
/// ```
pub fn is_ref_path(e: &crate::syntax::Expr) -> bool {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => crate::syntax::lexer::has_prefix(&n.sigils, &Text::lit("&")),
        crate::syntax::ExprKind::EField(r, _, _) => is_ref_path(&**r),
        crate::syntax::ExprKind::EIndex(r, _) => is_ref_path(&**r),
        crate::syntax::ExprKind::EGroup(x) => is_ref_path(&**x),
        _ => false,
    }
}

/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub fn upd_for_values(lx: &Lx, env: &Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, sty: &crate::check::types::Ty) -> crate::lower::model::Do {
    let src = own(&value_of(lx, env, source));
    let (kt, vt, is_array) = match sty {
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, out_ty_of(lx, &**v_), true),
        crate::check::types::Ty::TyMap(k, v_) => (out_ty_of(lx, &**k), out_ty_of(lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty, kty) = match sty {
        crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name = Text::from(format!("k{}", &span.start));
    let val_name = Text::from(format!("v{}", &span.start));
    let env1 = bind(&bind(env, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone())), &Text::lit("_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), Holding::Owned, vt.clone()));
    let env2 = if is_array {
        bind(&env1, &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone()))
    } else {
        env1.clone()
    };
    let (binds, env3) = match binders_opt {
        None => (Array::new(), env2.clone()),
        Some(fb) => match &fb.second {
            None => {
                let po = rust_pat(lx, &fb.first, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&env2, &po.binds))
            },
            Some(second) => {
                let pk = rust_pat(lx, &fb.first, &kty, &Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                let pv = rust_pat(lx, second, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&bind_all(&env2, &pk.binds), &pv.binds))
            },
        },
    };
    let (dos, _) = upd_stmts(lx, &env3, &body.stmts);
    if is_array {
        {
            let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
            crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head), &append(&binds, &dos)))
        }
    } else {
        crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new()), append(&binds, &dos))
    }
}

/// The step machine of `UpdForValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdForValues: unbounded fn Lx, Env, ?ForBinders, Expr, Block, Range, Ty -> Do
/// ```
pub struct UpdForValues {
    pub lx: Lx,
    pub env: Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub sty: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdForValues {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let sty = &self.sty;
        let binders_opt = binders_opt.clone();
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let source = source.clone();
        let span = span.clone();
        let sty = sty.clone();
        call_then(start_value_of(lx.clone(), env.clone(), source.clone()), move |value_of_120983: Vl| {
            let src = own(&value_of_120983);
            let (kt, vt, is_array) = match &sty {
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyMap(k, v_) => (out_ty_of(&lx, &**k), out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty, kty) = match &sty {
                crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name = Text::from(format!("k{}", &span.start));
            let val_name = Text::from(format!("v{}", &span.start));
            let env1 = bind(&bind(&env, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone())), &Text::lit("_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), Holding::Owned, vt.clone()));
            let env2 = if is_array {
                bind(&env1, &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone()))
            } else {
                env1.clone()
            };
            let (binds, env3) = match &binders_opt {
                None => (Array::new(), env2.clone()),
                Some(fb) => match &fb.second {
                    None => {
                        let po = rust_pat(&lx, &fb.first, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&env2, &po.binds))
                    },
                    Some(second) => {
                        let pk = rust_pat(&lx, &fb.first, &kty, &Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                        let pv = rust_pat(&lx, second, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&bind_all(&env2, &pk.binds), &pv.binds))
                    },
                },
            };
            call_then(start_upd_stmts(lx.clone(), env3.clone(), body.stmts.clone()), move |upd_stmts_122264: (Array<crate::lower::model::Do>, Env)| {
                let (dos, _) = upd_stmts_122264;
                if is_array {
                    {
                        let head = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Ex::XCall(Text::lit("nat_of"), Array::from(vec![crate::lower::model::Ex::XVar(Text::from(format!("i{}", &span.start)))])));
                        prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(Text::from(format!("i{}", &span.start))), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new())), Text::lit("enumerate"), Array::new()), append(&push(&Array::new(), &head), &append(&binds, &dos))))
                    }
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoFor(crate::lower::model::Pa::PaTuple(Array::from(vec![crate::lower::model::Pa::PaBind(key_name.clone()), crate::lower::model::Pa::PaBind(val_name.clone())])), crate::lower::model::Ex::XMethod(Rc::new(src.clone()), Text::lit("into_iter"), Array::new()), append(&binds, &dos)))
                }
            })
        })
    }
}

/// `Start UpdForValues, x`: what the function value is when passed to `@Run`.
pub fn start_upd_for_values(lx: Lx, env: Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, sty: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdForValues { lx, env, binders_opt, source, body, span, sty })
}

/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub fn upd_if(lx: &Lx, env: &Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>) -> crate::lower::model::Do {
    let (else_dos, _) = match else_b_opt {
        Some(b) => upd_stmts(lx, env, &b.stmts),
        None => (Array::new(), env.clone()),
    };
    match c {
        crate::syntax::Cond::CondExpr(x) => {
            let (then_dos, _) = upd_stmts(lx, env, &then_b.stmts);
            crate::lower::model::Do::DoIf(as_bool(&value_of(lx, env, &**x)), then_dos.clone(), else_dos.clone())
        },
        crate::syntax::Cond::CondBind(p_, x, _) => {
            let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
            let (then_dos, _) = upd_stmts(lx, &bind_all(env, &po.binds), &then_b.stmts);
            crate::lower::model::Do::DoIfLet(po.pa.clone(), own(&value_of(lx, env, &**x)), then_dos.clone(), else_dos.clone())
        },
    }
}

/// The step machine of `UpdIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdIf: unbounded fn Lx, Env, Cond, Block, ?Block -> Do
/// ```
pub struct UpdIf {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdIf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let (else_dos, _) = match else_b_opt {
            Some(b) => upd_stmts(lx, env, &b.stmts),
            None => (Array::new(), env.clone()),
        };
        match c {
            crate::syntax::Cond::CondExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_upd_stmts(lx.clone(), env.clone(), then_b.stmts.clone()), move |upd_stmts_122974: (Array<crate::lower::model::Do>, Env)| {
                    let (then_dos, _) = upd_stmts_122974;
                    call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_123030: Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIf(as_bool(&value_of_123030), then_dos.clone(), else_dos.clone())))
                })
            },
            crate::syntax::Cond::CondBind(p_, x, _) => {
                let env = env.clone();
                let lx = lx.clone();
                let p_ = p_.clone();
                let then_b = then_b.clone();
                let x = (**x).clone();
                call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::Owned, Text::from(format!("u{}", &x.span.start))), move |rust_pat_123121: PatOut| {
                    let po = rust_pat_123121;
                    call_then(start_upd_stmts(lx.clone(), bind_all(&env, &po.binds), then_b.stmts.clone()), move |upd_stmts_123220: (Array<crate::lower::model::Do>, Env)| {
                        let (then_dos, _) = upd_stmts_123220;
                        call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_123303: Vl| prism_rtl::Turn::Finished(crate::lower::model::Do::DoIfLet(po.pa.clone(), own(&value_of_123303), then_dos.clone(), else_dos.clone())))
                    })
                })
            },
        }
    }
}

/// `Start UpdIf, x`: what the function value is when passed to `@Run`.
pub fn start_upd_if(lx: Lx, env: Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdIf { lx, env, c, then_b, else_b_opt })
}

/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub fn upd_match(lx: &Lx, env: &Env, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>) -> crate::lower::model::Do {
    let sv = value_of(lx, env, scrut);
    let sty = type_at(lx, &scrut.span);
    let arms3 = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let lx = lx.clone();
        let sty = sty.clone();
        let scrut = scrut.clone();
        let env = env.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let lx = lx.clone();
            let sty = sty.clone();
            let scrut = scrut.clone();
            let env = env.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &dummy_arm());
                    call_then(start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), Holding::ByRef, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_123602: PatOut| {
                        let po = arm_pat_123602;
                        call_then(start_upd_stmts(lx.clone(), bind_all(&env, &po.binds), arm.body.stmts.clone()), move |upd_stmts_123695: (Array<crate::lower::model::Do>, Env)| {
                            let (dos, _) = upd_stmts_123695;
                            call_then(start_guard_conds(lx.clone(), bind_all(&env, &po.binds), arm.guard.clone()), move |guard_conds_123788: Array<crate::lower::model::Cc>| {
                                let guarded = append(&po.conds, &guard_conds_123788);
                                prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                            })
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    if fold(&arms3, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32)))) {
        crate::lower::model::Do::DoExpr(own(&arms_value(&ref_(&sv), &arms3, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnit)))
    } else {
        crate::lower::model::Do::DoMatch(ref_(&sv), each(&arms3, &(|a: &crate::lower::model::XArm| (a.pat.clone(), arm_dos(&a.body)))))
    }
}

/// The step machine of `UpdMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdMatch: unbounded fn Lx, Env, Expr, [Arm] -> Do
/// ```
pub struct UpdMatch {
    pub lx: Lx,
    pub env: Env,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
}

impl prism_rtl::Job<crate::lower::model::Do> for UpdMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let scrut = scrut.clone();
        call_then(start_value_of(lx.clone(), env.clone(), scrut.clone()), move |value_of_123440: Vl| {
            let sv = value_of_123440;
            let sty = type_at(&lx, &scrut.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let arms = arms.clone();
                let lx = lx.clone();
                let sty = sty.clone();
                let scrut = scrut.clone();
                let env = env.clone();
                Rc::new(move |p0: Nat| {
                    let arms = arms.clone();
                    let lx = lx.clone();
                    let sty = sty.clone();
                    let scrut = scrut.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let arm = or(&index(&arms, &i), &dummy_arm());
                            call_then(start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), Holding::ByRef, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_123602: PatOut| {
                                let po = arm_pat_123602;
                                call_then(start_upd_stmts(lx.clone(), bind_all(&env, &po.binds), arm.body.stmts.clone()), move |upd_stmts_123695: (Array<crate::lower::model::Do>, Env)| {
                                    let (dos, _) = upd_stmts_123695;
                                    call_then(start_guard_conds(lx.clone(), bind_all(&env, &po.binds), arm.guard.clone()), move |guard_conds_123788: Array<crate::lower::model::Cc>| {
                                        let guarded = append(&po.conds, &guard_conds_123788);
                                        prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(crate::lower::model::Ex::XUnit)) })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_123515: Array<crate::lower::model::XArm>| {
                let arms3 = each_123515;
                if fold(&arms3, &false, &(|f: &bool, a: &crate::lower::model::XArm| *f || (&len(&a.conds) > &Nat::from(0u32)))) {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(own(&arms_value(&ref_(&sv), &arms3, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnit))))
                } else {
                    prism_rtl::Turn::Finished(crate::lower::model::Do::DoMatch(ref_(&sv), each(&arms3, &(|a: &crate::lower::model::XArm| (a.pat.clone(), arm_dos(&a.body))))))
                }
            })
        })
    }
}

/// `Start UpdMatch, x`: what the function value is when passed to `@Run`.
pub fn start_upd_match(lx: Lx, env: Env, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(UpdMatch { lx, env, scrut, arms })
}

/// ```prism
/// AllOf: fn [Ex] -> Ex
/// ```
pub fn all_of(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one) = index(c0_0, &Nat::from(0u32)) {
            break 'c one.clone();
        }
        if let xs = xs0 {
            break 'c fold(&drop(xs, &Nat::from(1u32)), &or(&index(xs, &Nat::from(0u32)), &crate::lower::model::Ex::XBool(true)), &(|acc: &crate::lower::model::Ex, x: &crate::lower::model::Ex| crate::lower::model::Ex::XBin(Text::lit("&&"), Rc::new(acc.clone()), Rc::new(x.clone()))));
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// ArmDos: fn Ex -> [Do]
/// ```
pub fn arm_dos(ex0: &crate::lower::model::Ex) -> Array<crate::lower::model::Do> {
    match ex0 {
        crate::lower::model::Ex::XBlock(dos, _) => dos.clone(),
        x => Array::from(vec![crate::lower::model::Do::DoExpr(x.clone())]),
    }
}

/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub fn guard_conds(lx: &Lx, env: &Env, opt2: &Option<crate::syntax::Expr>) -> Array<crate::lower::model::Cc> {
    match opt2 {
        Some(ge) => Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of(lx, env, ge)))]),
        None => Array::new(),
    }
}

/// The step machine of `GuardConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GuardConds: unbounded fn Lx, Env, ?Expr -> [Cc]
/// ```
pub struct GuardConds {
    pub lx: Lx,
    pub env: Env,
    pub opt2: Option<crate::syntax::Expr>,
}

impl prism_rtl::Job<Array<crate::lower::model::Cc>> for GuardConds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Cc>> {
        let lx = &self.lx;
        let env = &self.env;
        let opt2 = &self.opt2;
        match opt2 {
            Some(ge) => {
                let env = env.clone();
                let ge = ge.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), ge.clone()), move |value_of_124630: Vl| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Cc::CcIf(as_bool(&value_of_124630))])))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start GuardConds, x`: what the function value is when passed to `@Run`.
pub fn start_guard_conds(lx: Lx, env: Env, opt2: Option<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Cc>>> {
    Rc::new(GuardConds { lx, env, opt2 })
}

/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn place_of(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match &*e.kind {
        crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
            Some(Bn::BnLocal(rs, _, _)) => rs.clone(),
            _ => crate::lower::model::Ex::XVar(snake(&crate::check::env::sname_key(n))),
        },
        crate::syntax::ExprKind::EField(r, _, name) => crate::lower::model::Ex::XField(Rc::new(place_of(lx, env, &**r)), snake(&name.name)),
        crate::syntax::ExprKind::EIndex(r, k) => {
            let rt = out_ty_of(lx, &peel(&type_at(lx, &r.span)));
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                _ => Text::lit("at_mut"),
            };
            crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx, env, &**r))), argument(lx, env, &**k)]))))
        },
        crate::syntax::ExprKind::EGroup(x) => place_of(lx, env, &**x),
        _ => refusal(&Text::lit("a reference path this back end does not lower")),
    }
}

/// The step machine of `PlaceOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlaceOf: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct PlaceOf {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for PlaceOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        match &*e.kind {
            crate::syntax::ExprKind::EName(n) => match get(&env.names, &crate::check::env::sname_key(n)) {
                Some(Bn::BnLocal(rs, _, _)) => prism_rtl::Turn::Finished(rs.clone()),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XVar(snake(&crate::check::env::sname_key(n)))),
            },
            crate::syntax::ExprKind::EField(r, _, name) => {
                let env = env.clone();
                let lx = lx.clone();
                let name = name.clone();
                let r = (**r).clone();
                call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_124998: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XField(Rc::new(place_of_124998), snake(&name.name))))
            },
            crate::syntax::ExprKind::EIndex(r, k) => {
                let env = env.clone();
                let k = (**k).clone();
                let lx = lx.clone();
                let r = (**r).clone();
                call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &r.span))), move |out_ty_of_125071: crate::lower::model::OutTy| {
                    let rt = out_ty_of_125071;
                    let f = match &rt {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("at_mut_map"),
                        _ => Text::lit("at_mut"),
                    };
                    call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_125253: crate::lower::model::Ex| call_then(start_argument(lx.clone(), env.clone(), k.clone()), move |argument_125276: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XDeref(Rc::new(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_125253)), argument_125276])))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(PlaceOf { lx: lx.clone(), env: env.clone(), e: (**x).clone() })),
            _ => prism_rtl::Turn::Finished(refusal(&Text::lit("a reference path this back end does not lower"))),
        }
    }
}

/// `Start PlaceOf, x`: what the function value is when passed to `@Run`.
pub fn start_place_of(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(PlaceOf { lx, env, e })
}

/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub fn assign(lx: &Lx, env: &Env, target: &crate::syntax::Expr, v_: &crate::lower::model::Ex) -> crate::lower::model::Do {
    match &*target.kind {
        crate::syntax::ExprKind::EIndex(r, k) => {
            let rt = out_ty_of(lx, &peel(&type_at(lx, &r.span)));
            let f = match &rt {
                crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                _ => Text::lit("set_index"),
            };
            crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of(lx, env, &**r))), argument(lx, env, &**k), v_.clone()])))
        },
        crate::syntax::ExprKind::EGroup(x) => assign(lx, env, &**x, v_),
        _ => crate::lower::model::Do::DoAssign(place_of(lx, env, target), v_.clone()),
    }
}

/// The step machine of `Assign`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assign: unbounded fn Lx, Env, Expr, Ex -> Do
/// ```
pub struct Assign {
    pub lx: Lx,
    pub env: Env,
    pub target: crate::syntax::Expr,
    pub v_: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Do> for Assign {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Do> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let v_ = &self.v_;
        match &*target.kind {
            crate::syntax::ExprKind::EIndex(r, k) => {
                let env = env.clone();
                let k = (**k).clone();
                let lx = lx.clone();
                let r = (**r).clone();
                let v_ = v_.clone();
                call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &r.span))), move |out_ty_of_125684: crate::lower::model::OutTy| {
                    let rt = out_ty_of_125684;
                    let f = match &rt {
                        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("set_key"),
                        _ => Text::lit("set_index"),
                    };
                    call_then(start_place_of(lx.clone(), env.clone(), r.clone()), move |place_of_125866: crate::lower::model::Ex| call_then(start_argument(lx.clone(), env.clone(), k.clone()), move |argument_125889: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoExpr(crate::lower::model::Ex::XCall(f.clone(), Array::from(vec![crate::lower::model::Ex::XRefMut(Rc::new(place_of_125866)), argument_125889, v_.clone()]))))))
                })
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Assign { lx: lx.clone(), env: env.clone(), target: (**x).clone(), v_: v_.clone() })),
            _ => {
                let env = env.clone();
                let lx = lx.clone();
                let target = target.clone();
                let v_ = v_.clone();
                call_then(start_place_of(lx.clone(), env.clone(), target.clone()), move |place_of_125976: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Do::DoAssign(place_of_125976, v_.clone())))
            },
        }
    }
}

/// `Start Assign, x`: what the function value is when passed to `@Run`.
pub fn start_assign(lx: Lx, env: Env, target: crate::syntax::Expr, v_: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Do>> {
    Rc::new(Assign { lx, env, target, v_ })
}

/// ```prism
/// BoundOf: fn Lx, Text -> [Text]
/// ```
pub fn bound_of(lx: &Lx, text1: &Text) -> Array<Text> {
    match text1 {
        c0_1 if (c0_1 == &Text::lit("Prelude.Eq")) => Array::from(vec![Text::lit("PartialEq")]),
        c1_1 if (c1_1 == &Text::lit("Prelude.Ord")) => Array::from(vec![Text::lit("PartialOrd")]),
        c2_1 if (c2_1 == &Text::lit("Prelude.Show")) => Array::from(vec![Text::lit("Show")]),
        c3_1 if (c3_1 == &Text::lit("Prelude.Num")) => Array::from(vec![Text::lit("Num")]),
        c4_1 if (c4_1 == &Text::lit("Prelude.Pod")) => Array::from(vec![Text::lit("ToPod"), Text::lit("FromPod")]),
        cls => match get(&lx.g.traits, cls) {
            Some(tr) => Array::from(vec![path_in(lx, &tr.home, &camel(&crate::check::types::bare_name(cls)))]),
            None => Array::new(),
        },
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// SchemeGenerics: fn Lx, Scheme -> [((Text, [Text]))]
/// ```
pub fn scheme_generics(lx: &Lx, sc: &crate::check::types::Scheme) -> Array<(Text, Array<Text>)> {
    each(&sc.qs, &(|q: &Text| {
        let bs = fold(&sc.bounds, &Array::from(vec![Text::lit("Clone")]), &(|acc: &Array<Text>, (v_, cls): &(Text, Text)| if v_ == q {
            crate::check::types::union_texts(acc, &bound_of(lx, cls))
        } else {
            acc.clone()
        }));
        (camel(q), bs.clone())
    }))
}

/// ```prism
/// ParamNames: fn Lx, [FnClause], [OutTy] -> [((Text, Bool))]
/// ```
pub fn param_names(lx: &Lx, clauses: &Array<crate::syntax::FnClause>, pts: &Array<crate::lower::model::OutTy>) -> Array<(Text, bool)> {
    each(&crate::check::errors::range0(&len(pts)), &(|i: &Nat| {
        let names = each(clauses, &(|c: &crate::syntax::FnClause| plain_binder(lx, &or(&index(&c.params, i), &dummy_pat()))));
        let first_ = or(&index(&names, &Nat::from(0u32)), &Text::lit(""));
        let same = (&first_ != &Text::lit("")) && fold(&names, &true, &(|ok: &bool, n: &Text| *ok && (n == &first_)));
        if same {
            (local_name(lx, &first_), false)
        } else {
            (param_word(&or(&index(pts, i), &crate::lower::model::OutTy::OutUnit), i), true)
        }
    }))
}

/// ```prism
/// PlainBinder: fn Lx, Pattern -> Text
/// ```
pub fn plain_binder(lx: &Lx, p_: &crate::syntax::Pattern_) -> Text {
    match &*p_.kind {
        crate::syntax::PatternKind::PName(n) => {
            let (qk_opt, why) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            let is_ctor = match &qk_opt {
                Some(qk) => crate::check::env::has_key(&lx.g.ctors, qk) && (crate::check::env::is_upper_text(&base(&crate::check::env::sname_key(n))) || is_unit_ctor(lx, qk)),
                None => false,
            };
            if is_ctor { Text::lit("") } else { crate::check::env::sname_key(n) }
        },
        crate::syntax::PatternKind::PGroup(q) => plain_binder(lx, &**q),
        _ => Text::lit(""),
    }
}

/// ```prism
/// ParamWord: fn OutTy, Nat -> Text
/// ```
pub fn param_word(t: &crate::lower::model::OutTy, i: &Nat) -> Text {
    let base_ = match t {
        crate::lower::model::OutTy::OutNamed(n, _) => snake(&or(&crate::syntax::lexer::last(&split(n, &Text::lit("::"))), &Text::lit("arg"))),
        crate::lower::model::OutTy::OutText => Text::lit("text"),
        crate::lower::model::OutTy::OutNat => Text::lit("n"),
        crate::lower::model::OutTy::OutInt => Text::lit("i"),
        crate::lower::model::OutTy::OutArray(_) => Text::lit("xs"),
        crate::lower::model::OutTy::OutMap(_, _) => Text::lit("map"),
        crate::lower::model::OutTy::OutOpt(_) => Text::lit("opt"),
        _ => Text::lit("arg"),
    };
    Text::from(format!("{}{}", &base_, i))
}

/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub fn clauses_body(lx: &Lx, env: &Env, clauses: &Array<crate::syntax::FnClause>, names: &Array<(Text, bool)>, ptys: &Array<crate::check::types::Ty>, body_fn: &Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label: &Text, t: &crate::lower::model::OutTy) -> crate::lower::model::Ex {
    let env1 = run_to_end(fold_job(crate::check::errors::range0(&len(names)), env.clone(), {
        let names = names.clone();
        let lx = lx.clone();
        let clauses = clauses.clone();
        let ptys = ptys.clone();
        Rc::new(move |(p0, p1): (Env, Nat)| {
            let names = names.clone();
            let lx = lx.clone();
            let clauses = clauses.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let en = p0;
                let i = p1;
                {
                    let (rs, matched) = or(&index(&names, &i), &(Text::lit(""), true));
                    if matched {
                        prism_rtl::Turn::Finished(en.clone())
                    } else {
                        call_then(start_out_ty_of(lx.clone(), peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_129269: crate::lower::model::OutTy| prism_rtl::Turn::Finished(bind(&en, &plain_binder(&lx, &or(&index(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params, &i), &dummy_pat())), &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::ByRef, out_ty_of_129269))))
                    }
                }
            }))
        }) as Rc<dyn Fn((Env, Nat)) -> Rc<dyn prism_rtl::Job<Env>>>
    }));
    let scrut_ix = filter(&crate::check::errors::range0(&len(names)), &(|i: &Nat| match index(names, i) {
        Some((_, true)) => true,
        _ => false,
    }));
    if &len(&scrut_ix) == &Nat::from(0u32) {
        {
            let c = or(&index(clauses, &Nat::from(0u32)), &dummy_clause());
            run_to_end(body_fn((lx.clone(), env1.clone(), c.body.clone())))
        }
    } else {
        {
            let scrut = 'm129566: {
                if let m129566_0 = &scrut_ix && (m129566_0.len() == 1) && let Some(i) = index(m129566_0, &Nat::from(0u32)) {
                    break 'm129566 crate::lower::model::Ex::XVar(or(&index(&each(names, &(|(n, _): &(Text, bool)| n.clone())), &i), &Text::lit("arg")));
                }
                crate::lower::model::Ex::XTuple(each(&scrut_ix, &(|i: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg"))))))
            };
            let arms = run_to_end(each_job(crate::check::errors::range0(&len(clauses)), {
                let clauses = clauses.clone();
                let scrut_ix = scrut_ix.clone();
                let lx = lx.clone();
                let ptys = ptys.clone();
                let label = label.clone();
                let body_fn = body_fn.clone();
                let env1 = env1.clone();
                Rc::new(move |p0: Nat| {
                    let clauses = clauses.clone();
                    let scrut_ix = scrut_ix.clone();
                    let lx = lx.clone();
                    let ptys = ptys.clone();
                    let label = label.clone();
                    let body_fn = body_fn.clone();
                    let env1 = env1.clone();
                    entered(once_job(move || {
                        let ci = p0;
                        {
                            let c = or(&index(&clauses, &ci), &dummy_clause());
                            call_value(each_job(scrut_ix.clone(), {
                                let lx = lx.clone();
                                let c = c.clone();
                                let ptys = ptys.clone();
                                let label = label.clone();
                                let ci = ci.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx = lx.clone();
                                    let c = c.clone();
                                    let ptys = ptys.clone();
                                    let label = label.clone();
                                    let ci = ci.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&c.params, &i), &dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: Holding::ByRef, fresh: Text::from(format!("{}{}_{}", &label, &ci, &i)) }))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                            }), move |each_129881: Array<PatOut>| {
                                let pos = each_129881;
                                let pa = 'm130007: {
                                    if let m130007_0 = &pos && (m130007_0.len() == 1) && let Some(o) = index(m130007_0, &Nat::from(0u32)) {
                                        break 'm130007 o.pa.clone();
                                    }
                                    crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &PatOut| o.pa.clone())))
                                };
                                let conds = fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                                let binds = fold(&pos, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds)));
                                call_value((&body_fn)((lx.clone(), bind_all(&env1, &binds), c.body.clone())), move |body_130287: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa.clone(), conds: conds.clone(), body: body_130287 }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }));
            own(&arms_value(&scrut, &arms, &Text::from(format!("'{}", label)), t))
        }
    }
}

/// The step machine of `ClausesBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClausesBody: unbounded fn Lx, Env, [FnClause], [((Text, Bool))], [Ty], (fn Lx, Env, FnBody -> Ex), Text, OutTy -> Ex
/// ```
pub struct ClausesBody {
    pub lx: Lx,
    pub env: Env,
    pub clauses: Array<crate::syntax::FnClause>,
    pub names: Array<(Text, bool)>,
    pub ptys: Array<crate::check::types::Ty>,
    pub body_fn: Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
    pub label: Text,
    pub t: crate::lower::model::OutTy,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ClausesBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let clauses = &self.clauses;
        let names = &self.names;
        let ptys = &self.ptys;
        let body_fn = &self.body_fn;
        let label = &self.label;
        let t = &self.t;
        let body_fn = body_fn.clone();
        let clauses = clauses.clone();
        let env = env.clone();
        let label = label.clone();
        let lx = lx.clone();
        let names = names.clone();
        let ptys = ptys.clone();
        let t = t.clone();
        call_value(fold_job(crate::check::errors::range0(&len(&names)), env.clone(), {
            let names = names.clone();
            let lx = lx.clone();
            let clauses = clauses.clone();
            let ptys = ptys.clone();
            Rc::new(move |(p0, p1): (Env, Nat)| {
                let names = names.clone();
                let lx = lx.clone();
                let clauses = clauses.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let en = p0;
                    let i = p1;
                    {
                        let (rs, matched) = or(&index(&names, &i), &(Text::lit(""), true));
                        if matched {
                            prism_rtl::Turn::Finished(en.clone())
                        } else {
                            call_then(start_out_ty_of(lx.clone(), peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_129269: crate::lower::model::OutTy| prism_rtl::Turn::Finished(bind(&en, &plain_binder(&lx, &or(&index(&or(&index(&clauses, &Nat::from(0u32)), &dummy_clause()).params, &i), &dummy_pat())), &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::ByRef, out_ty_of_129269))))
                        }
                    }
                }))
            }) as Rc<dyn Fn((Env, Nat)) -> Rc<dyn prism_rtl::Job<Env>>>
        }), move |fold_129025: Env| {
            let env1 = fold_129025;
            let scrut_ix = filter(&crate::check::errors::range0(&len(&names)), &(|i: &Nat| match index(&names, i) {
                Some((_, true)) => true,
                _ => false,
            }));
            if &len(&scrut_ix) == &Nat::from(0u32) {
                {
                    let c = or(&index(&clauses, &Nat::from(0u32)), &dummy_clause());
                    (&body_fn)((lx.clone(), env1.clone(), c.body.clone())).cycle()
                }
            } else {
                {
                    let scrut = 'm129566: {
                        if let m129566_0 = &scrut_ix && (m129566_0.len() == 1) && let Some(i) = index(m129566_0, &Nat::from(0u32)) {
                            break 'm129566 crate::lower::model::Ex::XVar(or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), &i), &Text::lit("arg")));
                        }
                        crate::lower::model::Ex::XTuple(each(&scrut_ix, &(|i: &Nat| crate::lower::model::Ex::XVar(or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg"))))))
                    };
                    call_value(each_job(crate::check::errors::range0(&len(&clauses)), {
                        let clauses = clauses.clone();
                        let scrut_ix = scrut_ix.clone();
                        let lx = lx.clone();
                        let ptys = ptys.clone();
                        let label = label.clone();
                        let body_fn = body_fn.clone();
                        let env1 = env1.clone();
                        Rc::new(move |p0: Nat| {
                            let clauses = clauses.clone();
                            let scrut_ix = scrut_ix.clone();
                            let lx = lx.clone();
                            let ptys = ptys.clone();
                            let label = label.clone();
                            let body_fn = body_fn.clone();
                            let env1 = env1.clone();
                            entered(once_job(move || {
                                let ci = p0;
                                {
                                    let c = or(&index(&clauses, &ci), &dummy_clause());
                                    call_value(each_job(scrut_ix.clone(), {
                                        let lx = lx.clone();
                                        let c = c.clone();
                                        let ptys = ptys.clone();
                                        let label = label.clone();
                                        let ci = ci.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx = lx.clone();
                                            let c = c.clone();
                                            let ptys = ptys.clone();
                                            let label = label.clone();
                                            let ci = ci.clone();
                                            entered(once_job(move || {
                                                let i = p0;
                                                prism_rtl::Turn::More(Rc::new(RustPat { lx: lx.clone(), p_: or(&index(&c.params, &i), &dummy_pat()), ty: or(&index(&ptys, &i), &crate::check::types::Ty::TyErr), mode: Holding::ByRef, fresh: Text::from(format!("{}{}_{}", &label, &ci, &i)) }))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                                    }), move |each_129881: Array<PatOut>| {
                                        let pos = each_129881;
                                        let pa = 'm130007: {
                                            if let m130007_0 = &pos && (m130007_0.len() == 1) && let Some(o) = index(m130007_0, &Nat::from(0u32)) {
                                                break 'm130007 o.pa.clone();
                                            }
                                            crate::lower::model::Pa::PaTuple(each(&pos, &(|o: &PatOut| o.pa.clone())))
                                        };
                                        let conds = fold(&pos, &Array::new(), &(|acc: &Array<crate::lower::model::Cc>, o: &PatOut| append(acc, &o.conds)));
                                        let binds = fold(&pos, &Array::new(), &(|acc: &Array<(Text, Bn)>, o: &PatOut| append(acc, &o.binds)));
                                        call_value((&body_fn)((lx.clone(), bind_all(&env1, &binds), c.body.clone())), move |body_130287: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: pa.clone(), conds: conds.clone(), body: body_130287 }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                    }), move |each_129776: Array<crate::lower::model::XArm>| {
                        let arms = each_129776;
                        prism_rtl::Turn::Finished(own(&arms_value(&scrut, &arms, &Text::from(format!("'{}", &label)), &t)))
                    })
                }
            }
        })
    }
}

/// `Start ClausesBody, x`: what the function value is when passed to `@Run`.
pub fn start_clauses_body(lx: Lx, env: Env, clauses: Array<crate::syntax::FnClause>, names: Array<(Text, bool)>, ptys: Array<crate::check::types::Ty>, body_fn: Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, label: Text, t: crate::lower::model::OutTy) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ClausesBody { lx, env, clauses, names, ptys, body_fn, label, t })
}

/// ```prism
/// let dummyClause
/// ```
pub fn dummy_clause() -> crate::syntax::FnClause {
    crate::syntax::FnClause { name: crate::syntax::DefName::DefOp(Text::lit(""), crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) }), params: Array::new(), body: crate::syntax::FnBody::BodyExpr(crate::syntax::Expr { kind: Rc::new(crate::syntax::ExprKind::EError), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::syntax::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn fn_body_value(lx: &Lx, env: &Env, fn_body2: &crate::syntax::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::FnBody::BodyExpr(x) => own(&value_of(lx, env, x)),
        crate::syntax::FnBody::BodyBlock(b) => own(&block_value(lx, env, b)),
    }
}

/// The step machine of `FnBodyValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnBodyValue: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct FnBodyValue {
    pub lx: Lx,
    pub env: Env,
    pub fn_body2: crate::syntax::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for FnBodyValue {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::FnBody::BodyExpr(x) => {
                let env = env.clone();
                let lx = lx.clone();
                let x = x.clone();
                call_then(start_value_of(lx.clone(), env.clone(), x.clone()), move |value_of_130646: Vl| prism_rtl::Turn::Finished(own(&value_of_130646)))
            },
            crate::syntax::FnBody::BodyBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_block_value(lx.clone(), env.clone(), b.clone()), move |block_value_130711: Vl| prism_rtl::Turn::Finished(own(&block_value_130711)))
            },
        }
    }
}

/// `Start FnBodyValue, x`: what the function value is when passed to `@Run`.
pub fn start_fn_body_value(lx: Lx, env: Env, fn_body2: crate::syntax::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(FnBodyValue { lx, env, fn_body2 })
}

/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub fn fn_def_of(lx: &Lx, qk: &Text, clauses: &Array<crate::syntax::FnClause>, sc: &crate::check::types::Scheme) -> crate::lower::model::FnDef {
    let (ptys0, res) = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
        other => (Array::new(), other.clone()),
    };
    let ptys = if has_blueprint(&res) {
        each(&ptys0, &(|p_: &crate::check::types::Ty| event_param(p_)))
    } else {
        ptys0.clone()
    };
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names = param_names(lx, clauses, &pts);
    let body = clauses_body(lx, &empty_env(), clauses, &names, &ptys, &(Rc::new(|(a0, a1, a2): (Lx, Env, crate::syntax::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("c"), &out_ty_of(lx, &peel(&res)));
    let params = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
    let ret = out_ty_of(lx, &peel(&res));
    let used = fold(&push(&pts, &ret), &Array::new(), &(|acc: &Array<Text>, t: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(t))));
    let generics = filter(&scheme_generics(lx, sc), &(|(g, _): &(Text, Array<Text>)| crate::check::types::has_text(&used, g)));
    crate::lower::model::FnDef { name: or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk))), generics: generics.clone(), params: params.clone(), ret: ret.clone(), body: body.clone(), doc: signature_text(lx, qk), public: true }
}

/// The step machine of `FnDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FnDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> FnDef
/// ```
pub struct FnDefOf {
    pub lx: Lx,
    pub qk: Text,
    pub clauses: Array<crate::syntax::FnClause>,
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for FnDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let (ptys0, res) = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        };
        let ptys = if has_blueprint(&res) {
            each(&ptys0, &(|p_: &crate::check::types::Ty| event_param(p_)))
        } else {
            ptys0.clone()
        };
        let clauses = clauses.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        let sc = sc.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_131268: Array<crate::lower::model::OutTy>| {
            let pts = each_131268;
            let names = param_names(&lx, &clauses, &pts);
            call_then(start_out_ty_of(lx.clone(), peel(&res)), move |out_ty_of_131431: crate::lower::model::OutTy| call_then(start_clauses_body(lx.clone(), empty_env(), clauses.clone(), names.clone(), ptys.clone(), Rc::new(|(a0, a1, a2): (Lx, Env, crate::syntax::FnBody)| entered(start_fn_body_value(a0, a1, a2))) as Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("c"), out_ty_of_131431), move |clauses_body_131364: crate::lower::model::Ex| {
                let body = clauses_body_131364;
                let params = each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), crate::lower::model::OutTy::OutRef(Rc::new(or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit))))));
                call_then(start_out_ty_of(lx.clone(), peel(&res)), move |out_ty_of_131599: crate::lower::model::OutTy| {
                    let ret = out_ty_of_131599;
                    let used = fold(&push(&pts, &ret), &Array::new(), &(|acc: &Array<Text>, t: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(t))));
                    let generics = filter(&scheme_generics(&lx, &sc), &(|(g, _): &(Text, Array<Text>)| crate::check::types::has_text(&used, g)));
                    prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx.rs_names, &qk), &snake(&crate::check::types::bare_name(&qk))), generics: generics.clone(), params: params.clone(), ret: ret.clone(), body: body.clone(), doc: signature_text(&lx, &qk), public: true })
                })
            }))
        })
    }
}

/// `Start FnDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_fn_def_of(lx: Lx, qk: Text, clauses: Array<crate::syntax::FnClause>, sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(FnDefOf { lx, qk, clauses, sc })
}

/// ```prism
/// TyParamsIn: fn OutTy -> [Text]
/// ```
pub fn ty_params_in(t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutGen(n) => Array::from(vec![n.clone()]),
        crate::lower::model::OutTy::OutNamed(_, ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutFn(ts, r) => fold(ts, &ty_params_in(&**r), &(|acc: &Array<Text>, x: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &ty_params_in(x)))),
        crate::lower::model::OutTy::OutJobFn(a, r) => crate::check::types::union_texts(&ty_params_in(&**a), &ty_params_in(&**r)),
        crate::lower::model::OutTy::OutMap(k, v_) => crate::check::types::union_texts(&ty_params_in(&**k), &ty_params_in(&**v_)),
        crate::lower::model::OutTy::OutOpt(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRes(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutArray(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutJob(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutEvent(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutDyn(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRc(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutRef(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutHold(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutCell(x) => ty_params_in(&**x),
        crate::lower::model::OutTy::OutLive(x) => ty_params_in(&**x),
        _ => Array::new(),
    }
}

/// ```prism
/// SignatureText: fn Lx, Text -> Text
/// ```
pub fn signature_text(lx: &Lx, qk: &Text) -> Text {
    match get(&lx.g.vals, qk) {
        Some(v_) => match index(&lx.g.srcs, &v_.file) {
            Some(src) => crate::syntax::lexer::trim(&crate::check::errors::span_text(&src, &v_.span)),
            None => crate::check::types::bare_name(qk),
        },
        None => crate::check::types::bare_name(qk),
    }
}

/// ```prism
/// DefinitionText: fn Lx, Text -> Text
/// ```
pub fn definition_text(lx: &Lx, qk: &Text) -> Text {
    let spans = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Nat, crate::syntax::Range)>, d: &crate::check::env::Def| if &d.qk == qk { push(acc, &(d.file.clone(), d.span.clone())) } else { acc.clone() }));
    let sig = match get(&lx.g.vals, qk) {
        Some(v_) => if &v_.span.start < &or(&index(&each(&spans, &(|(_, r): &(Nat, crate::syntax::Range)| r.start.clone())), &Nat::from(0u32)), &Nat::from(0u32)) {
            Array::from(vec![(v_.file.clone(), v_.span.clone())])
        } else {
            Array::new()
        },
        None => Array::new(),
    };
    crate::syntax::lexer::join(&each(&append(&sig, &spans), &(|(f, r): &(Nat, crate::syntax::Range)| src_text(lx, f, r))), &Text::lit("\n"))
}

/// ```prism
/// SrcText: fn Lx, Nat, Range -> Text
/// ```
pub fn src_text(lx: &Lx, f: &Nat, r: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, f) {
        Some(src) => drop_trailing_comments(&crate::check::errors::span_text(&src, r)),
        None => Text::lit(""),
    }
}

/// ```prism
/// DropTrailingComments: fn Text -> Text
/// ```
pub fn drop_trailing_comments(t: &Text) -> Text {
    let lines = split(t, &Text::lit("\n"));
    let keep = fold(&crate::check::errors::range0(&len(&lines)), &Nat::from(0u32), &(|k: &Nat, i: &Nat| if is_code_line(&or(&index(&lines, i), &Text::lit(""))) {
        i + &Nat::from(1u32)
    } else {
        k.clone()
    }));
    crate::syntax::lexer::trim_end(&crate::syntax::lexer::join(&take(&lines, &keep), &Text::lit("\n")))
}

/// ```prism
/// IsCodeLine: fn Text -> Bool
/// ```
pub fn is_code_line(l: &Text) -> bool {
    let s = crate::syntax::lexer::trim(l);
    (&s != &Text::lit("")) && !crate::syntax::lexer::has_prefix(&s, &Text::lit("#"))
}

/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub fn let_getter(lx: &Lx, qk: &Text, l: &crate::syntax::LetDecl) -> crate::lower::model::FnDef {
    let t = out_ty_of(lx, &peel(&type_at(lx, &l.value.span)));
    let v_ = value_of(lx, &empty_env(), &l.value);
    crate::lower::model::FnDef { name: or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk))), generics: Array::new(), params: Array::new(), ret: t.clone(), body: own(&v_), doc: Text::from(format!("let {}", &crate::check::types::bare_name(qk))), public: true }
}

/// The step machine of `LetGetter`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LetGetter: unbounded fn Lx, Text, LetDecl -> FnDef
/// ```
pub struct LetGetter {
    pub lx: Lx,
    pub qk: Text,
    pub l: crate::syntax::LetDecl,
}

impl prism_rtl::Job<crate::lower::model::FnDef> for LetGetter {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::FnDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let l = &self.l;
        let l = l.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &l.value.span))), move |out_ty_of_134448: crate::lower::model::OutTy| {
            let t = out_ty_of_134448;
            call_then(start_value_of(lx.clone(), empty_env(), l.value.clone()), move |value_of_134505: Vl| {
                let v_ = value_of_134505;
                prism_rtl::Turn::Finished(crate::lower::model::FnDef { name: or(&get(&lx.rs_names, &qk), &snake(&crate::check::types::bare_name(&qk))), generics: Array::new(), params: Array::new(), ret: t.clone(), body: own(&v_), doc: Text::from(format!("let {}", &crate::check::types::bare_name(&qk))), public: true })
            })
        })
    }
}

/// `Start LetGetter, x`: what the function value is when passed to `@Run`.
pub fn start_let_getter(lx: Lx, qk: Text, l: crate::syntax::LetDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>> {
    Rc::new(LetGetter { lx, qk, l })
}

/// ```prism
/// HasOwnShow: fn Lx, Text -> Bool
/// ```
pub fn has_own_show(lx: &Lx, tn: &Text) -> bool {
    fold(&or(&get(&lx.g.impls, &Text::lit("Prelude.Show")), &Array::new()), &false, &(|f: &bool, im: &crate::check::env::ImplInfo| *f || (!im.derived && (&head_name(&im.head) == tn))))
}

/// ```prism
/// HeadName: fn Ty -> Text
/// ```
pub fn head_name(ty0: &crate::check::types::Ty) -> Text {
    match ty0 {
        crate::check::types::Ty::TyCon(n, _) => n.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub fn self_in(t: &crate::check::types::Ty, param: &Text) -> crate::check::types::Ty {
    instantiated(t, &Array::from(vec![param.clone()]), &Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]))
}

/// The step machine of `SelfIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SelfIn: unbounded fn Ty, Text -> Ty
/// ```
pub struct SelfIn {
    pub t: crate::check::types::Ty,
    pub param: Text,
}

impl prism_rtl::Job<crate::check::types::Ty> for SelfIn {
    fn cycle(&self) -> prism_rtl::Turn<crate::check::types::Ty> {
        let t = &self.t;
        let param = &self.param;
        prism_rtl::Turn::More(Rc::new(Instantiated { t: t.clone(), params: Array::from(vec![param.clone()]), args: Array::from(vec![crate::check::types::Ty::TyCon(Text::lit("\0Self"), Array::new())]) }))
    }
}

/// `Start SelfIn, x`: what the function value is when passed to `@Run`.
pub fn start_self_in(t: crate::check::types::Ty, param: Text) -> Rc<dyn prism_rtl::Job<crate::check::types::Ty>> {
    Rc::new(SelfIn { t, param })
}

/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub fn trait_def_of(lx0: &Lx, tr: &crate::check::env::TraitInfo) -> crate::lower::model::TraitDef {
    let lx = in_module(lx0, &tr.file, &tr.home);
    let methods = run_to_end(each_job(tr.methods.clone(), {
        let lx = lx.clone();
        let tr = tr.clone();
        Rc::new(move |p0: Text| {
            let lx = lx.clone();
            let tr = tr.clone();
            entered(once_job(move || {
                let mq = p0;
                {
                    let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
                    let sc = {
                        let mut this: crate::check::types::Scheme = v_.scheme.clone();
                        this.ty = self_in(&this.ty, &tr.param);
                        this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                        this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                        this
                    };
                    let default_qk = fold(&tr.defaults, &Text::lit(""), &(|f: &Text, dq: &Text| if &crate::check::types::bare_name(dq) == &crate::check::types::bare_name(&mq) {
                        dq.clone()
                    } else {
                        f.clone()
                    }));
                    let clauses = if &default_qk == &Text::lit("") {
                        Array::new()
                    } else {
                        default_clauses(&lx.g, &default_qk)
                    };
                    call_then(start_fn_def_of(lx.clone(), mq.clone(), if &len(&clauses) == &Nat::from(0u32) {
                        Array::from(vec![dummy_clause()])
                    } else {
                        clauses.clone()
                    }, sc.clone()), move |fn_def_of_136042: crate::lower::model::FnDef| {
                        let fd = fn_def_of_136042;
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::FnDef = fd.clone();
                            this.public = &len(&clauses) > &Nat::from(0u32);
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    crate::lower::model::TraitDef { name: camel(&crate::check::types::bare_name(&tr.name)), methods: methods.clone(), defaults: tr.defaults.clone(), doc: type_doc(&lx, &crate::check::env::TyInfo { name: tr.name.clone(), home: tr.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr.file.clone(), span: tr.span.clone() }) }
}

/// The step machine of `TraitDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitDefOf: unbounded fn Lx, TraitInfo -> TraitDef
/// ```
pub struct TraitDefOf {
    pub lx0: Lx,
    pub tr: crate::check::env::TraitInfo,
}

impl prism_rtl::Job<crate::lower::model::TraitDef> for TraitDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TraitDef> {
        let lx0 = &self.lx0;
        let tr = &self.tr;
        let lx = in_module(lx0, &tr.file, &tr.home);
        let tr = tr.clone();
        call_value(each_job(tr.methods.clone(), {
            let lx = lx.clone();
            let tr = tr.clone();
            Rc::new(move |p0: Text| {
                let lx = lx.clone();
                let tr = tr.clone();
                entered(once_job(move || {
                    let mq = p0;
                    {
                        let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
                        let sc = {
                            let mut this: crate::check::types::Scheme = v_.scheme.clone();
                            this.ty = self_in(&this.ty, &tr.param);
                            this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                            this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                            this
                        };
                        let default_qk = fold(&tr.defaults, &Text::lit(""), &(|f: &Text, dq: &Text| if &crate::check::types::bare_name(dq) == &crate::check::types::bare_name(&mq) {
                            dq.clone()
                        } else {
                            f.clone()
                        }));
                        let clauses = if &default_qk == &Text::lit("") {
                            Array::new()
                        } else {
                            default_clauses(&lx.g, &default_qk)
                        };
                        call_then(start_fn_def_of(lx.clone(), mq.clone(), if &len(&clauses) == &Nat::from(0u32) {
                            Array::from(vec![dummy_clause()])
                        } else {
                            clauses.clone()
                        }, sc.clone()), move |fn_def_of_136042: crate::lower::model::FnDef| {
                            let fd = fn_def_of_136042;
                            prism_rtl::Turn::Finished({
                                let mut this: crate::lower::model::FnDef = fd.clone();
                                this.public = &len(&clauses) > &Nat::from(0u32);
                                this
                            })
                        })
                    }
                }))
            }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
        }), move |each_135550: Array<crate::lower::model::FnDef>| {
            let methods = each_135550;
            prism_rtl::Turn::Finished(crate::lower::model::TraitDef { name: camel(&crate::check::types::bare_name(&tr.name)), methods: methods.clone(), defaults: tr.defaults.clone(), doc: type_doc(&lx, &crate::check::env::TyInfo { name: tr.name.clone(), home: tr.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tr.file.clone(), span: tr.span.clone() }) })
        })
    }
}

/// `Start TraitDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_trait_def_of(lx0: Lx, tr: crate::check::env::TraitInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TraitDef>> {
    Rc::new(TraitDefOf { lx0, tr })
}

/// ```prism
/// DefaultClauses: fn G, Text -> [FnClause]
/// ```
pub fn default_clauses(g: &crate::check::env::G, qk: &Text) -> Array<crate::syntax::FnClause> {
    fold(&g.defs, &Array::new(), &(|acc: &Array<crate::syntax::FnClause>, d: &crate::check::env::Def| if &d.qk == qk { default_of(d, acc) } else { acc.clone() }))
}

/// ```prism
/// DefaultOf: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn default_of(d: &crate::check::env::Def, other: &Array<crate::syntax::FnClause>) -> Array<crate::syntax::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbDefault(cs, _) => cs.clone(),
        _ => other.clone(),
    }
}

/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub fn impl_def_of(lx: &Lx, im: &crate::check::env::ImplInfo) -> crate::lower::model::ImplDef {
    let tr = or(&get(&lx.g.traits, &im.cls), &dummy_trait_info());
    let head = out_ty_of(lx, &im.head);
    let defs = filter(&lx.g.defs, &(|d: &crate::check::env::Def| is_method_of(d, im)));
    let methods = run_to_end(each_job(defs.clone(), {
        let tr = tr.clone();
        let lx = lx.clone();
        let im = im.clone();
        Rc::new(move |p0: crate::check::env::Def| {
            let tr = tr.clone();
            let lx = lx.clone();
            let im = im.clone();
            entered(once_job(move || {
                let d = p0;
                {
                    let mq = fold(&tr.methods, &Text::lit(""), &(|found: &Text, q: &Text| if &crate::check::types::bare_name(q) == &d.name { q.clone() } else { found.clone() }));
                    let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
                    let sc = {
                        let mut this: crate::check::types::Scheme = v_.scheme.clone();
                        this.ty = instantiated(&this.ty, &Array::from(vec![tr.param.clone()]), &Array::from(vec![im.head.clone()]));
                        this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                        this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                        this
                    };
                    call_then(start_fn_def_of(lx.clone(), mq.clone(), method_clauses(&d), sc.clone()), move |fn_def_of_137375: crate::lower::model::FnDef| {
                        let fd = fn_def_of_137375;
                        if crate::syntax::lexer::has_prefix(&im.cls, &Text::lit("Prelude.")) {
                            prism_rtl::Turn::Finished(renamed(&fd, &Text::from(format!("{}_{}", &snake(&d.name), &snake(&crate::check::types::bare_name(&head_name(&im.head)))))))
                        } else {
                            prism_rtl::Turn::Finished(fd.clone())
                        }
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
    }));
    let generics = each(&im.qs, &(|q: &Text| (camel(q), Array::from(vec![Text::lit("Clone")]))));
    crate::lower::model::ImplDef { cls: im.cls.clone(), tr: path_in(lx, &tr.home, &camel(&crate::check::types::bare_name(&im.cls))), head: head.clone(), generics: generics.clone(), methods: methods.clone(), doc: Text::lit("") }
}

/// The step machine of `ImplDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ImplDefOf: unbounded fn Lx, ImplInfo -> ImplDef
/// ```
pub struct ImplDefOf {
    pub lx: Lx,
    pub im: crate::check::env::ImplInfo,
}

impl prism_rtl::Job<crate::lower::model::ImplDef> for ImplDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ImplDef> {
        let lx = &self.lx;
        let im = &self.im;
        let tr = or(&get(&lx.g.traits, &im.cls), &dummy_trait_info());
        let im = im.clone();
        let lx = lx.clone();
        call_then(start_out_ty_of(lx.clone(), im.head.clone()), move |out_ty_of_136868: crate::lower::model::OutTy| {
            let head = out_ty_of_136868;
            let defs = filter(&lx.g.defs, &(|d: &crate::check::env::Def| is_method_of(d, &im)));
            call_value(each_job(defs.clone(), {
                let tr = tr.clone();
                let lx = lx.clone();
                let im = im.clone();
                Rc::new(move |p0: crate::check::env::Def| {
                    let tr = tr.clone();
                    let lx = lx.clone();
                    let im = im.clone();
                    entered(once_job(move || {
                        let d = p0;
                        {
                            let mq = fold(&tr.methods, &Text::lit(""), &(|found: &Text, q: &Text| if &crate::check::types::bare_name(q) == &d.name { q.clone() } else { found.clone() }));
                            let v_ = or(&get(&lx.g.vals, &mq), &crate::check::env::builtin(&mq, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
                            let sc = {
                                let mut this: crate::check::types::Scheme = v_.scheme.clone();
                                this.ty = instantiated(&this.ty, &Array::from(vec![tr.param.clone()]), &Array::from(vec![im.head.clone()]));
                                this.qs = filter(&this.qs, &(|q: &Text| q != &tr.param));
                                this.bounds = filter(&this.bounds, &(|(q, _): &(Text, Text)| q != &tr.param));
                                this
                            };
                            call_then(start_fn_def_of(lx.clone(), mq.clone(), method_clauses(&d), sc.clone()), move |fn_def_of_137375: crate::lower::model::FnDef| {
                                let fd = fn_def_of_137375;
                                if crate::syntax::lexer::has_prefix(&im.cls, &Text::lit("Prelude.")) {
                                    prism_rtl::Turn::Finished(renamed(&fd, &Text::from(format!("{}_{}", &snake(&d.name), &snake(&crate::check::types::bare_name(&head_name(&im.head)))))))
                                } else {
                                    prism_rtl::Turn::Finished(fd.clone())
                                }
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::check::env::Def) -> Rc<dyn prism_rtl::Job<crate::lower::model::FnDef>>>
            }), move |each_136961: Array<crate::lower::model::FnDef>| {
                let methods = each_136961;
                let generics = each(&im.qs, &(|q: &Text| (camel(q), Array::from(vec![Text::lit("Clone")]))));
                prism_rtl::Turn::Finished(crate::lower::model::ImplDef { cls: im.cls.clone(), tr: path_in(&lx, &tr.home, &camel(&crate::check::types::bare_name(&im.cls))), head: head.clone(), generics: generics.clone(), methods: methods.clone(), doc: Text::lit("") })
            })
        })
    }
}

/// `Start ImplDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_impl_def_of(lx: Lx, im: crate::check::env::ImplInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::ImplDef>> {
    Rc::new(ImplDefOf { lx, im })
}

/// ```prism
/// Renamed: fn FnDef, Text -> FnDef
/// ```
pub fn renamed(fd: &crate::lower::model::FnDef, n: &Text) -> crate::lower::model::FnDef {
    let mut this: crate::lower::model::FnDef = fd.clone();
    this.name = n.clone();
    this
}

/// ```prism
/// IsMethodOf: fn Def, ImplInfo -> Bool
/// ```
pub fn is_method_of(d: &crate::check::env::Def, im: &crate::check::env::ImplInfo) -> bool {
    match &d.body {
        crate::check::env::DefBody::DbMethod(_, cls, other) => ((cls == &im.cls) && (&other.span == &im.span)) && (&other.file == &im.file),
        _ => false,
    }
}

/// ```prism
/// MethodClauses: fn Def -> [FnClause]
/// ```
pub fn method_clauses(d: &crate::check::env::Def) -> Array<crate::syntax::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbMethod(cs, _, _) => cs.clone(),
        _ => Array::new(),
    }
}

/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub fn if_gen_line(wx: &crate::lower::node_::Wx, menv: &Env, c: &crate::syntax::Expr, then_b: &crate::syntax::Block, else_b: &crate::syntax::Block, e: &crate::syntax::Expr) -> (crate::lower::node_::Wx, crate::lower::node_::Wres) {
    let lx = wx.lx.clone();
    let pos = wx.pos.clone();
    let wx1 = {
        let mut this: crate::lower::node_::Wx = wx.clone();
        this.pos = crate::lower::model::next_pos(&this.pos);
        this
    };
    let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("arm"));
    let base_ = Text::from(format!("{}{}{}", &wx.node_, &camel(&name), &crate::lower::node_::row_suffix(wx)));
    let yes = crate::lower::node_::gen_row_of(&wx2, menv, then_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_)), &name);
    let no = crate::lower::node_::gen_row_of(&yes.parent, menv, else_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_)), &name);
    let cond = as_bool(&value_of(&lx, menv, c));
    let tail_ = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::hosted_passed(wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
    let mk_fn = {
        let tail_ = tail_.clone();
        Rc::new(move |n: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
    };
    let select = crate::lower::model::Ex::XIf(Rc::new(cond.clone()), Rc::new((&mk_fn)(&yes.node_)), Rc::new((&mk_fn)(&no.node_)));
    let wx3 = {
        let mut this: crate::lower::node_::Wx = no.parent.clone();
        this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::place_at(wx, &Text::lit("self"), &pos), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select.clone(), transparent: false, width: Nat::from(0u32) });
        this.gen_holds = push(&this.gen_holds, &(name.clone(), Array::new()));
        this.rows = append(&append(&append(&push(&this.rows, &yes.node_), &yes.node_.children), &Array::from(vec![no.node_.clone()])), &no.node_.children);
        this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm's result, which a building `if` of widgets drops.") });
        this
    };
    (wx3.clone(), crate::lower::node_::Wres::WrUnit)
}

/// The step machine of `IfGenLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfGenLine: unbounded fn Wx, Env, Expr, Block, Block, Expr -> ((Wx, Wres))
/// ```
pub struct IfGenLine {
    pub wx: crate::lower::node_::Wx,
    pub menv: Env,
    pub c: crate::syntax::Expr,
    pub then_b: crate::syntax::Block,
    pub else_b: crate::syntax::Block,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)> for IfGenLine {
    fn cycle(&self) -> prism_rtl::Turn<(crate::lower::node_::Wx, crate::lower::node_::Wres)> {
        let wx = &self.wx;
        let menv = &self.menv;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b = &self.else_b;
        let e = &self.e;
        let lx = wx.lx.clone();
        let pos = wx.pos.clone();
        let wx1 = {
            let mut this: crate::lower::node_::Wx = wx.clone();
            this.pos = crate::lower::model::next_pos(&this.pos);
            this
        };
        let (name, wx2) = crate::lower::node_::fresh_name(&wx1, &Text::lit("arm"));
        let base_ = Text::from(format!("{}{}{}", &wx.node_, &camel(&name), &crate::lower::node_::row_suffix(wx)));
        let yes = crate::lower::node_::gen_row_of(&wx2, menv, then_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Then", &base_)), &name);
        let no = crate::lower::node_::gen_row_of(&yes.parent, menv, else_b, &crate::lower::model::OutTy::OutUnit, &Text::from(format!("{}Else", &base_)), &name);
        let c = c.clone();
        let menv = menv.clone();
        let wx = wx.clone();
        call_then(start_value_of(lx.clone(), menv.clone(), c.clone()), move |value_of_138841: Vl| {
            let cond = as_bool(&value_of_138841);
            let tail_ = append(&append(&Array::from(vec![crate::lower::model::Ex::XWeak(Rc::new(crate::lower::model::Ex::XSelf))]), &crate::lower::node_::hosted_passed(&wx)), &Array::from(vec![crate::lower::model::Ex::XCx]));
            let mk_fn = {
                let tail_ = tail_.clone();
                Rc::new(move |n: &crate::lower::model::NodeDef| crate::lower::model::Ex::XCast(Rc::new(try_of(&crate::lower::model::Ex::XCall(Text::from(format!("{}::build", &n.name)), append(&Array::from(vec![crate::lower::model::Ex::XVar(Text::lit("path")), crate::lower::model::Ex::XVar(Text::lit("value"))]), &tail_)))), crate::lower::model::OutTy::OutObj(Rc::new(crate::lower::model::OutTy::OutNamed(Text::lit("Row"), Array::new())))))
            };
            let select = crate::lower::model::Ex::XIf(Rc::new(cond.clone()), Rc::new((&mk_fn)(&yes.node_)), Rc::new((&mk_fn)(&no.node_)));
            let wx3 = {
                let mut this: crate::lower::node_::Wx = no.parent.clone();
                this.gens = push(&this.gens, &crate::lower::model::GenDef { name: name.clone(), pos: pos.clone(), at: crate::lower::node_::place_at(&wx, &Text::lit("self"), &pos), source: crate::lower::model::Ex::XUnit, value_ty: crate::lower::model::OutTy::OutUnit, select: select.clone(), transparent: false, width: Nat::from(0u32) });
                this.gen_holds = push(&this.gen_holds, &(name.clone(), Array::new()));
                this.rows = append(&append(&append(&push(&this.rows, &yes.node_), &yes.node_.children), &Array::from(vec![no.node_.clone()])), &no.node_.children);
                this.getters = push(&this.getters, &crate::lower::model::MethDef { name: Text::from(format!("{}_up", &name)), recv: crate::lower::model::Recv::RecvRc, params: Array::from(vec![(Text::lit("v"), crate::lower::model::OutTy::OutUnit)]), cx_: crate::lower::model::CxArg::CxMut, ret: crate::lower::model::OutTy::OutUnit, body: Array::new(), tail: crate::lower::model::Ex::XUnit, doc: Text::lit("An arm's result, which a building `if` of widgets drops.") });
                this
            };
            prism_rtl::Turn::Finished((wx3.clone(), crate::lower::node_::Wres::WrUnit))
        })
    }
}

/// `Start IfGenLine, x`: what the function value is when passed to `@Run`.
pub fn start_if_gen_line(wx: crate::lower::node_::Wx, menv: Env, c: crate::syntax::Expr, then_b: crate::syntax::Block, else_b: crate::syntax::Block, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<(crate::lower::node_::Wx, crate::lower::node_::Wres)>> {
    Rc::new(IfGenLine { wx, menv, c, then_b, else_b, e })
}

/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    match frame_call(lx, env, e, &true) {
        Some(c) => frame(lx, env, &c, &rest_text(lx, &e.span, &c.span, &e.span), &{
            let lx = lx.clone();
            let e = e.clone();
            Rc::new(move |p0: Env| {
                let lx = lx.clone();
                let e = e.clone();
                entered(once_job(move || {
                    let env2 = p0;
                    prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env2.clone(), e: e.clone() }))
                }))
            }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }),
        None => tail_here(lx, env, e),
    }
}

/// The step machine of `Tail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tail: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct Tail {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Tail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let lx = lx.clone();
        call_then(start_frame_call(lx.clone(), env.clone(), e.clone(), true), move |frame_call_140748: Option<crate::syntax::Expr>| match frame_call_140748 {
            Some(c) => prism_rtl::Turn::More(Rc::new(Frame { lx: lx.clone(), env: env.clone(), call: c.clone(), rest_text_: rest_text(&lx, &e.span, &c.span, &e.span), cont_fn: {
                let lx = lx.clone();
                let e = e.clone();
                Rc::new(move |p0: Env| {
                    let lx = lx.clone();
                    let e = e.clone();
                    entered(once_job(move || {
                        let env2 = p0;
                        prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env2.clone(), e: e.clone() }))
                    }))
                }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            } })),
            None => prism_rtl::Turn::More(Rc::new(TailHere { lx: lx.clone(), env: env.clone(), e: e.clone() })),
        })
    }
}

/// `Start Tail, x`: what the function value is when passed to `@Run`.
pub fn start_tail(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Tail { lx, env, e })
}

/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub fn tail_here(lx: &Lx, env: &Env, e: &crate::syntax::Expr) -> crate::lower::model::Ex {
    'm140966: {
        let scrutinee = &*e.kind;
        if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
            break 'm140966 tail(lx, env, &**x);
        }
        if let crate::syntax::ExprKind::EUpdate(target, b) = scrutinee {
            break 'm140966 if has_top_while(lx, b) {
                upd_tail(lx, env, &**target, b, &e.span, &(Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| once_job(move || {
                    let en = p0;
                    let v_ = p1;
                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_.clone()])))
                })) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>))
            } else {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of(lx, env, e))]))
            };
        }
        if let crate::syntax::ExprKind::EMatch(s, arms) = scrutinee {
            break 'm140966 tail_match(lx, env, &**s, arms, &e.span);
        }
        if let crate::syntax::ExprKind::EIf(m140966_3_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m140966_3_0 {
            break 'm140966 crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(lx, env, &**c))), Rc::new(tail_block(lx, env, then_b)), Rc::new(tail_block(lx, env, else_b)));
        }
        if let crate::syntax::ExprKind::ECall(callee, args, _, _) = scrutinee {
            break 'm140966 match tail_callee(lx, env, &**callee) {
                Some(qk) => {
                    let job = or(&get(&lx.rs_names, &qk), &snake(&crate::check::types::bare_name(&qk)));
                    let job_name = path_in(lx, &owner_of(&qk), &camel(&crate::check::types::bare_name(&qk)));
                    let (ptys, _) = scheme_parts(lx, &qk);
                    let fields = job_field_names(lx, &qk);
                    let vals = named_args_owned(lx, env, &qk, args);
                    if enters_at_once(lx, &qk, args) {
                        crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(path_in(lx, &owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())), Text::lit("cycle"), Array::new())
                    } else {
                        if is_color_poly(lx, &qk) {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(path_in(lx, &owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())]))
                        } else {
                            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name.clone(), each(&crate::check::errors::range0(&len(&vals)), &(|i: &Nat| (or(&index(&fields, i), &Text::lit("arg")), or(&index(&vals, i), &crate::lower::model::Ex::XUnit)))))]))]))
                        }
                    }
                },
                None => match local_job_fn(lx, env, &**callee) {
                    Some(f) => crate::lower::model::Ex::XMethod(Rc::new(start_call(&f, &start_args(lx, env, &f, args))), Text::lit("cycle"), Array::new()),
                    None => match prelude_job_call(lx, env, e) {
                        Some(job) => crate::lower::model::Ex::XMethod(Rc::new(job.clone()), Text::lit("cycle"), Array::new()),
                        None => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of(lx, env, e))])),
                    },
                },
            };
        }
        crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of(lx, env, e))]))
    }
}

/// The step machine of `TailHere`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailHere: unbounded fn Lx, Env, Expr -> Ex
/// ```
pub struct TailHere {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailHere {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        'm140966: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm140966 prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: (**x).clone() }));
            }
            if let crate::syntax::ExprKind::EUpdate(target, b) = scrutinee {
                break 'm140966 if has_top_while(lx, b) {
                    prism_rtl::Turn::More(Rc::new(UpdTail { lx: lx.clone(), env: env.clone(), target: (**target).clone(), b: b.clone(), to: e.span.clone(), cont_fn: Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| once_job(move || {
                        let en = p0;
                        let v_ = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![v_.clone()])))
                    })) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>> }))
                } else {
                    {
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_141205: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of_141205)]))))
                    }
                };
            }
            if let crate::syntax::ExprKind::EMatch(s, arms) = scrutinee {
                break 'm140966 prism_rtl::Turn::More(Rc::new(TailMatch { lx: lx.clone(), env: env.clone(), s: (**s).clone(), arms: arms.clone(), span: e.span.clone() }));
            }
            if let crate::syntax::ExprKind::EIf(m140966_3_0, then_b, Some(else_b)) = scrutinee && let crate::syntax::Cond::CondExpr(c) = &**m140966_3_0 {
                break 'm140966 {
                    let c = (**c).clone();
                    let else_b = else_b.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let then_b = then_b.clone();
                    call_then(start_value_of(lx.clone(), env.clone(), c.clone()), move |value_of_141335: Vl| call_then(start_tail_block(lx.clone(), env.clone(), then_b.clone()), move |tail_block_141358: crate::lower::model::Ex| call_then(start_tail_block(lx.clone(), env.clone(), else_b.clone()), move |tail_block_141386: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of_141335)), Rc::new(tail_block_141358), Rc::new(tail_block_141386))))))
                };
            }
            if let crate::syntax::ExprKind::ECall(callee, args, _, _) = scrutinee {
                break 'm140966 match tail_callee(lx, env, &**callee) {
                    Some(qk) => {
                        let job = or(&get(&lx.rs_names, &qk), &snake(&crate::check::types::bare_name(&qk)));
                        let job_name = path_in(lx, &owner_of(&qk), &camel(&crate::check::types::bare_name(&qk)));
                        let (ptys, _) = scheme_parts(lx, &qk);
                        let args = args.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_job_field_names(lx.clone(), qk.clone()), move |job_field_names_141716: Array<Text>| {
                            let fields = job_field_names_141716;
                            call_then(start_named_args_owned(lx.clone(), env.clone(), qk.clone(), args.clone()), move |named_args_owned_141760: Array<crate::lower::model::Ex>| {
                                let vals = named_args_owned_141760;
                                if enters_at_once(&lx, &qk, &args) {
                                    prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(crate::lower::model::Ex::XCall(path_in(&lx, &owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())), Text::lit("cycle"), Array::new()))
                                } else {
                                    if is_color_poly(&lx, &qk) {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(path_in(&lx, &owner_of(&qk), &Text::from(format!("start_{}", &job))), vals.clone())])))
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::More"), Array::from(vec![crate::lower::model::Ex::XCall(Text::lit("Rc::new"), Array::from(vec![crate::lower::model::Ex::XRecord(job_name.clone(), each(&crate::check::errors::range0(&len(&vals)), &(|i: &Nat| (or(&index(&fields, i), &Text::lit("arg")), or(&index(&vals, i), &crate::lower::model::Ex::XUnit)))))]))])))
                                    }
                                }
                            })
                        })
                    },
                    None => {
                        let args = args.clone();
                        let callee = (**callee).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        call_then(start_local_job_fn(lx.clone(), env.clone(), callee.clone()), move |local_job_fn_142240: Option<Vl>| match local_job_fn_142240 {
                            Some(f) => call_then(start_start_args(lx.clone(), env.clone(), f.clone(), args.clone()), move |start_args_142309: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(start_call(&f, &start_args_142309)), Text::lit("cycle"), Array::new()))),
                            None => call_then(start_prelude_job_call(lx.clone(), env.clone(), e.clone()), move |prelude_job_call_142376: Option<crate::lower::model::Ex>| match prelude_job_call_142376 {
                                Some(job) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XMethod(Rc::new(job.clone()), Text::lit("cycle"), Array::new())),
                                None => call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_142517: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of_142517)])))),
                            }),
                        })
                    },
                };
            }
            {
                let e = e.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), e.clone()), move |value_of_142596: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![own(&value_of_142596)]))))
            }
        }
    }
}

/// `Start TailHere, x`: what the function value is when passed to `@Run`.
pub fn start_tail_here(lx: Lx, env: Env, e: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailHere { lx, env, e })
}

/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub fn tail_block(lx: &Lx, env: &Env, b: &crate::syntax::Block) -> crate::lower::model::Ex {
    tail_from(lx, env, b, &Nat::from(0u32))
}

/// The step machine of `TailBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBlock: unbounded fn Lx, Env, Block -> Ex
/// ```
pub struct TailBlock {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBlock {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32) }))
    }
}

/// `Start TailBlock, x`: what the function value is when passed to `@Run`.
pub fn start_tail_block(lx: Lx, env: Env, b: crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBlock { lx, env, b })
}

/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub fn tail_from(lx: &Lx, env: &Env, b: &crate::syntax::Block, i: &Nat) -> crate::lower::model::Ex {
    let s = or(&index(&b.stmts, i), &dummy_stmt_l());
    if &(i + &Nat::from(1u32)) >= &len(&b.stmts) {
        match &s.kind {
            crate::syntax::StmtKind::SExpr(x) => tail(lx, env, x),
            _ => crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit])),
        }
    } else {
        {
            let found_opt = match &s.kind {
                crate::syntax::StmtKind::SLet(_, _, x) => frame_call(lx, env, x, &false),
                crate::syntax::StmtKind::SExpr(x) => frame_call(lx, env, x, &false),
                _ => None,
            };
            let looping_opt = match &s.kind {
                crate::syntax::StmtKind::SLet(p_, _, x) => match &*x.kind {
                    crate::syntax::ExprKind::EUpdate(target, ub) => if has_top_while(lx, ub) {
                        Some((p_.clone(), (**target).clone(), ub.clone(), x.clone()))
                    } else {
                        None
                    },
                    _ => None,
                },
                _ => None,
            };
            match &looping_opt {
                Some((p_, target, ub, x)) => upd_tail(lx, env, target, ub, &b.span, &{
                    let lx = lx.clone();
                    let p_ = p_.clone();
                    let x = x.clone();
                    let s = s.clone();
                    let b = b.clone();
                    let i = i.clone();
                    Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let x = x.clone();
                        let s = s.clone();
                        let b = b.clone();
                        let i = i.clone();
                        entered(once_job(move || {
                            let en = p0;
                            let v_ = p1;
                            call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_143719: PatOut| {
                                let po = rust_pat_143719;
                                call_then(start_tail_from(lx.clone(), bind_all(&en, &po.binds), b.clone(), &i + &Nat::from(1u32)), move |tail_from_143811: crate::lower::model::Ex| {
                                    let rest = tail_from_143811;
                                    prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), v_.clone())]), &rest))
                                })
                            })
                        }))
                    }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                }),
                None => match &found_opt {
                    Some(c) => frame(lx, env, c, &rest_text(lx, &s.span, &c.span, &b.span), &{
                        let lx = lx.clone();
                        let b = b.clone();
                        let i = i.clone();
                        Rc::new(move |p0: Env| {
                            let lx = lx.clone();
                            let b = b.clone();
                            let i = i.clone();
                            entered(once_job(move || {
                                let env2 = p0;
                                prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env2.clone(), b: b.clone(), i: i.clone() }))
                            }))
                        }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    }),
                    None => {
                        let (dos, env2) = block_stmt(lx, env, &s);
                        match tail_from(lx, &env2, b, &(i + &Nat::from(1u32))) {
                            crate::lower::model::Ex::XBlock(more, last) => crate::lower::model::Ex::XBlock(append(&dos, &more), Rc::new((*last).clone())),
                            last => if &len(&dos) == &Nat::from(0u32) {
                                last.clone()
                            } else {
                                crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone()))
                            },
                        }
                    },
                },
            }
        }
    }
}

/// The step machine of `TailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailFrom: unbounded fn Lx, Env, Block, Nat -> Ex
/// ```
pub struct TailFrom {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
    pub i: Nat,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let i = &self.i;
        let s = or(&index(&b.stmts, i), &dummy_stmt_l());
        if &(i + &Nat::from(1u32)) >= &len(&b.stmts) {
            match &s.kind {
                crate::syntax::StmtKind::SExpr(x) => prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: x.clone() })),
                _ => prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![crate::lower::model::Ex::XUnit]))),
            }
        } else {
            {
                let found_opt = match &s.kind {
                    crate::syntax::StmtKind::SLet(_, _, x) => frame_call(lx, env, x, &false),
                    crate::syntax::StmtKind::SExpr(x) => frame_call(lx, env, x, &false),
                    _ => None,
                };
                let looping_opt = match &s.kind {
                    crate::syntax::StmtKind::SLet(p_, _, x) => match &*x.kind {
                        crate::syntax::ExprKind::EUpdate(target, ub) => if has_top_while(lx, ub) {
                            Some((p_.clone(), (**target).clone(), ub.clone(), x.clone()))
                        } else {
                            None
                        },
                        _ => None,
                    },
                    _ => None,
                };
                match &looping_opt {
                    Some((p_, target, ub, x)) => prism_rtl::Turn::More(Rc::new(UpdTail { lx: lx.clone(), env: env.clone(), target: target.clone(), b: ub.clone(), to: b.span.clone(), cont_fn: {
                        let lx = lx.clone();
                        let p_ = p_.clone();
                        let x = x.clone();
                        let s = s.clone();
                        let b = b.clone();
                        let i = i.clone();
                        Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
                            let lx = lx.clone();
                            let p_ = p_.clone();
                            let x = x.clone();
                            let s = s.clone();
                            let b = b.clone();
                            let i = i.clone();
                            entered(once_job(move || {
                                let en = p0;
                                let v_ = p1;
                                call_then(start_rust_pat(lx.clone(), p_.clone(), type_at(&lx, &x.span), Holding::Owned, Text::from(format!("l{}", &s.span.start))), move |rust_pat_143719: PatOut| {
                                    let po = rust_pat_143719;
                                    call_then(start_tail_from(lx.clone(), bind_all(&en, &po.binds), b.clone(), &i + &Nat::from(1u32)), move |tail_from_143811: crate::lower::model::Ex| {
                                        let rest = tail_from_143811;
                                        prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), v_.clone())]), &rest))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } })),
                    None => match &found_opt {
                        Some(c) => prism_rtl::Turn::More(Rc::new(Frame { lx: lx.clone(), env: env.clone(), call: c.clone(), rest_text_: rest_text(lx, &s.span, &c.span, &b.span), cont_fn: {
                            let lx = lx.clone();
                            let b = b.clone();
                            let i = i.clone();
                            Rc::new(move |p0: Env| {
                                let lx = lx.clone();
                                let b = b.clone();
                                let i = i.clone();
                                entered(once_job(move || {
                                    let env2 = p0;
                                    prism_rtl::Turn::More(Rc::new(TailFrom { lx: lx.clone(), env: env2.clone(), b: b.clone(), i: i.clone() }))
                                }))
                            }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } })),
                        None => {
                            let b = b.clone();
                            let env = env.clone();
                            let i = i.clone();
                            let lx = lx.clone();
                            call_then(start_block_stmt(lx.clone(), env.clone(), s.clone()), move |block_stmt_144114: (Array<crate::lower::model::Do>, Env)| {
                                let (dos, env2) = block_stmt_144114;
                                call_then(start_tail_from(lx.clone(), env2.clone(), b.clone(), &i + &Nat::from(1u32)), move |tail_from_144161: crate::lower::model::Ex| match tail_from_144161 {
                                    crate::lower::model::Ex::XBlock(more, last) => prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(append(&dos, &more), Rc::new((*last).clone()))),
                                    last => if &len(&dos) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(last.clone())
                                    } else {
                                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone())))
                                    },
                                })
                            })
                        },
                    },
                }
            }
        }
    }
}

/// `Start TailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_tail_from(lx: Lx, env: Env, b: crate::syntax::Block, i: Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailFrom { lx, env, b, i })
}

/// ```prism
/// HasTopWhile: fn Lx, Block -> Bool
/// ```
pub fn has_top_while(lx: &Lx, b: &crate::syntax::Block) -> bool {
    fold(&b.stmts, &false, &(|f: &bool, st: &crate::syntax::Stmt| (*f || is_cycle_while(lx, st)) || holds_cycle_while(lx, st)))
}

/// ```prism
/// IsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn is_cycle_while(lx: &Lx, st: &crate::syntax::Stmt) -> bool {
    match &st.kind {
        crate::syntax::StmtKind::SWhile(_, _) => crate::check::env::has_key(&lx.unshrunk, &place_key(lx, &st.span)),
        _ => false,
    }
}

/// ```prism
/// ElseHasTopWhile: fn Lx, ?Block -> Bool
/// ```
pub fn else_has_top_while(lx: &Lx, opt1: &Option<crate::syntax::Block>) -> bool {
    match opt1 {
        Some(b) => has_top_while(lx, b),
        None => false,
    }
}

/// ```prism
/// HoldsCycleWhile: fn Lx, Stmt -> Bool
/// ```
pub fn holds_cycle_while(lx: &Lx, st: &crate::syntax::Stmt) -> bool {
    match &st.kind {
        crate::syntax::StmtKind::SWhile(_, wb) => has_top_while(lx, wb),
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(_, then_b, else_b_opt) => has_top_while(lx, then_b) || else_has_top_while(lx, else_b_opt),
            crate::syntax::ExprKind::EMatch(_, arms) => fold(arms, &false, &(|f: &bool, a: &crate::syntax::Arm| *f || has_top_while(lx, &a.body))),
            crate::syntax::ExprKind::EFor(_, _, fb) => has_top_while(lx, fb),
            _ => false,
        },
        _ => false,
    }
}

/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail(lx: &Lx, env: &Env, target: &crate::syntax::Expr, b: &crate::syntax::Block, to: &crate::syntax::Range, cont_fn: &Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let t = out_ty_of(lx, &peel(&type_at(lx, &target.span)));
    let tv = value_of(lx, env, target);
    let env1 = bind(env, &Text::lit("&_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), Holding::Owned, t.clone()));
    prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), own(&tv))]), &upd_tail_from(lx, env, &env1, b, &Nat::from(0u32), to, &cont_fn.clone()))
}

/// The step machine of `UpdTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTail: unbounded fn Lx, Env, Expr, Block, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTail {
    pub lx: Lx,
    pub env: Env,
    pub target: crate::syntax::Expr,
    pub b: crate::syntax::Block,
    pub to: crate::syntax::Range,
    pub cont_fn: Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTail {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let target = &self.target;
        let b = &self.b;
        let to = &self.to;
        let cont_fn = &self.cont_fn;
        let cont_fn = cont_fn.clone();
        let b = b.clone();
        let env = env.clone();
        let lx = lx.clone();
        let target = target.clone();
        let to = to.clone();
        call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &target.span))), move |out_ty_of_146719: crate::lower::model::OutTy| {
            let t = out_ty_of_146719;
            call_then(start_value_of(lx.clone(), env.clone(), target.clone()), move |value_of_146776: Vl| {
                let tv = value_of_146776;
                let env1 = bind(&env, &Text::lit("&_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(Text::lit("this")), Holding::Owned, t.clone()));
                call_then(start_upd_tail_from(lx.clone(), env.clone(), env1.clone(), b.clone(), Nat::from(0u32), to.clone(), cont_fn.clone()), move |upd_tail_from_146929: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&Array::from(vec![crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaMut(Text::lit("this"))), t.clone()), own(&tv))]), &upd_tail_from_146929)))
            })
        })
    }
}

/// `Start UpdTail, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail(lx: Lx, env: Env, target: crate::syntax::Expr, b: crate::syntax::Block, to: crate::syntax::Range, cont_fn: Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTail { lx, env, target, b, to, cont_fn })
}

/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub fn upd_tail_from(lx: &Lx, outer: &Env, env: &Env, b: &crate::syntax::Block, i: &Nat, to: &crate::syntax::Range, cont_fn: &Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    if i >= &len(&b.stmts) {
        run_to_end(cont_fn((outer.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))))
    } else {
        {
            let s = or(&index(&b.stmts, i), &dummy_stmt_l());
            let rest = rest_text(lx, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, to);
            let next_fn = {
                let lx = lx.clone();
                let b = b.clone();
                let i = i.clone();
                let to = to.clone();
                let cont_fn = cont_fn.clone();
                Rc::new(move |(p0, p1): (Env, Env)| {
                    let lx = lx.clone();
                    let b = b.clone();
                    let i = i.clone();
                    let to = to.clone();
                    let cont_fn = cont_fn.clone();
                    entered(once_job(move || {
                        let o2 = p0;
                        let e2 = p1;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: o2.clone(), env: e2.clone(), b: b.clone(), i: &i + &Nat::from(1u32), to: to.clone(), cont_fn: cont_fn.clone() }))
                    }))
                }) as Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            if is_cycle_while(lx, &s) || holds_cycle_while(lx, &s) {
                stmt_job(lx, outer, env, &s, &rest, &next_fn.clone())
            } else {
                {
                    let (dos, env2) = upd_stmt(lx, env, &s);
                    prepend(&dos, &upd_tail_from(lx, outer, &env2, b, &(i + &Nat::from(1u32)), to, &cont_fn.clone()))
                }
            }
        }
    }
}

/// The step machine of `UpdTailFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UpdTailFrom: unbounded fn Lx, Env, Env, Block, Nat, Range, (unbounded fn Env, Ex -> Ex) -> Ex
/// ```
pub struct UpdTailFrom {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub b: crate::syntax::Block,
    pub i: Nat,
    pub to: crate::syntax::Range,
    pub cont_fn: Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for UpdTailFrom {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let b = &self.b;
        let i = &self.i;
        let to = &self.to;
        let cont_fn = &self.cont_fn;
        if i >= &len(&b.stmts) {
            cont_fn((outer.clone(), crate::lower::model::Ex::XVar(Text::lit("this")))).cycle()
        } else {
            {
                let s = or(&index(&b.stmts, i), &dummy_stmt_l());
                let rest = rest_text(lx, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, &crate::syntax::Range { start: s.span.end.clone(), end: s.span.end.clone() }, to);
                let next_fn = {
                    let lx = lx.clone();
                    let b = b.clone();
                    let i = i.clone();
                    let to = to.clone();
                    let cont_fn = cont_fn.clone();
                    Rc::new(move |(p0, p1): (Env, Env)| {
                        let lx = lx.clone();
                        let b = b.clone();
                        let i = i.clone();
                        let to = to.clone();
                        let cont_fn = cont_fn.clone();
                        entered(once_job(move || {
                            let o2 = p0;
                            let e2 = p1;
                            prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: o2.clone(), env: e2.clone(), b: b.clone(), i: &i + &Nat::from(1u32), to: to.clone(), cont_fn: cont_fn.clone() }))
                        }))
                    }) as Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                };
                if is_cycle_while(lx, &s) || holds_cycle_while(lx, &s) {
                    prism_rtl::Turn::More(Rc::new(StmtJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), s: s.clone(), rest: rest.clone(), cont_fn: next_fn.clone() }))
                } else {
                    {
                        let cont_fn = cont_fn.clone();
                        let b = b.clone();
                        let env = env.clone();
                        let i = i.clone();
                        let lx = lx.clone();
                        let outer = outer.clone();
                        let to = to.clone();
                        call_then(start_upd_stmt(lx.clone(), env.clone(), s.clone()), move |upd_stmt_147556: (Array<crate::lower::model::Do>, Env)| {
                            let (dos, env2) = upd_stmt_147556;
                            call_then(start_upd_tail_from(lx.clone(), outer.clone(), env2.clone(), b.clone(), &i + &Nat::from(1u32), to.clone(), cont_fn.clone()), move |upd_tail_from_147601: crate::lower::model::Ex| prism_rtl::Turn::Finished(prepend(&dos, &upd_tail_from_147601)))
                        })
                    }
                }
            }
        }
    }
}

/// `Start UpdTailFrom, x`: what the function value is when passed to `@Run`.
pub fn start_upd_tail_from(lx: Lx, outer: Env, env: Env, b: crate::syntax::Block, i: Nat, to: crate::syntax::Range, cont_fn: Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(UpdTailFrom { lx, outer, env, b, i, to, cont_fn })
}

/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn stmt_job(lx: &Lx, outer: &Env, env: &Env, s: &crate::syntax::Stmt, rest: &Text, cont_fn: &Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &s.kind {
        crate::syntax::StmtKind::SWhile(c, wb) => while_job(lx, outer, env, c, wb, &s.span, rest, &cont_fn.clone()),
        crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
            crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => if_job(lx, outer, env, &**c, then_b, else_b_opt, &s.span, rest, &cont_fn.clone()),
            crate::syntax::ExprKind::EMatch(scrut, arms) => match_job(lx, outer, env, &**scrut, arms, &s.span, rest, &cont_fn.clone()),
            crate::syntax::ExprKind::EFor(binders_opt, source, body) => match ref_binder(binders_opt) {
                Some(_) => refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)")),
                None => for_job(lx, outer, env, binders_opt, &**source, body, &s.span, rest, &cont_fn.clone()),
            },
            _ => refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &kind_words(&*x.kind)))),
        },
        _ => refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)")),
    }
}

/// The step machine of `StmtJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtJob: unbounded fn Lx, Env, Env, Stmt, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct StmtJob {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub s: crate::syntax::Stmt,
    pub rest: Text,
    pub cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let s = &self.s;
        let rest = &self.rest;
        let cont_fn = &self.cont_fn;
        match &s.kind {
            crate::syntax::StmtKind::SWhile(c, wb) => prism_rtl::Turn::More(Rc::new(WhileJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), c: c.clone(), wb: wb.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
            crate::syntax::StmtKind::SExpr(x) => match &*x.kind {
                crate::syntax::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(IfJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                crate::syntax::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(MatchJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                crate::syntax::ExprKind::EFor(binders_opt, source, body) => match ref_binder(binders_opt) {
                    Some(_) => prism_rtl::Turn::Finished(refusal(&Text::lit("a cycle-point `while` in a `for &` of an `update` block, whose references a job cannot keep (gap LP)"))),
                    None => prism_rtl::Turn::More(Rc::new(ForJob { lx: lx.clone(), outer: outer.clone(), env: env.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), span: s.span.clone(), rest_text_: rest.clone(), cont_fn: cont_fn.clone() })),
                },
                _ => prism_rtl::Turn::Finished(refusal(&Text::from(format!("a cycle-point `while` in {} (gap LP)", &kind_words(&*x.kind))))),
            },
            _ => prism_rtl::Turn::Finished(refusal(&Text::lit("a cycle-point `while` in this statement (gap LP)"))),
        }
    }
}

/// `Start StmtJob, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_job(lx: Lx, outer: Env, env: Env, s: crate::syntax::Stmt, rest: Text, cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtJob { lx, outer, env, s, rest, cont_fn })
}

/// ```prism
/// Prepend: fn [Do], Ex -> Ex
/// ```
pub fn prepend(dos: &Array<crate::lower::model::Do>, ex1: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    match ex1 {
        crate::lower::model::Ex::XBlock(more, last) => crate::lower::model::Ex::XBlock(append(dos, more), Rc::new((**last).clone())),
        x => if &len(dos) == &Nat::from(0u32) {
            x.clone()
        } else {
            crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(x.clone()))
        },
    }
}

/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn while_job(lx: &Lx, outer: &Env, env: &Env, c: &crate::syntax::Cond, wb: &crate::syntax::Block, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
    let loop_text = match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, span),
        None => Text::lit(""),
    };
    let caps = caps_in(&env_s, &loop_text, &names);
    let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let env_c = fold(&caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let jobs = has_top_while(lx, wb);
    let finish_fn = {
        let jobs = jobs;
        Rc::new(move |x: &crate::lower::model::Ex| if jobs {
            crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x.clone()]))
        } else {
            x.clone()
        })
    };
    let step_ty = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty.clone(), st_ty.clone()]));
    let again = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack.clone()]))), step_ty.clone()));
    let stop = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack.clone()]))), step_ty.clone()));
    let body_fn = {
        let jobs = jobs;
        let lx = lx.clone();
        let wb = wb.clone();
        let again = again.clone();
        Rc::new(move |p0: Env| {
            let jobs = jobs;
            let lx = lx.clone();
            let wb = wb.clone();
            let again = again.clone();
            entered(once_job(move || {
                let en = p0;
                if jobs {
                    prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: en.clone(), env: en.clone(), b: wb.clone(), i: Nat::from(0u32), to: wb.span.clone(), cont_fn: {
                        let again = again.clone();
                        Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
                            let again = again.clone();
                            once_job(move || {
                                let o2 = p0;
                                let e2 = p1;
                                prism_rtl::Turn::Finished(again.clone())
                            })
                        }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    } }))
                } else {
                    prism_rtl::Turn::More(Rc::new(StmtsThen { lx: lx.clone(), env: en.clone(), b: wb.clone(), last: again.clone() }))
                }
            }))
        }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let res_ty = if jobs {
        crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty.clone()]))
    } else {
        st_ty.clone()
    };
    let turn = match c {
        crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(lx, &env_c, &**x))), Rc::new(run_to_end((&body_fn)(env_c.clone()))), Rc::new(stop.clone())),
        crate::syntax::Cond::CondBind(p_, x, g_opt) => {
            let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("w{}", &span.start)));
            let env_b = bind_all(&env_c, &po.binds);
            let conds = append(&po.conds, &guard_conds(lx, &env_b, &**g_opt));
            own(&arms_value(&own(&value_of(lx, &env_c, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: conds.clone(), body: run_to_end((&body_fn)(env_b.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop.clone() }]), &Text::from(format!("'w{}", &span.start)), &res_ty))
        },
    };
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(turn.clone())));
    let looping = if jobs { Text::lit("loop_turns") } else { Text::lit("loop_job") };
    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone())))))]));
    prepend(&out_dos, &enter)
}

/// The step machine of `WhileJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WhileJob: unbounded fn Lx, Env, Env, Cond, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct WhileJob {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub c: crate::syntax::Cond,
    pub wb: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for WhileJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let c = &self.c;
        let wb = &self.wb;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
        let loop_text = match index(&lx.g.srcs, &lx.file) {
            Some(src) => crate::check::errors::span_text(&src, span),
            None => Text::lit(""),
        };
        let caps = caps_in(&env_s, &loop_text, &names);
        let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let env_c = fold(&caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let jobs = has_top_while(lx, wb);
        let finish_fn = {
            let jobs = jobs;
            Rc::new(move |x: &crate::lower::model::Ex| if jobs {
                crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![x.clone()]))
            } else {
                x.clone()
            })
        };
        let step_ty = crate::lower::model::OutTy::OutNamed(Text::lit("Result"), Array::from(vec![st_ty.clone(), st_ty.clone()]));
        let again = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![pack.clone()]))), step_ty.clone()));
        let stop = (&finish_fn)(&crate::lower::model::Ex::XTyped(Rc::new(crate::lower::model::Ex::XCtor(Text::lit("Err"), Array::from(vec![pack.clone()]))), step_ty.clone()));
        let body_fn = {
            let jobs = jobs;
            let lx = lx.clone();
            let wb = wb.clone();
            let again = again.clone();
            Rc::new(move |p0: Env| {
                let jobs = jobs;
                let lx = lx.clone();
                let wb = wb.clone();
                let again = again.clone();
                entered(once_job(move || {
                    let en = p0;
                    if jobs {
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: en.clone(), env: en.clone(), b: wb.clone(), i: Nat::from(0u32), to: wb.span.clone(), cont_fn: {
                            let again = again.clone();
                            Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
                                let again = again.clone();
                                once_job(move || {
                                    let o2 = p0;
                                    let e2 = p1;
                                    prism_rtl::Turn::Finished(again.clone())
                                })
                            }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(StmtsThen { lx: lx.clone(), env: en.clone(), b: wb.clone(), last: again.clone() }))
                    }
                }))
            }) as Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        };
        let res_ty = if jobs {
            crate::lower::model::OutTy::OutNamed(Text::lit("prism_rtl::Turn"), Array::from(vec![step_ty.clone()]))
        } else {
            st_ty.clone()
        };
        let turn = match c {
            crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(lx, &env_c, &**x))), Rc::new(run_to_end((&body_fn)(env_c.clone()))), Rc::new(stop.clone())),
            crate::syntax::Cond::CondBind(p_, x, g_opt) => {
                let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("w{}", &span.start)));
                let env_b = bind_all(&env_c, &po.binds);
                let conds = append(&po.conds, &guard_conds(lx, &env_b, &**g_opt));
                own(&arms_value(&own(&value_of(lx, &env_c, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: conds.clone(), body: run_to_end((&body_fn)(env_b.clone())) }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: stop.clone() }]), &Text::from(format!("'w{}", &span.start)), &res_ty))
            },
        };
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(turn.clone())));
        let looping = if jobs { Text::lit("loop_turns") } else { Text::lit("loop_job") };
        let cont_fn = cont_fn.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_152106: crate::lower::model::Ex| {
            let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_152106))]));
            prism_rtl::Turn::Finished(prepend(&out_dos, &enter))
        })
    }
}

/// `Start WhileJob, x`: what the function value is when passed to `@Run`.
pub fn start_while_job(lx: Lx, outer: Env, env: Env, c: crate::syntax::Cond, wb: crate::syntax::Block, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(WhileJob { lx, outer, env, c, wb, span, rest_text_, cont_fn })
}

/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub fn stmts_then(lx: &Lx, env: &Env, b: &crate::syntax::Block, last: &crate::lower::model::Ex) -> crate::lower::model::Ex {
    let (dos, _) = upd_stmts(lx, env, &b.stmts);
    crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone()))
}

/// The step machine of `StmtsThen`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsThen: unbounded fn Lx, Env, Block, Ex -> Ex
/// ```
pub struct StmtsThen {
    pub lx: Lx,
    pub env: Env,
    pub b: crate::syntax::Block,
    pub last: crate::lower::model::Ex,
}

impl prism_rtl::Job<crate::lower::model::Ex> for StmtsThen {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let b = &self.b;
        let last = &self.last;
        let b = b.clone();
        let env = env.clone();
        let last = last.clone();
        let lx = lx.clone();
        call_then(start_upd_stmts(lx.clone(), env.clone(), b.stmts.clone()), move |upd_stmts_152319: (Array<crate::lower::model::Do>, Env)| {
            let (dos, _) = upd_stmts_152319;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(last.clone())))
        })
    }
}

/// `Start StmtsThen, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_then(lx: Lx, env: Env, b: crate::syntax::Block, last: crate::lower::model::Ex) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(StmtsThen { lx, env, b, last })
}

/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn if_job(lx: &Lx, outer: &Env, env: &Env, c: &crate::syntax::Cond, then_b: &crate::syntax::Block, else_b_opt: &Option<crate::syntax::Block>, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let k_name = Text::from(format!("k_if{}", &span.start));
    let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone()))))));
    let to_k_fn = {
        let k_name = k_name.clone();
        let pack = pack.clone();
        Rc::new(move |o2: &Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
    };
    let branch_fn = {
        let lx = lx.clone();
        let env = env.clone();
        let to_k_fn = to_k_fn.clone();
        Rc::new(move |p0: crate::syntax::Block| {
            let lx = lx.clone();
            let env = env.clone();
            let to_k_fn = to_k_fn.clone();
            entered(once_job(move || {
                let b = p0;
                prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: env.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32), to: b.span.clone(), cont_fn: {
                    let f = to_k_fn.clone();
                    Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                        let f = f.clone();
                        once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                    }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                } }))
            }))
        }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    };
    let else_x = match else_b_opt {
        Some(eb) => run_to_end((&branch_fn)(eb.clone())),
        None => crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])),
    };
    let choose = match c {
        crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(lx, env, &**x))), Rc::new(run_to_end((&branch_fn)(then_b.clone()))), Rc::new(else_x.clone())),
        crate::syntax::Cond::CondBind(p_, x, _) => {
            let po = rust_pat(lx, p_, &type_at(lx, &x.span), &Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
            let then_x = upd_tail_from(lx, &bind_all(env, &po.binds), &bind_all(env, &po.binds), then_b, &Nat::from(0u32), &then_b.span, &{
                let f = to_k_fn.clone();
                Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                    let f = f.clone();
                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            });
            own(&arms_value(&own(&value_of(lx, env, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: po.conds.clone(), body: then_x.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x.clone() }]), &Text::from(format!("'u{}", &x.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
        },
    };
    prepend(&push(&out_dos, &k_do), &choose)
}

/// The step machine of `IfJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfJob: unbounded fn Lx, Env, Env, Cond, Block, ?Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct IfJob {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub c: crate::syntax::Cond,
    pub then_b: crate::syntax::Block,
    pub else_b_opt: Option<crate::syntax::Block>,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for IfJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let k_name = Text::from(format!("k_if{}", &span.start));
        let else_b_opt = else_b_opt.clone();
        let cont_fn = cont_fn.clone();
        let c = c.clone();
        let env = env.clone();
        let lx = lx.clone();
        let span = span.clone();
        let then_b = then_b.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_154031: crate::lower::model::Ex| {
            let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_154031)));
            let to_k_fn = {
                let k_name = k_name.clone();
                let pack = pack.clone();
                Rc::new(move |o2: &Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
            };
            let branch_fn = {
                let lx = lx.clone();
                let env = env.clone();
                let to_k_fn = to_k_fn.clone();
                Rc::new(move |p0: crate::syntax::Block| {
                    let lx = lx.clone();
                    let env = env.clone();
                    let to_k_fn = to_k_fn.clone();
                    entered(once_job(move || {
                        let b = p0;
                        prism_rtl::Turn::More(Rc::new(UpdTailFrom { lx: lx.clone(), outer: env.clone(), env: env.clone(), b: b.clone(), i: Nat::from(0u32), to: b.span.clone(), cont_fn: {
                            let f = to_k_fn.clone();
                            Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                                let f = f.clone();
                                once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                            }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                        } }))
                    }))
                }) as Rc<dyn Fn(crate::syntax::Block) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            };
            let else_x = match &else_b_opt {
                Some(eb) => run_to_end((&branch_fn)(eb.clone())),
                None => crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])),
            };
            let choose = match &c {
                crate::syntax::Cond::CondExpr(x) => crate::lower::model::Ex::XIf(Rc::new(as_bool(&value_of(&lx, &env, &**x))), Rc::new(run_to_end((&branch_fn)(then_b.clone()))), Rc::new(else_x.clone())),
                crate::syntax::Cond::CondBind(p_, x, _) => {
                    let po = rust_pat(&lx, p_, &type_at(&lx, &x.span), &Holding::Owned, &Text::from(format!("u{}", &x.span.start)));
                    let then_x = upd_tail_from(&lx, &bind_all(&env, &po.binds), &bind_all(&env, &po.binds), &then_b, &Nat::from(0u32), &then_b.span, &{
                        let f = to_k_fn.clone();
                        Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                            let f = f.clone();
                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                        }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    });
                    own(&arms_value(&own(&value_of(&lx, &env, &**x)), &Array::from(vec![crate::lower::model::XArm { pat: po.pa.clone(), conds: po.conds.clone(), body: then_x.clone() }, crate::lower::model::XArm { pat: crate::lower::model::Pa::PaWild, conds: Array::new(), body: else_x.clone() }]), &Text::from(format!("'u{}", &x.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
                },
            };
            prism_rtl::Turn::Finished(prepend(&push(&out_dos, &k_do), &choose))
        })
    }
}

/// `Start IfJob, x`: what the function value is when passed to `@Run`.
pub fn start_if_job(lx: Lx, outer: Env, env: Env, c: crate::syntax::Cond, then_b: crate::syntax::Block, else_b_opt: Option<crate::syntax::Block>, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(IfJob { lx, outer, env, c, then_b, else_b_opt, span, rest_text_, cont_fn })
}

/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn match_job(lx: &Lx, outer: &Env, env: &Env, scrut: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let k_name = Text::from(format!("k_match{}", &span.start));
    let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone()))))));
    let to_k_fn = {
        let k_name = k_name.clone();
        let pack = pack.clone();
        Rc::new(move |o2: &Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
    };
    let sty = type_at(lx, &scrut.span);
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let lx = lx.clone();
        let sty = sty.clone();
        let scrut = scrut.clone();
        let env = env.clone();
        let to_k_fn = to_k_fn.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let lx = lx.clone();
            let sty = sty.clone();
            let scrut = scrut.clone();
            let env = env.clone();
            let to_k_fn = to_k_fn.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &dummy_arm());
                    call_then(start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), Holding::Owned, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_156598: PatOut| {
                        let po = arm_pat_156598;
                        let env_a = bind_all(&env, &po.binds);
                        call_then(start_guard_conds(lx.clone(), env_a.clone(), arm.guard.clone()), move |guard_conds_156742: Array<crate::lower::model::Cc>| {
                            let guarded = append(&po.conds, &guard_conds_156742);
                            call_then(start_upd_tail_from(lx.clone(), env_a.clone(), env_a.clone(), arm.body.clone(), Nat::from(0u32), arm.body.span.clone(), {
                                let f = to_k_fn.clone();
                                Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                                    let f = f.clone();
                                    once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            }), move |upd_tail_from_156820: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: upd_tail_from_156820 }))
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    prepend(&push(&out_dos, &k_do), &own(&arms_value(&own(&value_of(lx, env, scrut)), &xarms, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))
}

/// The step machine of `MatchJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchJob: unbounded fn Lx, Env, Env, Expr, [Arm], Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct MatchJob {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub scrut: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for MatchJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
        let out_caps = caps_in(outer, rest_text_, &names);
        let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
        let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
        let k_name = Text::from(format!("k_match{}", &span.start));
        let cont_fn = cont_fn.clone();
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_156393: crate::lower::model::Ex| {
            let k_do = crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(k_name.clone()), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_156393)));
            let to_k_fn = {
                let k_name = k_name.clone();
                let pack = pack.clone();
                Rc::new(move |o2: &Env, e2: &crate::lower::model::Ex| crate::lower::model::Ex::XCall(k_name.clone(), Array::from(vec![pack.clone()])))
            };
            let sty = type_at(&lx, &scrut.span);
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let arms = arms.clone();
                let lx = lx.clone();
                let sty = sty.clone();
                let scrut = scrut.clone();
                let env = env.clone();
                let to_k_fn = to_k_fn.clone();
                Rc::new(move |p0: Nat| {
                    let arms = arms.clone();
                    let lx = lx.clone();
                    let sty = sty.clone();
                    let scrut = scrut.clone();
                    let env = env.clone();
                    let to_k_fn = to_k_fn.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let arm = or(&index(&arms, &i), &dummy_arm());
                            call_then(start_arm_pat(lx.clone(), arm.pattern.clone(), sty.clone(), Holding::Owned, Text::from(format!("u{}_{}", &scrut.span.start, &i))), move |arm_pat_156598: PatOut| {
                                let po = arm_pat_156598;
                                let env_a = bind_all(&env, &po.binds);
                                call_then(start_guard_conds(lx.clone(), env_a.clone(), arm.guard.clone()), move |guard_conds_156742: Array<crate::lower::model::Cc>| {
                                    let guarded = append(&po.conds, &guard_conds_156742);
                                    call_then(start_upd_tail_from(lx.clone(), env_a.clone(), env_a.clone(), arm.body.clone(), Nat::from(0u32), arm.body.span.clone(), {
                                        let f = to_k_fn.clone();
                                        Rc::new(move |(a0, a1): (Env, crate::lower::model::Ex)| {
                                            let f = f.clone();
                                            once_job(move || prism_rtl::Turn::Finished(f(&a0, &a1)))
                                        }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                                    }), move |upd_tail_from_156820: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: guarded.clone(), body: upd_tail_from_156820 }))
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
            }), move |each_156511: Array<crate::lower::model::XArm>| {
                let xarms = each_156511;
                call_then(start_value_of(lx.clone(), env.clone(), scrut.clone()), move |value_of_156936: Vl| prism_rtl::Turn::Finished(prepend(&push(&out_dos, &k_do), &own(&arms_value(&own(&value_of_156936), &xarms, &Text::from(format!("'u{}", &scrut.span.start)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))))
            })
        })
    }
}

/// `Start MatchJob, x`: what the function value is when passed to `@Run`.
pub fn start_match_job(lx: Lx, outer: Env, env: Env, scrut: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(MatchJob { lx, outer, env, scrut, arms, span, rest_text_, cont_fn })
}

/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub fn for_job(lx: &Lx, outer: &Env, env: &Env, binders_opt: &Option<crate::syntax::ForBinders>, source: &crate::syntax::Expr, body: &crate::syntax::Block, span: &crate::syntax::Range, rest_text_: &Text, cont_fn: &Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
        acc.clone()
    } else {
        match get(&env.names, k) {
            Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
            _ => acc.clone(),
        }
    }));
    let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
    let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
    let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
    let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
    let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
    let src = own(&value_of(lx, env, source));
    let sty = peel(&type_at(lx, &source.span));
    let (kt, vt, is_array) = match &sty {
        crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, out_ty_of(lx, &**v_), true),
        crate::check::types::Ty::TyMap(k, v_) => (out_ty_of(lx, &**k), out_ty_of(lx, &**v_), false),
        _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
    };
    let (vty, kty) = match &sty {
        crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
        crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
        _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
    };
    let key_name = Text::from(format!("k{}", &span.start));
    let val_name = Text::from(format!("v{}", &span.start));
    let loop_text = match index(&lx.g.srcs, &lx.file) {
        Some(src2) => crate::check::errors::span_text(&src2, span),
        None => Text::lit(""),
    };
    let caps = caps_in(&env_s, &loop_text, &names);
    let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let env_c = fold(&caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let env1 = bind(&bind(&env_c, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone())), &Text::lit("_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), Holding::Owned, vt.clone()));
    let env_k = if is_array {
        bind(&env1, &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone()))
    } else {
        env1.clone()
    };
    let (binds, env_b) = match binders_opt {
        None => (Array::new(), env_k.clone()),
        Some(fb) => match &fb.second {
            None => {
                let po = rust_pat(lx, &fb.first, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&env_k, &po.binds))
            },
            Some(second) => {
                let pk = rust_pat(lx, &fb.first, &kty, &Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                let pv = rust_pat(lx, second, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&bind_all(&env_k, &pk.binds), &pv.binds))
            },
        },
    };
    let turn = prepend(&binds, &upd_tail_from(lx, &env_b, &env_b, body, &Nat::from(0u32), &body.span, &{
        let pack = pack.clone();
        Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
            let pack = pack.clone();
            once_job(move || {
                let o2 = p0;
                let e2 = p1;
                prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack.clone()])))
            })
        }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    }));
    let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name.clone())), kt.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name.clone())), vt.clone())]), Rc::new(turn.clone())));
    let out_caps = caps_in(outer, rest_text_, &names);
    let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
    let outer2 = fold(&out_caps, outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
    let looping = if is_array { Text::lit("for_turns_indexed") } else { Text::lit("for_turns_keyed") };
    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![src.clone(), pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(run_to_end(cont_fn((outer2.clone(), env2.clone())))))]));
    prepend(&out_dos, &enter)
}

/// The step machine of `ForJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForJob: unbounded fn Lx, Env, Env, ?ForBinders, Expr, Block, Range, Text, (unbounded fn Env, Env -> Ex) -> Ex
/// ```
pub struct ForJob {
    pub lx: Lx,
    pub outer: Env,
    pub env: Env,
    pub binders_opt: Option<crate::syntax::ForBinders>,
    pub source: crate::syntax::Expr,
    pub body: crate::syntax::Block,
    pub span: crate::syntax::Range,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for ForJob {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let outer = &self.outer;
        let env = &self.env;
        let binders_opt = &self.binders_opt;
        let source = &self.source;
        let body = &self.body;
        let span = &self.span;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        let state = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, Text, crate::lower::model::OutTy)>, k: &Text| if !crate::syntax::lexer::has_prefix(k, &Text::lit("&")) {
            acc.clone()
        } else {
            match get(&env.names, k) {
                Some(Bn::BnLocal(rs, _, bt)) => push(acc, &(k.clone(), place_stem(&rs), bt.clone())),
                _ => acc.clone(),
            }
        }));
        let names = each(&state, &(|(_, rs, _): &(Text, Text, crate::lower::model::OutTy)| rs.clone()));
        let st_ty = crate::lower::model::OutTy::OutTuple(each(&state, &(|(_, _, bt): &(Text, Text, crate::lower::model::OutTy)| bt.clone())));
        let pat = crate::lower::model::Pa::PaTuple(each(&names, &(|n: &Text| crate::lower::model::Pa::PaMut(Text::from(format!("{}", n))))));
        let pack = crate::lower::model::Ex::XTuple(each(&names, &(|n: &Text| crate::lower::model::Ex::XVar(n.clone()))));
        let env_s = fold(&state, env, &(|en: &Env, (k, rs, bt): &(Text, Text, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(rs.clone()), Holding::Owned, bt.clone()))));
        let binders_opt = binders_opt.clone();
        let cont_fn = cont_fn.clone();
        let body = body.clone();
        let env = env.clone();
        let lx = lx.clone();
        let outer = outer.clone();
        let rest_text_ = rest_text_.clone();
        let source = source.clone();
        let span = span.clone();
        call_then(start_value_of(lx.clone(), env.clone(), source.clone()), move |value_of_158173: Vl| {
            let src = own(&value_of_158173);
            let sty = peel(&type_at(&lx, &source.span));
            let (kt, vt, is_array) = match &sty {
                crate::check::types::Ty::TyArray(v_) => (crate::lower::model::OutTy::OutNat, out_ty_of(&lx, &**v_), true),
                crate::check::types::Ty::TyMap(k, v_) => (out_ty_of(&lx, &**k), out_ty_of(&lx, &**v_), false),
                _ => (crate::lower::model::OutTy::OutUnit, crate::lower::model::OutTy::OutUnit, true),
            };
            let (vty, kty) = match &sty {
                crate::check::types::Ty::TyArray(v_) => ((**v_).clone(), crate::check::types::Ty::TyCon(Text::lit("Nat"), Array::new())),
                crate::check::types::Ty::TyMap(k, v_) => ((**v_).clone(), (**k).clone()),
                _ => (crate::check::types::Ty::TyErr, crate::check::types::Ty::TyErr),
            };
            let key_name = Text::from(format!("k{}", &span.start));
            let val_name = Text::from(format!("v{}", &span.start));
            let loop_text = match index(&lx.g.srcs, &lx.file) {
                Some(src2) => crate::check::errors::span_text(&src2, &span),
                None => Text::lit(""),
            };
            let caps = caps_in(&env_s, &loop_text, &names);
            let cap_dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
            let env_c = fold(&caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
            let env1 = bind(&bind(&env_c, &Text::lit("key"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone())), &Text::lit("_"), &Bn::BnLocal(crate::lower::model::Ex::XVar(val_name.clone()), Holding::Owned, vt.clone()));
            let env_k = if is_array {
                bind(&env1, &Text::lit("ix"), &Bn::BnLocal(crate::lower::model::Ex::XVar(key_name.clone()), Holding::Owned, kt.clone()))
            } else {
                env1.clone()
            };
            let (binds, env_b) = match &binders_opt {
                None => (Array::new(), env_k.clone()),
                Some(fb) => match &fb.second {
                    None => {
                        let po = rust_pat(&lx, &fb.first, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(po.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&env_k, &po.binds))
                    },
                    Some(second) => {
                        let pk = rust_pat(&lx, &fb.first, &kty, &Holding::Owned, &Text::from(format!("k{}_", &span.start)));
                        let pv = rust_pat(&lx, second, &vty, &Holding::Owned, &Text::from(format!("e{}", &span.start)));
                        (Array::from(vec![crate::lower::model::Do::DoLet(pk.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(key_name.clone())))), crate::lower::model::Do::DoLet(pv.pa.clone(), crate::lower::model::Ex::XClone(Rc::new(crate::lower::model::Ex::XVar(val_name.clone()))))]), bind_all(&bind_all(&env_k, &pk.binds), &pv.binds))
                    },
                },
            };
            call_then(start_upd_tail_from(lx.clone(), env_b.clone(), env_b.clone(), body.clone(), Nat::from(0u32), body.span.clone(), {
                let pack = pack.clone();
                Rc::new(move |(p0, p1): (Env, crate::lower::model::Ex)| {
                    let pack = pack.clone();
                    once_job(move || {
                        let o2 = p0;
                        let e2 = p1;
                        prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("prism_rtl::Turn::Finished"), Array::from(vec![pack.clone()])))
                    })
                }) as Rc<dyn Fn((Env, crate::lower::model::Ex)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
            }), move |upd_tail_from_159938: crate::lower::model::Ex| {
                let turn = prepend(&binds, &upd_tail_from_159938);
                let step_fn = prepend(&cap_dos, &crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(key_name.clone())), kt.clone()), crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(val_name.clone())), vt.clone())]), Rc::new(turn.clone())));
                let out_caps = caps_in(&outer, &rest_text_, &names);
                let out_dos = each(&out_caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
                let outer2 = fold(&out_caps, &outer, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
                let env2 = fold(&out_caps, &env_s, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
                let looping = if is_array { Text::lit("for_turns_indexed") } else { Text::lit("for_turns_keyed") };
                call_value((&cont_fn)((outer2.clone(), env2.clone())), move |cont_160786: crate::lower::model::Ex| {
                    let enter = crate::lower::model::Ex::XCall(Text::lit("call_then"), Array::from(vec![crate::lower::model::Ex::XCall(looping.clone(), Array::from(vec![src.clone(), pack.clone(), step_fn.clone()])), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(pat.clone()), st_ty.clone())]), Rc::new(cont_160786))]));
                    prism_rtl::Turn::Finished(prepend(&out_dos, &enter))
                })
            })
        })
    }
}

/// `Start ForJob, x`: what the function value is when passed to `@Run`.
pub fn start_for_job(lx: Lx, outer: Env, env: Env, binders_opt: Option<crate::syntax::ForBinders>, source: crate::syntax::Expr, body: crate::syntax::Block, span: crate::syntax::Range, rest_text_: Text, cont_fn: Rc<dyn Fn((Env, Env)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(ForJob { lx, outer, env, binders_opt, source, body, span, rest_text_, cont_fn })
}

/// ```prism
/// InstanceOf: fn Text -> Text
/// ```
pub fn instance_of(k: &Text) -> Text {
    or(&index(&split(k, &Text::lit("#inst")), &Nat::from(0u32)), k)
}

/// ```prism
/// CapsIn: fn Env, Text, [Text] -> [((Text, Ex, Holding, OutTy))]
/// ```
pub fn caps_in(env: &Env, text: &Text, skip: &Array<Text>) -> Array<(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)> {
    fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
        Some(Bn::BnLocal(rs, mode, bt)) => if (crate::check::types::has_text(skip, &place_stem(&rs)) || on_self(&rs)) || !mentions(text, &crate::syntax::lexer::drop_prefix(&instance_of(k), &crate::check::types::marks_of(k))) {
            acc.clone()
        } else {
            push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
        },
        _ => acc.clone(),
    }))
}

/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub fn frame_call(lx: &Lx, env: &Env, e: &crate::syntax::Expr, top: &bool) -> Option<crate::syntax::Expr> {
    if crate::check::env::has_key(&env.spans, &place_key(lx, &e.span)) {
        None
    } else {
        'm161952: {
            let scrutinee = &*e.kind;
            if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                break 'm161952 frame_call(lx, env, &**x, top);
            }
            if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                break 'm161952 match first_frame(lx, env, &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))) {
                    Some(x) => Some(x.clone()),
                    None => if *top {
                        None
                    } else {
                        match tail_callee(lx, env, &**c) {
                            Some(_) => Some(e.clone()),
                            None => match local_job_fn(lx, env, &**c) {
                                Some(_) => Some(e.clone()),
                                None => match prelude_job_call(lx, env, e) {
                                    Some(_) => Some(e.clone()),
                                    None => None,
                                },
                            },
                        }
                    },
                };
            }
            if let crate::syntax::ExprKind::EMatch(x, _) = scrutinee {
                break 'm161952 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EIf(m161952_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x) = &**m161952_3_0 {
                break 'm161952 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EBinary(op, l, r) = scrutinee {
                break 'm161952 if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
                    frame_call(lx, env, &**l, &false)
                } else {
                    first_frame(lx, env, &Array::from(vec![(**l).clone(), (**r).clone()]))
                };
            }
            if let crate::syntax::ExprKind::ETuple(es) = scrutinee {
                break 'm161952 first_frame(lx, env, es);
            }
            if let crate::syntax::ExprKind::EArray(es) = scrutinee {
                break 'm161952 first_frame(lx, env, es);
            }
            if let crate::syntax::ExprKind::EUnary(_, x) = scrutinee {
                break 'm161952 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EField(x, _, _) = scrutinee {
                break 'm161952 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::EIndex(x, i) = scrutinee {
                break 'm161952 first_frame(lx, env, &Array::from(vec![(**x).clone(), (**i).clone()]));
            }
            if let crate::syntax::ExprKind::EMethod(x, _, args) = scrutinee {
                break 'm161952 first_frame(lx, env, &append(&Array::from(vec![(**x).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))));
            }
            if let crate::syntax::ExprKind::ECast(x, _, _) = scrutinee {
                break 'm161952 frame_call(lx, env, &**x, &false);
            }
            if let crate::syntax::ExprKind::ELit(l) = scrutinee {
                break 'm161952 match &l.kind {
                    crate::syntax::LitKind::LText(segs) => first_frame(lx, env, &placeholders(segs)),
                    _ => None,
                };
            }
            None
        }
    }
}

/// The step machine of `FrameCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FrameCall: unbounded fn Lx, Env, Expr, Bool -> ?Expr
/// ```
pub struct FrameCall {
    pub lx: Lx,
    pub env: Env,
    pub e: crate::syntax::Expr,
    pub top: bool,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FrameCall {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx = &self.lx;
        let env = &self.env;
        let e = &self.e;
        let top = &self.top;
        if crate::check::env::has_key(&env.spans, &place_key(lx, &e.span)) {
            prism_rtl::Turn::Finished(None)
        } else {
            'm161952: {
                let scrutinee = &*e.kind;
                if let crate::syntax::ExprKind::EGroup(x) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: *top }));
                }
                if let crate::syntax::ExprKind::ECall(c, args, _, _) = scrutinee {
                    break 'm161952 {
                        let args = args.clone();
                        let c = (**c).clone();
                        let e = e.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        let top = *top;
                        call_then(start_first_frame(lx.clone(), env.clone(), each(&args, &(|a: &crate::syntax::Arg| a.value.clone()))), move |first_frame_162056: Option<crate::syntax::Expr>| match first_frame_162056 {
                            Some(x) => prism_rtl::Turn::Finished(Some(x.clone())),
                            None => if top {
                                prism_rtl::Turn::Finished(None)
                            } else {
                                match tail_callee(&lx, &env, &c) {
                                    Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                    None => call_then(start_local_job_fn(lx.clone(), env.clone(), c.clone()), move |local_job_fn_162287: Option<Vl>| match local_job_fn_162287 {
                                        Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                        None => call_then(start_prelude_job_call(lx.clone(), env.clone(), e.clone()), move |prelude_job_call_162384: Option<crate::lower::model::Ex>| match prelude_job_call_162384 {
                                            Some(_) => prism_rtl::Turn::Finished(Some(e.clone())),
                                            None => prism_rtl::Turn::Finished(None),
                                        }),
                                    }),
                                }
                            },
                        })
                    };
                }
                if let crate::syntax::ExprKind::EMatch(x, _) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EIf(m161952_3_0, _, _) = scrutinee && let crate::syntax::Cond::CondExpr(x) = &**m161952_3_0 {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EBinary(op, l, r) = scrutinee {
                    break 'm161952 if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
                        prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**l).clone(), top: false }))
                    } else {
                        prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: Array::from(vec![(**l).clone(), (**r).clone()]) }))
                    };
                }
                if let crate::syntax::ExprKind::ETuple(es) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: es.clone() }));
                }
                if let crate::syntax::ExprKind::EArray(es) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: es.clone() }));
                }
                if let crate::syntax::ExprKind::EUnary(_, x) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EField(x, _, _) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::EIndex(x, i) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: Array::from(vec![(**x).clone(), (**i).clone()]) }));
                }
                if let crate::syntax::ExprKind::EMethod(x, _, args) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: append(&Array::from(vec![(**x).clone()]), &each(args, &(|a: &crate::syntax::Arg| a.value.clone()))) }));
                }
                if let crate::syntax::ExprKind::ECast(x, _, _) = scrutinee {
                    break 'm161952 prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: (**x).clone(), top: false }));
                }
                if let crate::syntax::ExprKind::ELit(l) = scrutinee {
                    break 'm161952 match &l.kind {
                        crate::syntax::LitKind::LText(segs) => prism_rtl::Turn::More(Rc::new(FirstFrame { lx: lx.clone(), env: env.clone(), es: placeholders(segs) })),
                        _ => prism_rtl::Turn::Finished(None),
                    };
                }
                prism_rtl::Turn::Finished(None)
            }
        }
    }
}

/// `Start FrameCall, x`: what the function value is when passed to `@Run`.
pub fn start_frame_call(lx: Lx, env: Env, e: crate::syntax::Expr, top: bool) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FrameCall { lx, env, e, top })
}

/// ```prism
/// Placeholders: fn [TextSeg] -> [Expr]
/// ```
pub fn placeholders(segs: &Array<crate::syntax::TextSeg>) -> Array<crate::syntax::Expr> {
    fold(segs, &Array::new(), &(|acc: &Array<crate::syntax::Expr>, sg: &crate::syntax::TextSeg| match sg {
        crate::syntax::TextSeg::SegPlaceholder(x) => push(acc, x),
        _ => acc.clone(),
    }))
}

/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub fn first_frame(lx: &Lx, env: &Env, es: &Array<crate::syntax::Expr>) -> Option<crate::syntax::Expr> {
    run_to_end(fold_job(es.clone(), None, {
        let lx = lx.clone();
        let env = env.clone();
        Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
            let lx = lx.clone();
            let env = env.clone();
            entered(once_job(move || {
                let found_opt = p0;
                let x = p1;
                match &found_opt {
                    Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                    None => prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: x.clone(), top: false })),
                }
            }))
        }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
    }))
}

/// The step machine of `FirstFrame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?FirstFrame: unbounded fn Lx, Env, [Expr] -> ?Expr
/// ```
pub struct FirstFrame {
    pub lx: Lx,
    pub env: Env,
    pub es: Array<crate::syntax::Expr>,
}

impl prism_rtl::Job<Option<crate::syntax::Expr>> for FirstFrame {
    fn cycle(&self) -> prism_rtl::Turn<Option<crate::syntax::Expr>> {
        let lx = &self.lx;
        let env = &self.env;
        let es = &self.es;
        fold_job(es.clone(), None, {
            let lx = lx.clone();
            let env = env.clone();
            Rc::new(move |(p0, p1): (Option<crate::syntax::Expr>, crate::syntax::Expr)| {
                let lx = lx.clone();
                let env = env.clone();
                entered(once_job(move || {
                    let found_opt = p0;
                    let x = p1;
                    match &found_opt {
                        Some(f) => prism_rtl::Turn::Finished(Some(f.clone())),
                        None => prism_rtl::Turn::More(Rc::new(FrameCall { lx: lx.clone(), env: env.clone(), e: x.clone(), top: false })),
                    }
                }))
            }) as Rc<dyn Fn((Option<crate::syntax::Expr>, crate::syntax::Expr)) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>>>
        }).cycle()
    }
}

/// `Start FirstFrame, x`: what the function value is when passed to `@Run`.
pub fn start_first_frame(lx: Lx, env: Env, es: Array<crate::syntax::Expr>) -> Rc<dyn prism_rtl::Job<Option<crate::syntax::Expr>>> {
    Rc::new(FirstFrame { lx, env, es })
}

/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub fn frame(lx: &Lx, env: &Env, call: &crate::syntax::Expr, rest_text_: &Text, cont_fn: &Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> crate::lower::model::Ex {
    match &*call.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => {
            let qk_opt = tail_callee(lx, env, &**c);
            let qk = or(&qk_opt, &Text::lit(""));
            let base_ = match &qk_opt {
                Some(q) => or(&get(&lx.rs_names, q), &snake(&crate::check::types::bare_name(q))),
                None => snake(&callee_text(&**c)),
            };
            let v_ = Text::from(format!("{}_{}", &base_, &call.span.start));
            let t = out_ty_of(lx, &peel(&type_at(lx, &call.span)));
            let caps = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
                Some(Bn::BnLocal(rs, mode, bt)) => if ((&mode == &Holding::ByRef) || (&mode == &Holding::RcRef)) && mentions(rest_text_, &instance_of(k)) {
                    push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
                } else {
                    acc.clone()
                },
                _ => acc.clone(),
            }));
            let dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
            let env2 = fold(&caps, env, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
            let vals = match &qk_opt {
                Some(q) => named_args_owned(lx, &env2, q, args),
                None => match local_job_fn(lx, &env2, &**c) {
                    Some(f) => start_args(lx, &env2, &f, args),
                    None => run_to_end(each_job(args.clone(), {
                        let lx = lx.clone();
                        let env2 = env2.clone();
                        Rc::new(move |p0: crate::syntax::Arg| {
                            let lx = lx.clone();
                            let env2 = env2.clone();
                            entered(once_job(move || {
                                let a = p0;
                                call_then(start_value_of(lx.clone(), env2.clone(), a.value.clone()), move |value_of_165107: Vl| prism_rtl::Turn::Finished(own(&value_of_165107)))
                            }))
                        }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                    })),
                },
            };
            let env3 = bind_span(&env2, &place_key(lx, &call.span), &Vl::VlOwned(crate::lower::model::Ex::XVar(v_.clone()), t.clone()));
            let body = run_to_end(cont_fn(env3.clone()));
            let (job, how) = match &qk_opt {
                Some(q) => (crate::lower::model::Ex::XCall(path_in(lx, &owner_of(q), &Text::from(format!("start_{}", &base_))), vals.clone()), if enters_at_once(lx, q, args) {
                    Text::lit("call_value")
                } else {
                    Text::lit("call_then")
                }),
                None => match local_job_fn(lx, &env2, &**c) {
                    Some(f) => (start_call(&f, &vals), Text::lit("call_value")),
                    None => match prelude_job_call(lx, &env2, call) {
                        Some(pj) => (pj.clone(), Text::lit("call_value")),
                        None => (refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                    },
                },
            };
            let enter = crate::lower::model::Ex::XCall(how.clone(), Array::from(vec![job.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_.clone())), t.clone())]), Rc::new(body.clone()))]));
            if &len(&dos) == &Nat::from(0u32) {
                enter.clone()
            } else {
                crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(enter.clone()))
            }
        },
        _ => run_to_end(cont_fn(env.clone())),
    }
}

/// The step machine of `Frame`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Frame: unbounded fn Lx, Env, Expr, Text, (unbounded fn Env -> Ex) -> Ex
/// ```
pub struct Frame {
    pub lx: Lx,
    pub env: Env,
    pub call: crate::syntax::Expr,
    pub rest_text_: Text,
    pub cont_fn: Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for Frame {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let call = &self.call;
        let rest_text_ = &self.rest_text_;
        let cont_fn = &self.cont_fn;
        match &*call.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => {
                let qk_opt = tail_callee(lx, env, &**c);
                let qk = or(&qk_opt, &Text::lit(""));
                let base_ = match &qk_opt {
                    Some(q) => or(&get(&lx.rs_names, q), &snake(&crate::check::types::bare_name(q))),
                    None => snake(&callee_text(&**c)),
                };
                let v_ = Text::from(format!("{}_{}", &base_, &call.span.start));
                let cont_fn = cont_fn.clone();
                let args = args.clone();
                let c = (**c).clone();
                let call = call.clone();
                let env = env.clone();
                let lx = lx.clone();
                let rest_text_ = rest_text_.clone();
                call_then(start_out_ty_of(lx.clone(), peel(&type_at(&lx, &call.span))), move |out_ty_of_164352: crate::lower::model::OutTy| {
                    let t = out_ty_of_164352;
                    let caps = fold(&keys(&env.names), &Array::new(), &(|acc: &Array<(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)>, k: &Text| match get(&env.names, k) {
                        Some(Bn::BnLocal(rs, mode, bt)) => if ((&mode == &Holding::ByRef) || (&mode == &Holding::RcRef)) && mentions(&rest_text_, &instance_of(k)) {
                            push(acc, &(k.clone(), rs.clone(), mode.clone(), bt.clone()))
                        } else {
                            acc.clone()
                        },
                        _ => acc.clone(),
                    }));
                    let dos = each(&caps, &(|(_, rs, mode, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(place_stem(rs)), own(&Vl::VlPlace(rs.clone(), mode.clone(), bt.clone())))));
                    let env2 = fold(&caps, &env, &(|en: &Env, (k, rs, _, bt): &(Text, crate::lower::model::Ex, Holding, crate::lower::model::OutTy)| bind(en, k, &Bn::BnLocal(crate::lower::model::Ex::XVar(place_stem(rs)), Holding::Owned, bt.clone()))));
                    let vals = match &qk_opt {
                        Some(q) => named_args_owned(&lx, &env2, q, &args),
                        None => match local_job_fn(&lx, &env2, &c) {
                            Some(f) => start_args(&lx, &env2, &f, &args),
                            None => run_to_end(each_job(args.clone(), {
                                let lx = lx.clone();
                                let env2 = env2.clone();
                                Rc::new(move |p0: crate::syntax::Arg| {
                                    let lx = lx.clone();
                                    let env2 = env2.clone();
                                    entered(once_job(move || {
                                        let a = p0;
                                        call_then(start_value_of(lx.clone(), env2.clone(), a.value.clone()), move |value_of_165107: Vl| prism_rtl::Turn::Finished(own(&value_of_165107)))
                                    }))
                                }) as Rc<dyn Fn(crate::syntax::Arg) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
                            })),
                        },
                    };
                    let env3 = bind_span(&env2, &place_key(&lx, &call.span), &Vl::VlOwned(crate::lower::model::Ex::XVar(v_.clone()), t.clone()));
                    call_value((&cont_fn)(env3.clone()), move |cont_165235: crate::lower::model::Ex| {
                        let body = cont_165235;
                        let (job, how) = match &qk_opt {
                            Some(q) => (crate::lower::model::Ex::XCall(path_in(&lx, &owner_of(q), &Text::from(format!("start_{}", &base_))), vals.clone()), if enters_at_once(&lx, q, &args) {
                                Text::lit("call_value")
                            } else {
                                Text::lit("call_then")
                            }),
                            None => match local_job_fn(&lx, &env2, &c) {
                                Some(f) => (start_call(&f, &vals), Text::lit("call_value")),
                                None => match prelude_job_call(&lx, &env2, &call) {
                                    Some(pj) => (pj.clone(), Text::lit("call_value")),
                                    None => (refusal(&Text::lit("a call this frame cannot enter")), Text::lit("call_then")),
                                },
                            },
                        };
                        let enter = crate::lower::model::Ex::XCall(how.clone(), Array::from(vec![job.clone(), crate::lower::model::Ex::XClosure(true, Array::from(vec![crate::lower::model::Pa::PaTyped(Rc::new(crate::lower::model::Pa::PaBind(v_.clone())), t.clone())]), Rc::new(body.clone()))]));
                        if &len(&dos) == &Nat::from(0u32) {
                            prism_rtl::Turn::Finished(enter.clone())
                        } else {
                            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(dos.clone(), Rc::new(enter.clone())))
                        }
                    })
                })
            },
            _ => cont_fn(env.clone()).cycle(),
        }
    }
}

/// `Start Frame, x`: what the function value is when passed to `@Run`.
pub fn start_frame(lx: Lx, env: Env, call: crate::syntax::Expr, rest_text_: Text, cont_fn: Rc<dyn Fn(Env) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(Frame { lx, env, call, rest_text_, cont_fn })
}

/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub fn local_job_fn(lx: &Lx, env: &Env, c: &crate::syntax::Expr) -> Option<Vl> {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
            job_value(&name_value(lx, env, n, &c.span))
        } else {
            None
        },
        crate::syntax::ExprKind::EGroup(x) => local_job_fn(lx, env, &**x),
        crate::syntax::ExprKind::EField(_, _, _) => job_value(&value_of(lx, env, c)),
        _ => None,
    }
}

/// The step machine of `LocalJobFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?LocalJobFn: unbounded fn Lx, Env, Expr -> ?Vl
/// ```
pub struct LocalJobFn {
    pub lx: Lx,
    pub env: Env,
    pub c: crate::syntax::Expr,
}

impl prism_rtl::Job<Option<Vl>> for LocalJobFn {
    fn cycle(&self) -> prism_rtl::Turn<Option<Vl>> {
        let lx = &self.lx;
        let env = &self.env;
        let c = &self.c;
        match &*c.kind {
            crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
                {
                    let c = c.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_then(start_name_value(lx.clone(), env.clone(), n.clone(), c.span.clone()), move |name_value_166152: Vl| prism_rtl::Turn::Finished(job_value(&name_value_166152)))
                }
            } else {
                prism_rtl::Turn::Finished(None)
            },
            crate::syntax::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(LocalJobFn { lx: lx.clone(), env: env.clone(), c: (**x).clone() })),
            crate::syntax::ExprKind::EField(_, _, _) => {
                let c = c.clone();
                let env = env.clone();
                let lx = lx.clone();
                call_then(start_value_of(lx.clone(), env.clone(), c.clone()), move |value_of_166283: Vl| prism_rtl::Turn::Finished(job_value(&value_of_166283)))
            },
            _ => prism_rtl::Turn::Finished(None),
        }
    }
}

/// `Start LocalJobFn, x`: what the function value is when passed to `@Run`.
pub fn start_local_job_fn(lx: Lx, env: Env, c: crate::syntax::Expr) -> Rc<dyn prism_rtl::Job<Option<Vl>>> {
    Rc::new(LocalJobFn { lx, env, c })
}

/// ```prism
/// ?JobValue: fn Vl -> ?Vl
/// ```
pub fn job_value(f: &Vl) -> Option<Vl> {
    match value_ty(f) {
        crate::lower::model::OutTy::OutJobFn(_, _) => Some(f.clone()),
        _ => None,
    }
}

/// ```prism
/// StartCall: fn Vl, [Ex] -> Ex
/// ```
pub fn start_call(f: &Vl, vals: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    crate::lower::model::Ex::XApply(Rc::new(ref_(f)), Array::from(vec![one_or_tuple(vals)]))
}

/// ```prism
/// OneOrTuple: fn [Ex] -> Ex
/// ```
pub fn one_or_tuple(xs0: &Array<crate::lower::model::Ex>) -> crate::lower::model::Ex {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 1) && let Some(one) = index(c0_0, &Nat::from(0u32)) {
            break 'c one.clone();
        }
        if let vals = xs0 {
            break 'c crate::lower::model::Ex::XTuple(vals.clone());
        }
        unreachable!("no clause matched")
    }
}

/// ```prism
/// CalleeText: fn Expr -> Text
/// ```
pub fn callee_text(c: &crate::syntax::Expr) -> Text {
    match &*c.kind {
        crate::syntax::ExprKind::EName(n) => crate::check::env::dotted(&n.path_),
        crate::syntax::ExprKind::EGroup(x) => callee_text(&**x),
        _ => Text::lit("call"),
    }
}

/// ```prism
/// RestText: fn Lx, Range, Range, Range -> Text
/// ```
pub fn rest_text(lx: &Lx, from: &crate::syntax::Range, call: &crate::syntax::Range, to: &crate::syntax::Range) -> Text {
    match index(&lx.g.srcs, &lx.file) {
        Some(src) => crate::check::errors::span_text(&src, &crate::syntax::Range { start: from.start.clone(), end: to.end.clone() }),
        None => Text::lit(""),
    }
}

/// ```prism
/// Mentions: fn Text, Text -> Bool
/// ```
pub fn mentions(text: &Text, name: &Text) -> bool {
    let parts = split(text, name);
    let last = crate::syntax::lexer::dec(&len(&parts));
    fold(&crate::check::errors::range0(&last), &false, &(|found: &bool, i: &Nat| {
        let before_ = or(&index(&parts, i), &Text::lit(""));
        let after_ = or(&index(&parts, &(i + &Nat::from(1u32))), &Text::lit(""));
        let left_word = if &before_ != &Text::lit("") {
            ends_ident(&before_)
        } else {
            (i > &Nat::from(0u32)) && ends_ident(name)
        };
        let right_word = if &after_ != &Text::lit("") {
            starts_ident(&after_)
        } else {
            (&(i + &Nat::from(1u32)) < &last) && starts_ident(name)
        };
        *found || (!left_word && !right_word)
    }))
}

/// ```prism
/// EndsIdent: fn Text -> Bool
/// ```
pub fn ends_ident(t: &Text) -> bool {
    (&len_text(t) > &Nat::from(0u32)) && crate::syntax::lexer::is_ident_char(&crate::syntax::lexer::last_char(t))
}

/// ```prism
/// StartsIdent: fn Text -> Bool
/// ```
pub fn starts_ident(t: &Text) -> bool {
    (&len_text(t) > &Nat::from(0u32)) && crate::syntax::lexer::is_ident_char(&crate::syntax::lexer::head(t))
}

/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub fn tail_body(lx: &Lx, env: &Env, fn_body2: &crate::syntax::FnBody) -> crate::lower::model::Ex {
    match fn_body2 {
        crate::syntax::FnBody::BodyExpr(x) => tail(lx, env, x),
        crate::syntax::FnBody::BodyBlock(b) => tail_block(lx, env, b),
    }
}

/// The step machine of `TailBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailBody: unbounded fn Lx, Env, FnBody -> Ex
/// ```
pub struct TailBody {
    pub lx: Lx,
    pub env: Env,
    pub fn_body2: crate::syntax::FnBody,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let fn_body2 = &self.fn_body2;
        match fn_body2 {
            crate::syntax::FnBody::BodyExpr(x) => prism_rtl::Turn::More(Rc::new(Tail { lx: lx.clone(), env: env.clone(), e: x.clone() })),
            crate::syntax::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(TailBlock { lx: lx.clone(), env: env.clone(), b: b.clone() })),
        }
    }
}

/// `Start TailBody, x`: what the function value is when passed to `@Run`.
pub fn start_tail_body(lx: Lx, env: Env, fn_body2: crate::syntax::FnBody) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailBody { lx, env, fn_body2 })
}

/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub fn tail_match(lx: &Lx, env: &Env, s: &crate::syntax::Expr, arms: &Array<crate::syntax::Arm>, span: &crate::syntax::Range) -> crate::lower::model::Ex {
    let sv = value_of(lx, env, s);
    let sty = type_at(lx, &s.span);
    let label = Text::from(format!("m{}", &span.start));
    let by_ref = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let lx = lx.clone();
        let arms = arms.clone();
        let sty = sty.clone();
        let label = label.clone();
        Rc::new(move |p0: Nat| {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
    }));
    let chain = fold(&by_ref, &false, &(|f: &bool, po: &PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
    let owned = match &sv {
        Vl::VlOwned(_, _) => !chain,
        _ => false,
    };
    let pats = if owned {
        run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
            let lx = lx.clone();
            let arms = arms.clone();
            let sty = sty.clone();
            let label = label.clone();
            Rc::new(move |p0: Nat| {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                entered(once_job(move || {
                    let i = p0;
                    prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
        }))
    } else {
        by_ref.clone()
    };
    let xarms = run_to_end(each_job(crate::check::errors::range0(&len(arms)), {
        let arms = arms.clone();
        let pats = pats.clone();
        let env = env.clone();
        let lx = lx.clone();
        Rc::new(move |p0: Nat| {
            let arms = arms.clone();
            let pats = pats.clone();
            let env = env.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let arm = or(&index(&arms, &i), &dummy_arm());
                    let po = or(&index(&pats, &i), &PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                    let env2 = bind_all(&env, &po.binds);
                    call_then(start_guard_conds(lx.clone(), env2.clone(), arm.guard.clone()), move |guard_conds_169193: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx.clone(), env2.clone(), arm.body.clone()), move |tail_block_169234: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard_conds_169193), body: tail_block_169234 })))
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
    }));
    let scrut = if owned { own(&sv) } else { ref_(&sv) };
    own(&arms_value(&scrut, &xarms, &Text::from(format!("'{}", &label)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))))
}

/// The step machine of `TailMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailMatch: unbounded fn Lx, Env, Expr, [Arm], Range -> Ex
/// ```
pub struct TailMatch {
    pub lx: Lx,
    pub env: Env,
    pub s: crate::syntax::Expr,
    pub arms: Array<crate::syntax::Arm>,
    pub span: crate::syntax::Range,
}

impl prism_rtl::Job<crate::lower::model::Ex> for TailMatch {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let env = &self.env;
        let s = &self.s;
        let arms = &self.arms;
        let span = &self.span;
        let arms = arms.clone();
        let env = env.clone();
        let lx = lx.clone();
        let s = s.clone();
        let span = span.clone();
        call_then(start_value_of(lx.clone(), env.clone(), s.clone()), move |value_of_168415: Vl| {
            let sv = value_of_168415;
            let sty = type_at(&lx, &s.span);
            let label = Text::from(format!("m{}", &span.start));
            call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                let lx = lx.clone();
                let arms = arms.clone();
                let sty = sty.clone();
                let label = label.clone();
                Rc::new(move |p0: Nat| {
                    let lx = lx.clone();
                    let arms = arms.clone();
                    let sty = sty.clone();
                    let label = label.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::ByRef, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
            }), move |each_168514: Array<PatOut>| {
                let by_ref = each_168514;
                let chain = fold(&by_ref, &false, &(|f: &bool, po: &PatOut| *f || fold(&po.conds, &false, &(|f2: &bool, c: &crate::lower::model::Cc| *f2 || is_let_cond(c)))));
                let owned = match &sv {
                    Vl::VlOwned(_, _) => !chain,
                    _ => false,
                };
                let pats = if owned {
                    run_to_end(each_job(crate::check::errors::range0(&len(&arms)), {
                        let lx = lx.clone();
                        let arms = arms.clone();
                        let sty = sty.clone();
                        let label = label.clone();
                        Rc::new(move |p0: Nat| {
                            let lx = lx.clone();
                            let arms = arms.clone();
                            let sty = sty.clone();
                            let label = label.clone();
                            entered(once_job(move || {
                                let i = p0;
                                prism_rtl::Turn::More(Rc::new(ArmPat { lx: lx.clone(), opt1: or(&index(&arms, &i), &dummy_arm()).pattern.clone(), ty: sty.clone(), mode: Holding::Owned, fresh: Text::from(format!("{}_{}", &label, &i)) }))
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<PatOut>>>
                    }))
                } else {
                    by_ref.clone()
                };
                call_value(each_job(crate::check::errors::range0(&len(&arms)), {
                    let arms = arms.clone();
                    let pats = pats.clone();
                    let env = env.clone();
                    let lx = lx.clone();
                    Rc::new(move |p0: Nat| {
                        let arms = arms.clone();
                        let pats = pats.clone();
                        let env = env.clone();
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let i = p0;
                            {
                                let arm = or(&index(&arms, &i), &dummy_arm());
                                let po = or(&index(&pats, &i), &PatOut { pa: crate::lower::model::Pa::PaWild, conds: Array::new(), binds: Array::new() });
                                let env2 = bind_all(&env, &po.binds);
                                call_then(start_guard_conds(lx.clone(), env2.clone(), arm.guard.clone()), move |guard_conds_169193: Array<crate::lower::model::Cc>| call_then(start_tail_block(lx.clone(), env2.clone(), arm.body.clone()), move |tail_block_169234: crate::lower::model::Ex| prism_rtl::Turn::Finished(crate::lower::model::XArm { pat: po.pa.clone(), conds: append(&po.conds, &guard_conds_169193), body: tail_block_169234 })))
                            }
                        }))
                    }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<crate::lower::model::XArm>>>
                }), move |each_168960: Array<crate::lower::model::XArm>| {
                    let xarms = each_168960;
                    let scrut = if owned { own(&sv) } else { ref_(&sv) };
                    prism_rtl::Turn::Finished(own(&arms_value(&scrut, &xarms, &Text::from(format!("'{}", &label)), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")))))
                })
            })
        })
    }
}

/// `Start TailMatch, x`: what the function value is when passed to `@Run`.
pub fn start_tail_match(lx: Lx, env: Env, s: crate::syntax::Expr, arms: Array<crate::syntax::Arm>, span: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(TailMatch { lx, env, s, arms, span })
}

/// ```prism
/// ?TailCallee: fn Lx, Env, Expr -> ?Text
/// ```
pub fn tail_callee(lx: &Lx, env: &Env, callee: &crate::syntax::Expr) -> Option<Text> {
    match &*callee.kind {
        crate::syntax::ExprKind::EName(n) => if (&len(&n.path_) == &Nat::from(1u32)) && crate::check::env::has_key(&env.names, &crate::check::env::sname_key(n)) {
            None
        } else {
            {
                let (qk_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                match &qk_opt {
                    Some(qk) => if crate::check::types::has_text(&lx.unbs, qk) && !in_prelude(lx, qk) {
                        Some(qk.clone())
                    } else {
                        None
                    },
                    None => None,
                }
            }
        },
        _ => None,
    }
}

/// ```prism
/// SchemeParts: fn Lx, Text -> (([Ty], Ty))
/// ```
pub fn scheme_parts(lx: &Lx, qk: &Text) -> (Array<crate::check::types::Ty>, crate::check::types::Ty) {
    match get(&lx.g.vals, qk) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        },
        None => (Array::new(), crate::check::types::Ty::TyErr),
    }
}

/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub fn job_field_names(lx: &Lx, qk: &Text) -> Array<Text> {
    let clauses = clauses_of(&lx.g, qk);
    let (ptys, _) = scheme_parts(lx, qk);
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    each(&param_names(lx, &clauses, &pts), &(|(n, _): &(Text, bool)| n.clone()))
}

/// The step machine of `JobFieldNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobFieldNames: unbounded fn Lx, Text -> [Text]
/// ```
pub struct JobFieldNames {
    pub lx: Lx,
    pub qk: Text,
}

impl prism_rtl::Job<Array<Text>> for JobFieldNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = clauses_of(&lx.g, qk);
        let (ptys, _) = scheme_parts(lx, qk);
        let lx = lx.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_170301: Array<crate::lower::model::OutTy>| {
            let pts = each_170301;
            prism_rtl::Turn::Finished(each(&param_names(&lx, &clauses, &pts), &(|(n, _): &(Text, bool)| n.clone())))
        })
    }
}

/// `Start JobFieldNames, x`: what the function value is when passed to `@Run`.
pub fn start_job_field_names(lx: Lx, qk: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobFieldNames { lx, qk })
}

/// ```prism
/// ClausesOf: fn G, Text -> [FnClause]
/// ```
pub fn clauses_of(g: &crate::check::env::G, qk: &Text) -> Array<crate::syntax::FnClause> {
    fold(&g.defs, &Array::new(), &(|acc: &Array<crate::syntax::FnClause>, d: &crate::check::env::Def| if &d.qk == qk { def_clauses(d, acc) } else { acc.clone() }))
}

/// ```prism
/// DefClauses: fn Def, [FnClause] -> [FnClause]
/// ```
pub fn def_clauses(d: &crate::check::env::Def, other: &Array<crate::syntax::FnClause>) -> Array<crate::syntax::FnClause> {
    match &d.body {
        crate::check::env::DefBody::DbFn(cs) => cs.clone(),
        _ => other.clone(),
    }
}

/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub fn job_def_of(lx: &Lx, qk: &Text, clauses: &Array<crate::syntax::FnClause>, sc: &crate::check::types::Scheme) -> crate::lower::model::JobDef {
    let (ptys, res) = match &sc.ty {
        crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
        other => (Array::new(), other.clone()),
    };
    let pts = run_to_end(each_job(ptys.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::types::Ty| {
            let lx = lx.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
            }))
        }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
    }));
    let names = param_names(lx, clauses, &pts);
    let body = job_clauses(lx, clauses, &names, &ptys, &pts);
    let base_ = or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk)));
    crate::lower::model::JobDef { name: camel(&crate::check::types::bare_name(qk)), start: Text::from(format!("start_{}", &base_)), generics: scheme_generics(lx, sc), fields: each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit)))), ret: out_ty_of(lx, &peel(&res)), body: body.clone(), doc: signature_text(lx, qk) }
}

/// The step machine of `JobDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobDefOf: unbounded fn Lx, Text, [FnClause], Scheme -> JobDef
/// ```
pub struct JobDefOf {
    pub lx: Lx,
    pub qk: Text,
    pub clauses: Array<crate::syntax::FnClause>,
    pub sc: crate::check::types::Scheme,
}

impl prism_rtl::Job<crate::lower::model::JobDef> for JobDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::JobDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let (ptys, res) = match &sc.ty {
            crate::check::types::Ty::TyFn(_, ps, r) => (ps.clone(), (**r).clone()),
            other => (Array::new(), other.clone()),
        };
        let clauses = clauses.clone();
        let lx = lx.clone();
        let qk = qk.clone();
        let sc = sc.clone();
        call_value(each_job(ptys.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::types::Ty| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(OutTyOf { lx: lx.clone(), t: peel(&p_) }))
                }))
            }) as Rc<dyn Fn(crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>>>
        }), move |each_170955: Array<crate::lower::model::OutTy>| {
            let pts = each_170955;
            let names = param_names(&lx, &clauses, &pts);
            call_then(start_job_clauses(lx.clone(), clauses.clone(), names.clone(), ptys.clone(), pts.clone()), move |job_clauses_171051: crate::lower::model::Ex| {
                let body = job_clauses_171051;
                let base_ = or(&get(&lx.rs_names, &qk), &snake(&crate::check::types::bare_name(&qk)));
                call_then(start_out_ty_of(lx.clone(), peel(&res)), move |out_ty_of_171362: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::JobDef { name: camel(&crate::check::types::bare_name(&qk)), start: Text::from(format!("start_{}", &base_)), generics: scheme_generics(&lx, &sc), fields: each(&crate::check::errors::range0(&len(&pts)), &(|i: &Nat| (or(&index(&each(&names, &(|(n, _): &(Text, bool)| n.clone())), i), &Text::lit("arg")), or(&index(&pts, i), &crate::lower::model::OutTy::OutUnit)))), ret: out_ty_of_171362, body: body.clone(), doc: signature_text(&lx, &qk) }))
            })
        })
    }
}

/// `Start JobDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_job_def_of(lx: Lx, qk: Text, clauses: Array<crate::syntax::FnClause>, sc: crate::check::types::Scheme) -> Rc<dyn prism_rtl::Job<crate::lower::model::JobDef>> {
    Rc::new(JobDefOf { lx, qk, clauses, sc })
}

/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub fn job_clauses(lx: &Lx, clauses: &Array<crate::syntax::FnClause>, names: &Array<(Text, bool)>, ptys: &Array<crate::check::types::Ty>, pts: &Array<crate::lower::model::OutTy>) -> crate::lower::model::Ex {
    let lets = each(&crate::check::errors::range0(&len(names)), &(|i: &Nat| {
        let (rs, _) = or(&index(names, i), &(Text::lit("arg"), true));
        crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()))))
    }));
    let inner = clauses_body(lx, &empty_env(), clauses, names, ptys, &(Rc::new(|(a0, a1, a2): (Lx, Env, crate::syntax::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>), &Text::lit("j"), &crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn")));
    crate::lower::model::Ex::XBlock(lets.clone(), Rc::new(inner.clone()))
}

/// The step machine of `JobClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobClauses: unbounded fn Lx, [FnClause], [((Text, Bool))], [Ty], [OutTy] -> Ex
/// ```
pub struct JobClauses {
    pub lx: Lx,
    pub clauses: Array<crate::syntax::FnClause>,
    pub names: Array<(Text, bool)>,
    pub ptys: Array<crate::check::types::Ty>,
    pub pts: Array<crate::lower::model::OutTy>,
}

impl prism_rtl::Job<crate::lower::model::Ex> for JobClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Ex> {
        let lx = &self.lx;
        let clauses = &self.clauses;
        let names = &self.names;
        let ptys = &self.ptys;
        let pts = &self.pts;
        let lets = each(&crate::check::errors::range0(&len(names)), &(|i: &Nat| {
            let (rs, _) = or(&index(names, i), &(Text::lit("arg"), true));
            crate::lower::model::Do::DoLet(crate::lower::model::Pa::PaBind(rs.clone()), crate::lower::model::Ex::XRef(Rc::new(crate::lower::model::Ex::XField(Rc::new(crate::lower::model::Ex::XSelf), rs.clone()))))
        }));
        let clauses = clauses.clone();
        let lx = lx.clone();
        let names = names.clone();
        let ptys = ptys.clone();
        call_then(start_clauses_body(lx.clone(), empty_env(), clauses.clone(), names.clone(), ptys.clone(), Rc::new(|(a0, a1, a2): (Lx, Env, crate::syntax::FnBody)| entered(start_tail_body(a0, a1, a2))) as Rc<dyn Fn((Lx, Env, crate::syntax::FnBody)) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>, Text::lit("j"), crate::lower::model::OutTy::OutUnknown(Text::lit("the job's turn"))), move |clauses_body_171791: crate::lower::model::Ex| {
            let inner = clauses_body_171791;
            prism_rtl::Turn::Finished(crate::lower::model::Ex::XBlock(lets.clone(), Rc::new(inner.clone())))
        })
    }
}

/// `Start JobClauses, x`: what the function value is when passed to `@Run`.
pub fn start_job_clauses(lx: Lx, clauses: Array<crate::syntax::FnClause>, names: Array<(Text, bool)>, ptys: Array<crate::check::types::Ty>, pts: Array<crate::lower::model::OutTy>) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>> {
    Rc::new(JobClauses { lx, clauses, names, ptys, pts })
}

/// ```prism
/// InModule: fn Lx, Nat, Text -> Lx
/// ```
pub fn in_module(lx: &Lx, file: &Nat, home: &Text) -> Lx {
    let mut this: Lx = lx.clone();
    this.file = file.clone();
    this.home = home.clone();
    this.site = home.clone();
    this
}

/// ```prism
/// InModuleAt: fn Lx, Nat, Text, Text -> Lx
/// ```
pub fn in_module_at(lx: &Lx, file: &Nat, home: &Text, site: &Text) -> Lx {
    let mut this: Lx = lx.clone();
    this.file = file.clone();
    this.home = home.clone();
    this.site = site.clone();
    this
}

/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub fn lower_program(srcs: &Array<crate::check::errors::Src>, trees: &Array<crate::syntax::Module>, shown: &Nat, tp: &crate::check::typed::TProgram, name: &Text) -> crate::lower::model::Model {
    let (g, _) = crate::check::env::build_g(srcs, trees);
    let (tys, apps, bs, ims) = typed_tables(tp);
    let gens = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::InstNote>>, n: &crate::check::typed::InstNote| insert(m, &inst_key(n), &push(&or(&get(m, &inst_key(n)), &Array::new()), n))));
    let quants = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, Text>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, Text>, q: &Text| insert(m2, q, &n.name)))));
    let gen_of_q = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, crate::check::typed::GenNote>, q: &Text| insert(m2, q, n)))));
    let use_insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, crate::check::typed::InstNote>, n: &crate::check::typed::InstNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let mods = needed_mods(&g, shown);
    let rs_mods = fold(&mods, &Map::new(), &(|acc: &Map<Text, Text>, m: &Text| insert(acc, m, &rust_mod_name(m))));
    let lx0 = Lx { g: g.clone(), tys: tys.clone(), apps: apps.clone(), binders: bs.clone(), impls: ims.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods.clone(), rs_names: value_names(&g), layouts: layouts(&g), unbs: Array::new(), notes: Array::new(), globals: global_names(&g), in_node: false, unshrunk: fold(&tp.unshrunk, &Map::new(), &(|m: &Map<Text, bool>, a: &crate::check::typed::SrcAt| insert(m, &crate::check::typed::at_key(a), &true))), gens: gens.clone(), insts: insts.clone(), quants: quants.clone(), gen_of_q: gen_of_q.clone(), use_insts: use_insts.clone(), subst: Map::new(), csubst: Map::new() };
    let lx = {
        let mut this: Lx = lx0.clone();
        this.unbs = job_roots(&lx0);
        this
    };
    let roots = root_widgets(&lx);
    let mod_defs = run_to_end(each_job(mods.clone(), {
        let lx = lx.clone();
        let roots = roots.clone();
        let g = g.clone();
        let mods = mods.clone();
        Rc::new(move |p0: Text| {
            let lx = lx.clone();
            let roots = roots.clone();
            let g = g.clone();
            let mods = mods.clone();
            entered(once_job(move || {
                let m = p0;
                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0: lx.clone(), m: m.clone(), roots: roots.clone(), info: or(&get(&g.mods, &m), &crate::check::env::dummy_mod()), mods: mods.clone() }))
            }))
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }));
    let programs = run_to_end(each_job(roots.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: (Text, bool)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (qk, _) = p0;
                prism_rtl::Turn::More(Rc::new(ProgDefOf { lx: lx.clone(), qk: qk.clone() }))
            }))
        }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
    }));
    let main_qk = fold(&g.defs, &Text::lit(""), &(|found: &Text, d: &crate::check::env::Def| if (found == &Text::lit("")) && is_main(&d.qk) { d.qk.clone() } else { found.clone() }));
    let root_opt = if &main_qk == &Text::lit("") { None } else { Some(prog_def_of(&lx, &main_qk)) };
    let checks = run_to_end(fold_job(g.defs.clone(), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                match &d.body {
                    crate::check::env::DefBody::DbCheck(c) => {
                        let c = c.clone();
                        call_then(start_check_def_of(in_module_at(&lx, &d.file, &d.home, &Text::lit("\0main")), c.clone()), move |check_def_of_174466: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc, &check_def_of_174466)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
    }));
    let with_needs_ = with_groups(&with_needs(&g, srcs, tp, &mod_defs));
    let elem = elem_row(&lx, &mods);
    let answer = answer_enum(&in_module_at(&lx, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), &mods);
    let names = each(&with_needs_, &(|d: &crate::lower::model::ModDef| d.name.clone()));
    let value_tys = value_types(&with_needs_);
    let elem_held = fold(&elem.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new())))));
    let answer_held = fold(&answer.cases, &elem_held, &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &k.ty))));
    let answer_named = fold(&answer.cases, &Array::new(), &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &named_in(&names, &Text::lit(""), &k.ty))));
    crate::lower::model::Model { name: name.clone(), mods: with_needs_.clone(), programs: programs.clone(), root: root_opt.clone(), checks: checks.clone(), elem: elem.clone(), answer: answer.clone(), elem_complete: answer_held.clone(), elem_declared: crate::check::types::minus_texts(&answer_named, &answer_held), scripts: Array::new(), notes: Array::new() }
}

/// The step machine of `LowerProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LowerProgram: unbounded fn [Src], [Module], Nat, TProgram, Text -> Model
/// ```
pub struct LowerProgram {
    pub srcs: Array<crate::check::errors::Src>,
    pub trees: Array<crate::syntax::Module>,
    pub shown: Nat,
    pub tp: crate::check::typed::TProgram,
    pub name: Text,
}

impl prism_rtl::Job<crate::lower::model::Model> for LowerProgram {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::Model> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let shown = &self.shown;
        let tp = &self.tp;
        let name = &self.name;
        let name = name.clone();
        let shown = shown.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        let trees = trees.clone();
        call_then(crate::check::env::start_build_g(srcs.clone(), trees.clone()), move |build_g_172975: (crate::check::env::G, crate::check::types::St)| {
            let (g, _) = build_g_172975;
            let (tys, apps, bs, ims) = typed_tables(&tp);
            let gens = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
            let insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::InstNote>>, n: &crate::check::typed::InstNote| insert(m, &inst_key(n), &push(&or(&get(m, &inst_key(n)), &Array::new()), n))));
            let quants = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, Text>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, Text>, q: &Text| insert(m2, q, &n.name)))));
            let gen_of_q = fold(&tp.gens, &Map::new(), &(|m: &Map<Text, crate::check::typed::GenNote>, n: &crate::check::typed::GenNote| fold(&append(&n.tys, &n.cols), m, &(|m2: &Map<Text, crate::check::typed::GenNote>, q: &Text| insert(m2, q, n)))));
            let use_insts = fold(&tp.insts, &Map::new(), &(|m: &Map<Text, crate::check::typed::InstNote>, n: &crate::check::typed::InstNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
            call_then(start_needed_mods(g.clone(), shown.clone()), move |needed_mods_173501: Array<Text>| {
                let mods = needed_mods_173501;
                let rs_mods = fold(&mods, &Map::new(), &(|acc: &Map<Text, Text>, m: &Text| insert(acc, m, &rust_mod_name(m))));
                call_then(start_layouts(g.clone()), move |layouts_173733: Map<Text, Array<bool>>| {
                    let lx0 = Lx { g: g.clone(), tys: tys.clone(), apps: apps.clone(), binders: bs.clone(), impls: ims.clone(), file: Nat::from(0u32), home: Text::lit(""), site: Text::lit(""), rs_mods: rs_mods.clone(), rs_names: value_names(&g), layouts: layouts_173733, unbs: Array::new(), notes: Array::new(), globals: global_names(&g), in_node: false, unshrunk: fold(&tp.unshrunk, &Map::new(), &(|m: &Map<Text, bool>, a: &crate::check::typed::SrcAt| insert(m, &crate::check::typed::at_key(a), &true))), gens: gens.clone(), insts: insts.clone(), quants: quants.clone(), gen_of_q: gen_of_q.clone(), use_insts: use_insts.clone(), subst: Map::new(), csubst: Map::new() };
                    let lx = {
                        let mut this: Lx = lx0.clone();
                        this.unbs = job_roots(&lx0);
                        this
                    };
                    let roots = root_widgets(&lx);
                    call_value(each_job(mods.clone(), {
                        let lx = lx.clone();
                        let roots = roots.clone();
                        let g = g.clone();
                        let mods = mods.clone();
                        Rc::new(move |p0: Text| {
                            let lx = lx.clone();
                            let roots = roots.clone();
                            let g = g.clone();
                            let mods = mods.clone();
                            entered(once_job(move || {
                                let m = p0;
                                prism_rtl::Turn::More(Rc::new(ModDefOf { lx0: lx.clone(), m: m.clone(), roots: roots.clone(), info: or(&get(&g.mods, &m), &crate::check::env::dummy_mod()), mods: mods.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
                    }), move |each_174075: Array<crate::lower::model::ModDef>| {
                        let mod_defs = each_174075;
                        call_value(each_job(roots.clone(), {
                            let lx = lx.clone();
                            Rc::new(move |p0: (Text, bool)| {
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let (qk, _) = p0;
                                    prism_rtl::Turn::More(Rc::new(ProgDefOf { lx: lx.clone(), qk: qk.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, bool)) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>>>
                        }), move |each_174164: Array<crate::lower::model::ProgDef>| {
                            let programs = each_174164;
                            let main_qk = fold(&g.defs, &Text::lit(""), &(|found: &Text, d: &crate::check::env::Def| if (found == &Text::lit("")) && is_main(&d.qk) { d.qk.clone() } else { found.clone() }));
                            let root_opt = if &main_qk == &Text::lit("") { None } else { Some(prog_def_of(&lx, &main_qk)) };
                            call_value(fold_job(g.defs.clone(), Array::new(), {
                                let lx = lx.clone();
                                Rc::new(move |(p0, p1): (Array<crate::lower::model::CheckDef>, crate::check::env::Def)| {
                                    let lx = lx.clone();
                                    entered(once_job(move || {
                                        let acc = p0;
                                        let d = p1;
                                        match &d.body {
                                            crate::check::env::DefBody::DbCheck(c) => {
                                                let c = c.clone();
                                                call_then(start_check_def_of(in_module_at(&lx, &d.file, &d.home, &Text::lit("\0main")), c.clone()), move |check_def_of_174466: crate::lower::model::CheckDef| prism_rtl::Turn::Finished(push(&acc, &check_def_of_174466)))
                                            },
                                            _ => prism_rtl::Turn::Finished(acc.clone()),
                                        }
                                    }))
                                }) as Rc<dyn Fn((Array<crate::lower::model::CheckDef>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::CheckDef>>>>
                            }), move |fold_174393: Array<crate::lower::model::CheckDef>| {
                                let checks = fold_174393;
                                call_then(start_with_needs(g.clone(), srcs.clone(), tp.clone(), mod_defs.clone()), move |with_needs_174581: Array<crate::lower::model::ModDef>| call_then(start_with_groups(with_needs_174581), move |with_groups_174569: Array<crate::lower::model::ModDef>| {
                                    let with_needs_ = with_groups_174569;
                                    call_then(start_elem_row(lx.clone(), mods.clone()), move |elem_row_174628: crate::lower::model::RowDef| {
                                        let elem = elem_row_174628;
                                        call_then(start_answer_enum(in_module_at(&lx, &Nat::from(0u32), &Text::lit(""), &Text::lit("\0main")), mods.clone()), move |answer_enum_174662: crate::lower::model::AnswerDef| {
                                            let answer = answer_enum_174662;
                                            let names = each(&with_needs_, &(|d: &crate::lower::model::ModDef| d.name.clone()));
                                            let value_tys = value_types(&with_needs_);
                                            let elem_held = fold(&elem.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new())))));
                                            let answer_held = fold(&answer.cases, &elem_held, &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &held_in(&names, &value_tys, &Text::lit(""), &k.ty))));
                                            let answer_named = fold(&answer.cases, &Array::new(), &(|acc: &Array<Text>, k: &crate::lower::model::AnswerCase| crate::check::types::union_texts(acc, &named_in(&names, &Text::lit(""), &k.ty))));
                                            prism_rtl::Turn::Finished(crate::lower::model::Model { name: name.clone(), mods: with_needs_.clone(), programs: programs.clone(), root: root_opt.clone(), checks: checks.clone(), elem: elem.clone(), answer: answer.clone(), elem_complete: answer_held.clone(), elem_declared: crate::check::types::minus_texts(&answer_named, &answer_held), scripts: Array::new(), notes: Array::new() })
                                        })
                                    })
                                }))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start LowerProgram, x`: what the function value is when passed to `@Run`.
pub fn start_lower_program(srcs: Array<crate::check::errors::Src>, trees: Array<crate::syntax::Module>, shown: Nat, tp: crate::check::typed::TProgram, name: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::Model>> {
    Rc::new(LowerProgram { srcs, trees, shown, tp, name })
}

/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub fn with_needs(g: &crate::check::env::G, srcs: &Array<crate::check::errors::Src>, tp: &crate::check::typed::TProgram, defs: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let names = each(defs, &(|d: &crate::lower::model::ModDef| d.name.clone()));
    let value_tys = value_types(defs);
    let refs = named_mods(g, srcs, tp, &each(defs, &(|d: &crate::lower::model::ModDef| d.prism.clone())));
    run_to_end(each_job(defs.clone(), {
        let names = names.clone();
        let value_tys = value_tys.clone();
        let refs = refs.clone();
        Rc::new(move |p0: crate::lower::model::ModDef| {
            let names = names.clone();
            let value_tys = value_tys.clone();
            let refs = refs.clone();
            entered(once_job(move || {
                let d = p0;
                {
                    let held = fold(&d.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::lower::model::Item| crate::check::types::union_texts(acc, &item_held(&names, &value_tys, &d.name, it))));
                    let complete = filter(&held, &(|n: &Text| n != &d.name));
                    call_then(start_reached_by(refs.clone(), Array::from(vec![d.prism.clone()]), Array::new()), move |reached_by_175876: Array<Text>| {
                        let reached = each(&reached_by_175876, &(|m: &Text| rust_mod_name(m)));
                        let declared = filter(&names, &(|n: &Text| ((n != &d.name) && crate::check::types::has_text(&reached, n)) && !crate::check::types::has_text(&complete, n)));
                        prism_rtl::Turn::Finished({
                            let mut this: crate::lower::model::ModDef = d.clone();
                            this.complete = complete.clone();
                            this.declared = declared.clone();
                            this
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
    }))
}

/// The step machine of `WithNeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithNeeds: unbounded fn G, [Src], TProgram, [ModDef] -> [ModDef]
/// ```
pub struct WithNeeds {
    pub g: crate::check::env::G,
    pub srcs: Array<crate::check::errors::Src>,
    pub tp: crate::check::typed::TProgram,
    pub defs: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithNeeds {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let g = &self.g;
        let srcs = &self.srcs;
        let tp = &self.tp;
        let defs = &self.defs;
        let names = each(defs, &(|d: &crate::lower::model::ModDef| d.name.clone()));
        let value_tys = value_types(defs);
        let defs = defs.clone();
        let g = g.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        call_then(start_named_mods(g.clone(), srcs.clone(), tp.clone(), each(&defs, &(|d: &crate::lower::model::ModDef| d.prism.clone()))), move |named_mods_175621: Map<Text, Array<Text>>| {
            let refs = named_mods_175621;
            each_job(defs.clone(), {
                let names = names.clone();
                let value_tys = value_tys.clone();
                let refs = refs.clone();
                Rc::new(move |p0: crate::lower::model::ModDef| {
                    let names = names.clone();
                    let value_tys = value_tys.clone();
                    let refs = refs.clone();
                    entered(once_job(move || {
                        let d = p0;
                        {
                            let held = fold(&d.items, &Array::new(), &(|acc: &Array<Text>, it: &crate::lower::model::Item| crate::check::types::union_texts(acc, &item_held(&names, &value_tys, &d.name, it))));
                            let complete = filter(&held, &(|n: &Text| n != &d.name));
                            call_then(start_reached_by(refs.clone(), Array::from(vec![d.prism.clone()]), Array::new()), move |reached_by_175876: Array<Text>| {
                                let reached = each(&reached_by_175876, &(|m: &Text| rust_mod_name(m)));
                                let declared = filter(&names, &(|n: &Text| ((n != &d.name) && crate::check::types::has_text(&reached, n)) && !crate::check::types::has_text(&complete, n)));
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::lower::model::ModDef = d.clone();
                                    this.complete = complete.clone();
                                    this.declared = declared.clone();
                                    this
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(crate::lower::model::ModDef) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>>>
            }).cycle()
        })
    }
}

/// `Start WithNeeds, x`: what the function value is when passed to `@Run`.
pub fn start_with_needs(g: crate::check::env::G, srcs: Array<crate::check::errors::Src>, tp: crate::check::typed::TProgram, defs: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithNeeds { g, srcs, tp, defs })
}

/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub fn named_mods(g: &crate::check::env::G, srcs: &Array<crate::check::errors::Src>, tp: &crate::check::typed::TProgram, ms: &Array<Text>) -> Map<Text, Array<Text>> {
    let by_path = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Text, Text>, info: &crate::check::env::ModInfo| insert(acc, &or(&index(srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info.name)));
    let by_file = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Nat, Text>, info: &crate::check::env::ModInfo| insert(acc, &info.file, &info.name)));
    let solved = fold(&tp.impls, &Map::new(), &(|acc: &Map<Text, Array<Text>>, n: &crate::check::typed::ImplNote| match get(&by_file, &n.at.file) {
        Some(site) => match get(&by_path, &impl_path(&n.how)) {
            Some(home) => if (&home == &site) || crate::check::types::has_text(&or(&get(acc, &site), &Array::new()), &home) {
                acc.clone()
            } else {
                insert(acc, &site, &push(&or(&get(acc, &site), &Array::new()), &home))
            },
            None => acc.clone(),
        },
        None => acc.clone(),
    }));
    run_to_end(fold_job(ms.clone(), Map::new(), {
        let g = g.clone();
        let srcs = srcs.clone();
        let ms = ms.clone();
        let solved = solved.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
            let g = g.clone();
            let srcs = srcs.clone();
            let ms = ms.clone();
            let solved = solved.clone();
            entered(once_job(move || {
                let acc = p0;
                let m = p1;
                match get(&g.mods, &m) {
                    Some(info) => {
                        let code = crate::syntax::lexer::join(&filter(&split(&or(&index(&srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l: &Text| !crate::syntax::lexer::has_prefix(&crate::syntax::lexer::trim_start(l), &Text::lit("#")))), &Text::lit("\n"));
                        let qualified = filter(&ms, &(|o: &Text| ((o != &m) && (o != &Text::lit(""))) && crate::syntax::lexer::contains(&code, &Text::from(format!("{}.", o)))));
                        call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_177523: Array<Text>| prism_rtl::Turn::Finished(insert(&acc, &m, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_177523, &qualified), &or(&get(&solved, &m), &Array::new())))))
                    },
                    None => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }))
}

/// The step machine of `NamedMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NamedMods: unbounded fn G, [Src], TProgram, [Text] -> (Text ==> [Text])
/// ```
pub struct NamedMods {
    pub g: crate::check::env::G,
    pub srcs: Array<crate::check::errors::Src>,
    pub tp: crate::check::typed::TProgram,
    pub ms: Array<Text>,
}

impl prism_rtl::Job<Map<Text, Array<Text>>> for NamedMods {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Array<Text>>> {
        let g = &self.g;
        let srcs = &self.srcs;
        let tp = &self.tp;
        let ms = &self.ms;
        let by_path = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Text, Text>, info: &crate::check::env::ModInfo| insert(acc, &or(&index(srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).path_, &info.name)));
        let by_file = fold(&values(&g.mods), &Map::new(), &(|acc: &Map<Nat, Text>, info: &crate::check::env::ModInfo| insert(acc, &info.file, &info.name)));
        let solved = fold(&tp.impls, &Map::new(), &(|acc: &Map<Text, Array<Text>>, n: &crate::check::typed::ImplNote| match get(&by_file, &n.at.file) {
            Some(site) => match get(&by_path, &impl_path(&n.how)) {
                Some(home) => if (&home == &site) || crate::check::types::has_text(&or(&get(acc, &site), &Array::new()), &home) {
                    acc.clone()
                } else {
                    insert(acc, &site, &push(&or(&get(acc, &site), &Array::new()), &home))
                },
                None => acc.clone(),
            },
            None => acc.clone(),
        }));
        fold_job(ms.clone(), Map::new(), {
            let g = g.clone();
            let srcs = srcs.clone();
            let ms = ms.clone();
            let solved = solved.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, Text)| {
                let g = g.clone();
                let srcs = srcs.clone();
                let ms = ms.clone();
                let solved = solved.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let m = p1;
                    match get(&g.mods, &m) {
                        Some(info) => {
                            let code = crate::syntax::lexer::join(&filter(&split(&or(&index(&srcs, &info.file), &crate::check::errors::mk_src(&Text::lit(""), &Text::lit(""))).text, &Text::lit("\n")), &(|l: &Text| !crate::syntax::lexer::has_prefix(&crate::syntax::lexer::trim_start(l), &Text::lit("#")))), &Text::lit("\n"));
                            let qualified = filter(&ms, &(|o: &Text| ((o != &m) && (o != &Text::lit(""))) && crate::syntax::lexer::contains(&code, &Text::from(format!("{}.", o)))));
                            call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_177523: Array<Text>| prism_rtl::Turn::Finished(insert(&acc, &m, &crate::check::types::union_texts(&crate::check::types::union_texts(&mod_refs_177523, &qualified), &or(&get(&solved, &m), &Array::new())))))
                        },
                        None => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }).cycle()
    }
}

/// `Start NamedMods, x`: what the function value is when passed to `@Run`.
pub fn start_named_mods(g: crate::check::env::G, srcs: Array<crate::check::errors::Src>, tp: crate::check::typed::TProgram, ms: Array<Text>) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>> {
    Rc::new(NamedMods { g, srcs, tp, ms })
}

/// ```prism
/// ImplPath: fn Text -> Text
/// ```
pub fn impl_path(how: &Text) -> Text {
    let rest = or(&crate::syntax::lexer::after_prefix(how, &Text::lit("impl ")), &or(&crate::syntax::lexer::after_prefix(how, &Text::lit("derived ")), &Text::lit("")));
    let parts = split(&rest, &Text::lit(":"));
    crate::syntax::lexer::join(&take(&parts, &crate::syntax::lexer::dec(&len(&parts))), &Text::lit(":"))
}

/// ```prism
/// ValueTypes: fn [ModDef] -> (Text ==> Bool)
/// ```
pub fn value_types(defs: &Array<crate::lower::model::ModDef>) -> Map<Text, bool> {
    fold(defs, &Map::new(), &(|acc: &Map<Text, bool>, d: &crate::lower::model::ModDef| fold(&d.items, acc, &(|a: &Map<Text, bool>, it: &crate::lower::model::Item| match it {
        crate::lower::model::Item::ItType(t) => match &t.shape {
            crate::lower::model::TyShape::ShapeChoice => a.clone(),
            _ => insert(a, &Text::from(format!("{}::{}", &d.name, &t.name)), &true),
        },
        crate::lower::model::Item::ItTag(t) => insert(a, &Text::from(format!("{}::{}", &d.name, &t.name)), &true),
        _ => a.clone(),
    }))))
}

/// ```prism
/// ItemHeld: fn [Text], (Text ==> Bool), Text, Item -> [Text]
/// ```
pub fn item_held(names: &Array<Text>, value_tys: &Map<Text, bool>, home: &Text, it: &crate::lower::model::Item) -> Array<Text> {
    match it {
        crate::lower::model::Item::ItType(t) => fold(&t.cases, &Array::new(), &(|acc: &Array<Text>, c: &crate::lower::model::CaseDef| fold(&c.fields, acc, &(|a: &Array<Text>, (_, ft): &(Text, crate::lower::model::OutTy)| crate::check::types::union_texts(a, &held_in(names, value_tys, home, ft)))))),
        crate::lower::model::Item::ItTag(t) => fold(&t.fields, &Array::new(), &(|acc: &Array<Text>, (_, _, ft): &(Text, Text, crate::lower::model::OutTy)| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, ft)))),
        crate::lower::model::Item::ItRow(r) => fold(&r.cases, &Array::new(), &(|acc: &Array<Text>, (_, sp): &(Text, Text)| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, &crate::lower::model::OutTy::OutNamed(sp.clone(), Array::new()))))),
        _ => Array::new(),
    }
}

/// ```prism
/// HeldIn: fn [Text], (Text ==> Bool), Text, OutTy -> [Text]
/// ```
pub fn held_in(names: &Array<Text>, value_tys: &Map<Text, bool>, home: &Text, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let p_ = path_from(names, home, n);
            let own_ = if crate::check::env::has_key(value_tys, &p_) {
                Array::from(vec![parent_of(&p_)])
            } else {
                Array::new()
            };
            fold(args, &own_, &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, a))))
        },
        crate::lower::model::OutTy::OutOpt(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutRes(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutCell(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutRc(i) => held_in(names, value_tys, home, &**i),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &held_in(names, value_tys, home, a)))),
        _ => Array::new(),
    }
}

/// ```prism
/// NamedIn: fn [Text], Text, OutTy -> [Text]
/// ```
pub fn named_in(names: &Array<Text>, home: &Text, t: &crate::lower::model::OutTy) -> Array<Text> {
    match t {
        crate::lower::model::OutTy::OutNamed(n, args) => {
            let p_ = path_from(names, home, n);
            let own_ = if crate::check::types::has_text(names, &parent_of(&p_)) {
                Array::from(vec![parent_of(&p_)])
            } else {
                Array::new()
            };
            fold(args, &own_, &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a))))
        },
        crate::lower::model::OutTy::OutOpt(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutRes(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutCell(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutArray(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutRc(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutEvent(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutDyn(i) => named_in(names, home, &**i),
        crate::lower::model::OutTy::OutMap(k, v_) => crate::check::types::union_texts(&named_in(names, home, &**k), &named_in(names, home, &**v_)),
        crate::lower::model::OutTy::OutTuple(ts) => fold(ts, &Array::new(), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a)))),
        crate::lower::model::OutTy::OutFn(ps, r) => fold(ps, &named_in(names, home, &**r), &(|acc: &Array<Text>, a: &crate::lower::model::OutTy| crate::check::types::union_texts(acc, &named_in(names, home, a)))),
        _ => Array::new(),
    }
}

/// ```prism
/// PathFrom: fn [Text], Text, Text -> Text
/// ```
pub fn path_from(names: &Array<Text>, home: &Text, n: &Text) -> Text {
    let q = crate::syntax::lexer::drop_prefix(n, &Text::lit("crate::"));
    if starts_with_module(names, &q) {
        q.clone()
    } else {
        if home == &Text::lit("") {
            q.clone()
        } else {
            Text::from(format!("{}::{}", home, &q))
        }
    }
}

/// ```prism
/// StartsWithModule: fn [Text], Text -> Bool
/// ```
pub fn starts_with_module(names: &Array<Text>, q: &Text) -> bool {
    fold(names, &false, &(|f: &bool, n: &Text| *f || ((n != &Text::lit("")) && crate::syntax::lexer::has_prefix(q, &Text::from(format!("{}::", n))))))
}

/// ```prism
/// ParentOf: fn Text -> Text
/// ```
pub fn parent_of(p_: &Text) -> Text {
    let segs = split(p_, &Text::lit("::"));
    crate::syntax::lexer::join(&take(&segs, &crate::syntax::lexer::dec(&len(&segs))), &Text::lit("::"))
}

/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub fn with_groups(defs: &Array<crate::lower::model::ModDef>) -> Array<crate::lower::model::ModDef> {
    let edges = fold(defs, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::lower::model::ModDef| insert(m, &d.name, &d.complete)));
    let reach = run_to_end(fold_job(defs.clone(), Map::new(), {
        let edges = edges.clone();
        Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
            let edges = edges.clone();
            entered(once_job(move || {
                let m = p0;
                let d = p1;
                call_then(start_reached_by(edges.clone(), Array::from(vec![d.name.clone()]), Array::new()), move |reached_by_181809: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &d.name, &reached_by_181809)))
            }))
        }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
    }));
    each(defs, &(|d: &crate::lower::model::ModDef| {
        let mine = or(&get(&reach, &d.name), &Array::new());
        {
            let mut this: crate::lower::model::ModDef = d.clone();
            this.types_with = filter(&each(defs, &(|o: &crate::lower::model::ModDef| o.name.clone())), &(|n: &Text| (n == &d.name) || (crate::check::types::has_text(&mine, n) && crate::check::types::has_text(&or(&get(&reach, n), &Array::new()), &d.name))));
            this
        }
    }))
}

/// The step machine of `WithGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WithGroups: unbounded fn [ModDef] -> [ModDef]
/// ```
pub struct WithGroups {
    pub defs: Array<crate::lower::model::ModDef>,
}

impl prism_rtl::Job<Array<crate::lower::model::ModDef>> for WithGroups {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::ModDef>> {
        let defs = &self.defs;
        let edges = fold(defs, &Map::new(), &(|m: &Map<Text, Array<Text>>, d: &crate::lower::model::ModDef| insert(m, &d.name, &d.complete)));
        let defs = defs.clone();
        call_value(fold_job(defs.clone(), Map::new(), {
            let edges = edges.clone();
            Rc::new(move |(p0, p1): (Map<Text, Array<Text>>, crate::lower::model::ModDef)| {
                let edges = edges.clone();
                entered(once_job(move || {
                    let m = p0;
                    let d = p1;
                    call_then(start_reached_by(edges.clone(), Array::from(vec![d.name.clone()]), Array::new()), move |reached_by_181809: Array<Text>| prism_rtl::Turn::Finished(insert(&m, &d.name, &reached_by_181809)))
                }))
            }) as Rc<dyn Fn((Map<Text, Array<Text>>, crate::lower::model::ModDef)) -> Rc<dyn prism_rtl::Job<Map<Text, Array<Text>>>>>
        }), move |fold_181767: Map<Text, Array<Text>>| {
            let reach = fold_181767;
            prism_rtl::Turn::Finished(each(&defs, &(|d: &crate::lower::model::ModDef| {
                let mine = or(&get(&reach, &d.name), &Array::new());
                {
                    let mut this: crate::lower::model::ModDef = d.clone();
                    this.types_with = filter(&each(&defs, &(|o: &crate::lower::model::ModDef| o.name.clone())), &(|n: &Text| (n == &d.name) || (crate::check::types::has_text(&mine, n) && crate::check::types::has_text(&or(&get(&reach, n), &Array::new()), &d.name))));
                    this
                }
            })))
        })
    }
}

/// `Start WithGroups, x`: what the function value is when passed to `@Run`.
pub fn start_with_groups(defs: Array<crate::lower::model::ModDef>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::ModDef>>> {
    Rc::new(WithGroups { defs })
}

/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub fn reached_by(edges: &Map<Text, Array<Text>>, todo: &Array<Text>, seen: &Array<Text>) -> Array<Text> {
    match index(todo, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(m) => if crate::check::types::has_text(seen, &m) {
            reached_by(edges, &drop(todo, &Nat::from(1u32)), seen)
        } else {
            reached_by(edges, &append(&drop(todo, &Nat::from(1u32)), &or(&get(edges, &m), &Array::new())), &push(seen, &m))
        },
    }
}

/// The step machine of `ReachedBy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachedBy: unbounded fn (Text ==> [Text]), [Text], [Text] -> [Text]
/// ```
pub struct ReachedBy {
    pub edges: Map<Text, Array<Text>>,
    pub todo: Array<Text>,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachedBy {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let edges = &self.edges;
        let todo = &self.todo;
        let seen = &self.seen;
        match index(todo, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(m) => if crate::check::types::has_text(seen, &m) {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges: edges.clone(), todo: drop(todo, &Nat::from(1u32)), seen: seen.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(ReachedBy { edges: edges.clone(), todo: append(&drop(todo, &Nat::from(1u32)), &or(&get(edges, &m), &Array::new())), seen: push(seen, &m) }))
            },
        }
    }
}

/// `Start ReachedBy, x`: what the function value is when passed to `@Run`.
pub fn start_reached_by(edges: Map<Text, Array<Text>>, todo: Array<Text>, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachedBy { edges, todo, seen })
}

/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub fn needed_mods(g: &crate::check::env::G, shown: &Nat) -> Array<Text> {
    let own_ = filter(&keys(&g.mods), &(|m: &Text| (&or(&get(&g.mods, m), &crate::check::env::dummy_mod()).file < shown) && (m != &Text::lit("Prelude"))));
    let grown = run_to_end(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own_.clone(), {
        let g = g.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let g = g.clone();
            entered(once_job(move || {
                let acc = p0;
                let _ = p1;
                fold_job(acc.clone(), acc.clone(), {
                    let g = g.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let g = g.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let m = p1;
                            call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_182832: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &mod_refs_182832)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    filter(&keys(&g.mods), &(|m: &Text| (m != &Text::lit("Prelude")) && crate::check::types::has_text(&grown, m)))
}

/// The step machine of `NeededMods`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NeededMods: unbounded fn G, Nat -> [Text]
/// ```
pub struct NeededMods {
    pub g: crate::check::env::G,
    pub shown: Nat,
}

impl prism_rtl::Job<Array<Text>> for NeededMods {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let shown = &self.shown;
        let own_ = filter(&keys(&g.mods), &(|m: &Text| (&or(&get(&g.mods, m), &crate::check::env::dummy_mod()).file < shown) && (m != &Text::lit("Prelude"))));
        let g = g.clone();
        call_value(fold_job(crate::check::errors::range0(&Nat::from(6u32)), own_.clone(), {
            let g = g.clone();
            Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                let g = g.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let _ = p1;
                    fold_job(acc.clone(), acc.clone(), {
                        let g = g.clone();
                        Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                            let g = g.clone();
                            entered(once_job(move || {
                                let a = p0;
                                let m = p1;
                                call_then(start_mod_refs(g.clone(), m.clone()), move |mod_refs_182832: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &mod_refs_182832)))
                            }))
                        }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_182757: Array<Text>| {
            let grown = fold_182757;
            prism_rtl::Turn::Finished(filter(&keys(&g.mods), &(|m: &Text| (m != &Text::lit("Prelude")) && crate::check::types::has_text(&grown, m))))
        })
    }
}

/// `Start NeededMods, x`: what the function value is when passed to `@Run`.
pub fn start_needed_mods(g: crate::check::env::G, shown: Nat) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(NeededMods { g, shown })
}

/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub fn mod_refs(g: &crate::check::env::G, m: &Text) -> Array<Text> {
    match get(&g.mods, m) {
        Some(info) => {
            let used = each(&info.uses, &(|(u, _): &(Text, bool)| u.clone()));
            let fams = match &info.tree.emit_row {
                Some(rw) => fold(&rw.terms, &Array::new(), &(|acc: &Array<Text>, t: &crate::syntax::RowTerm| match t {
                    crate::syntax::RowTerm::RFamily(q) => push(acc, &or(&get(&g.fam_owner, &crate::check::env::dotted(&q.path_)), &crate::check::env::dotted(&q.path_))),
                    _ => acc.clone(),
                })),
                None => Array::new(),
            };
            filter(&append(&used, &fams), &(|x: &Text| crate::check::env::has_key(&g.mods, x)))
        },
        None => Array::new(),
    }
}

/// The step machine of `ModRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModRefs: unbounded fn G, Text -> [Text]
/// ```
pub struct ModRefs {
    pub g: crate::check::env::G,
    pub m: Text,
}

impl prism_rtl::Job<Array<Text>> for ModRefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let g = &self.g;
        let m = &self.m;
        match get(&g.mods, m) {
            Some(info) => {
                let used = each(&info.uses, &(|(u, _): &(Text, bool)| u.clone()));
                let fams = match &info.tree.emit_row {
                    Some(rw) => fold(&rw.terms, &Array::new(), &(|acc: &Array<Text>, t: &crate::syntax::RowTerm| match t {
                        crate::syntax::RowTerm::RFamily(q) => push(acc, &or(&get(&g.fam_owner, &crate::check::env::dotted(&q.path_)), &crate::check::env::dotted(&q.path_))),
                        _ => acc.clone(),
                    })),
                    None => Array::new(),
                };
                prism_rtl::Turn::Finished(filter(&append(&used, &fams), &(|x: &Text| crate::check::env::has_key(&g.mods, x))))
            },
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start ModRefs, x`: what the function value is when passed to `@Run`.
pub fn start_mod_refs(g: crate::check::env::G, m: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ModRefs { g, m })
}

/// ```prism
/// RootWidgets: fn Lx -> [((Text, Bool))]
/// ```
pub fn root_widgets(lx: &Lx) -> Array<(Text, bool)> {
    let tested = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Text, bool)>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbTest(t) => match blueprint_qk(&in_module(lx, &d.file, &d.home), &t.blueprint) {
            m183586_0 if (&m183586_0 == &Text::lit("")) => acc.clone(),
            qk => if crate::check::types::has_text(&each(acc, &(|(q, _): &(Text, bool)| q.clone())), &qk) {
                acc.clone()
            } else {
                push(acc, &(qk.clone(), true))
            },
            _ => unreachable!("no arm matched"),
        },
        _ => acc.clone(),
    }));
    let main = fold(&lx.g.defs, &Array::new(), &(|acc: &Array<(Text, bool)>, d: &crate::check::env::Def| if is_main(&d.qk) { push(acc, &(d.qk.clone(), false)) } else { acc.clone() }));
    fold(&main, &tested, &(|acc: &Array<(Text, bool)>, (k, b): &(Text, bool)| if crate::check::types::has_text(&each(acc, &(|(q, _): &(Text, bool)| q.clone())), k) {
        acc.clone()
    } else {
        push(acc, &(k.clone(), *b))
    }))
}

/// ```prism
/// IsMain: fn Text -> Bool
/// ```
pub fn is_main(qk: &Text) -> bool {
    ((&owner_of(qk) == &Text::lit("")) && (&base(&crate::check::types::bare_name(qk)) == &Text::lit("main"))) && crate::syntax::lexer::has_prefix(&crate::check::types::bare_name(qk), &Text::lit("@"))
}

/// ```prism
/// BlueprintQk: fn Lx, Expr -> Text
/// ```
pub fn blueprint_qk(lx: &Lx, e: &crate::syntax::Expr) -> Text {
    match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => blueprint_qk(lx, &**c),
        crate::syntax::ExprKind::EGroup(x) => blueprint_qk(lx, &**x),
        crate::syntax::ExprKind::EName(n) => {
            let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
            or(&q_opt, &Text::lit(""))
        },
        _ => Text::lit(""),
    }
}

/// ```prism
/// ValOf: fn Lx, Text -> ValInfo
/// ```
pub fn val_of(lx: &Lx, qk: &Text) -> crate::check::env::ValInfo {
    match get(&lx.g.vals, qk) {
        Some(v_) => v_.clone(),
        None => {
            let d = fold(&lx.g.defs, &crate::check::env::dummy_def(), &(|found: &crate::check::env::Def, df: &crate::check::env::Def| if &df.qk == qk { df.clone() } else { found.clone() }));
            crate::check::env::ValInfo { qk: qk.clone(), scheme: crate::check::types::mono(&crate::check::types::Ty::TyErr), sort: Text::lit("fn"), has_sig: false, home: d.home.clone(), file: d.file.clone(), span: d.span.clone() }
        },
    }
}

/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub fn prog_def_of(lx: &Lx, qk: &Text) -> crate::lower::model::ProgDef {
    let v_ = val_of(lx, qk);
    let ptys = match &v_.scheme.ty {
        crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
        _ => Array::new(),
    };
    let lxm = in_module_at(lx, &v_.file, &v_.home, &Text::lit("\0main"));
    let params = run_to_end(each_job(crate::check::errors::range0(&len(&ptys)), {
        let lxm = lxm.clone();
        let ptys = ptys.clone();
        Rc::new(move |p0: Nat| {
            let lxm = lxm.clone();
            let ptys = ptys.clone();
            entered(once_job(move || {
                let i = p0;
                call_then(start_out_ty_of(lxm.clone(), peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_185161: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i)), out_ty_of_185161)))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
    }));
    let node_ = Text::from(format!("{}::{}", &rust_mod_name(&v_.home), &camel(&crate::check::types::bare_name(qk))));
    let fams = or(&get(&lx.g.mods, &v_.home), &crate::check::env::dummy_mod()).emit_rw.fams.clone();
    let world = if crate::check::types::has_text(&fams, &Text::lit("Gui")) {
        Text::lit("canvas")
    } else {
        if crate::check::types::has_text(&fams, &Text::lit("Ui")) {
            Text::lit("none")
        } else {
            Text::lit("cli")
        }
    };
    crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &camel(&crate::check::types::bare_name(qk)))), prism: crate::syntax::lexer::after_first(&crate::check::types::bare_name(qk)), node_: node_.clone(), params: params.clone(), fallible: true, world: world.clone() }
}

/// The step machine of `ProgDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ProgDefOf: unbounded fn Lx, Text -> ProgDef
/// ```
pub struct ProgDefOf {
    pub lx: Lx,
    pub qk: Text,
}

impl prism_rtl::Job<crate::lower::model::ProgDef> for ProgDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ProgDef> {
        let lx = &self.lx;
        let qk = &self.qk;
        let v_ = val_of(lx, qk);
        let ptys = match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(_, ps, _) => ps.clone(),
            _ => Array::new(),
        };
        let lxm = in_module_at(lx, &v_.file, &v_.home, &Text::lit("\0main"));
        let lx = lx.clone();
        let qk = qk.clone();
        call_value(each_job(crate::check::errors::range0(&len(&ptys)), {
            let lxm = lxm.clone();
            let ptys = ptys.clone();
            Rc::new(move |p0: Nat| {
                let lxm = lxm.clone();
                let ptys = ptys.clone();
                entered(once_job(move || {
                    let i = p0;
                    call_then(start_out_ty_of(lxm.clone(), peel(&or(&index(&ptys, &i), &crate::check::types::Ty::TyErr))), move |out_ty_of_185161: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::from(format!("arg{}", &i)), out_ty_of_185161)))
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
        }), move |each_185117: Array<(Text, crate::lower::model::OutTy)>| {
            let params = each_185117;
            let node_ = Text::from(format!("{}::{}", &rust_mod_name(&v_.home), &camel(&crate::check::types::bare_name(&qk))));
            let fams = or(&get(&lx.g.mods, &v_.home), &crate::check::env::dummy_mod()).emit_rw.fams.clone();
            let world = if crate::check::types::has_text(&fams, &Text::lit("Gui")) {
                Text::lit("canvas")
            } else {
                if crate::check::types::has_text(&fams, &Text::lit("Ui")) {
                    Text::lit("none")
                } else {
                    Text::lit("cli")
                }
            };
            prism_rtl::Turn::Finished(crate::lower::model::ProgDef { name: Text::from(format!("{}Program", &camel(&crate::check::types::bare_name(&qk)))), prism: crate::syntax::lexer::after_first(&crate::check::types::bare_name(&qk)), node_: node_.clone(), params: params.clone(), fallible: true, world: world.clone() })
        })
    }
}

/// `Start ProgDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_prog_def_of(lx: Lx, qk: Text) -> Rc<dyn prism_rtl::Job<crate::lower::model::ProgDef>> {
    Rc::new(ProgDefOf { lx, qk })
}

/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub fn job_roots(lx: &Lx) -> Array<Text> {
    let direct = run_to_end(fold_job(lx.g.defs.clone(), Array::new(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                {
                    let lxd = in_module(&lx, &d.file, &d.home);
                    call_then(start_run_targets(lxd.clone(), d.clone()), move |run_targets_185996: Array<Text>| call_then(start_unbounded_values(lxd.clone(), d.clone()), move |unbounded_values_186018: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc, &run_targets_185996), &unbounded_values_186018))))
                }
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }));
    run_to_end(fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct.clone(), {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let _ = p1;
                fold_job(acc.clone(), acc.clone(), {
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let qk = p1;
                            call_then(start_tail_targets(lx.clone(), qk.clone()), move |tail_targets_186125: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &tail_targets_186125)))
                        }))
                    }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `JobRoots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// JobRoots: unbounded fn Lx -> [Text]
/// ```
pub struct JobRoots {
    pub lx: Lx,
}

impl prism_rtl::Job<Array<Text>> for JobRoots {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let lx = lx.clone();
        call_value(fold_job(lx.g.defs.clone(), Array::new(), {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::check::env::Def)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let d = p1;
                    {
                        let lxd = in_module(&lx, &d.file, &d.home);
                        call_then(start_run_targets(lxd.clone(), d.clone()), move |run_targets_185996: Array<Text>| call_then(start_unbounded_values(lxd.clone(), d.clone()), move |unbounded_values_186018: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&crate::check::types::union_texts(&acc, &run_targets_185996), &unbounded_values_186018))))
                    }
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }), move |fold_185881: Array<Text>| {
            let direct = fold_185881;
            fold_job(crate::check::errors::range0(&Nat::from(8u32)), direct.clone(), {
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<Text>, Nat)| {
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let _ = p1;
                        fold_job(acc.clone(), acc.clone(), {
                            let lx = lx.clone();
                            Rc::new(move |(p0, p1): (Array<Text>, Text)| {
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let a = p0;
                                    let qk = p1;
                                    call_then(start_tail_targets(lx.clone(), qk.clone()), move |tail_targets_186125: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&a, &tail_targets_186125)))
                                }))
                            }) as Rc<dyn Fn((Array<Text>, Text)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
                        }).cycle()
                    }))
                }) as Rc<dyn Fn((Array<Text>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
            }).cycle()
        })
    }
}

/// `Start JobRoots, x`: what the function value is when passed to `@Run`.
pub fn start_job_roots(lx: Lx) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(JobRoots { lx })
}

/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub fn unbounded_values(lx: &Lx, d: &crate::check::env::Def) -> Array<Text> {
    let es = match &d.body {
        crate::check::env::DefBody::DbWidget(w) => crate::check::typed::block_exprs(&w.body),
        crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::FnClause)| entered(once_job(move || {
            let acc = p0;
            let c = p1;
            call_then(crate::check::typed::start_body_exprs(c.body.clone()), move |body_exprs_186476: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_186476)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        crate::check::env::DefBody::DbLet(l) => crate::check::typed::exprs_in(&l.value),
        _ => Array::new(),
    };
    let callees = fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => push(acc, &place_key(lx, &c.span)),
        _ => acc.clone(),
    }));
    fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::EName(n) => if crate::check::types::has_text(&callees, &place_key(lx, &e.span)) {
            acc.clone()
        } else {
            {
                let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                match &q_opt {
                    Some(q) => if is_unbounded(lx, q) { crate::check::types::add_text(acc, q) } else { acc.clone() },
                    None => acc.clone(),
                }
            }
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `UnboundedValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnboundedValues: unbounded fn Lx, Def -> [Text]
/// ```
pub struct UnboundedValues {
    pub lx: Lx,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for UnboundedValues {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let d = &self.d;
        let es = match &d.body {
            crate::check::env::DefBody::DbWidget(w) => crate::check::typed::block_exprs(&w.body),
            crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::FnClause)| entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(crate::check::typed::start_body_exprs(c.body.clone()), move |body_exprs_186476: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_186476)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            crate::check::env::DefBody::DbLet(l) => crate::check::typed::exprs_in(&l.value),
            _ => Array::new(),
        };
        let callees = fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, _, _, _) => push(acc, &place_key(lx, &c.span)),
            _ => acc.clone(),
        }));
        prism_rtl::Turn::Finished(fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::EName(n) => if crate::check::types::has_text(&callees, &place_key(lx, &e.span)) {
                acc.clone()
            } else {
                {
                    let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                    match &q_opt {
                        Some(q) => if is_unbounded(lx, q) { crate::check::types::add_text(acc, q) } else { acc.clone() },
                        None => acc.clone(),
                    }
                }
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start UnboundedValues, x`: what the function value is when passed to `@Run`.
pub fn start_unbounded_values(lx: Lx, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(UnboundedValues { lx, d })
}

/// ```prism
/// InPrelude: fn Lx, Text -> Bool
/// ```
pub fn in_prelude(lx: &Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => &v_.home == &Text::lit("Prelude"),
        None => false,
    }
}

/// ```prism
/// IsColorPoly: fn Lx, Text -> Bool
/// ```
pub fn is_color_poly(lx: &Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CQ(_), _, _) => true,
            crate::check::types::Ty::TyFn(crate::check::types::Col::CRigid(_), _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// EntersAtOnce: fn Lx, Text, [Arg] -> Bool
/// ```
pub fn enters_at_once(lx: &Lx, q: &Text, args: &Array<crate::syntax::Arg>) -> bool {
    is_color_poly(lx, q) && !fold(args, &false, &(|seen: &bool, a: &crate::syntax::Arg| *seen || is_unbounded_arg(lx, a)))
}

/// ```prism
/// IsUnboundedArg: fn Lx, Arg -> Bool
/// ```
pub fn is_unbounded_arg(lx: &Lx, a: &crate::syntax::Arg) -> bool {
    match peel(&type_at(lx, &a.value.span)) {
        crate::check::types::Ty::TyFn(crate::check::types::Col::CUnbound, _, _) => true,
        _ => false,
    }
}

/// ```prism
/// IsUnbounded: fn Lx, Text -> Bool
/// ```
pub fn is_unbounded(lx: &Lx, q: &Text) -> bool {
    match get(&lx.g.vals, q) {
        Some(v_) => match &v_.scheme.ty {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => false,
            crate::check::types::Ty::TyFn(_, _, _) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub fn run_targets(lx: &Lx, d: &crate::check::env::Def) -> Array<Text> {
    let es = match &d.body {
        crate::check::env::DefBody::DbWidget(w) => crate::check::typed::block_exprs(&w.body),
        crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::FnClause)| entered(once_job(move || {
            let acc = p0;
            let c = p1;
            call_then(crate::check::typed::start_body_exprs(c.body.clone()), move |body_exprs_188705: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_188705)))
        }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
        _ => Array::new(),
    };
    fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, args, _, _) => if &blueprint_qk(lx, &**c) == &Text::lit("Prelude.@Run") {
            match index(args, &Nat::from(0u32)) {
                Some(a) => match &*a.value.kind {
                    crate::syntax::ExprKind::EName(n) => {
                        let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                        match &q_opt {
                            Some(q) => crate::check::types::add_text(acc, q),
                            None => acc.clone(),
                        }
                    },
                    _ => acc.clone(),
                },
                None => acc.clone(),
            }
        } else {
            acc.clone()
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `RunTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RunTargets: unbounded fn Lx, Def -> [Text]
/// ```
pub struct RunTargets {
    pub lx: Lx,
    pub d: crate::check::env::Def,
}

impl prism_rtl::Job<Array<Text>> for RunTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let d = &self.d;
        let es = match &d.body {
            crate::check::env::DefBody::DbWidget(w) => crate::check::typed::block_exprs(&w.body),
            crate::check::env::DefBody::DbFn(cs) => run_to_end(fold_job(cs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<crate::syntax::Expr>, crate::syntax::FnClause)| entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(crate::check::typed::start_body_exprs(c.body.clone()), move |body_exprs_188705: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_188705)))
            }))) as Rc<dyn Fn((Array<crate::syntax::Expr>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<crate::syntax::Expr>>>>)),
            _ => Array::new(),
        };
        prism_rtl::Turn::Finished(fold(&es, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, args, _, _) => if &blueprint_qk(lx, &**c) == &Text::lit("Prelude.@Run") {
                match index(args, &Nat::from(0u32)) {
                    Some(a) => match &*a.value.kind {
                        crate::syntax::ExprKind::EName(n) => {
                            let (q_opt, _) = crate::check::env::resolve_value(&lx.g, &lx.home, n);
                            match &q_opt {
                                Some(q) => crate::check::types::add_text(acc, q),
                                None => acc.clone(),
                            }
                        },
                        _ => acc.clone(),
                    },
                    None => acc.clone(),
                }
            } else {
                acc.clone()
            },
            _ => acc.clone(),
        })))
    }
}

/// `Start RunTargets, x`: what the function value is when passed to `@Run`.
pub fn start_run_targets(lx: Lx, d: crate::check::env::Def) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(RunTargets { lx, d })
}

/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub fn tail_targets(lx: &Lx, qk: &Text) -> Array<Text> {
    let v_ = or(&get(&lx.g.vals, qk), &crate::check::env::builtin(qk, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
    let lxm = in_module(lx, &v_.file, &v_.home);
    run_to_end(fold_job(clauses_of(&lx.g, qk), Array::new(), {
        let lxm = lxm.clone();
        Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FnClause)| {
            let lxm = lxm.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                call_then(start_tails_of_body(lxm.clone(), c.body.clone()), move |tails_of_body_189584: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &tails_of_body_189584)))
            }))
        }) as Rc<dyn Fn((Array<Text>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
    }))
}

/// The step machine of `TailTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailTargets: unbounded fn Lx, Text -> [Text]
/// ```
pub struct TailTargets {
    pub lx: Lx,
    pub qk: Text,
}

impl prism_rtl::Job<Array<Text>> for TailTargets {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let qk = &self.qk;
        let v_ = or(&get(&lx.g.vals, qk), &crate::check::env::builtin(qk, &crate::check::types::mono(&crate::check::types::Ty::TyErr)));
        let lxm = in_module(lx, &v_.file, &v_.home);
        fold_job(clauses_of(&lx.g, qk), Array::new(), {
            let lxm = lxm.clone();
            Rc::new(move |(p0, p1): (Array<Text>, crate::syntax::FnClause)| {
                let lxm = lxm.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    call_then(start_tails_of_body(lxm.clone(), c.body.clone()), move |tails_of_body_189584: Array<Text>| prism_rtl::Turn::Finished(crate::check::types::union_texts(&acc, &tails_of_body_189584)))
                }))
            }) as Rc<dyn Fn((Array<Text>, crate::syntax::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Text>>>>
        }).cycle()
    }
}

/// `Start TailTargets, x`: what the function value is when passed to `@Run`.
pub fn start_tail_targets(lx: Lx, qk: Text) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailTargets { lx, qk })
}

/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub fn tails_of_body(lx: &Lx, body: &crate::syntax::FnBody) -> Array<Text> {
    fold(&crate::check::typed::body_exprs(body), &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
        crate::syntax::ExprKind::ECall(c, _, _, _) => {
            let q = blueprint_qk(lx, &**c);
            match get(&lx.g.vals, &q) {
                Some(v_) => match &v_.scheme.ty {
                    crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc.clone(),
                    crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc, &q),
                    _ => acc.clone(),
                },
                None => acc.clone(),
            }
        },
        _ => acc.clone(),
    }))
}

/// The step machine of `TailsOfBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TailsOfBody: unbounded fn Lx, FnBody -> [Text]
/// ```
pub struct TailsOfBody {
    pub lx: Lx,
    pub body: crate::syntax::FnBody,
}

impl prism_rtl::Job<Array<Text>> for TailsOfBody {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let lx = &self.lx;
        let body = &self.body;
        let body = body.clone();
        let lx = lx.clone();
        call_then(crate::check::typed::start_body_exprs(body.clone()), move |body_exprs_189689: Array<crate::syntax::Expr>| prism_rtl::Turn::Finished(fold(&body_exprs_189689, &Array::new(), &(|acc: &Array<Text>, e: &crate::syntax::Expr| match &*e.kind {
            crate::syntax::ExprKind::ECall(c, _, _, _) => {
                let q = blueprint_qk(&lx, &**c);
                match get(&lx.g.vals, &q) {
                    Some(v_) => match &v_.scheme.ty {
                        crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, _, _) => acc.clone(),
                        crate::check::types::Ty::TyFn(_, _, _) => crate::check::types::add_text(acc, &q),
                        _ => acc.clone(),
                    },
                    None => acc.clone(),
                }
            },
            _ => acc.clone(),
        }))))
    }
}

/// `Start TailsOfBody, x`: what the function value is when passed to `@Run`.
pub fn start_tails_of_body(lx: Lx, body: crate::syntax::FnBody) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(TailsOfBody { lx, body })
}

/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub fn mod_def_of(lx0: &Lx, m: &Text, roots: &Array<(Text, bool)>, info: &crate::check::env::ModInfo, mods: &Array<Text>) -> crate::lower::model::ModDef {
    let lx = in_module(lx0, &info.file, m);
    let path_ = match index(&lx.g.srcs, &info.file) {
        Some(src) => src.path_.clone(),
        None => Text::lit(""),
    };
    let types = run_to_end(fold_job(values(&lx.g.types), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let ti = p1;
                if &ti.home == &m {
                    call_then(start_ty_defs(lx.clone(), ti.clone()), move |ty_defs_190414: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &ty_defs_190414)))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let tags = run_to_end(fold_job(values(&lx.g.tags), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let tg = p1;
                if (&tg.home == &m) && (&tg.kind != &Text::lit("Prelude.Fault")) {
                    call_then(start_tag_def_of(lx.clone(), tg.clone()), move |tag_def_of_190562: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTag(tag_def_of_190562))))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let defs = run_to_end(fold_job(lx.g.defs.clone(), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        let roots = roots.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
            let m = m.clone();
            let lx = lx.clone();
            let roots = roots.clone();
            entered(once_job(move || {
                let acc = p0;
                let d = p1;
                if &d.home == &m {
                    call_then(start_def_items(in_module(&lx, &d.file, &m), d.clone(), roots.clone()), move |def_items_190666: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &def_items_190666)))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let traits = run_to_end(fold_job(values(&lx.g.traits), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let tr = p1;
                if &tr.home == &m {
                    call_then(start_trait_def_of(lx.clone(), tr.clone()), move |trait_def_of_190819: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTrait(trait_def_of_190819))))
                } else {
                    prism_rtl::Turn::Finished(acc.clone())
                }
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let impls = run_to_end(fold_job(values(&lx.g.impls), Array::new(), {
        let m = m.clone();
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
            let m = m.clone();
            let lx = lx.clone();
            entered(once_job(move || {
                let acc = p0;
                let ims = p1;
                fold_job(ims.clone(), acc.clone(), {
                    let m = m.clone();
                    let lx = lx.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                        let m = m.clone();
                        let lx = lx.clone();
                        entered(once_job(move || {
                            let a = p0;
                            let im = p1;
                            if (&im.home == &m) && !im.derived {
                                call_then(start_impl_def_of(in_module(&lx, &im.file, &m), im.clone()), move |impl_def_of_190986: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a, &crate::lower::model::Item::ItImpl(impl_def_of_190986))))
                            } else {
                                prism_rtl::Turn::Finished(a.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
    }));
    let uses = filter(&each(mods, &(|o: &Text| rust_mod_name(o))), &(|o: &Text| o != &rust_mod_name(m)));
    crate::lower::model::ModDef { name: rust_mod_name(m), prism: m.clone(), path_: path_.clone(), uses: uses.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types, &tags), &traits), &impls), &defs) }
}

/// The step machine of `ModDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ModDefOf: unbounded fn Lx, Text, [((Text, Bool))], ModInfo, [Text] -> ModDef
/// ```
pub struct ModDefOf {
    pub lx0: Lx,
    pub m: Text,
    pub roots: Array<(Text, bool)>,
    pub info: crate::check::env::ModInfo,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::ModDef> for ModDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::ModDef> {
        let lx0 = &self.lx0;
        let m = &self.m;
        let roots = &self.roots;
        let info = &self.info;
        let mods = &self.mods;
        let lx = in_module(lx0, &info.file, m);
        let path_ = match index(&lx.g.srcs, &info.file) {
            Some(src) => src.path_.clone(),
            None => Text::lit(""),
        };
        let m = m.clone();
        let mods = mods.clone();
        let roots = roots.clone();
        call_value(fold_job(values(&lx.g.types), Array::new(), {
            let m = m.clone();
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TyInfo)| {
                let m = m.clone();
                let lx = lx.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let ti = p1;
                    if &ti.home == &m {
                        call_then(start_ty_defs(lx.clone(), ti.clone()), move |ty_defs_190414: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &ty_defs_190414)))
                    } else {
                        prism_rtl::Turn::Finished(acc.clone())
                    }
                }))
            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TyInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
        }), move |fold_190341: Array<crate::lower::model::Item>| {
            let types = fold_190341;
            call_value(fold_job(values(&lx.g.tags), Array::new(), {
                let m = m.clone();
                let lx = lx.clone();
                Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TagInfo)| {
                    let m = m.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let tg = p1;
                        if (&tg.home == &m) && (&tg.kind != &Text::lit("Prelude.Fault")) {
                            call_then(start_tag_def_of(lx.clone(), tg.clone()), move |tag_def_of_190562: crate::lower::model::TagDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTag(tag_def_of_190562))))
                        } else {
                            prism_rtl::Turn::Finished(acc.clone())
                        }
                    }))
                }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
            }), move |fold_190454: Array<crate::lower::model::Item>| {
                let tags = fold_190454;
                call_value(fold_job(lx.g.defs.clone(), Array::new(), {
                    let m = m.clone();
                    let lx = lx.clone();
                    let roots = roots.clone();
                    Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::Def)| {
                        let m = m.clone();
                        let lx = lx.clone();
                        let roots = roots.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let d = p1;
                            if &d.home == &m {
                                call_then(start_def_items(in_module(&lx, &d.file, &m), d.clone(), roots.clone()), move |def_items_190666: Array<crate::lower::model::Item>| prism_rtl::Turn::Finished(append(&acc, &def_items_190666)))
                            } else {
                                prism_rtl::Turn::Finished(acc.clone())
                            }
                        }))
                    }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::Def)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                }), move |fold_190605: Array<crate::lower::model::Item>| {
                    let defs = fold_190605;
                    call_value(fold_job(values(&lx.g.traits), Array::new(), {
                        let m = m.clone();
                        let lx = lx.clone();
                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::TraitInfo)| {
                            let m = m.clone();
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let acc = p0;
                                let tr = p1;
                                if &tr.home == &m {
                                    call_then(start_trait_def_of(lx.clone(), tr.clone()), move |trait_def_of_190819: crate::lower::model::TraitDef| prism_rtl::Turn::Finished(push(&acc, &crate::lower::model::Item::ItTrait(trait_def_of_190819))))
                                } else {
                                    prism_rtl::Turn::Finished(acc.clone())
                                }
                            }))
                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::TraitInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                    }), move |fold_190738: Array<crate::lower::model::Item>| {
                        let traits = fold_190738;
                        call_value(fold_job(values(&lx.g.impls), Array::new(), {
                            let m = m.clone();
                            let lx = lx.clone();
                            Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)| {
                                let m = m.clone();
                                let lx = lx.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let ims = p1;
                                    fold_job(ims.clone(), acc.clone(), {
                                        let m = m.clone();
                                        let lx = lx.clone();
                                        Rc::new(move |(p0, p1): (Array<crate::lower::model::Item>, crate::check::env::ImplInfo)| {
                                            let m = m.clone();
                                            let lx = lx.clone();
                                            entered(once_job(move || {
                                                let a = p0;
                                                let im = p1;
                                                if (&im.home == &m) && !im.derived {
                                                    call_then(start_impl_def_of(in_module(&lx, &im.file, &m), im.clone()), move |impl_def_of_190986: crate::lower::model::ImplDef| prism_rtl::Turn::Finished(push(&a, &crate::lower::model::Item::ItImpl(impl_def_of_190986))))
                                                } else {
                                                    prism_rtl::Turn::Finished(a.clone())
                                                }
                                            }))
                                        }) as Rc<dyn Fn((Array<crate::lower::model::Item>, crate::check::env::ImplInfo)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                                    }).cycle()
                                }))
                            }) as Rc<dyn Fn((Array<crate::lower::model::Item>, Array<crate::check::env::ImplInfo>)) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>>>
                        }), move |fold_190865: Array<crate::lower::model::Item>| {
                            let impls = fold_190865;
                            let uses = filter(&each(&mods, &(|o: &Text| rust_mod_name(o))), &(|o: &Text| o != &rust_mod_name(&m)));
                            prism_rtl::Turn::Finished(crate::lower::model::ModDef { name: rust_mod_name(&m), prism: m.clone(), path_: path_.clone(), uses: uses.clone(), complete: Array::new(), declared: Array::new(), types_with: Array::new(), items: append(&append(&append(&append(&types, &tags), &traits), &impls), &defs) })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ModDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_mod_def_of(lx0: Lx, m: Text, roots: Array<(Text, bool)>, info: crate::check::env::ModInfo, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::ModDef>> {
    Rc::new(ModDefOf { lx0, m, roots, info, mods })
}

/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub fn def_items(lx: &Lx, d: &crate::check::env::Def, roots: &Array<(Text, bool)>) -> Array<crate::lower::model::Item> {
    let is_root = crate::check::types::has_text(&each(roots, &(|(q, _): &(Text, bool)| q.clone())), &d.qk);
    match &d.body {
        crate::check::env::DefBody::DbWidget(w) => if is_root {
            node_items(&crate::lower::node_::node_def_of(lx, &d.qk, &Array::new(), &w.body, &or(&get(&lx.g.vals, &d.qk), &crate::check::env::builtin(&d.qk, &crate::check::types::mono(&crate::check::types::Ty::TyErr))).scheme, &true))
        } else {
            Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))])
        },
        crate::check::env::DefBody::DbFn(clauses) => match get(&lx.g.vals, &d.qk) {
            None => Array::new(),
            Some(v_) => 'm191904: {
                let scrutinee = &v_.scheme.ty;
                if let crate::check::types::Ty::TyFn(_, _, m191904_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m191904_0_2 {
                    break 'm191904 if !is_root {
                        Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))])
                    } else {
                        'm192100: {
                            if let m192100_0 = clauses && (m192100_0.len() == 1) && let Some(c) = index(m192100_0, &Nat::from(0u32)) {
                                break 'm192100 match &c.body {
                                    crate::syntax::FnBody::BodyBlock(b) => node_items(&crate::lower::node_::node_def_of(lx, &d.qk, &c.params, b, &v_.scheme, &true)),
                                    _ => Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d.name)))]),
                                };
                            }
                            Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d.name)))])
                        }
                    };
                }
                {
                    let f = crate::lower::model::Item::ItFn(fn_def_of(lx, &d.qk, clauses, &v_.scheme));
                    if crate::check::types::has_text(&lx.unbs, &d.qk) {
                        Array::from(vec![f.clone(), crate::lower::model::Item::ItJob(job_def_of(lx, &d.qk, clauses, &v_.scheme))])
                    } else {
                        Array::from(vec![f.clone()])
                    }
                }
            },
        },
        crate::check::env::DefBody::DbLet(l) => Array::from(vec![crate::lower::model::Item::ItFn(let_getter(lx, &d.qk, l))]),
        _ => Array::new(),
    }
}

/// The step machine of `DefItems`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DefItems: unbounded fn Lx, Def, [((Text, Bool))] -> [Item]
/// ```
pub struct DefItems {
    pub lx: Lx,
    pub d: crate::check::env::Def,
    pub roots: Array<(Text, bool)>,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for DefItems {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx = &self.lx;
        let d = &self.d;
        let roots = &self.roots;
        let is_root = crate::check::types::has_text(&each(roots, &(|(q, _): &(Text, bool)| q.clone())), &d.qk);
        match &d.body {
            crate::check::env::DefBody::DbWidget(w) => if is_root {
                {
                    let d = d.clone();
                    let lx = lx.clone();
                    let w = w.clone();
                    call_then(crate::lower::node_::start_node_def_of(lx.clone(), d.qk.clone(), Array::new(), w.body.clone(), or(&get(&lx.g.vals, &d.qk), &crate::check::env::builtin(&d.qk, &crate::check::types::mono(&crate::check::types::Ty::TyErr))).scheme.clone(), true), move |node_def_of_191647: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_191647)))
                }
            } else {
                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))]))
            },
            crate::check::env::DefBody::DbFn(clauses) => match get(&lx.g.vals, &d.qk) {
                None => prism_rtl::Turn::Finished(Array::new()),
                Some(v_) => 'm191904: {
                    let scrutinee = &v_.scheme.ty;
                    if let crate::check::types::Ty::TyFn(_, _, m191904_0_2) = scrutinee && let crate::check::types::Ty::TyAt(_, _) = &**m191904_0_2 {
                        break 'm191904 if !is_root {
                            prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItNote(Text::from(format!("`{}` is inlined where it is applied.", &d.name)))]))
                        } else {
                            'm192100: {
                                if let m192100_0 = clauses && (m192100_0.len() == 1) && let Some(c) = index(m192100_0, &Nat::from(0u32)) {
                                    break 'm192100 match &c.body {
                                        crate::syntax::FnBody::BodyBlock(b) => {
                                            let b = b.clone();
                                            let d = d.clone();
                                            let lx = lx.clone();
                                            call_then(crate::lower::node_::start_node_def_of(lx.clone(), d.qk.clone(), c.params.clone(), b.clone(), v_.scheme.clone(), true), move |node_def_of_192212: crate::lower::model::NodeDef| prism_rtl::Turn::Finished(node_items(&node_def_of_192212)))
                                        },
                                        _ => prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget whose body is one expression", &d.name)))])),
                                    };
                                }
                                prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRefused(Text::from(format!("`{}`, a root widget of several clauses", &d.name)))]))
                            }
                        };
                    }
                    {
                        let clauses = clauses.clone();
                        let d = d.clone();
                        let lx = lx.clone();
                        call_then(start_fn_def_of(lx.clone(), d.qk.clone(), clauses.clone(), v_.scheme.clone()), move |fn_def_of_192528: crate::lower::model::FnDef| {
                            let f = crate::lower::model::Item::ItFn(fn_def_of_192528);
                            if crate::check::types::has_text(&lx.unbs, &d.qk) {
                                call_then(start_job_def_of(lx.clone(), d.qk.clone(), clauses.clone(), v_.scheme.clone()), move |job_def_of_192623: crate::lower::model::JobDef| prism_rtl::Turn::Finished(Array::from(vec![f.clone(), crate::lower::model::Item::ItJob(job_def_of_192623)])))
                            } else {
                                prism_rtl::Turn::Finished(Array::from(vec![f.clone()]))
                            }
                        })
                    }
                },
            },
            crate::check::env::DefBody::DbLet(l) => {
                let d = d.clone();
                let l = l.clone();
                let lx = lx.clone();
                call_then(start_let_getter(lx.clone(), d.qk.clone(), l.clone()), move |let_getter_192700: crate::lower::model::FnDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItFn(let_getter_192700)])))
            },
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DefItems, x`: what the function value is when passed to `@Run`.
pub fn start_def_items(lx: Lx, d: crate::check::env::Def, roots: Array<(Text, bool)>) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(DefItems { lx, d, roots })
}

/// ```prism
/// NodeItems: fn NodeDef -> [Item]
/// ```
pub fn node_items(n: &crate::lower::model::NodeDef) -> Array<crate::lower::model::Item> {
    append(&Array::from(vec![crate::lower::model::Item::ItNode(n.clone())]), &each(&n.children, &(|c: &crate::lower::model::NodeDef| crate::lower::model::Item::ItNode(c.clone()))))
}

/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub fn ty_defs(lx: &Lx, ti: &crate::check::env::TyInfo) -> Array<crate::lower::model::Item> {
    let derives = each(&ti.derives, &(|dn: &Text| crate::check::types::bare_name(dn)));
    let params = each(&ti.params, &(|p_: &Text| camel(p_)));
    let floaty_ = floaty(&lx.g, &crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), &Array::new());
    let bare = crate::check::types::bare_name(&ti.name);
    let mk_fn = {
        let bare = bare.clone();
        let params = params.clone();
        let derives = derives.clone();
        let floaty_ = floaty_;
        let lx = lx.clone();
        let ti = ti.clone();
        Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
            let bare = bare.clone();
            let params = params.clone();
            let derives = derives.clone();
            let floaty_ = floaty_;
            let lx = lx.clone();
            let ti = ti.clone();
            entered(once_job(move || {
                let shape = p0;
                let cases = p1;
                call_then(start_ty_podable(lx.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |ty_podable_193492: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: camel(&bare), prism: bare.clone(), params: params.clone(), shape: shape.clone(), cases: cases.clone(), eq: crate::check::types::has_text(&derives, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives, &Text::lit("Ord")), floaty: floaty_, show: if has_own_show(&lx, &ti.name) {
                    crate::lower::model::Shown::ShownOwn
                } else {
                    if crate::check::types::has_text(&derives, &Text::lit("Show")) {
                        crate::lower::model::Shown::ShownDerived
                    } else {
                        crate::lower::model::Shown::NotShown
                    }
                }, pod: ty_podable_193492 && run_to_end(fold_job(cases.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                    let ok = p0;
                    let c = p1;
                    prism_rtl::Turn::Finished(ok && run_to_end(fold_job(c.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                        let ok2 = p0;
                        let (_, ft) = p1;
                        prism_rtl::Turn::Finished(ok2 && podable(&ft))
                    }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx, &ti) }))
            }))
        }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
    };
    match &ti.body {
        crate::check::env::TyBody::BRecord(fs) => {
            let fields = run_to_end(each_job(crate::check::errors::range0(&len(fs)), {
                let fs = fs.clone();
                let lx = lx.clone();
                let ti = ti.clone();
                Rc::new(move |p0: Nat| {
                    let fs = fs.clone();
                    let lx = lx.clone();
                    let ti = ti.clone();
                    entered(once_job(move || {
                        let i = p0;
                        {
                            let (fname, ft) = or(&index(&fs, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                            call_then(start_out_ty_of(lx.clone(), ft.clone()), move |out_ty_of_193838: crate::lower::model::OutTy| {
                                let rt = out_ty_of_193838;
                                prism_rtl::Turn::Finished((snake(&fname), if rc_field(&lx, &ti.name, &i) {
                                    crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
                                } else {
                                    rt.clone()
                                }))
                            })
                        }
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
            }));
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_fn)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: camel(&bare), prism: bare.clone(), fields: fields.clone() }])))))])
        },
        crate::check::env::TyBody::BChoice(cases) => {
            let defs = run_to_end(each_job(cases.clone(), {
                let ti = ti.clone();
                let lx = lx.clone();
                Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                    let ti = ti.clone();
                    let lx = lx.clone();
                    entered(once_job(move || {
                        let (cn, ats) = p0;
                        {
                            let ck = crate::check::env::qual_key(&ti.home, &cn);
                            call_value(each_job(crate::check::errors::range0(&len(&ats)), {
                                let lx = lx.clone();
                                let ck = ck.clone();
                                let ats = ats.clone();
                                Rc::new(move |p0: Nat| {
                                    let lx = lx.clone();
                                    let ck = ck.clone();
                                    let ats = ats.clone();
                                    entered(once_job(move || {
                                        let i = p0;
                                        call_then(start_case_field(lx.clone(), ck.clone(), i.clone(), or(&index(&ats, &i), &crate::check::types::Ty::TyErr)), move |case_field_194246: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_194246)))
                                    }))
                                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                            }), move |each_194209: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: camel(&cn), prism: cn.clone(), fields: each_194209 }))
                        }
                    }))
                }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
            }));
            let shape = 'm194315: {
                if let m194315_0 = cases && (m194315_0.len() == 1) && let Some((cn, m194315_0_0_1)) = index(m194315_0, &Nat::from(0u32)) && ((&m194315_0_0_1).len() == 0) {
                    break 'm194315 if crate::check::env::is_lower_text(&cn) {
                        crate::lower::model::TyShape::ShapeUnit
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                if let m194315_1 = cases && (m194315_1.len() == 1) && let Some((cn, _)) = index(m194315_1, &Nat::from(0u32)) {
                    break 'm194315 if &cn == &bare {
                        crate::lower::model::TyShape::ShapeNewtype
                    } else {
                        crate::lower::model::TyShape::ShapeChoice
                    };
                }
                crate::lower::model::TyShape::ShapeChoice
            };
            Array::from(vec![crate::lower::model::Item::ItType(run_to_end((&mk_fn)((shape.clone(), defs.clone()))))])
        },
        crate::check::env::TyBody::BRowKind => if &ti.name == &Text::lit("Prelude.Fault") {
            Array::new()
        } else {
            Array::from(vec![crate::lower::model::Item::ItRow(row_def_of(lx, ti))])
        },
        _ => Array::new(),
    }
}

/// The step machine of `TyDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyDefs: unbounded fn Lx, TyInfo -> [Item]
/// ```
pub struct TyDefs {
    pub lx: Lx,
    pub ti: crate::check::env::TyInfo,
}

impl prism_rtl::Job<Array<crate::lower::model::Item>> for TyDefs {
    fn cycle(&self) -> prism_rtl::Turn<Array<crate::lower::model::Item>> {
        let lx = &self.lx;
        let ti = &self.ti;
        let derives = each(&ti.derives, &(|dn: &Text| crate::check::types::bare_name(dn)));
        let params = each(&ti.params, &(|p_: &Text| camel(p_)));
        let lx = lx.clone();
        let ti = ti.clone();
        call_then(start_floaty(lx.g.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |floaty_193127: bool| {
            let floaty_ = floaty_193127;
            let bare = crate::check::types::bare_name(&ti.name);
            let mk_fn = {
                let bare = bare.clone();
                let params = params.clone();
                let derives = derives.clone();
                let floaty_ = floaty_;
                let lx = lx.clone();
                let ti = ti.clone();
                Rc::new(move |(p0, p1): (crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)| {
                    let bare = bare.clone();
                    let params = params.clone();
                    let derives = derives.clone();
                    let floaty_ = floaty_;
                    let lx = lx.clone();
                    let ti = ti.clone();
                    entered(once_job(move || {
                        let shape = p0;
                        let cases = p1;
                        call_then(start_ty_podable(lx.clone(), crate::check::types::Ty::TyCon(ti.name.clone(), Array::new()), Array::new()), move |ty_podable_193492: bool| prism_rtl::Turn::Finished(crate::lower::model::TyDef { name: camel(&bare), prism: bare.clone(), params: params.clone(), shape: shape.clone(), cases: cases.clone(), eq: crate::check::types::has_text(&derives, &Text::lit("Eq")), ord: crate::check::types::has_text(&derives, &Text::lit("Ord")), floaty: floaty_, show: if has_own_show(&lx, &ti.name) {
                            crate::lower::model::Shown::ShownOwn
                        } else {
                            if crate::check::types::has_text(&derives, &Text::lit("Show")) {
                                crate::lower::model::Shown::ShownDerived
                            } else {
                                crate::lower::model::Shown::NotShown
                            }
                        }, pod: ty_podable_193492 && run_to_end(fold_job(cases.clone(), true, Rc::new(move |(p0, p1): (bool, crate::lower::model::CaseDef)| entered(once_job(move || {
                            let ok = p0;
                            let c = p1;
                            prism_rtl::Turn::Finished(ok && run_to_end(fold_job(c.fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, crate::lower::model::OutTy))| entered(once_job(move || {
                                let ok2 = p0;
                                let (_, ft) = p1;
                                prism_rtl::Turn::Finished(ok2 && podable(&ft))
                            }))) as Rc<dyn Fn((bool, (Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)))
                        }))) as Rc<dyn Fn((bool, crate::lower::model::CaseDef)) -> Rc<dyn prism_rtl::Job<bool>>>)), doc: type_doc(&lx, &ti) }))
                    }))
                }) as Rc<dyn Fn((crate::lower::model::TyShape, Array<crate::lower::model::CaseDef>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::TyDef>>>
            };
            match &ti.body {
                crate::check::env::TyBody::BRecord(fs) => {
                    let fs = fs.clone();
                    call_value(each_job(crate::check::errors::range0(&len(&fs)), {
                        let fs = fs.clone();
                        let lx = lx.clone();
                        let ti = ti.clone();
                        Rc::new(move |p0: Nat| {
                            let fs = fs.clone();
                            let lx = lx.clone();
                            let ti = ti.clone();
                            entered(once_job(move || {
                                let i = p0;
                                {
                                    let (fname, ft) = or(&index(&fs, &i), &(Text::lit(""), crate::check::types::Ty::TyErr));
                                    call_then(start_out_ty_of(lx.clone(), ft.clone()), move |out_ty_of_193838: crate::lower::model::OutTy| {
                                        let rt = out_ty_of_193838;
                                        prism_rtl::Turn::Finished((snake(&fname), if rc_field(&lx, &ti.name, &i) {
                                            crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
                                        } else {
                                            rt.clone()
                                        }))
                                    })
                                }
                            }))
                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                    }), move |each_193724: Array<(Text, crate::lower::model::OutTy)>| {
                        let fields = each_193724;
                        call_value((&mk_fn)((crate::lower::model::TyShape::ShapeRecord, Array::from(vec![crate::lower::model::CaseDef { name: camel(&bare), prism: bare.clone(), fields: fields.clone() }]))), move |mk_193955: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_193955)])))
                    })
                },
                crate::check::env::TyBody::BChoice(cases) => {
                    let cases = cases.clone();
                    call_value(each_job(cases.clone(), {
                        let ti = ti.clone();
                        let lx = lx.clone();
                        Rc::new(move |p0: (Text, Array<crate::check::types::Ty>)| {
                            let ti = ti.clone();
                            let lx = lx.clone();
                            entered(once_job(move || {
                                let (cn, ats) = p0;
                                {
                                    let ck = crate::check::env::qual_key(&ti.home, &cn);
                                    call_value(each_job(crate::check::errors::range0(&len(&ats)), {
                                        let lx = lx.clone();
                                        let ck = ck.clone();
                                        let ats = ats.clone();
                                        Rc::new(move |p0: Nat| {
                                            let lx = lx.clone();
                                            let ck = ck.clone();
                                            let ats = ats.clone();
                                            entered(once_job(move || {
                                                let i = p0;
                                                call_then(start_case_field(lx.clone(), ck.clone(), i.clone(), or(&index(&ats, &i), &crate::check::types::Ty::TyErr)), move |case_field_194246: crate::lower::model::OutTy| prism_rtl::Turn::Finished((Text::lit(""), case_field_194246)))
                                            }))
                                        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::lower::model::OutTy)>>>
                                    }), move |each_194209: Array<(Text, crate::lower::model::OutTy)>| prism_rtl::Turn::Finished(crate::lower::model::CaseDef { name: camel(&cn), prism: cn.clone(), fields: each_194209 }))
                                }
                            }))
                        }) as Rc<dyn Fn((Text, Array<crate::check::types::Ty>)) -> Rc<dyn prism_rtl::Job<crate::lower::model::CaseDef>>>
                    }), move |each_194078: Array<crate::lower::model::CaseDef>| {
                        let defs = each_194078;
                        let shape = 'm194315: {
                            if let m194315_0 = &cases && (m194315_0.len() == 1) && let Some((cn, m194315_0_0_1)) = index(m194315_0, &Nat::from(0u32)) && ((&m194315_0_0_1).len() == 0) {
                                break 'm194315 if crate::check::env::is_lower_text(&cn) {
                                    crate::lower::model::TyShape::ShapeUnit
                                } else {
                                    crate::lower::model::TyShape::ShapeChoice
                                };
                            }
                            if let m194315_1 = &cases && (m194315_1.len() == 1) && let Some((cn, _)) = index(m194315_1, &Nat::from(0u32)) {
                                break 'm194315 if &cn == &bare {
                                    crate::lower::model::TyShape::ShapeNewtype
                                } else {
                                    crate::lower::model::TyShape::ShapeChoice
                                };
                            }
                            crate::lower::model::TyShape::ShapeChoice
                        };
                        call_value((&mk_fn)((shape.clone(), defs.clone())), move |mk_194552: crate::lower::model::TyDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItType(mk_194552)])))
                    })
                },
                crate::check::env::TyBody::BRowKind => if &ti.name == &Text::lit("Prelude.Fault") {
                    prism_rtl::Turn::Finished(Array::new())
                } else {
                    call_then(start_row_def_of(lx.clone(), ti.clone()), move |row_def_of_194639: crate::lower::model::RowDef| prism_rtl::Turn::Finished(Array::from(vec![crate::lower::model::Item::ItRow(row_def_of_194639)])))
                },
                _ => prism_rtl::Turn::Finished(Array::new()),
            }
        })
    }
}

/// `Start TyDefs, x`: what the function value is when passed to `@Run`.
pub fn start_ty_defs(lx: Lx, ti: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<Array<crate::lower::model::Item>>> {
    Rc::new(TyDefs { lx, ti })
}

/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_podable(lx: &Lx, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m194960_2_0, _) if (m194960_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m194960_3_0, _) if (m194960_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i) => ty_podable(lx, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), true, {
            let lx = lx.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx = lx.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => ty_podable(lx, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => ty_podable(lx, &**k, seen) && ty_podable(lx, &**v_, seen),
        crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
            true
        } else {
            {
                let more = push(seen, n);
                let args_ok = run_to_end(fold_job(args.clone(), true, {
                    let lx = lx.clone();
                    let more = more.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx = lx.clone();
                        let more = more.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &more))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok && match get(&lx.g.types, n) {
                    Some(ti) => match &ti.body {
                        crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), true, {
                            let lx = lx.clone();
                            let more = more.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                let lx = lx.clone();
                                let more = more.clone();
                                entered(once_job(move || {
                                    let ok = p0;
                                    let (_, ft) = p1;
                                    prism_rtl::Turn::Finished(ok && ty_podable(&lx, &ft, &more))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), true, {
                            let lx = lx.clone();
                            let more = more.clone();
                            Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                let lx = lx.clone();
                                let more = more.clone();
                                entered(once_job(move || {
                                    let ok = p0;
                                    let (_, ats) = p1;
                                    prism_rtl::Turn::Finished(ok && run_to_end(fold_job(ats.clone(), true, {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                            let lx = lx.clone();
                                            let more = more.clone();
                                            entered(once_job(move || {
                                                let ok2 = p0;
                                                let x = p1;
                                                prism_rtl::Turn::Finished(ok2 && ty_podable(&lx, &x, &more))
                                            }))
                                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                    })))
                                }))
                            }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                        })),
                        crate::check::env::TyBody::BAlias(a) => ty_podable(lx, a, &more),
                        _ => true,
                    },
                    None => true,
                }
            }
        },
        _ => true,
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TyPodable`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TyPodable: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub struct TyPodable {
    pub lx: Lx,
    pub t: crate::check::types::Ty,
    pub seen: Array<Text>,
}

impl prism_rtl::Job<bool> for TyPodable {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let lx = &self.lx;
        let t = &self.t;
        let seen = &self.seen;
        match t {
            crate::check::types::Ty::TyFn(_, _, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TyAt(_, _) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m194960_2_0, _) if (m194960_2_0 == &Text::lit("!")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(m194960_3_0, _) if (m194960_3_0 == &Text::lit("$")) => prism_rtl::Turn::Finished(false),
            crate::check::types::Ty::TySig(_, i) => prism_rtl::Turn::More(Rc::new(TyPodable { lx: lx.clone(), t: (**i).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyTuple(ts) => fold_job(ts.clone(), true, {
                let lx = lx.clone();
                let seen = seen.clone();
                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                    let lx = lx.clone();
                    let seen = seen.clone();
                    entered(once_job(move || {
                        let ok = p0;
                        let x = p1;
                        prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &seen))
                    }))
                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
            }).cycle(),
            crate::check::types::Ty::TyArray(e) => prism_rtl::Turn::More(Rc::new(TyPodable { lx: lx.clone(), t: (**e).clone(), seen: seen.clone() })),
            crate::check::types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let lx = lx.clone();
                let seen = seen.clone();
                let v_ = (**v_).clone();
                call_then(start_ty_podable(lx.clone(), k.clone(), seen.clone()), move |ty_podable_195263: bool| prism_rtl::Turn::Finished(ty_podable_195263 && ty_podable(&lx, &v_, &seen)))
            },
            crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
                prism_rtl::Turn::Finished(true)
            } else {
                {
                    let more = push(seen, n);
                    let args = args.clone();
                    let lx = lx.clone();
                    let n = n.clone();
                    call_value(fold_job(args.clone(), true, {
                        let lx = lx.clone();
                        let more = more.clone();
                        Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                            let lx = lx.clone();
                            let more = more.clone();
                            entered(once_job(move || {
                                let ok = p0;
                                let x = p1;
                                prism_rtl::Turn::Finished(ok && ty_podable(&lx, &x, &more))
                            }))
                        }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |fold_195439: bool| {
                        let args_ok = fold_195439;
                        prism_rtl::Turn::Finished(args_ok && match get(&lx.g.types, &n) {
                            Some(ti) => match &ti.body {
                                crate::check::env::TyBody::BRecord(fs) => run_to_end(fold_job(fs.clone(), true, {
                                    let lx = lx.clone();
                                    let more = more.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, crate::check::types::Ty))| {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        entered(once_job(move || {
                                            let ok = p0;
                                            let (_, ft) = p1;
                                            prism_rtl::Turn::Finished(ok && ty_podable(&lx, &ft, &more))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, crate::check::types::Ty))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BChoice(cs) => run_to_end(fold_job(cs.clone(), true, {
                                    let lx = lx.clone();
                                    let more = more.clone();
                                    Rc::new(move |(p0, p1): (bool, (Text, Array<crate::check::types::Ty>))| {
                                        let lx = lx.clone();
                                        let more = more.clone();
                                        entered(once_job(move || {
                                            let ok = p0;
                                            let (_, ats) = p1;
                                            prism_rtl::Turn::Finished(ok && run_to_end(fold_job(ats.clone(), true, {
                                                let lx = lx.clone();
                                                let more = more.clone();
                                                Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                                                    let lx = lx.clone();
                                                    let more = more.clone();
                                                    entered(once_job(move || {
                                                        let ok2 = p0;
                                                        let x = p1;
                                                        prism_rtl::Turn::Finished(ok2 && ty_podable(&lx, &x, &more))
                                                    }))
                                                }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                                            })))
                                        }))
                                    }) as Rc<dyn Fn((bool, (Text, Array<crate::check::types::Ty>))) -> Rc<dyn prism_rtl::Job<bool>>>
                                })),
                                crate::check::env::TyBody::BAlias(a) => ty_podable(&lx, a, &more),
                                _ => true,
                            },
                            None => true,
                        })
                    })
                }
            },
            _ => prism_rtl::Turn::Finished(true),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TyPodable, x`: what the function value is when passed to `@Run`.
pub fn start_ty_podable(lx: Lx, t: crate::check::types::Ty, seen: Array<Text>) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(TyPodable { lx, t, seen })
}

/// ```prism
/// TyHasEq: unbounded fn Lx, Ty, [Text] -> Bool
/// ```
pub fn ty_has_eq(lx: &Lx, t: &crate::check::types::Ty, seen: &Array<Text>) -> bool {
    match t {
        crate::check::types::Ty::TyFn(_, _, _) => false,
        crate::check::types::Ty::TyAt(_, _) => false,
        crate::check::types::Ty::TySig(m196393_2_0, _) if (m196393_2_0 == &Text::lit("!")) => false,
        crate::check::types::Ty::TySig(m196393_3_0, _) if (m196393_3_0 == &Text::lit("$")) => false,
        crate::check::types::Ty::TySig(_, i) => ty_has_eq(lx, &**i, seen),
        crate::check::types::Ty::TyTuple(ts) => run_to_end(fold_job(ts.clone(), true, {
            let lx = lx.clone();
            let seen = seen.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                let lx = lx.clone();
                let seen = seen.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let x = p1;
                    prism_rtl::Turn::Finished(ok && ty_has_eq(&lx, &x, &seen))
                }))
            }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
        })),
        crate::check::types::Ty::TyArray(e) => ty_has_eq(lx, &**e, seen),
        crate::check::types::Ty::TyMap(k, v_) => ty_has_eq(lx, &**k, seen) && ty_has_eq(lx, &**v_, seen),
        crate::check::types::Ty::TyElem(_, _) => true,
        crate::check::types::Ty::TyElemAny(_) => true,
        crate::check::types::Ty::TyCon(n, args) => if crate::check::types::has_text(seen, n) {
            true
        } else {
            {
                let args_ok = run_to_end(fold_job(args.clone(), true, {
                    let lx = lx.clone();
                    let seen = seen.clone();
                    let n = n.clone();
                    Rc::new(move |(p0, p1): (bool, crate::check::types::Ty)| {
                        let lx = lx.clone();
                        let seen = seen.clone();
                        let n = n.clone();
                        entered(once_job(move || {
                            let ok = p0;
                            let x = p1;
                            prism_rtl::Turn::Finished(ok && ty_has_eq(&lx, &x, &push(&seen, &n)))
                        }))
                    }) as Rc<dyn Fn((bool, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<bool>>>
                }));
                args_ok && match get(&lx.g.types, n) {
                    Some(ti) => fold(&ti.derives, &false, &(|f: &bool, d: &Text| *f || (&crate::check::types::bare_name(d) == &Text::lit("Eq")))) || has_own_eq(lx, n),
                    None => true,
                }
            }
        },
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// HasOwnEq: fn Lx, Text -> Bool
/// ```
pub fn has_own_eq(lx: &Lx, tn: &Text) -> bool {
    fold(&or(&get(&lx.g.impls, &Text::lit("Prelude.Eq")), &Array::new()), &false, &(|f: &bool, im: &crate::check::env::ImplInfo| *f || (&head_name(&im.head) == tn)))
}

/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub fn case_field(lx: &Lx, ck: &Text, i: &Nat, t: &crate::check::types::Ty) -> crate::lower::model::OutTy {
    let rt = out_ty_of(lx, t);
    if rc_field(lx, ck, i) {
        crate::lower::model::OutTy::OutRc(Rc::new(rt.clone()))
    } else {
        rt.clone()
    }
}

/// The step machine of `CaseField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CaseField: unbounded fn Lx, Text, Nat, Ty -> OutTy
/// ```
pub struct CaseField {
    pub lx: Lx,
    pub ck: Text,
    pub i: Nat,
    pub t: crate::check::types::Ty,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for CaseField {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let ck = &self.ck;
        let i = &self.i;
        let t = &self.t;
        let ck = ck.clone();
        let i = i.clone();
        let lx = lx.clone();
        let t = t.clone();
        call_then(start_out_ty_of(lx.clone(), t.clone()), move |out_ty_of_197371: crate::lower::model::OutTy| {
            let rt = out_ty_of_197371;
            if rc_field(&lx, &ck, &i) {
                prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutRc(Rc::new(rt.clone())))
            } else {
                prism_rtl::Turn::Finished(rt.clone())
            }
        })
    }
}

/// `Start CaseField, x`: what the function value is when passed to `@Run`.
pub fn start_case_field(lx: Lx, ck: Text, i: Nat, t: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(CaseField { lx, ck, i, t })
}

/// ```prism
/// TypeDoc: fn Lx, TyInfo -> Text
/// ```
pub fn type_doc(lx: &Lx, ti: &crate::check::env::TyInfo) -> Text {
    match index(&lx.g.srcs, &ti.file) {
        Some(src) => crate::syntax::lexer::trim(&crate::check::errors::line_text(&src, &crate::check::errors::cline_of(&src.starts, &ti.span.start))),
        None => ti.name.clone(),
    }
}

/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub fn tag_def_of(lx: &Lx, tg: &crate::check::env::TagInfo) -> crate::lower::model::TagDef {
    let fields = run_to_end(each_job(level_fields(tg), {
        let lx = lx.clone();
        Rc::new(move |p0: (Text, crate::check::types::Ty)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let (fname, ft) = p0;
                call_then(start_out_ty_of(lx.clone(), peel(&ft)), move |out_ty_of_197881: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname.clone(), snake(&fname), out_ty_of_197881)))
            }))
        }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
    }));
    crate::lower::model::TagDef { name: tag_struct(&tg.name), tag_name: tg.name.clone(), fields: fields.clone(), doc: type_doc(lx, &crate::check::env::TyInfo { name: tg.name.clone(), home: tg.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg.file.clone(), span: tg.span.clone() }), pod: run_to_end(fold_job(fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
        let ok = p0;
        let (_, _, t) = p1;
        prism_rtl::Turn::Finished(ok && podable(&t))
    }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>)) }
}

/// The step machine of `TagDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagDefOf: unbounded fn Lx, TagInfo -> TagDef
/// ```
pub struct TagDefOf {
    pub lx: Lx,
    pub tg: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::TagDef> for TagDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::TagDef> {
        let lx = &self.lx;
        let tg = &self.tg;
        let lx = lx.clone();
        let tg = tg.clone();
        call_value(each_job(level_fields(&tg), {
            let lx = lx.clone();
            Rc::new(move |p0: (Text, crate::check::types::Ty)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let (fname, ft) = p0;
                    call_then(start_out_ty_of(lx.clone(), peel(&ft)), move |out_ty_of_197881: crate::lower::model::OutTy| prism_rtl::Turn::Finished((fname.clone(), snake(&fname), out_ty_of_197881)))
                }))
            }) as Rc<dyn Fn((Text, crate::check::types::Ty)) -> Rc<dyn prism_rtl::Job<(Text, Text, crate::lower::model::OutTy)>>>
        }), move |each_197816: Array<(Text, Text, crate::lower::model::OutTy)>| {
            let fields = each_197816;
            call_value(fold_job(fields.clone(), true, Rc::new(move |(p0, p1): (bool, (Text, Text, crate::lower::model::OutTy))| entered(once_job(move || {
                let ok = p0;
                let (_, _, t) = p1;
                prism_rtl::Turn::Finished(ok && podable(&t))
            }))) as Rc<dyn Fn((bool, (Text, Text, crate::lower::model::OutTy))) -> Rc<dyn prism_rtl::Job<bool>>>), move |fold_198105: bool| prism_rtl::Turn::Finished(crate::lower::model::TagDef { name: tag_struct(&tg.name), tag_name: tg.name.clone(), fields: fields.clone(), doc: type_doc(&lx, &crate::check::env::TyInfo { name: tg.name.clone(), home: tg.home.clone(), params: Array::new(), body: crate::check::env::TyBody::BOpaque, derives: Array::new(), file: tg.file.clone(), span: tg.span.clone() }), pod: fold_198105 }))
        })
    }
}

/// `Start TagDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_tag_def_of(lx: Lx, tg: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::TagDef>> {
    Rc::new(TagDefOf { lx, tg })
}

/// ```prism
/// LevelFields: fn TagInfo -> [((Text, Ty))]
/// ```
pub fn level_fields(tg: &crate::check::env::TagInfo) -> Array<(Text, crate::check::types::Ty)> {
    filter(&tg.fields, &(|(_, ft): &(Text, crate::check::types::Ty)| &layer_of(ft) != &Layer::LyEv))
}

/// ```prism
/// KindTags: fn Lx, Text, [Text] -> [TagInfo]
/// ```
pub fn kind_tags(lx: &Lx, kind: &Text, mods: &Array<Text>) -> Array<crate::check::env::TagInfo> {
    filter(&values(&lx.g.tags), &(|tg: &crate::check::env::TagInfo| (&tg.kind == kind) && crate::check::types::has_text(mods, &tg.home)))
}

/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub fn row_def_of(lx: &Lx, ti: &crate::check::env::TyInfo) -> crate::lower::model::RowDef {
    let tags = kind_tags(lx, &ti.name, &keys(&lx.rs_mods));
    let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (tag_struct(&tg.name), path_in(lx, &tg.home, &tag_struct(&tg.name)))));
    let pod = run_to_end(fold_job(tags.clone(), true, {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let ok = p0;
                let tg = p1;
                prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name: camel(&crate::check::types::bare_name(&ti.name)), prism: ti.name.clone(), cases: cases.clone(), pod, doc: type_doc(lx, ti) }
}

/// The step machine of `RowDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RowDefOf: unbounded fn Lx, TyInfo -> RowDef
/// ```
pub struct RowDefOf {
    pub lx: Lx,
    pub ti: crate::check::env::TyInfo,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for RowDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx = &self.lx;
        let ti = &self.ti;
        let tags = kind_tags(lx, &ti.name, &keys(&lx.rs_mods));
        let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (tag_struct(&tg.name), path_in(lx, &tg.home, &tag_struct(&tg.name)))));
        let lx = lx.clone();
        let ti = ti.clone();
        call_value(fold_job(tags.clone(), true, {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let tg = p1;
                    prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_198819: bool| {
            let pod = fold_198819;
            prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: camel(&crate::check::types::bare_name(&ti.name)), prism: ti.name.clone(), cases: cases.clone(), pod, doc: type_doc(&lx, &ti) })
        })
    }
}

/// `Start RowDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_row_def_of(lx: Lx, ti: crate::check::env::TyInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(RowDefOf { lx, ti })
}

/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub fn elem_row(lx: &Lx, mods: &Array<Text>) -> crate::lower::model::RowDef {
    let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
    let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (tag_struct(&tg.name), Text::from(format!("{}::{}", &rust_mod_name(&tg.home), &tag_struct(&tg.name))))));
    let pod = run_to_end(fold_job(tags.clone(), true, {
        let lx = lx.clone();
        Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
            let lx = lx.clone();
            entered(once_job(move || {
                let ok = p0;
                let tg = p1;
                prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
            }))
        }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases.clone(), pod, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.") }
}

/// The step machine of `ElemRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElemRow: unbounded fn Lx, [Text] -> RowDef
/// ```
pub struct ElemRow {
    pub lx: Lx,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::RowDef> for ElemRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::RowDef> {
        let lx = &self.lx;
        let mods = &self.mods;
        let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
        let cases = each(&tags, &(|tg: &crate::check::env::TagInfo| (tag_struct(&tg.name), Text::from(format!("{}::{}", &rust_mod_name(&tg.home), &tag_struct(&tg.name))))));
        let lx = lx.clone();
        call_value(fold_job(tags.clone(), true, {
            let lx = lx.clone();
            Rc::new(move |(p0, p1): (bool, crate::check::env::TagInfo)| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let ok = p0;
                    let tg = p1;
                    prism_rtl::Turn::Finished(ok && tag_def_of(&lx, &tg).pod)
                }))
            }) as Rc<dyn Fn((bool, crate::check::env::TagInfo)) -> Rc<dyn prism_rtl::Job<bool>>>
        }), move |fold_199421: bool| {
            let pod = fold_199421;
            prism_rtl::Turn::Finished(crate::lower::model::RowDef { name: Text::lit("Elem"), prism: Text::lit("Elem"), cases: cases.clone(), pod, doc: Text::lit("`Elem r`: an element as a document holds it, its `Level` in a tick.") })
        })
    }
}

/// `Start ElemRow, x`: what the function value is when passed to `@Run`.
pub fn start_elem_row(lx: Lx, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::RowDef>> {
    Rc::new(ElemRow { lx, mods })
}

/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub fn answer_enum(lx: &Lx, mods: &Array<Text>) -> crate::lower::model::AnswerDef {
    let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
    crate::lower::model::AnswerDef { cases: run_to_end(each_job(tags.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::check::env::TagInfo| {
            let lx = lx.clone();
            entered(once_job(move || {
                let tg = p0;
                call_then(start_answer_ty(lx.clone(), tg.clone()), move |answer_ty_200012: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: tag_struct(&tg.name), accessor: crate::lower::node_::answer_accessor(&tg), struct_path: Text::from(format!("{}::{}", &rust_mod_name(&tg.home), &tag_struct(&tg.name))), tag_name: tg.name.clone(), ty: answer_ty_200012 }))
            }))
        }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
    })) }
}

/// The step machine of `AnswerEnum`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerEnum: unbounded fn Lx, [Text] -> AnswerDef
/// ```
pub struct AnswerEnum {
    pub lx: Lx,
    pub mods: Array<Text>,
}

impl prism_rtl::Job<crate::lower::model::AnswerDef> for AnswerEnum {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::AnswerDef> {
        let lx = &self.lx;
        let mods = &self.mods;
        let tags = kind_tags(lx, &Text::lit("Element"), &push(mods, &Text::lit("Prelude")));
        let lx = lx.clone();
        call_value(each_job(tags.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::check::env::TagInfo| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let tg = p0;
                    call_then(start_answer_ty(lx.clone(), tg.clone()), move |answer_ty_200012: crate::lower::model::OutTy| prism_rtl::Turn::Finished(crate::lower::model::AnswerCase { variant: tag_struct(&tg.name), accessor: crate::lower::node_::answer_accessor(&tg), struct_path: Text::from(format!("{}::{}", &rust_mod_name(&tg.home), &tag_struct(&tg.name))), tag_name: tg.name.clone(), ty: answer_ty_200012 }))
                }))
            }) as Rc<dyn Fn(crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerCase>>>
        }), move |each_199847: Array<crate::lower::model::AnswerCase>| prism_rtl::Turn::Finished(crate::lower::model::AnswerDef { cases: each_199847 }))
    }
}

/// `Start AnswerEnum, x`: what the function value is when passed to `@Run`.
pub fn start_answer_enum(lx: Lx, mods: Array<Text>) -> Rc<dyn prism_rtl::Job<crate::lower::model::AnswerDef>> {
    Rc::new(AnswerEnum { lx, mods })
}

/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub fn answer_ty(lx: &Lx, tg: &crate::check::env::TagInfo) -> crate::lower::model::OutTy {
    let out = peel(&tg.out);
    let part = match &out {
        crate::check::types::Ty::TyTuple(cs) => fold(cs, &out, &(|found: &crate::check::types::Ty, c: &crate::check::types::Ty| if &layer_of(c) == &Layer::LyEv { peel(c) } else { found.clone() })),
        _ => out.clone(),
    };
    match out_ty_of(lx, &part) {
        crate::lower::model::OutTy::OutGen(_) => crate::lower::model::OutTy::OutPod,
        t => t.clone(),
    }
}

/// The step machine of `AnswerTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AnswerTy: unbounded fn Lx, TagInfo -> OutTy
/// ```
pub struct AnswerTy {
    pub lx: Lx,
    pub tg: crate::check::env::TagInfo,
}

impl prism_rtl::Job<crate::lower::model::OutTy> for AnswerTy {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::OutTy> {
        let lx = &self.lx;
        let tg = &self.tg;
        let out = peel(&tg.out);
        let part = match &out {
            crate::check::types::Ty::TyTuple(cs) => fold(cs, &out, &(|found: &crate::check::types::Ty, c: &crate::check::types::Ty| if &layer_of(c) == &Layer::LyEv { peel(c) } else { found.clone() })),
            _ => out.clone(),
        };
        let lx = lx.clone();
        call_then(start_out_ty_of(lx.clone(), part.clone()), move |out_ty_of_200539: crate::lower::model::OutTy| match out_ty_of_200539 {
            crate::lower::model::OutTy::OutGen(_) => prism_rtl::Turn::Finished(crate::lower::model::OutTy::OutPod),
            t => prism_rtl::Turn::Finished(t.clone()),
        })
    }
}

/// `Start AnswerTy, x`: what the function value is when passed to `@Run`.
pub fn start_answer_ty(lx: Lx, tg: crate::check::env::TagInfo) -> Rc<dyn prism_rtl::Job<crate::lower::model::OutTy>> {
    Rc::new(AnswerTy { lx, tg })
}

/// ```prism
/// TagPaths: fn Lx, TagInfo -> ((Text, Text))
/// ```
pub fn tag_paths(lx: &Lx, tg: &crate::check::env::TagInfo) -> (Text, Text) {
    let st = tag_struct(&tg.name);
    let struct_path = path_in(lx, &tg.home, &st);
    (Text::from(format!("{}::{}", &kind_path(lx, &tg.kind), &st)), struct_path.clone())
}

/// ```prism
/// VariantOf: fn Lx, TagInfo -> Text
/// ```
pub fn variant_of(lx: &Lx, tg: &crate::check::env::TagInfo) -> Text {
    Text::from(format!("{}::{}", &kind_path(lx, &tg.kind), &tag_struct(&tg.name)))
}

/// ```prism
/// KindPath: fn Lx, Text -> Text
/// ```
pub fn kind_path(lx: &Lx, kind: &Text) -> Text {
    if kind == &Text::lit("Element") {
        Text::lit("crate::Elem")
    } else {
        path_in(lx, &or(&get(&lx.g.types, kind), &crate::check::env::dummy_ty_info()).home, &camel(&crate::check::types::bare_name(kind)))
    }
}

/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub fn check_def_of(lx: &Lx, c: &crate::syntax::CheckDecl) -> crate::lower::model::CheckDef {
    crate::lower::model::CheckDef { name: c.name.name.clone(), lines: run_to_end(each_job(c.lines.clone(), {
        let lx = lx.clone();
        Rc::new(move |p0: crate::syntax::CheckLine| {
            let lx = lx.clone();
            entered(once_job(move || {
                let l = p0;
                call_then(start_value_of(lx.clone(), empty_env(), l.expr.clone()), move |value_of_201387: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(own(&value_of_201387)), Text::lit("to_pod"), Array::new())]))))
            }))
        }) as Rc<dyn Fn(crate::syntax::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
    })) }
}

/// The step machine of `CheckDefOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckDefOf: unbounded fn Lx, CheckDecl -> CheckDef
/// ```
pub struct CheckDefOf {
    pub lx: Lx,
    pub c: crate::syntax::CheckDecl,
}

impl prism_rtl::Job<crate::lower::model::CheckDef> for CheckDefOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::lower::model::CheckDef> {
        let lx = &self.lx;
        let c = &self.c;
        let c = c.clone();
        let lx = lx.clone();
        call_value(each_job(c.lines.clone(), {
            let lx = lx.clone();
            Rc::new(move |p0: crate::syntax::CheckLine| {
                let lx = lx.clone();
                entered(once_job(move || {
                    let l = p0;
                    call_then(start_value_of(lx.clone(), empty_env(), l.expr.clone()), move |value_of_201387: Vl| prism_rtl::Turn::Finished(crate::lower::model::Ex::XCtor(Text::lit("Ok"), Array::from(vec![crate::lower::model::Ex::XMethod(Rc::new(own(&value_of_201387)), Text::lit("to_pod"), Array::new())]))))
                }))
            }) as Rc<dyn Fn(crate::syntax::CheckLine) -> Rc<dyn prism_rtl::Job<crate::lower::model::Ex>>>
        }), move |each_201339: Array<crate::lower::model::Ex>| prism_rtl::Turn::Finished(crate::lower::model::CheckDef { name: c.name.name.clone(), lines: each_201339 }))
    }
}

/// `Start CheckDefOf, x`: what the function value is when passed to `@Run`.
pub fn start_check_def_of(lx: Lx, c: crate::syntax::CheckDecl) -> Rc<dyn prism_rtl::Job<crate::lower::model::CheckDef>> {
    Rc::new(CheckDefOf { lx, c })
}
