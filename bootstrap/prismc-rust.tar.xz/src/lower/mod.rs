//! The module `Lower`, from `target/bootstrap/src/prismc/lower/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod functions;
pub mod jobs;
pub mod model;
pub mod node_;
pub mod patterns;
pub mod program;
pub mod templates;
pub mod types;

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lx {
    pub g: crate::check::env::G,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub apps: Map<Text, crate::check::typed::AppNote>,
    pub lifts: Map<Text, crate::check::typed::LiftNote>,
    pub binders: Map<Text, crate::check::types::Ty>,
    pub impls: Map<Text, Array<crate::check::typed::ImplNote>>,
    pub file: Nat,
    pub home: Text,
    pub site: Text,
    pub rs_mods: Map<Text, Text>,
    pub mod_segments: Map<Text, bool>,
    pub rs_names: Map<Text, Text>,
    pub layouts: Map<Text, Array<bool>>,
    pub unbs: Array<Text>,
    pub notes: Array<Text>,
    pub globals: Map<Text, bool>,
    pub in_node: bool,
    pub unshrunk: Map<Text, bool>,
    pub gens: Map<Text, crate::check::typed::GenNote>,
    pub insts: Map<Text, Array<crate::check::typed::InstNote>>,
    pub quants: Map<Text, Text>,
    pub gen_of_q: Map<Text, crate::check::typed::GenNote>,
    pub use_insts: Map<Text, crate::check::typed::InstNote>,
    pub local_ids: Map<Text, Nat>,
    pub use_ids: Map<Text, Nat>,
    pub subst: Map<Text, crate::check::types::Ty>,
    pub csubst: Map<Text, crate::check::types::Col>,
}

impl Show for Lx {
    fn show(&self, p: &mut Printer) {
        p.record("Lx", &[("g", &self.g), ("tys", &self.tys), ("apps", &self.apps), ("lifts", &self.lifts), ("binders", &self.binders), ("impls", &self.impls), ("file", &self.file), ("home", &self.home), ("site", &self.site), ("rs_mods", &self.rs_mods), ("mod_segments", &self.mod_segments), ("rs_names", &self.rs_names), ("layouts", &self.layouts), ("unbs", &self.unbs), ("notes", &self.notes), ("globals", &self.globals), ("in_node", &self.in_node), ("unshrunk", &self.unshrunk), ("gens", &self.gens), ("insts", &self.insts), ("quants", &self.quants), ("gen_of_q", &self.gen_of_q), ("use_insts", &self.use_insts), ("local_ids", &self.local_ids), ("use_ids", &self.use_ids), ("subst", &self.subst), ("csubst", &self.csubst)]);
    }
}

impl ToPod for Lx {
    fn to_pod(&self) -> Pod {
        Pod::record("Lx", vec![("g", self.g.to_pod()), ("tys", self.tys.to_pod()), ("apps", self.apps.to_pod()), ("lifts", self.lifts.to_pod()), ("binders", self.binders.to_pod()), ("impls", self.impls.to_pod()), ("file", self.file.to_pod()), ("home", self.home.to_pod()), ("site", self.site.to_pod()), ("rs_mods", self.rs_mods.to_pod()), ("mod_segments", self.mod_segments.to_pod()), ("rs_names", self.rs_names.to_pod()), ("layouts", self.layouts.to_pod()), ("unbs", self.unbs.to_pod()), ("notes", self.notes.to_pod()), ("globals", self.globals.to_pod()), ("in_node", self.in_node.to_pod()), ("unshrunk", self.unshrunk.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("quants", self.quants.to_pod()), ("gen_of_q", self.gen_of_q.to_pod()), ("use_insts", self.use_insts.to_pod()), ("local_ids", self.local_ids.to_pod()), ("use_ids", self.use_ids.to_pod()), ("subst", self.subst.to_pod()), ("csubst", self.csubst.to_pod())])
    }
}

impl FromPod for Lx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lx { g: FromPod::from_pod(field(p, "g")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, lifts: FromPod::from_pod(field(p, "lifts")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, file: FromPod::from_pod(field(p, "file")?)?, home: FromPod::from_pod(field(p, "home")?)?, site: FromPod::from_pod(field(p, "site")?)?, rs_mods: FromPod::from_pod(field(p, "rs_mods")?)?, mod_segments: FromPod::from_pod(field(p, "mod_segments")?)?, rs_names: FromPod::from_pod(field(p, "rs_names")?)?, layouts: FromPod::from_pod(field(p, "layouts")?)?, unbs: FromPod::from_pod(field(p, "unbs")?)?, notes: FromPod::from_pod(field(p, "notes")?)?, globals: FromPod::from_pod(field(p, "globals")?)?, in_node: FromPod::from_pod(field(p, "in_node")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, quants: FromPod::from_pod(field(p, "quants")?)?, gen_of_q: FromPod::from_pod(field(p, "gen_of_q")?)?, use_insts: FromPod::from_pod(field(p, "use_insts")?)?, local_ids: FromPod::from_pod(field(p, "local_ids")?)?, use_ids: FromPod::from_pod(field(p, "use_ids")?)?, subst: FromPod::from_pod(field(p, "subst")?)?, csubst: FromPod::from_pod(field(p, "csubst")?)? })
    }
}

/// ```prism
/// PlaceKey: fn Lx, Range -> Text
/// ```
pub fn place_key(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> Text {
    Text::from(format!("{}:{}:{}", &lx_p0.file, &r_p1.start, &r_p1.end))
}

/// ```prism
/// TypeAt: fn Lx, Range -> Ty
/// ```
pub fn type_at(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    subst_ty(lx_p0, &or(&get(&lx_p0.tys, &place_key(lx_p0, r_p1)), &crate::check::types::Ty::TyErr))
}

/// ```prism
/// BinderTy: fn Lx, Range -> Ty
/// ```
pub fn binder_ty(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    match get(&lx_p0.binders, &place_key(lx_p0, r_p1)) {
        Some(t_p2) => subst_ty(lx_p0, &t_p2),
        None => type_at(lx_p0, r_p1),
    }
}

/// ```prism
/// SubstTy: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    if (&len(&keys(&lx_p0.subst)) == &Nat::from(0u32)) && (&len(&keys(&lx_p0.csubst)) == &Nat::from(0u32)) {
        t_p1.clone()
    } else {
        subst_ty_in(lx_p0, t_p1)
    }
}

/// ```prism
/// SubstTyIn: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_in(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyFlex(n_p2) => or(&get(&lx_p0.subst, &Text::from(format!("\'{}", n_p2))), t_p1),
        crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::check::types::Ty::TyCon(n_p3.clone(), each(args_p4, &(|a_p5: &crate::check::types::Ty| subst_ty_in(lx_p0, a_p5)))),
        crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => crate::check::types::Ty::TyFn(inst_col(lx_p0, c_p6), each(ps_p7, &(|p_p9: &crate::check::types::Ty| subst_ty_in(lx_p0, p_p9))), Rc::new(subst_ty_in(lx_p0, &**res_p8))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::check::types::Ty::TyTuple(each(ts_pa, &(|a_pb: &crate::check::types::Ty| subst_ty_in(lx_p0, a_pb)))),
        crate::check::types::Ty::TyArray(e_pc) => crate::check::types::Ty::TyArray(Rc::new(subst_ty_in(lx_p0, &**e_pc))),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::Ty::TyMap(Rc::new(subst_ty_in(lx_p0, &**k_pd)), Rc::new(subst_ty_in(lx_p0, &**v_pe))),
        crate::check::types::Ty::TySig(s_pf, i_pg) => crate::check::types::Ty::TySig(s_pf.clone(), Rc::new(subst_ty_in(lx_p0, &**i_pg))),
        crate::check::types::Ty::TyAt(i_ph, rw_pi) => crate::check::types::Ty::TyAt(Rc::new(subst_ty_in(lx_p0, &**i_ph)), rw_pi.clone()),
        crate::check::types::Ty::TyElem(rw_pj, o_pk) => crate::check::types::Ty::TyElem(rw_pj.clone(), Rc::new(subst_ty_in(lx_p0, &**o_pk))),
        crate::check::types::Ty::TyAssoc(n_pl, a_pm) => crate::check::types::Ty::TyAssoc(n_pl.clone(), Rc::new(subst_ty_in(lx_p0, &**a_pm))),
        other_pn => other_pn.clone(),
    }
}

/// ```prism
/// InstCol: fn Lx, Col -> Col
/// ```
pub fn inst_col(lx_p0: &Lx, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => or(&get(&lx_p0.csubst, q_p1), &crate::check::types::Col::CQ(q_p1.clone())),
        c_p3 => c_p3.clone(),
    }
}

/// ```prism
/// IsQuantCol: fn Lx, Col -> Bool
/// ```
pub fn is_quant_col(lx_p0: &Lx, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => crate::check::env::has_key(&lx_p0.quants, q_p1),
        c_p3 => false,
    }
}

/// ```prism
/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub fn typed_tables(tp_p0: &crate::check::typed::TProgram) -> (Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>) {
    let tys_p1 = fold(&tp_p0.exprs, &Map::new(), &(|m_p5: &Map<Text, crate::check::types::Ty>, n_p6: &crate::check::typed::TyNote| insert(m_p5, &crate::check::typed::at_key(&n_p6.at), &n_p6.ty)));
    let apps_p2 = fold(&tp_p0.apps, &Map::new(), &(|m_p7: &Map<Text, crate::check::typed::AppNote>, n_p8: &crate::check::typed::AppNote| insert(m_p7, &crate::check::typed::at_key(&n_p8.at), n_p8)));
    let bs_p3 = fold(&tp_p0.binders, &Map::new(), &(|m_p9: &Map<Text, crate::check::types::Ty>, n_pa: &crate::check::typed::BinderNote| insert(m_p9, &crate::check::typed::at_key(&n_pa.at), &n_pa.ty)));
    let ims_p4 = fold(&tp_p0.impls, &Map::new(), &(|m_pb: &Map<Text, Array<crate::check::typed::ImplNote>>, n_pc: &crate::check::typed::ImplNote| insert(m_pb, &crate::check::typed::at_key(&n_pc.at), &push(&or(&get(m_pb, &crate::check::typed::at_key(&n_pc.at)), &Array::new()), n_pc))));
    (tys_p1.clone(), apps_p2.clone(), bs_p3.clone(), ims_p4.clone())
}

/// ```prism
/// let rustKeywords
/// ```
pub fn rust_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")])
}

/// ```prism
/// Base: fn Text -> Text
/// ```
pub fn base(name_p0: &Text) -> Text {
    crate::syntax::lexer::chars::drop_prefix(name_p0, &crate::check::types::unify::marks_of(name_p0))
}

/// ```prism
/// Snake: fn Text -> Text
/// ```
pub fn snake(name_p0: &Text) -> Text {
    let (out_p6, _) = crate::syntax::lexer::chars::fold_chars(&base(name_p0), &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc_p2, prev_p3) = p0;
        let c_p4 = p1;
        {
            let sep_p5 = if crate::syntax::lexer::chars::is_upper(&c_p4) && (crate::syntax::lexer::chars::is_lower(&prev_p3) || crate::syntax::lexer::chars::is_digit(&prev_p3)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc_p2, &sep_p5, &lower_char(&c_p4))), c_p4.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    let plain_p1 = if &out_p6 == &Text::lit("") { Text::lit("x") } else { out_p6.clone() };
    if crate::check::types::has_text(&rust_keywords(), &plain_p1) {
        Text::from(format!("{}_", &plain_p1))
    } else {
        plain_p1.clone()
    }
}

/// ```prism
/// LowerChar: fn Text -> Text
/// ```
pub fn lower_char(c_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::is_upper(c_p0) {
        crate::prelude::lower(c_p0)
    } else {
        c_p0.clone()
    }
}

/// ```prism
/// Camel: fn Text -> Text
/// ```
pub fn camel(name_p0: &Text) -> Text {
    let b_p1 = base(name_p0);
    let first_p2 = crate::syntax::lexer::chars::head(&b_p1);
    let fixed_p3 = if crate::syntax::lexer::chars::is_lower(&first_p2) {
        Text::from(format!("{}{}", &upper(&first_p2), &crate::syntax::lexer::chars::after_first(&b_p1)))
    } else {
        b_p1.clone()
    };
    if (&fixed_p3 == &Text::lit("Self")) || crate::check::types::has_text(&runtime_names(), &fixed_p3) {
        Text::from(format!("{}_", &fixed_p3))
    } else {
        fixed_p3.clone()
    }
}

/// ```prism
/// let runtimeNames
/// ```
pub fn runtime_names() -> Array<Text> {
    Array::from(vec![Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")])
}

/// ```prism
/// let runtimeFns
/// ```
pub fn runtime_fns() -> Map<Text, bool> {
    fold(&Array::from(vec![Text::lit("abs"), Text::lit("after"), Text::lit("append"), Text::lit("as"), Text::lit("ask"), Text::lit("at"), Text::lit("at_mut"), Text::lit("at_mut_map"), Text::lit("back"), Text::lit("before"), Text::lit("call_then"), Text::lit("call_value"), Text::lit("case_unicode_version"), Text::lit("cat"), Text::lit("char_is_alphabetic"), Text::lit("char_is_alphanumeric"), Text::lit("char_is_uppercase"), Text::lit("char_is_whitespace"), Text::lit("char_of"), Text::lit("cloned"), Text::lit("compare"), Text::lit("concat"), Text::lit("cos"), Text::lit("cursor_at"), Text::lit("deref"), Text::lit("diff"), Text::lit("display"), Text::lit("div"), Text::lit("drive"), Text::lit("drop"), Text::lit("dynamic_blueprint"), Text::lit("dynamic_of"), Text::lit("each"), Text::lit("each_job"), Text::lit("each_map"), Text::lit("each_map_job"), Text::lit("element_blueprint"), Text::lit("entered"), Text::lit("enumerate"), Text::lit("event_blueprint"), Text::lit("event_of"), Text::lit("expect"), Text::lit("field"), Text::lit("filter"), Text::lit("filter_job"), Text::lit("filter_map"), Text::lit("filter_map_job"), Text::lit("filter_some"), Text::lit("find"), Text::lit("find_clickables"), Text::lit("finished"), Text::lit("first"), Text::lit("float"), Text::lit("float_"), Text::lit("float_digits"), Text::lit("fmap"), Text::lit("fold"), Text::lit("fold_from"), Text::lit("fold_job"), Text::lit("fold_map"), Text::lit("fold_map_job"), Text::lit("for_each"), Text::lit("for_turns"), Text::lit("for_turns_indexed"), Text::lit("for_turns_keyed"), Text::lit("forward_on_none"), Text::lit("freeze"), Text::lit("from_pod"), Text::lit("front"), Text::lit("get"), Text::lit("host_new"), Text::lit("ignore"), Text::lit("index"), Text::lit("indexed"), Text::lit("insert"), Text::lit("int"), Text::lit("int_"), Text::lit("is"), Text::lit("is_err"), Text::lit("is_none"), Text::lit("is_ok"), Text::lit("is_some"), Text::lit("iter_mut"), Text::lit("ix"), Text::lit("keys"), Text::lit("len"), Text::lit("len_map"), Text::lit("len_text"), Text::lit("loop_job"), Text::lit("loop_turns"), Text::lit("lower"), Text::lit("make_new"), Text::lit("make_rc"), Text::lit("map"), Text::lit("map_job"), Text::lit("map_of"), Text::lit("match_"), Text::lit("matches"), Text::lit("max"), Text::lit("min"), Text::lit("mismatch"), Text::lit("mismatch_fault"), Text::lit("mod_"), Text::lit("more"), Text::lit("named"), Text::lit("nat"), Text::lit("nat_of"), Text::lit("never_blueprint"), Text::lit("never_event"), Text::lit("new_rows"), Text::lit("next"), Text::lit("numbered"), Text::lit("ok"), Text::lit("ok_or"), Text::lit("on_big_stack"), Text::lit("once_job"), Text::lit("or"), Text::lit("or_"), Text::lit("pairs_of"), Text::lit("panic"), Text::lit("parse_nat_opt"), Text::lit("parse_nat_try"), Text::lit("path_of"), Text::lit("place"), Text::lit("plain_blueprint"), Text::lit("print_path"), Text::lit("print_tick"), Text::lit("push"), Text::lit("rc"), Text::lit("rc_placed"), Text::lit("rc_static_cast"), Text::lit("read_file"), Text::lit("regex"), Text::lit("remove"), Text::lit("replace"), Text::lit("run_canvas"), Text::lit("run_cli"), Text::lit("run_scripts"), Text::lit("run_to_end"), Text::lit("set_index"), Text::lit("set_key"), Text::lit("share"), Text::lit("show"), Text::lit("show_ref"), Text::lit("show_text"), Text::lit("sign"), Text::lit("sin"), Text::lit("size"), Text::lit("snapshot"), Text::lit("some_of"), Text::lit("split"), Text::lit("split_on"), Text::lit("step"), Text::lit("step_back"), Text::lit("str"), Text::lit("strip_comment_header"), Text::lit("subscribe_row"), Text::lit("sum"), Text::lit("take"), Text::lit("text"), Text::lit("text_lower"), Text::lit("text_upper"), Text::lit("to_float"), Text::lit("to_pod"), Text::lit("to_string"), Text::lit("u8_"), Text::lit("unexpected"), Text::lit("union"), Text::lit("union_"), Text::lit("unreachable"), Text::lit("unwrap_or_default"), Text::lit("upgrade"), Text::lit("upper"), Text::lit("utf8_decode"), Text::lit("utf8_encode"), Text::lit("utf8_error_at"), Text::lit("utf8_push"), Text::lit("values"), Text::lit("weaken"), Text::lit("world_option")]), &Map::new(), &(|m_p0: &Map<Text, bool>, n_p1: &Text| insert(m_p0, n_p1, &true)))
}

/// ```prism
/// Unclash: fn Text -> Text
/// ```
pub fn unclash(n_p0: &Text) -> Text {
    let n1_p1 = if crate::check::env::has_key(&runtime_fns(), n_p0) {
        Text::from(format!("{}_", n_p0))
    } else {
        n_p0.clone()
    };
    if crate::check::env::has_key(&runtime_fns(), &n1_p1) {
        Text::from(format!("{}_", &n1_p1))
    } else {
        n1_p1.clone()
    }
}

/// ```prism
/// RustModName: fn Text -> Text
/// ```
pub fn rust_mod_name(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("program")
    } else {
        crate::syntax::lexer::chars::join(&each(&split_on(m_p0, &Text::lit(".")), &(|s_p1: &Text| mod_segment(s_p1))), &Text::lit("::"))
    }
}

/// ```prism
/// ModSegment: fn Text -> Text
/// ```
pub fn mod_segment(s_p0: &Text) -> Text {
    let n_p1 = snake(s_p0);
    if crate::check::types::has_text(&cpp_keywords(), &n_p1) {
        Text::from(format!("{}_", &n_p1))
    } else {
        n_p1.clone()
    }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")])
}

/// ```prism
/// PathIn: fn Lx, Text, Text -> Text
/// ```
pub fn path_in(lx_p0: &Lx, owner_p1: &Text, name_p2: &Text) -> Text {
    if owner_p1 == &lx_p0.site {
        name_p2.clone()
    } else {
        if owner_p1 == &Text::lit("Prelude") {
            prelude_path(lx_p0, name_p2)
        } else {
            Text::from(format!("crate::{}::{}", &or(&get(&lx_p0.rs_mods, owner_p1), &rust_mod_name(owner_p1)), name_p2))
        }
    }
}

/// ```prism
/// PreludePath: fn Lx, Text -> Text
/// ```
pub fn prelude_path(lx_p0: &Lx, name_p1: &Text) -> Text {
    if crate::check::env::has_key(&lx_p0.globals, &Text::from(format!("{}.{}", &lx_p0.site, name_p1))) || crate::check::env::has_key(&lx_p0.mod_segments, name_p1) {
        Text::from(format!("crate::prelude::{}", name_p1))
    } else {
        name_p1.clone()
    }
}

/// ```prism
/// ValueNames: fn G -> (Text ==> Text)
/// ```
pub fn value_names(g_p0: &crate::check::env::G) -> Map<Text, Text> {
    let lets_p1 = fold(&g_p0.defs, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::check::env::Def| match &d_p5.body {
        crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text(acc_p4, &d_p5.qk),
        _ => acc_p4.clone(),
    }));
    let keys_p2 = crate::check::types::union_texts(&keys(&g_p0.vals), &lets_p1);
    let bases_p3 = fold(&keys_p2, &Map::new(), &(|m_p6: &Map<Text, Array<Text>>, k_p7: &Text| insert(m_p6, &base_key(k_p7), &push(&or(&get(m_p6, &base_key(k_p7)), &Array::new()), k_p7))));
    fold(&keys_p2, &Map::new(), &(|m_p8: &Map<Text, Text>, k_p9: &Text| {
        let name_pa = value_name(k_p9, &len(&or(&get(&bases_p3, &base_key(k_p9)), &Array::new())));
        let runtimes_pb = (&owner_of(k_p9) == &Text::lit("Prelude")) || match get(&g_p0.vals, k_p9) {
            Some(v_pc) => (&v_pc.sort == &Text::lit("builtin")) || (&v_pc.home == &Text::lit("Prelude")),
            None => false,
        };
        insert(m_p8, k_p9, &(if runtimes_pb { name_pa.clone() } else { unclash(&name_pa) }))
    }))
}

/// ```prism
/// GlobalNames: fn G -> (Text ==> Bool)
/// ```
pub fn global_names(g_p0: &crate::check::env::G) -> Map<Text, bool> {
    let names_p1 = value_names(g_p0);
    fold(&keys(&names_p1), &Map::new(), &(|m_p2: &Map<Text, bool>, k_p3: &Text| insert(m_p2, &Text::from(format!("{}.{}", &owner_of(k_p3), &or(&get(&names_p1, k_p3), &Text::lit("")))), &true)))
}

/// ```prism
/// LocalName: fn Lx, Text -> Text
/// ```
pub fn local_name(lx_p0: &Lx, nkey_p1: &Text) -> Text {
    let marks_p2 = crate::check::types::unify::marks_of(nkey_p1);
    let base_p3 = snake(nkey_p1);
    let bare_p4 = crate::syntax::lexer::chars::drop_prefix(nkey_p1, &marks_p2);
    let s0_p5 = if crate::syntax::lexer::chars::contains(&marks_p2, &Text::lit("?")) {
        Text::from(format!("{}_opt", &base_p3))
    } else {
        if crate::syntax::lexer::chars::contains(&marks_p2, &Text::lit("~")) {
            Text::from(format!("{}_try", &base_p3))
        } else {
            base_p3.clone()
        }
    };
    let s1_p6 = if crate::check::env::is_upper_text(&crate::syntax::lexer::chars::head(&bare_p4)) {
        Text::from(format!("{}_fn", &s0_p5))
    } else {
        s0_p5.clone()
    };
    unclash(&(if crate::check::env::has_key(&lx_p0.globals, &Text::from(format!("{}.{}", &lx_p0.site, &s1_p6))) || crate::check::env::has_key(&lx_p0.globals, &Text::from(format!("Prelude.{}", &s1_p6))) {
        Text::from(format!("{}_", &s1_p6))
    } else {
        s1_p6.clone()
    }))
}

/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub fn local_name_at(lx_p0: &Lx, nkey_p1: &Text, span_p2: &crate::syntax::Range) -> Text {
    match get(&lx_p0.local_ids, &place_key(lx_p0, span_p2)) {
        Some(id_p3) => Text::from(format!("{}_{}{}", &local_base(nkey_p1), &kind_letter(&binder_ty(lx_p0, span_p2)), &base32(&id_p3))),
        None => local_name(lx_p0, nkey_p1),
    }
}

/// The step machine of `LocalNameAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub struct LocalNameAt {
    pub lx_p0: Lx,
    pub nkey_p1: Text,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<Text> for LocalNameAt {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let lx_p0 = &self.lx_p0;
        let nkey_p1 = &self.nkey_p1;
        let span_p2 = &self.span_p2;
        match get(&lx_p0.local_ids, &place_key(lx_p0, span_p2)) {
            Some(id_p3) => {
                let lx_p0 = lx_p0.clone();
                let nkey_p1 = nkey_p1.clone();
                let span_p2 = span_p2.clone();
                call_then(start_local_base(nkey_p1.clone()), move |local_base_17647: Text| call_then(start_base32(id_p3.clone()), move |base32_17696: Text| prism_rtl::Turn::Finished(Text::from(format!("{}_{}{}", &local_base_17647, &kind_letter(&binder_ty(&lx_p0, &span_p2)), &base32_17696)))))
            },
            None => prism_rtl::Turn::Finished(local_name(lx_p0, nkey_p1)),
        }
    }
}

/// `Start LocalNameAt, x`: what the function value is when passed to `@Run`.
pub fn start_local_name_at(lx_p0: Lx, nkey_p1: Text, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LocalNameAt { lx_p0, nkey_p1, span_p2 })
}

/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub fn local_base(nkey_p0: &Text) -> Text {
    let bare_p1 = crate::syntax::lexer::chars::drop_prefix(nkey_p0, &crate::check::types::unify::marks_of(nkey_p0));
    let base_p2 = snake(&bare_p1);
    let trimmed_p3 = trim_underscores(&base_p2);
    if &trimmed_p3 == &Text::lit("") { Text::lit("topic") } else { trimmed_p3.clone() }
}

/// The step machine of `LocalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub struct LocalBase {
    pub nkey_p0: Text,
}

impl prism_rtl::Job<Text> for LocalBase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let nkey_p0 = &self.nkey_p0;
        let bare_p1 = crate::syntax::lexer::chars::drop_prefix(nkey_p0, &crate::check::types::unify::marks_of(nkey_p0));
        let base_p2 = snake(&bare_p1);
        call_then(start_trim_underscores(base_p2.clone()), move |trim_underscores_18021: Text| {
            let trimmed_p3 = trim_underscores_18021;
            if &trimmed_p3 == &Text::lit("") {
                prism_rtl::Turn::Finished(Text::lit("topic"))
            } else {
                prism_rtl::Turn::Finished(trimmed_p3.clone())
            }
        })
    }
}

/// `Start LocalBase, x`: what the function value is when passed to `@Run`.
pub fn start_local_base(nkey_p0: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LocalBase { nkey_p0 })
}

/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub fn trim_underscores(t_p0: &Text) -> Text {
    match crate::syntax::lexer::chars::before_suffix(t_p0, &Text::lit("_")) {
        Some(s_p1) => trim_underscores(&s_p1),
        None => t_p0.clone(),
    }
}

/// The step machine of `TrimUnderscores`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub struct TrimUnderscores {
    pub t_p0: Text,
}

impl prism_rtl::Job<Text> for TrimUnderscores {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match crate::syntax::lexer::chars::before_suffix(t_p0, &Text::lit("_")) {
            Some(s_p1) => prism_rtl::Turn::More(Rc::new(TrimUnderscores { t_p0: s_p1.clone() })),
            None => prism_rtl::Turn::Finished(t_p0.clone()),
        }
    }
}

/// `Start TrimUnderscores, x`: what the function value is when passed to `@Run`.
pub fn start_trim_underscores(t_p0: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TrimUnderscores { t_p0 })
}

/// ```prism
/// KindLetter: fn Ty -> Text
/// ```
pub fn kind_letter(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TySig(m18427_0_0, _) if (m18427_0_0 == &Text::lit("!")) => Text::lit("e"),
        crate::check::types::Ty::TySig(m18427_1_0, _) if (m18427_1_0 == &Text::lit("$")) => Text::lit("d"),
        crate::check::types::Ty::TySig(m18427_2_0, _) if (m18427_2_0 == &Text::lit("?")) => Text::lit("o"),
        crate::check::types::Ty::TySig(m18427_3_0, _) if (m18427_3_0 == &Text::lit("~")) => Text::lit("r"),
        crate::check::types::Ty::TySig(m18427_4_0, i_p1) if (m18427_4_0 == &Text::lit("&")) => kind_letter(&**i_p1),
        crate::check::types::Ty::TyAt(_, _) => Text::lit("b"),
        crate::check::types::Ty::TyFn(_, _, _) => Text::lit("f"),
        _ => Text::lit("p"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub fn base32(n_p0: &Nat) -> Text {
    let digit_p1 = crate::syntax::lexer::chars::char_at_byte(&Text::lit("0123456789abcdefghijklmnopqrstuv"), &or(&mod_(n_p0, &Nat::from(32u32)), &Nat::from(0u32)));
    match div(n_p0, &Nat::from(32u32)) {
        Some(q_p2) if (&q_p2 > &Nat::from(0u32)) => Text::from(format!("{}{}", &base32(&q_p2), &digit_p1)),
        _ => digit_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Base32`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub struct Base32 {
    pub n_p0: Nat,
}

impl prism_rtl::Job<Text> for Base32 {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n_p0 = &self.n_p0;
        let digit_p1 = crate::syntax::lexer::chars::char_at_byte(&Text::lit("0123456789abcdefghijklmnopqrstuv"), &or(&mod_(n_p0, &Nat::from(32u32)), &Nat::from(0u32)));
        match div(n_p0, &Nat::from(32u32)) {
            Some(q_p2) if (&q_p2 > &Nat::from(0u32)) => call_then(start_base32(q_p2.clone()), move |base32_18893: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &base32_18893, &digit_p1)))),
            _ => prism_rtl::Turn::Finished(digit_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Base32, x`: what the function value is when passed to `@Run`.
pub fn start_base32(n_p0: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Base32 { n_p0 })
}

/// ```prism
/// BaseKey: fn Text -> Text
/// ```
pub fn base_key(k_p0: &Text) -> Text {
    let parts_p1 = split_on(k_p0, &Text::lit("."));
    let last_p2 = or(&crate::syntax::lexer::chars::last(&parts_p1), k_p0);
    Text::from(format!("{}.{}", &crate::syntax::lexer::chars::join(&take(&parts_p1, &crate::syntax::lexer::chars::dec(&len(&parts_p1))), &Text::lit(".")), &snake(&last_p2)))
}

/// ```prism
/// ValueName: fn Text, Nat -> Text
/// ```
pub fn value_name(k_p0: &Text, count_p1: &Nat) -> Text {
    let last_p2 = crate::check::types::bare_name(k_p0);
    let marks_p3 = crate::check::types::unify::marks_of(&last_p2);
    let base_p4 = snake(&last_p2);
    if (count_p1 > &Nat::from(1u32)) && (&marks_p3 != &Text::lit("")) {
        Text::from(format!("{}_{}", &base_p4, &sigil_word(&crate::syntax::lexer::chars::head(&marks_p3))))
    } else {
        if (count_p1 > &Nat::from(1u32)) && !crate::check::env::is_upper_text(&crate::syntax::lexer::chars::head(&last_p2)) {
            Text::from(format!("{}_value", &base_p4))
        } else {
            base_p4.clone()
        }
    }
}

/// ```prism
/// SigilWord: fn Text -> Text
/// ```
pub fn sigil_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("?")) => Text::lit("opt"),
        c1_0 if (c1_0 == &Text::lit("~")) => Text::lit("try"),
        c2_0 if (c2_0 == &Text::lit("!")) => Text::lit("ev"),
        c3_0 if (c3_0 == &Text::lit("$")) => Text::lit("dyn"),
        c4_0 if (c4_0 == &Text::lit("@")) => Text::lit("widget"),
        c5_0 if (c5_0 == &Text::lit("&")) => Text::lit("ref"),
        other_p0 => Text::lit("x"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ValuePath: fn Lx, Text -> Text
/// ```
pub fn value_path(lx_p0: &Lx, qk_p1: &Text) -> Text {
    let owner_p2 = match get(&lx_p0.g.vals, qk_p1) {
        Some(v_p3) => v_p3.home.clone(),
        None => owner_of(qk_p1),
    };
    path_in(lx_p0, &owner_p2, &or(&get(&lx_p0.rs_names, qk_p1), &snake(&crate::check::types::bare_name(qk_p1))))
}

/// ```prism
/// OwnerOf: fn Text -> Text
/// ```
pub fn owner_of(qk_p0: &Text) -> Text {
    let parts_p1 = split_on(qk_p0, &Text::lit("."));
    crate::syntax::lexer::chars::join(&take(&parts_p1, &crate::syntax::lexer::chars::dec(&len(&parts_p1))), &Text::lit("."))
}

/// ```prism
/// TagStruct: fn Text -> Text
/// ```
pub fn tag_struct(tn_p0: &Text) -> Text {
    concat(&each(&split_on(tn_p0, &Text::lit(".")), &(|p_p1: &Text| camel(p_p1))))
}
