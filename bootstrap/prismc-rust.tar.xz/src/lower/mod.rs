//! The module `Lower`, from `target/bootstrap/src/prismc/lower/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod functions;
pub mod jobs;
pub mod model;
pub mod node_;
pub mod patterns;
pub mod program;
pub mod templates;
pub mod types;

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lx {
    pub g: crate::check::env::G,
    pub tys: Map<Text, crate::check::types::Ty>,
    pub apps: Map<Text, crate::check::typed::AppNote>,
    pub binders: Map<Text, crate::check::types::Ty>,
    pub impls: Map<Text, Array<crate::check::typed::ImplNote>>,
    pub file: Nat,
    pub home: Text,
    pub site: Text,
    pub rs_mods: Map<Text, Text>,
    pub mod_segments: Map<Text, bool>,
    pub rs_names: Map<Text, Text>,
    pub layouts: Map<Text, Array<bool>>,
    pub unbs: Array<Text>,
    pub notes: Array<Text>,
    pub globals: Map<Text, bool>,
    pub in_node: bool,
    pub unshrunk: Map<Text, bool>,
    pub gens: Map<Text, crate::check::typed::GenNote>,
    pub insts: Map<Text, Array<crate::check::typed::InstNote>>,
    pub quants: Map<Text, Text>,
    pub gen_of_q: Map<Text, crate::check::typed::GenNote>,
    pub use_insts: Map<Text, crate::check::typed::InstNote>,
    pub subst: Map<Text, crate::check::types::Ty>,
    pub csubst: Map<Text, crate::check::types::Col>,
}

impl Show for Lx {
    fn show(&self, p: &mut Printer) {
        p.record("Lx", &[("g", &self.g), ("tys", &self.tys), ("apps", &self.apps), ("binders", &self.binders), ("impls", &self.impls), ("file", &self.file), ("home", &self.home), ("site", &self.site), ("rs_mods", &self.rs_mods), ("mod_segments", &self.mod_segments), ("rs_names", &self.rs_names), ("layouts", &self.layouts), ("unbs", &self.unbs), ("notes", &self.notes), ("globals", &self.globals), ("in_node", &self.in_node), ("unshrunk", &self.unshrunk), ("gens", &self.gens), ("insts", &self.insts), ("quants", &self.quants), ("gen_of_q", &self.gen_of_q), ("use_insts", &self.use_insts), ("subst", &self.subst), ("csubst", &self.csubst)]);
    }
}

impl ToPod for Lx {
    fn to_pod(&self) -> Pod {
        Pod::record("Lx", vec![("g", self.g.to_pod()), ("tys", self.tys.to_pod()), ("apps", self.apps.to_pod()), ("binders", self.binders.to_pod()), ("impls", self.impls.to_pod()), ("file", self.file.to_pod()), ("home", self.home.to_pod()), ("site", self.site.to_pod()), ("rs_mods", self.rs_mods.to_pod()), ("mod_segments", self.mod_segments.to_pod()), ("rs_names", self.rs_names.to_pod()), ("layouts", self.layouts.to_pod()), ("unbs", self.unbs.to_pod()), ("notes", self.notes.to_pod()), ("globals", self.globals.to_pod()), ("in_node", self.in_node.to_pod()), ("unshrunk", self.unshrunk.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("quants", self.quants.to_pod()), ("gen_of_q", self.gen_of_q.to_pod()), ("use_insts", self.use_insts.to_pod()), ("subst", self.subst.to_pod()), ("csubst", self.csubst.to_pod())])
    }
}

impl FromPod for Lx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lx { g: FromPod::from_pod(field(p, "g")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, file: FromPod::from_pod(field(p, "file")?)?, home: FromPod::from_pod(field(p, "home")?)?, site: FromPod::from_pod(field(p, "site")?)?, rs_mods: FromPod::from_pod(field(p, "rs_mods")?)?, mod_segments: FromPod::from_pod(field(p, "mod_segments")?)?, rs_names: FromPod::from_pod(field(p, "rs_names")?)?, layouts: FromPod::from_pod(field(p, "layouts")?)?, unbs: FromPod::from_pod(field(p, "unbs")?)?, notes: FromPod::from_pod(field(p, "notes")?)?, globals: FromPod::from_pod(field(p, "globals")?)?, in_node: FromPod::from_pod(field(p, "in_node")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, quants: FromPod::from_pod(field(p, "quants")?)?, gen_of_q: FromPod::from_pod(field(p, "gen_of_q")?)?, use_insts: FromPod::from_pod(field(p, "use_insts")?)?, subst: FromPod::from_pod(field(p, "subst")?)?, csubst: FromPod::from_pod(field(p, "csubst")?)? })
    }
}

/// ```prism
/// PlaceKey: fn Lx, Range -> Text
/// ```
pub fn place_key(lx: &Lx, r: &crate::syntax::Range) -> Text {
    Text::from(format!("{}:{}:{}", &lx.file, &r.start, &r.end))
}

/// ```prism
/// TypeAt: fn Lx, Range -> Ty
/// ```
pub fn type_at(lx: &Lx, r: &crate::syntax::Range) -> crate::check::types::Ty {
    subst_ty(lx, &or(&get(&lx.tys, &place_key(lx, r)), &crate::check::types::Ty::TyErr))
}

/// ```prism
/// BinderTy: fn Lx, Range -> Ty
/// ```
pub fn binder_ty(lx: &Lx, r: &crate::syntax::Range) -> crate::check::types::Ty {
    match get(&lx.binders, &place_key(lx, r)) {
        Some(t) => subst_ty(lx, &t),
        None => type_at(lx, r),
    }
}

/// ```prism
/// SubstTy: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty(lx: &Lx, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    if (&len(&keys(&lx.subst)) == &Nat::from(0u32)) && (&len(&keys(&lx.csubst)) == &Nat::from(0u32)) {
        t.clone()
    } else {
        subst_ty_in(lx, t)
    }
}

/// ```prism
/// SubstTyIn: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_in(lx: &Lx, t: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t {
        crate::check::types::Ty::TyFlex(n) => or(&get(&lx.subst, &Text::from(format!("\'{}", n))), t),
        crate::check::types::Ty::TyCon(n, args) => crate::check::types::Ty::TyCon(n.clone(), each(args, &(|a: &crate::check::types::Ty| subst_ty_in(lx, a)))),
        crate::check::types::Ty::TyFn(c, ps, res) => crate::check::types::Ty::TyFn(inst_col(lx, c), each(ps, &(|p_: &crate::check::types::Ty| subst_ty_in(lx, p_))), Rc::new(subst_ty_in(lx, &**res))),
        crate::check::types::Ty::TyTuple(ts) => crate::check::types::Ty::TyTuple(each(ts, &(|a: &crate::check::types::Ty| subst_ty_in(lx, a)))),
        crate::check::types::Ty::TyArray(e) => crate::check::types::Ty::TyArray(Rc::new(subst_ty_in(lx, &**e))),
        crate::check::types::Ty::TyMap(k, v_) => crate::check::types::Ty::TyMap(Rc::new(subst_ty_in(lx, &**k)), Rc::new(subst_ty_in(lx, &**v_))),
        crate::check::types::Ty::TySig(s, i) => crate::check::types::Ty::TySig(s.clone(), Rc::new(subst_ty_in(lx, &**i))),
        crate::check::types::Ty::TyAt(i, rw) => crate::check::types::Ty::TyAt(Rc::new(subst_ty_in(lx, &**i)), rw.clone()),
        crate::check::types::Ty::TyElem(rw, o) => crate::check::types::Ty::TyElem(rw.clone(), Rc::new(subst_ty_in(lx, &**o))),
        crate::check::types::Ty::TyAssoc(n, a) => crate::check::types::Ty::TyAssoc(n.clone(), Rc::new(subst_ty_in(lx, &**a))),
        other => other.clone(),
    }
}

/// ```prism
/// InstCol: fn Lx, Col -> Col
/// ```
pub fn inst_col(lx: &Lx, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(q) => or(&get(&lx.csubst, q), &crate::check::types::Col::CQ(q.clone())),
        c => c.clone(),
    }
}

/// ```prism
/// IsQuantCol: fn Lx, Col -> Bool
/// ```
pub fn is_quant_col(lx: &Lx, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CQ(q) => crate::check::env::has_key(&lx.quants, q),
        c => false,
    }
}

/// ```prism
/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub fn typed_tables(tp: &crate::check::typed::TProgram) -> (Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>) {
    let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::TyNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
    let apps = fold(&tp.apps, &Map::new(), &(|m: &Map<Text, crate::check::typed::AppNote>, n: &crate::check::typed::AppNote| insert(m, &crate::check::typed::at_key(&n.at), n)));
    let bs = fold(&tp.binders, &Map::new(), &(|m: &Map<Text, crate::check::types::Ty>, n: &crate::check::typed::BinderNote| insert(m, &crate::check::typed::at_key(&n.at), &n.ty)));
    let ims = fold(&tp.impls, &Map::new(), &(|m: &Map<Text, Array<crate::check::typed::ImplNote>>, n: &crate::check::typed::ImplNote| insert(m, &crate::check::typed::at_key(&n.at), &push(&or(&get(m, &crate::check::typed::at_key(&n.at)), &Array::new()), n))));
    (tys.clone(), apps.clone(), bs.clone(), ims.clone())
}

/// ```prism
/// let rustKeywords
/// ```
pub fn rust_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")])
}

/// ```prism
/// Base: fn Text -> Text
/// ```
pub fn base(name: &Text) -> Text {
    crate::syntax::lexer::chars::drop_prefix(name, &crate::check::types::unify::marks_of(name))
}

/// ```prism
/// Snake: fn Text -> Text
/// ```
pub fn snake(name: &Text) -> Text {
    let (out, _) = crate::syntax::lexer::chars::fold_chars(&base(name), &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc, prev) = p0;
        let c = p1;
        {
            let sep = if crate::syntax::lexer::chars::is_upper(&c) && (crate::syntax::lexer::chars::is_lower(&prev) || crate::syntax::lexer::chars::is_digit(&prev)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc, &sep, &lower_char(&c))), c.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    let plain = if &out == &Text::lit("") { Text::lit("x") } else { out.clone() };
    if crate::check::types::has_text(&rust_keywords(), &plain) {
        Text::from(format!("{}_", &plain))
    } else {
        plain.clone()
    }
}

/// ```prism
/// LowerChar: fn Text -> Text
/// ```
pub fn lower_char(c: &Text) -> Text {
    if crate::syntax::lexer::chars::is_upper(c) {
        crate::prelude::lower(c)
    } else {
        c.clone()
    }
}

/// ```prism
/// Camel: fn Text -> Text
/// ```
pub fn camel(name: &Text) -> Text {
    let b = base(name);
    let first_ = crate::syntax::lexer::chars::head(&b);
    let fixed = if crate::syntax::lexer::chars::is_lower(&first_) {
        Text::from(format!("{}{}", &upper(&first_), &crate::syntax::lexer::chars::after_first(&b)))
    } else {
        b.clone()
    };
    if (&fixed == &Text::lit("Self")) || crate::check::types::has_text(&runtime_names(), &fixed) {
        Text::from(format!("{}_", &fixed))
    } else {
        fixed.clone()
    }
}

/// ```prism
/// let runtimeNames
/// ```
pub fn runtime_names() -> Array<Text> {
    Array::from(vec![Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")])
}

/// ```prism
/// RustModName: fn Text -> Text
/// ```
pub fn rust_mod_name(m: &Text) -> Text {
    if m == &Text::lit("") {
        Text::lit("program")
    } else {
        crate::syntax::lexer::chars::join(&each(&split_on(m, &Text::lit(".")), &(|s: &Text| mod_segment(s))), &Text::lit("::"))
    }
}

/// ```prism
/// ModSegment: fn Text -> Text
/// ```
pub fn mod_segment(s: &Text) -> Text {
    let n = snake(s);
    if crate::check::types::has_text(&cpp_keywords(), &n) {
        Text::from(format!("{}_", &n))
    } else {
        n.clone()
    }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords() -> Array<Text> {
    Array::from(vec![Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")])
}

/// ```prism
/// PathIn: fn Lx, Text, Text -> Text
/// ```
pub fn path_in(lx: &Lx, owner: &Text, name: &Text) -> Text {
    if owner == &lx.site {
        name.clone()
    } else {
        if owner == &Text::lit("Prelude") {
            prelude_path(lx, name)
        } else {
            Text::from(format!("crate::{}::{}", &or(&get(&lx.rs_mods, owner), &rust_mod_name(owner)), name))
        }
    }
}

/// ```prism
/// PreludePath: fn Lx, Text -> Text
/// ```
pub fn prelude_path(lx: &Lx, name: &Text) -> Text {
    if crate::check::env::has_key(&lx.globals, &Text::from(format!("{}.{}", &lx.site, name))) || crate::check::env::has_key(&lx.mod_segments, name) {
        Text::from(format!("crate::prelude::{}", name))
    } else {
        name.clone()
    }
}

/// ```prism
/// ValueNames: fn G -> (Text ==> Text)
/// ```
pub fn value_names(g: &crate::check::env::G) -> Map<Text, Text> {
    let lets = fold(&g.defs, &Array::new(), &(|acc: &Array<Text>, d: &crate::check::env::Def| match &d.body {
        crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text(acc, &d.qk),
        _ => acc.clone(),
    }));
    let keys_ = crate::check::types::union_texts(&keys(&g.vals), &lets);
    let bases = fold(&keys_, &Map::new(), &(|m: &Map<Text, Array<Text>>, k: &Text| insert(m, &base_key(k), &push(&or(&get(m, &base_key(k)), &Array::new()), k))));
    fold(&keys_, &Map::new(), &(|m: &Map<Text, Text>, k: &Text| insert(m, k, &value_name(k, &len(&or(&get(&bases, &base_key(k)), &Array::new()))))))
}

/// ```prism
/// GlobalNames: fn G -> (Text ==> Bool)
/// ```
pub fn global_names(g: &crate::check::env::G) -> Map<Text, bool> {
    let names = value_names(g);
    fold(&keys(&names), &Map::new(), &(|m: &Map<Text, bool>, k: &Text| insert(m, &Text::from(format!("{}.{}", &owner_of(k), &or(&get(&names, k), &Text::lit("")))), &true)))
}

/// ```prism
/// LocalName: fn Lx, Text -> Text
/// ```
pub fn local_name(lx: &Lx, nkey: &Text) -> Text {
    let marks = crate::check::types::unify::marks_of(nkey);
    let base_ = snake(nkey);
    let bare = crate::syntax::lexer::chars::drop_prefix(nkey, &marks);
    let s0 = if crate::syntax::lexer::chars::contains(&marks, &Text::lit("?")) {
        Text::from(format!("{}_opt", &base_))
    } else {
        if crate::syntax::lexer::chars::contains(&marks, &Text::lit("~")) {
            Text::from(format!("{}_try", &base_))
        } else {
            base_.clone()
        }
    };
    let s1 = if crate::check::env::is_upper_text(&crate::syntax::lexer::chars::head(&bare)) {
        Text::from(format!("{}_fn", &s0))
    } else {
        s0.clone()
    };
    if crate::check::env::has_key(&lx.globals, &Text::from(format!("{}.{}", &lx.site, &s1))) || crate::check::env::has_key(&lx.globals, &Text::from(format!("Prelude.{}", &s1))) {
        Text::from(format!("{}_", &s1))
    } else {
        s1.clone()
    }
}

/// ```prism
/// BaseKey: fn Text -> Text
/// ```
pub fn base_key(k: &Text) -> Text {
    let parts = split_on(k, &Text::lit("."));
    let last = or(&crate::syntax::lexer::chars::last(&parts), k);
    Text::from(format!("{}.{}", &crate::syntax::lexer::chars::join(&take(&parts, &crate::syntax::lexer::chars::dec(&len(&parts))), &Text::lit(".")), &snake(&last)))
}

/// ```prism
/// ValueName: fn Text, Nat -> Text
/// ```
pub fn value_name(k: &Text, count: &Nat) -> Text {
    let last = crate::check::types::bare_name(k);
    let marks = crate::check::types::unify::marks_of(&last);
    let base_ = snake(&last);
    if (count > &Nat::from(1u32)) && (&marks != &Text::lit("")) {
        Text::from(format!("{}_{}", &base_, &sigil_word(&crate::syntax::lexer::chars::head(&marks))))
    } else {
        if (count > &Nat::from(1u32)) && !crate::check::env::is_upper_text(&crate::syntax::lexer::chars::head(&last)) {
            Text::from(format!("{}_value", &base_))
        } else {
            base_.clone()
        }
    }
}

/// ```prism
/// SigilWord: fn Text -> Text
/// ```
pub fn sigil_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("?")) => Text::lit("opt"),
        c1_0 if (c1_0 == &Text::lit("~")) => Text::lit("try"),
        c2_0 if (c2_0 == &Text::lit("!")) => Text::lit("ev"),
        c3_0 if (c3_0 == &Text::lit("$")) => Text::lit("dyn"),
        c4_0 if (c4_0 == &Text::lit("@")) => Text::lit("widget"),
        c5_0 if (c5_0 == &Text::lit("&")) => Text::lit("ref"),
        other => Text::lit("x"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ValuePath: fn Lx, Text -> Text
/// ```
pub fn value_path(lx: &Lx, qk: &Text) -> Text {
    let owner = match get(&lx.g.vals, qk) {
        Some(v_) => v_.home.clone(),
        None => owner_of(qk),
    };
    path_in(lx, &owner, &or(&get(&lx.rs_names, qk), &snake(&crate::check::types::bare_name(qk))))
}

/// ```prism
/// OwnerOf: fn Text -> Text
/// ```
pub fn owner_of(qk: &Text) -> Text {
    let parts = split_on(qk, &Text::lit("."));
    crate::syntax::lexer::chars::join(&take(&parts, &crate::syntax::lexer::chars::dec(&len(&parts))), &Text::lit("."))
}

/// ```prism
/// TagStruct: fn Text -> Text
/// ```
pub fn tag_struct(tn: &Text) -> Text {
    concat(&each(&split_on(tn, &Text::lit(".")), &(|p_: &Text| camel(p_))))
}
