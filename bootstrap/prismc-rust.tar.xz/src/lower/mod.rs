//! The module `Lower`, from `target/bootstrap/src/prismc/lower/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
pub mod expr;
pub mod functions;
pub mod jobs;
pub mod model;
pub mod node_;
pub mod patterns;
pub mod program;
pub mod templates;
pub mod types;

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Lx {
    pub g_p: crate::check::env::G,
    pub tys_p: Map<Text, crate::check::types::Ty>,
    pub apps_p: Map<Text, crate::check::typed::AppNote>,
    pub lifts_p: Map<Text, crate::check::typed::LiftNote>,
    pub binders_p: Map<Text, crate::check::types::Ty>,
    pub impls_p: Map<Text, Array<crate::check::typed::ImplNote>>,
    pub file_p: Nat,
    pub home_p: Text,
    pub site_p: Text,
    pub rs_mods_p: Map<Text, Text>,
    pub mod_segments_p: Map<Text, bool>,
    pub rs_names_p: Map<Text, Text>,
    pub layouts_p: Map<Text, Array<bool>>,
    pub unbs_p: Array<Text>,
    pub notes_p: Array<Text>,
    pub globals_p: Map<Text, bool>,
    pub in_node_p: bool,
    pub unshrunk_p: Map<Text, bool>,
    pub gens_p: Map<Text, crate::check::typed::GenNote>,
    pub insts_p: Map<Text, Array<crate::check::typed::InstNote>>,
    pub quants_p: Map<Text, Text>,
    pub gen_of_q_p: Map<Text, crate::check::typed::GenNote>,
    pub use_insts_p: Map<Text, crate::check::typed::InstNote>,
    pub local_ids_p: Map<Text, Nat>,
    pub use_ids_p: Map<Text, Nat>,
    pub call_ids_p: Map<Text, Nat>,
    pub inlined_p: Text,
    pub subst_p: Map<Text, crate::check::types::Ty>,
    pub csubst_p: Map<Text, crate::check::types::Col>,
}

impl Show for Lx {
    fn show(&self, p: &mut Printer) {
        p.record("Lx", &[("g", &self.g_p), ("tys", &self.tys_p), ("apps", &self.apps_p), ("lifts", &self.lifts_p), ("binders", &self.binders_p), ("impls", &self.impls_p), ("file", &self.file_p), ("home", &self.home_p), ("site", &self.site_p), ("rsMods", &self.rs_mods_p), ("modSegments", &self.mod_segments_p), ("rsNames", &self.rs_names_p), ("layouts", &self.layouts_p), ("unbs", &self.unbs_p), ("notes", &self.notes_p), ("globals", &self.globals_p), ("inNode", &self.in_node_p), ("unshrunk", &self.unshrunk_p), ("gens", &self.gens_p), ("insts", &self.insts_p), ("quants", &self.quants_p), ("genOfQ", &self.gen_of_q_p), ("useInsts", &self.use_insts_p), ("localIds", &self.local_ids_p), ("useIds", &self.use_ids_p), ("callIds", &self.call_ids_p), ("inlined", &self.inlined_p), ("subst", &self.subst_p), ("csubst", &self.csubst_p)]);
    }
}

impl ToPod for Lx {
    fn to_pod(&self) -> Pod {
        Pod::record("Lx", vec![("g", self.g_p.to_pod()), ("tys", self.tys_p.to_pod()), ("apps", self.apps_p.to_pod()), ("lifts", self.lifts_p.to_pod()), ("binders", self.binders_p.to_pod()), ("impls", self.impls_p.to_pod()), ("file", self.file_p.to_pod()), ("home", self.home_p.to_pod()), ("site", self.site_p.to_pod()), ("rsMods", self.rs_mods_p.to_pod()), ("modSegments", self.mod_segments_p.to_pod()), ("rsNames", self.rs_names_p.to_pod()), ("layouts", self.layouts_p.to_pod()), ("unbs", self.unbs_p.to_pod()), ("notes", self.notes_p.to_pod()), ("globals", self.globals_p.to_pod()), ("inNode", self.in_node_p.to_pod()), ("unshrunk", self.unshrunk_p.to_pod()), ("gens", self.gens_p.to_pod()), ("insts", self.insts_p.to_pod()), ("quants", self.quants_p.to_pod()), ("genOfQ", self.gen_of_q_p.to_pod()), ("useInsts", self.use_insts_p.to_pod()), ("localIds", self.local_ids_p.to_pod()), ("useIds", self.use_ids_p.to_pod()), ("callIds", self.call_ids_p.to_pod()), ("inlined", self.inlined_p.to_pod()), ("subst", self.subst_p.to_pod()), ("csubst", self.csubst_p.to_pod())])
    }
}

impl FromPod for Lx {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Lx { g_p: FromPod::from_pod(field(p, "g")?)?, tys_p: FromPod::from_pod(field(p, "tys")?)?, apps_p: FromPod::from_pod(field(p, "apps")?)?, lifts_p: FromPod::from_pod(field(p, "lifts")?)?, binders_p: FromPod::from_pod(field(p, "binders")?)?, impls_p: FromPod::from_pod(field(p, "impls")?)?, file_p: FromPod::from_pod(field(p, "file")?)?, home_p: FromPod::from_pod(field(p, "home")?)?, site_p: FromPod::from_pod(field(p, "site")?)?, rs_mods_p: FromPod::from_pod(field(p, "rsMods")?)?, mod_segments_p: FromPod::from_pod(field(p, "modSegments")?)?, rs_names_p: FromPod::from_pod(field(p, "rsNames")?)?, layouts_p: FromPod::from_pod(field(p, "layouts")?)?, unbs_p: FromPod::from_pod(field(p, "unbs")?)?, notes_p: FromPod::from_pod(field(p, "notes")?)?, globals_p: FromPod::from_pod(field(p, "globals")?)?, in_node_p: FromPod::from_pod(field(p, "inNode")?)?, unshrunk_p: FromPod::from_pod(field(p, "unshrunk")?)?, gens_p: FromPod::from_pod(field(p, "gens")?)?, insts_p: FromPod::from_pod(field(p, "insts")?)?, quants_p: FromPod::from_pod(field(p, "quants")?)?, gen_of_q_p: FromPod::from_pod(field(p, "genOfQ")?)?, use_insts_p: FromPod::from_pod(field(p, "useInsts")?)?, local_ids_p: FromPod::from_pod(field(p, "localIds")?)?, use_ids_p: FromPod::from_pod(field(p, "useIds")?)?, call_ids_p: FromPod::from_pod(field(p, "callIds")?)?, inlined_p: FromPod::from_pod(field(p, "inlined")?)?, subst_p: FromPod::from_pod(field(p, "subst")?)?, csubst_p: FromPod::from_pod(field(p, "csubst")?)? })
    }
}

/// ```prism
/// PlaceKey: fn Lx, Range -> Text
/// ```
pub fn place_key_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> Text {
    Text::from(format!("{}:{}:{}", &lx_p0.file_p, &r_p1.start_p, &r_p1.end_p))
}

/// ```prism
/// TypeAt: fn Lx, Range -> Ty
/// ```
pub fn type_at_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    subst_ty_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.tys_p, &place_key_f(lx_p0, r_p1)), &crate::check::types::Ty::TyErr))
}

/// ```prism
/// BinderTy: fn Lx, Range -> Ty
/// ```
pub fn binder_ty_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    match crate::prelude::get(&lx_p0.binders_p, &place_key_f(lx_p0, r_p1)) {
        Some(t_p2) => subst_ty_f(lx_p0, &t_p2),
        None => type_at_f(lx_p0, r_p1),
    }
}

/// ```prism
/// SubstTy: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_f(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    if (&crate::prelude::len(&crate::prelude::keys(&lx_p0.subst_p)) == &Nat::from(0u32)) && (&crate::prelude::len(&crate::prelude::keys(&lx_p0.csubst_p)) == &Nat::from(0u32)) {
        t_p1.clone()
    } else {
        subst_ty_in_f(lx_p0, t_p1)
    }
}

/// ```prism
/// SubstTyIn: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_in_f(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyFlex(n_p2) => crate::prelude::or(&crate::prelude::get(&lx_p0.subst_p, &Text::from(format!("\'{}", n_p2))), t_p1),
        crate::check::types::Ty::TyCon(n_p3, args_p4) => crate::check::types::Ty::TyCon(n_p3.clone(), crate::prelude::each(args_p4, &(|a_p5: &crate::check::types::Ty| subst_ty_in_f(lx_p0, a_p5)))),
        crate::check::types::Ty::TyFn(c_p6, ps_p7, res_p8) => crate::check::types::Ty::TyFn(inst_col_f(lx_p0, c_p6), crate::prelude::each(ps_p7, &(|p_p9: &crate::check::types::Ty| subst_ty_in_f(lx_p0, p_p9))), Rc::new(subst_ty_in_f(lx_p0, &**res_p8))),
        crate::check::types::Ty::TyTuple(ts_pa) => crate::check::types::Ty::TyTuple(crate::prelude::each(ts_pa, &(|a_pb: &crate::check::types::Ty| subst_ty_in_f(lx_p0, a_pb)))),
        crate::check::types::Ty::TyArray(e_pc) => crate::check::types::Ty::TyArray(Rc::new(subst_ty_in_f(lx_p0, &**e_pc))),
        crate::check::types::Ty::TyMap(k_pd, v_pe) => crate::check::types::Ty::TyMap(Rc::new(subst_ty_in_f(lx_p0, &**k_pd)), Rc::new(subst_ty_in_f(lx_p0, &**v_pe))),
        crate::check::types::Ty::TySig(s_pf, i_pg) => crate::check::types::Ty::TySig(s_pf.clone(), Rc::new(subst_ty_in_f(lx_p0, &**i_pg))),
        crate::check::types::Ty::TyAt(i_ph, rw_pi) => crate::check::types::Ty::TyAt(Rc::new(subst_ty_in_f(lx_p0, &**i_ph)), rw_pi.clone()),
        crate::check::types::Ty::TyElem(rw_pj, o_pk) => crate::check::types::Ty::TyElem(rw_pj.clone(), Rc::new(subst_ty_in_f(lx_p0, &**o_pk))),
        crate::check::types::Ty::TyAssoc(n_pl, a_pm) => crate::check::types::Ty::TyAssoc(n_pl.clone(), Rc::new(subst_ty_in_f(lx_p0, &**a_pm))),
        other_pn => other_pn.clone(),
    }
}

/// ```prism
/// InstCol: fn Lx, Col -> Col
/// ```
pub fn inst_col_f(lx_p0: &Lx, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => crate::prelude::or(&crate::prelude::get(&lx_p0.csubst_p, q_p1), &crate::check::types::Col::CQ(q_p1.clone())),
        c_p3 => c_p3.clone(),
    }
}

/// ```prism
/// IsQuantCol: fn Lx, Col -> Bool
/// ```
pub fn is_quant_col_f(lx_p0: &Lx, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => crate::check::env::has_key_f(&lx_p0.quants_p, q_p1),
        c_p3 => false,
    }
}

/// ```prism
/// TypedTables: fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub fn typed_tables_f(tp_p0: &crate::check::typed::TProgram) -> (Map<Text, crate::check::types::Ty>, Map<Text, crate::check::typed::AppNote>, Map<Text, crate::check::types::Ty>, Map<Text, Array<crate::check::typed::ImplNote>>) {
    let tys_p1 = crate::prelude::fold(&tp_p0.exprs_p, &Map::new(), &(|m_p5: &Map<Text, crate::check::types::Ty>, n_p6: &crate::check::typed::TyNote| crate::prelude::insert(m_p5, &crate::check::typed::at_key_f(&n_p6.at_p), &n_p6.ty_p)));
    let apps_p2 = crate::prelude::fold(&tp_p0.apps_p, &Map::new(), &(|m_p7: &Map<Text, crate::check::typed::AppNote>, n_p8: &crate::check::typed::AppNote| crate::prelude::insert(m_p7, &crate::check::typed::at_key_f(&n_p8.at_p), n_p8)));
    let bs_p3 = crate::prelude::fold(&tp_p0.binders_p, &Map::new(), &(|m_p9: &Map<Text, crate::check::types::Ty>, n_pa: &crate::check::typed::BinderNote| crate::prelude::insert(m_p9, &crate::check::typed::at_key_f(&n_pa.at_p), &n_pa.ty_p)));
    let ims_p4 = crate::prelude::fold(&tp_p0.impls_p, &Map::new(), &(|m_pb: &Map<Text, Array<crate::check::typed::ImplNote>>, n_pc: &crate::check::typed::ImplNote| crate::prelude::insert(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p)), &Array::new()), n_pc))));
    (tys_p1.clone(), apps_p2.clone(), bs_p3.clone(), ims_p4.clone())
}

/// ```prism
/// let rustKeywords
/// ```
pub fn rust_keywords_p() -> Array<Text> {
    Array::from(vec![Text::lit("as"), Text::lit("async"), Text::lit("await"), Text::lit("box"), Text::lit("break"), Text::lit("const"), Text::lit("continue"), Text::lit("crate"), Text::lit("do"), Text::lit("dyn"), Text::lit("else"), Text::lit("enum"), Text::lit("extern"), Text::lit("false"), Text::lit("final"), Text::lit("fn"), Text::lit("for"), Text::lit("gen"), Text::lit("if"), Text::lit("impl"), Text::lit("in"), Text::lit("let"), Text::lit("loop"), Text::lit("macro"), Text::lit("match"), Text::lit("mod"), Text::lit("move"), Text::lit("mut"), Text::lit("override"), Text::lit("priv"), Text::lit("pub"), Text::lit("ref"), Text::lit("return"), Text::lit("self"), Text::lit("static"), Text::lit("struct"), Text::lit("super"), Text::lit("trait"), Text::lit("true"), Text::lit("try"), Text::lit("type"), Text::lit("typeof"), Text::lit("unsafe"), Text::lit("unsized"), Text::lit("use"), Text::lit("virtual"), Text::lit("where"), Text::lit("while"), Text::lit("yield"), Text::lit("u8"), Text::lit("u16"), Text::lit("u32"), Text::lit("u64"), Text::lit("i8"), Text::lit("i16"), Text::lit("i32"), Text::lit("i64"), Text::lit("f32"), Text::lit("f64"), Text::lit("bool"), Text::lit("char"), Text::lit("str"), Text::lit("usize"), Text::lit("isize"), Text::lit("cx"), Text::lit("node"), Text::lit("path"), Text::lit("v"), Text::lit("p")])
}

/// ```prism
/// Base: fn Text -> Text
/// ```
pub fn base_f(name_p0: &Text) -> Text {
    crate::syntax::lexer::chars::drop_prefix_f(name_p0, &crate::check::types::unify::marks_of_f(name_p0))
}

/// ```prism
/// Snake: fn Text -> Text
/// ```
pub fn snake_f(name_p0: &Text) -> Text {
    let (out_p6, _) = crate::syntax::lexer::chars::fold_chars_f(&base_f(name_p0), &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| crate::prelude::once_job(move || {
        let (acc_p2, prev_p3) = p0;
        let c_p4 = p1;
        {
            let sep_p5 = if crate::syntax::lexer::chars::is_upper_f(&c_p4) && (crate::syntax::lexer::chars::is_lower_f(&prev_p3) || crate::syntax::lexer::chars::is_digit_f(&prev_p3)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc_p2, &sep_p5, &lower_char_f(&c_p4))), c_p4.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    let plain_p1 = if &out_p6 == &Text::lit("") { Text::lit("x") } else { out_p6.clone() };
    if crate::check::types::has_text_f(&rust_keywords_p(), &plain_p1) {
        Text::from(format!("{}_", &plain_p1))
    } else {
        plain_p1.clone()
    }
}

/// ```prism
/// LowerChar: fn Text -> Text
/// ```
pub fn lower_char_f(c_p0: &Text) -> Text {
    if crate::syntax::lexer::chars::is_upper_f(c_p0) {
        crate::prelude::lower(c_p0)
    } else {
        c_p0.clone()
    }
}

/// ```prism
/// Camel: fn Text -> Text
/// ```
pub fn camel_f(name_p0: &Text) -> Text {
    let b_p1 = base_f(name_p0);
    let first_p2 = crate::syntax::lexer::chars::head_f(&b_p1);
    let fixed_p3 = if crate::syntax::lexer::chars::is_lower_f(&first_p2) {
        Text::from(format!("{}{}", &crate::prelude::upper(&first_p2), &crate::syntax::lexer::chars::after_first_f(&b_p1)))
    } else {
        b_p1.clone()
    };
    if (&fixed_p3 == &Text::lit("Self")) || crate::check::types::has_text_f(&runtime_names_p(), &fixed_p3) {
        Text::from(format!("{}_", &fixed_p3))
    } else {
        fixed_p3.clone()
    }
}

/// ```prism
/// let runtimeNames
/// ```
pub fn runtime_names_p() -> Array<Text> {
    Array::from(vec![Text::lit("AnswerOf"), Text::lit("BigInt"), Text::lit("Blueprint"), Text::lit("Box"), Text::lit("Built"), Text::lit("Cache"), Text::lit("Case"), Text::lit("Cell"), Text::lit("Clickable"), Text::lit("Collector"), Text::lit("Cursor"), Text::lit("Cx"), Text::lit("Defer"), Text::lit("Demand"), Text::lit("Document"), Text::lit("Done"), Text::lit("DynShow"), Text::lit("Dynamic"), Text::lit("Edit"), Text::lit("Err"), Text::lit("Event"), Text::lit("F64"), Text::lit("Fallible"), Text::lit("Fields"), Text::lit("Finishing"), Text::lit("Fn"), Text::lit("Forward"), Text::lit("FromPod"), Text::lit("Gathered"), Text::lit("Gen"), Text::lit("Handle"), Text::lit("Hold"), Text::lit("Host"), Text::lit("HostOf"), Text::lit("HostRow"), Text::lit("Inert"), Text::lit("IsShared"), Text::lit("IsValue"), Text::lit("Job"), Text::lit("JobRef"), Text::lit("Later"), Text::lit("Link"), Text::lit("List"), Text::lit("Live"), Text::lit("MakeNew"), Text::lit("MutElements"), Text::lit("Nanos"), Text::lit("NeverEvent"), Text::lit("NewSnapshot"), Text::lit("Node"), Text::lit("NodeRef"), Text::lit("None"), Text::lit("Ok"), Text::lit("OkUnit"), Text::lit("Option"), Text::lit("Outcome"), Text::lit("Panic"), Text::lit("Patch"), Text::lit("Path"), Text::lit("Pattern"), Text::lit("Pod"), Text::lit("Port"), Text::lit("Pos"), Text::lit("Printer"), Text::lit("Program"), Text::lit("Rc"), Text::lit("ReadyMap"), Text::lit("ReadyState"), Text::lit("RefCell"), Text::lit("Report"), Text::lit("Request"), Text::lit("Result"), Text::lit("Row"), Text::lit("Rows"), Text::lit("Runtime"), Text::lit("Scope"), Text::lit("Segment"), Text::lit("ShowRef"), Text::lit("ShownText"), Text::lit("Sink"), Text::lit("Slot"), Text::lit("Snapshot"), Text::lit("Some"), Text::lit("Stamped"), Text::lit("String"), Text::lit("Subscribed"), Text::lit("Subscriber"), Text::lit("Supplied"), Text::lit("Supplier"), Text::lit("TestWorld"), Text::lit("Tick"), Text::lit("TickIn"), Text::lit("TickOut"), Text::lit("ToPod"), Text::lit("Unexpected"), Text::lit("Unit"), Text::lit("Vec"), Text::lit("Weak"), Text::lit("World"), Text::lit("XorShift")])
}

/// ```prism
/// RustModName: fn Text -> Text
/// ```
pub fn rust_mod_name_f(m_p0: &Text) -> Text {
    if m_p0 == &Text::lit("") {
        Text::lit("program")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(m_p0, &Text::lit(".")), &(|s_p1: &Text| mod_segment_f(s_p1))), &Text::lit("::"))
    }
}

/// ```prism
/// ModSegment: fn Text -> Text
/// ```
pub fn mod_segment_f(s_p0: &Text) -> Text {
    let n_p1 = snake_f(s_p0);
    if crate::check::types::has_text_f(&cpp_keywords_p(), &n_p1) {
        Text::from(format!("{}_", &n_p1))
    } else {
        n_p1.clone()
    }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords_p() -> Array<Text> {
    Array::from(vec![Text::lit("explicit"), Text::lit("and"), Text::lit("and_eq"), Text::lit("asm"), Text::lit("auto"), Text::lit("bitand"), Text::lit("bitor"), Text::lit("bool"), Text::lit("case"), Text::lit("catch"), Text::lit("char"), Text::lit("char8_t"), Text::lit("char16_t"), Text::lit("char32_t"), Text::lit("class"), Text::lit("compl"), Text::lit("concept"), Text::lit("const_cast"), Text::lit("consteval"), Text::lit("constexpr"), Text::lit("constinit"), Text::lit("co_await"), Text::lit("co_return"), Text::lit("co_yield"), Text::lit("decltype"), Text::lit("default"), Text::lit("delete"), Text::lit("double"), Text::lit("dynamic_cast"), Text::lit("explicit"), Text::lit("export"), Text::lit("extern"), Text::lit("float"), Text::lit("friend"), Text::lit("goto"), Text::lit("inline"), Text::lit("int"), Text::lit("long"), Text::lit("mutable"), Text::lit("namespace"), Text::lit("new"), Text::lit("noexcept"), Text::lit("not"), Text::lit("not_eq"), Text::lit("nullptr"), Text::lit("operator"), Text::lit("or"), Text::lit("or_eq"), Text::lit("private"), Text::lit("protected"), Text::lit("public"), Text::lit("register"), Text::lit("reinterpret_cast"), Text::lit("requires"), Text::lit("short"), Text::lit("signed"), Text::lit("sizeof"), Text::lit("static_assert"), Text::lit("static_cast"), Text::lit("switch"), Text::lit("template"), Text::lit("this"), Text::lit("thread_local"), Text::lit("throw"), Text::lit("try"), Text::lit("typedef"), Text::lit("typeid"), Text::lit("typename"), Text::lit("union"), Text::lit("unsigned"), Text::lit("using"), Text::lit("virtual"), Text::lit("void"), Text::lit("volatile"), Text::lit("wchar_t"), Text::lit("xor"), Text::lit("xor_eq"), Text::lit("errno"), Text::lit("assert"), Text::lit("NULL"), Text::lit("EOF"), Text::lit("stdin"), Text::lit("stdout"), Text::lit("stderr"), Text::lit("major"), Text::lit("minor")])
}

/// ```prism
/// PathIn: fn Lx, Text, Text -> Text
/// ```
pub fn path_in_f(lx_p0: &Lx, owner_p1: &Text, name_p2: &Text) -> Text {
    if owner_p1 == &lx_p0.site_p {
        name_p2.clone()
    } else {
        if owner_p1 == &Text::lit("Prelude") {
            prelude_path_f(lx_p0, name_p2)
        } else {
            Text::from(format!("crate::{}::{}", &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_mods_p, owner_p1), &rust_mod_name_f(owner_p1)), name_p2))
        }
    }
}

/// ```prism
/// PreludePath: fn Lx, Text -> Text
/// ```
pub fn prelude_path_f(lx0: &Lx, name_p0: &Text) -> Text {
    match lx0 {
        _ => helper_f(name_p0),
    }
}

/// ```prism
/// Helper: fn Text -> Text
/// ```
pub fn helper_f(n_p0: &Text) -> Text {
    Text::from(format!("crate::prelude::{}", n_p0))
}

/// ```prism
/// ValueNames: unbounded fn G -> (Text ==> Text)
/// ```
pub fn value_names_f(g_p0: &crate::check::env::G) -> Map<Text, Text> {
    let lets_p1 = crate::prelude::fold(&g_p0.defs_p, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::check::env::Def| match &d_p5.body_p {
        crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text_f(acc_p4, &d_p5.qk_p),
        _ => acc_p4.clone(),
    }));
    let keys_p2 = crate::check::types::union_texts_f(&crate::prelude::keys(&g_p0.vals_p), &lets_p1);
    let bases_p3 = crate::prelude::fold(&keys_p2, &Map::new(), &(|m_p6: &Map<Text, Array<Text>>, k_p7: &Text| crate::prelude::insert(m_p6, &base_key_f(k_p7), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p6, &base_key_f(k_p7)), &Array::new()), k_p7))));
    crate::prelude::run_to_end(crate::prelude::fold_job(keys_p2.clone(), Map::new(), {
        let g_p0x = g_p0.clone();
        let bases_p3x = bases_p3.clone();
        Rc::new(move |(p0, p1): (Map<Text, Text>, Text)| {
            let g_p0xy = g_p0x.clone();
            let bases_p3xy = bases_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p8 = p0;
                let k_p9 = p1;
                {
                    let runtimes_pa = (&owner_of_f(&k_p9) == &Text::lit("Prelude")) || match crate::prelude::get(&g_p0xy.vals_p, &k_p9) {
                        Some(v_pb) => (&v_pb.sort_p == &Text::lit("builtin")) || (&v_pb.home_p == &Text::lit("Prelude")),
                        None => false,
                    };
                    prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &k_p9, &(if runtimes_pa {
                        value_name_f(&k_p9, &crate::prelude::len(&crate::prelude::or(&crate::prelude::get(&bases_p3xy, &base_key_f(&k_p9)), &Array::new())))
                    } else {
                        Text::from(format!("{}_{}", &global_base_f(&k_p9), &global_letter_f(&g_p0xy, &k_p9)))
                    })))
                }
            }))
        }) as Rc<dyn Fn((Map<Text, Text>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Text>>>>
    }))
}

/// The step machine of `ValueNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueNames: unbounded fn G -> (Text ==> Text)
/// ```
pub struct ValueNames {
    pub g_p0: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, Text>> for ValueNames {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, Text>> {
        let g_p0 = &self.g_p0;
        let lets_p1 = crate::prelude::fold(&g_p0.defs_p, &Array::new(), &(|acc_p4: &Array<Text>, d_p5: &crate::check::env::Def| match &d_p5.body_p {
            crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text_f(acc_p4, &d_p5.qk_p),
            _ => acc_p4.clone(),
        }));
        let keys_p2 = crate::check::types::union_texts_f(&crate::prelude::keys(&g_p0.vals_p), &lets_p1);
        let bases_p3 = crate::prelude::fold(&keys_p2, &Map::new(), &(|m_p6: &Map<Text, Array<Text>>, k_p7: &Text| crate::prelude::insert(m_p6, &base_key_f(k_p7), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p6, &base_key_f(k_p7)), &Array::new()), k_p7))));
        crate::prelude::fold_job(keys_p2.clone(), Map::new(), {
            let g_p0x = g_p0.clone();
            let bases_p3x = bases_p3.clone();
            Rc::new(move |(p0, p1): (Map<Text, Text>, Text)| {
                let g_p0xy = g_p0x.clone();
                let bases_p3xy = bases_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p8 = p0;
                    let k_p9 = p1;
                    {
                        let runtimes_pa = (&owner_of_f(&k_p9) == &Text::lit("Prelude")) || match crate::prelude::get(&g_p0xy.vals_p, &k_p9) {
                            Some(v_pb) => (&v_pb.sort_p == &Text::lit("builtin")) || (&v_pb.home_p == &Text::lit("Prelude")),
                            None => false,
                        };
                        prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &k_p9, &(if runtimes_pa {
                            value_name_f(&k_p9, &crate::prelude::len(&crate::prelude::or(&crate::prelude::get(&bases_p3xy, &base_key_f(&k_p9)), &Array::new())))
                        } else {
                            Text::from(format!("{}_{}", &global_base_f(&k_p9), &global_letter_f(&g_p0xy, &k_p9)))
                        })))
                    }
                }))
            }) as Rc<dyn Fn((Map<Text, Text>, Text)) -> Rc<dyn prism_rtl::Job<Map<Text, Text>>>>
        }).cycle()
    }
}

/// `Start ValueNames, x`: what the function value is when passed to `@Run`.
pub fn start_value_names_f(g_p0: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, Text>>> {
    Rc::new(ValueNames { g_p0 })
}

/// ```prism
/// GlobalBase: unbounded fn Text -> Text
/// ```
pub fn global_base_f(k_p0: &Text) -> Text {
    let base_p1 = trim_underscores_f(&snake_f(&crate::check::types::bare_name_f(k_p0)));
    if &base_p1 == &Text::lit("") { Text::lit("topic") } else { base_p1.clone() }
}

/// The step machine of `GlobalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalBase: unbounded fn Text -> Text
/// ```
pub struct GlobalBase {
    pub k_p0: Text,
}

impl prism_rtl::Job<Text> for GlobalBase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let k_p0 = &self.k_p0;
        let k_p0x = k_p0.clone();
        crate::prelude::call_then(start_trim_underscores_f(snake_f(&crate::check::types::bare_name_f(&k_p0x))), move |trim_underscores_f_13639: Text| {
            let base_p1 = trim_underscores_f_13639;
            if &base_p1 == &Text::lit("") {
                prism_rtl::Turn::Finished(Text::lit("topic"))
            } else {
                prism_rtl::Turn::Finished(base_p1.clone())
            }
        })
    }
}

/// `Start GlobalBase, x`: what the function value is when passed to `@Run`.
pub fn start_global_base_f(k_p0: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GlobalBase { k_p0 })
}

/// ```prism
/// FieldSpell: unbounded fn Text, Text, Ty -> Text
/// ```
pub fn field_spell_f(text0: &Text, fname_p0: &Text, ft_p1: &crate::check::types::Ty) -> Text {
    match text0 {
        _ => Text::from(format!("{}_{}", &global_base_f(fname_p0), &sigil_or_kind_f(fname_p0, ft_p1))),
    }
}

/// The step machine of `FieldSpell`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldSpell: unbounded fn Text, Text, Ty -> Text
/// ```
pub struct FieldSpell {
    pub text0: Text,
    pub fname_p0: Text,
    pub ft_p1: crate::check::types::Ty,
}

impl prism_rtl::Job<Text> for FieldSpell {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let text0 = &self.text0;
        let fname_p0 = &self.fname_p0;
        let ft_p1 = &self.ft_p1;
        match text0 {
            _ => {
                let fname_p0x = fname_p0.clone();
                let ft_p1x = ft_p1.clone();
                crate::prelude::call_then(start_global_base_f(fname_p0x.clone()), move |global_base_f_14214: Text| prism_rtl::Turn::Finished(Text::from(format!("{}_{}", &global_base_f_14214, &sigil_or_kind_f(&fname_p0x, &ft_p1x)))))
            },
        }
    }
}

/// `Start FieldSpell, x`: what the function value is when passed to `@Run`.
pub fn start_field_spell_f(text0: Text, fname_p0: Text, ft_p1: crate::check::types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldSpell { text0, fname_p0, ft_p1 })
}

/// ```prism
/// SigilOrKind: fn Text, Ty -> Text
/// ```
pub fn sigil_or_kind_f(name_p0: &Text, t_p1: &crate::check::types::Ty) -> Text {
    let marks_p2 = crate::check::types::unify::marks_of_f(name_p0);
    if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("?")) {
        Text::lit("o")
    } else {
        if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("~")) {
            Text::lit("r")
        } else {
            if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("!")) {
                Text::lit("e")
            } else {
                if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("$")) {
                    Text::lit("d")
                } else {
                    if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("@")) {
                        Text::lit("b")
                    } else {
                        kind_letter_f(t_p1)
                    }
                }
            }
        }
    }
}

/// ```prism
/// GlobalLetter: fn G, Text -> Text
/// ```
pub fn global_letter_f(g_p0: &crate::check::env::G, k_p1: &Text) -> Text {
    match crate::prelude::get(&g_p0.vals_p, k_p1) {
        Some(v_p2) => sigil_or_kind_f(&crate::check::types::bare_name_f(k_p1), &v_p2.scheme_p.ty_p),
        None => sigil_or_kind_f(&crate::check::types::bare_name_f(k_p1), &(if crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&base_f(&crate::check::types::bare_name_f(k_p1)))) {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, Array::new(), Rc::new(crate::check::types::Ty::TyErr))
        } else {
            crate::check::types::Ty::TyErr
        })),
    }
}

/// ```prism
/// GlobalNames: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn global_names_f(g_p0: &crate::check::env::G) -> Map<Text, bool> {
    let names_p1 = value_names_f(g_p0);
    crate::prelude::fold(&crate::prelude::keys(&names_p1), &Map::new(), &(|m_p2: &Map<Text, bool>, k_p3: &Text| crate::prelude::insert(m_p2, &Text::from(format!("{}.{}", &owner_of_f(k_p3), &crate::prelude::or(&crate::prelude::get(&names_p1, k_p3), &Text::lit("")))), &true)))
}

/// The step machine of `GlobalNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalNames: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct GlobalNames {
    pub g_p0: crate::check::env::G,
}

impl prism_rtl::Job<Map<Text, bool>> for GlobalNames {
    fn cycle(&self) -> prism_rtl::Turn<Map<Text, bool>> {
        let g_p0 = &self.g_p0;
        let g_p0x = g_p0.clone();
        crate::prelude::call_then(start_value_names_f(g_p0x.clone()), move |value_names_f_14871: Map<Text, Text>| {
            let names_p1 = value_names_f_14871;
            prism_rtl::Turn::Finished(crate::prelude::fold(&crate::prelude::keys(&names_p1), &Map::new(), &(|m_p2: &Map<Text, bool>, k_p3: &Text| crate::prelude::insert(m_p2, &Text::from(format!("{}.{}", &owner_of_f(k_p3), &crate::prelude::or(&crate::prelude::get(&names_p1, k_p3), &Text::lit("")))), &true))))
        })
    }
}

/// `Start GlobalNames, x`: what the function value is when passed to `@Run`.
pub fn start_global_names_f(g_p0: crate::check::env::G) -> Rc<dyn prism_rtl::Job<Map<Text, bool>>> {
    Rc::new(GlobalNames { g_p0 })
}

/// ```prism
/// LocalName: fn Lx, Text -> Text
/// ```
pub fn local_name_f(lx_p0: &Lx, nkey_p1: &Text) -> Text {
    let marks_p2 = crate::check::types::unify::marks_of_f(nkey_p1);
    let base_p3 = snake_f(nkey_p1);
    let bare_p4 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p1, &marks_p2);
    let s0_p5 = if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("?")) {
        Text::from(format!("{}_opt", &base_p3))
    } else {
        if crate::syntax::lexer::chars::contains_f(&marks_p2, &Text::lit("~")) {
            Text::from(format!("{}_try", &base_p3))
        } else {
            base_p3.clone()
        }
    };
    let s1_p6 = if crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&bare_p4)) {
        Text::from(format!("{}_fn", &s0_p5))
    } else {
        s0_p5.clone()
    };
    if crate::check::env::has_key_f(&lx_p0.globals_p, &Text::from(format!("{}.{}", &lx_p0.site_p, &s1_p6))) || crate::check::env::has_key_f(&lx_p0.globals_p, &Text::from(format!("Prelude.{}", &s1_p6))) {
        Text::from(format!("{}_", &s1_p6))
    } else {
        s1_p6.clone()
    }
}

/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub fn local_name_at_f(lx_p0: &Lx, nkey_p1: &Text, span_p2: &crate::syntax::Range) -> Text {
    match crate::prelude::get(&lx_p0.local_ids_p, &place_key_f(lx_p0, span_p2)) {
        Some(id_p3) => Text::from(format!("{}_{}{}{}", &local_base_f(nkey_p1), &kind_letter_f(&binder_ty_f(lx_p0, span_p2)), &base32_f(&id_p3), &lx_p0.inlined_p)),
        None => local_name_f(lx_p0, nkey_p1),
    }
}

/// The step machine of `LocalNameAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub struct LocalNameAt {
    pub lx_p0: Lx,
    pub nkey_p1: Text,
    pub span_p2: crate::syntax::Range,
}

impl prism_rtl::Job<Text> for LocalNameAt {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let lx_p0 = &self.lx_p0;
        let nkey_p1 = &self.nkey_p1;
        let span_p2 = &self.span_p2;
        match crate::prelude::get(&lx_p0.local_ids_p, &place_key_f(lx_p0, span_p2)) {
            Some(id_p3) => {
                let lx_p0x = lx_p0.clone();
                let nkey_p1x = nkey_p1.clone();
                let span_p2x = span_p2.clone();
                crate::prelude::call_then(start_local_base_f(nkey_p1x.clone()), move |local_base_f_16261: Text| crate::prelude::call_then(start_base32_f(id_p3.clone()), move |base32_f_16310: Text| prism_rtl::Turn::Finished(Text::from(format!("{}_{}{}{}", &local_base_f_16261, &kind_letter_f(&binder_ty_f(&lx_p0x, &span_p2x)), &base32_f_16310, &lx_p0x.inlined_p)))))
            },
            None => prism_rtl::Turn::Finished(local_name_f(lx_p0, nkey_p1)),
        }
    }
}

/// `Start LocalNameAt, x`: what the function value is when passed to `@Run`.
pub fn start_local_name_at_f(lx_p0: Lx, nkey_p1: Text, span_p2: crate::syntax::Range) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LocalNameAt { lx_p0, nkey_p1, span_p2 })
}

/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub fn local_base_f(nkey_p0: &Text) -> Text {
    let bare_p1 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p0, &crate::check::types::unify::marks_of_f(nkey_p0));
    let base_p2 = snake_f(&bare_p1);
    let trimmed_p3 = trim_underscores_f(&base_p2);
    if &trimmed_p3 == &Text::lit("") { Text::lit("topic") } else { trimmed_p3.clone() }
}

/// The step machine of `LocalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub struct LocalBase {
    pub nkey_p0: Text,
}

impl prism_rtl::Job<Text> for LocalBase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let nkey_p0 = &self.nkey_p0;
        let bare_p1 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p0, &crate::check::types::unify::marks_of_f(nkey_p0));
        let base_p2 = snake_f(&bare_p1);
        crate::prelude::call_then(start_trim_underscores_f(base_p2.clone()), move |trim_underscores_f_16647: Text| {
            let trimmed_p3 = trim_underscores_f_16647;
            if &trimmed_p3 == &Text::lit("") {
                prism_rtl::Turn::Finished(Text::lit("topic"))
            } else {
                prism_rtl::Turn::Finished(trimmed_p3.clone())
            }
        })
    }
}

/// `Start LocalBase, x`: what the function value is when passed to `@Run`.
pub fn start_local_base_f(nkey_p0: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(LocalBase { nkey_p0 })
}

/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub fn trim_underscores_f(t_p0: &Text) -> Text {
    match crate::syntax::lexer::chars::before_suffix_o(t_p0, &Text::lit("_")) {
        Some(s_p1) => trim_underscores_f(&s_p1),
        None => t_p0.clone(),
    }
}

/// The step machine of `TrimUnderscores`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub struct TrimUnderscores {
    pub t_p0: Text,
}

impl prism_rtl::Job<Text> for TrimUnderscores {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t_p0 = &self.t_p0;
        match crate::syntax::lexer::chars::before_suffix_o(t_p0, &Text::lit("_")) {
            Some(s_p1) => prism_rtl::Turn::More(Rc::new(TrimUnderscores { t_p0: s_p1.clone() })),
            None => prism_rtl::Turn::Finished(t_p0.clone()),
        }
    }
}

/// `Start TrimUnderscores, x`: what the function value is when passed to `@Run`.
pub fn start_trim_underscores_f(t_p0: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TrimUnderscores { t_p0 })
}

/// ```prism
/// KindLetter: fn Ty -> Text
/// ```
pub fn kind_letter_f(t_p0: &crate::check::types::Ty) -> Text {
    match t_p0 {
        crate::check::types::Ty::TySig(m17053_0_0, _) if (m17053_0_0 == &Text::lit("!")) => Text::lit("e"),
        crate::check::types::Ty::TySig(m17053_1_0, _) if (m17053_1_0 == &Text::lit("$")) => Text::lit("d"),
        crate::check::types::Ty::TySig(m17053_2_0, _) if (m17053_2_0 == &Text::lit("?")) => Text::lit("o"),
        crate::check::types::Ty::TySig(m17053_3_0, _) if (m17053_3_0 == &Text::lit("~")) => Text::lit("r"),
        crate::check::types::Ty::TySig(m17053_4_0, i_p1) if (m17053_4_0 == &Text::lit("&")) => kind_letter_f(&**i_p1),
        crate::check::types::Ty::TyAt(_, _) => Text::lit("b"),
        crate::check::types::Ty::TyFn(_, _, _) => Text::lit("f"),
        _ => Text::lit("p"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub fn base32_f(n_p0: &Nat) -> Text {
    let digit_p1 = crate::syntax::lexer::chars::char_at_byte_f(&Text::lit("0123456789abcdefghijklmnopqrstuv"), &crate::prelude::or(&crate::prelude::mod_(n_p0, &Nat::from(32u32)), &Nat::from(0u32)));
    match crate::prelude::div(n_p0, &Nat::from(32u32)) {
        Some(q_p2) if (&q_p2 > &Nat::from(0u32)) => Text::from(format!("{}{}", &base32_f(&q_p2), &digit_p1)),
        _ => digit_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Base32`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub struct Base32 {
    pub n_p0: Nat,
}

impl prism_rtl::Job<Text> for Base32 {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n_p0 = &self.n_p0;
        let digit_p1 = crate::syntax::lexer::chars::char_at_byte_f(&Text::lit("0123456789abcdefghijklmnopqrstuv"), &crate::prelude::or(&crate::prelude::mod_(n_p0, &Nat::from(32u32)), &Nat::from(0u32)));
        match crate::prelude::div(n_p0, &Nat::from(32u32)) {
            Some(q_p2) if (&q_p2 > &Nat::from(0u32)) => crate::prelude::call_then(start_base32_f(q_p2.clone()), move |base32_f_17519: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &base32_f_17519, &digit_p1)))),
            _ => prism_rtl::Turn::Finished(digit_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Base32, x`: what the function value is when passed to `@Run`.
pub fn start_base32_f(n_p0: Nat) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Base32 { n_p0 })
}

/// ```prism
/// BaseKey: fn Text -> Text
/// ```
pub fn base_key_f(k_p0: &Text) -> Text {
    let parts_p1 = crate::prelude::split_on(k_p0, &Text::lit("."));
    let last_p2 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&parts_p1), k_p0);
    Text::from(format!("{}.{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p1))), &Text::lit(".")), &snake_f(&last_p2)))
}

/// ```prism
/// ValueName: fn Text, Nat -> Text
/// ```
pub fn value_name_f(k_p0: &Text, count_p1: &Nat) -> Text {
    let last_p2 = crate::check::types::bare_name_f(k_p0);
    let marks_p3 = crate::check::types::unify::marks_of_f(&last_p2);
    let base_p4 = snake_f(&last_p2);
    if (count_p1 > &Nat::from(1u32)) && (&marks_p3 != &Text::lit("")) {
        Text::from(format!("{}_{}", &base_p4, &sigil_word_f(&crate::syntax::lexer::chars::head_f(&marks_p3))))
    } else {
        if (count_p1 > &Nat::from(1u32)) && !crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&last_p2)) {
            Text::from(format!("{}_value", &base_p4))
        } else {
            base_p4.clone()
        }
    }
}

/// ```prism
/// SigilWord: fn Text -> Text
/// ```
pub fn sigil_word_f(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("?")) => Text::lit("opt"),
        c1_0 if (c1_0 == &Text::lit("~")) => Text::lit("try"),
        c2_0 if (c2_0 == &Text::lit("!")) => Text::lit("ev"),
        c3_0 if (c3_0 == &Text::lit("$")) => Text::lit("dyn"),
        c4_0 if (c4_0 == &Text::lit("@")) => Text::lit("widget"),
        c5_0 if (c5_0 == &Text::lit("&")) => Text::lit("ref"),
        other_p0 => Text::lit("x"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ValuePath: fn Lx, Text -> Text
/// ```
pub fn value_path_f(lx_p0: &Lx, qk_p1: &Text) -> Text {
    let owner_p2 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        Some(v_p3) => v_p3.home_p.clone(),
        None => owner_of_f(qk_p1),
    };
    path_in_f(lx_p0, &owner_p2, &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &snake_f(&crate::check::types::bare_name_f(qk_p1))))
}

/// ```prism
/// OwnerOf: fn Text -> Text
/// ```
pub fn owner_of_f(qk_p0: &Text) -> Text {
    let parts_p1 = crate::prelude::split_on(qk_p0, &Text::lit("."));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p1))), &Text::lit("."))
}

/// ```prism
/// TagStruct: fn Text -> Text
/// ```
pub fn tag_struct_f(tn_p0: &Text) -> Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(tn_p0, &Text::lit(".")), &(|p_p1: &Text| camel_f(p_p1))))
}
