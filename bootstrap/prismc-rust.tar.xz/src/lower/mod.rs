//! The module `Lower`, from `target/bootstrap/src/prismc/lower/mod.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;
pub mod expr;
pub mod functions;
pub mod jobs;
pub mod model;
pub mod node_;
pub mod patterns;
pub mod program;
pub mod templates;
pub mod types;

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Lx {
    pub g_p: crate::check::env::G,
    pub tys_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub apps_p: crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>,
    pub lifts_p: crate::prelude::Map<crate::prelude::Text, crate::check::typed::LiftNote>,
    pub binders_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub impls_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>,
    pub file_p: crate::prelude::Nat,
    pub home_p: crate::prelude::Text,
    pub site_p: crate::prelude::Text,
    pub rs_mods_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub mod_segments_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub rs_names_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub layouts_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<bool>>,
    pub unbs_p: crate::prelude::Array<crate::prelude::Text>,
    pub notes_p: crate::prelude::Array<crate::prelude::Text>,
    pub globals_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub in_node_p: bool,
    pub whole_p: bool,
    pub whole_fns_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub no_cx_p: bool,
    pub unshrunk_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub gens_p: crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>,
    pub insts_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::InstNote>>,
    pub quants_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>,
    pub gen_of_q_p: crate::prelude::Map<crate::prelude::Text, crate::check::typed::GenNote>,
    pub use_insts_p: crate::prelude::Map<crate::prelude::Text, crate::check::typed::InstNote>,
    pub local_ids_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub use_ids_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub use_names_p: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<(crate::prelude::Nat, crate::prelude::Text)>>,
    pub call_ids_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Nat>,
    pub inlined_p: crate::prelude::Text,
    pub subst_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub csubst_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Col>,
    pub faults_p: crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>,
    pub plains_p: crate::prelude::Map<crate::prelude::Text, bool>,
    pub shared_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>,
    pub recursing_p: crate::prelude::Array<crate::prelude::Text>,
    pub valued_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::lower::model::Pa, crate::prelude::Array<crate::lower::model::Cc>, crate::prelude::Array<crate::lower::model::Ex>)>>,
    pub valued_at_p: crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<(crate::prelude::Text, crate::check::types::Ty)>)>>,
    pub in_definition_p: crate::prelude::Text,
}

impl crate::prelude::Show for Lx {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Lx", &[("g", &self.g_p), ("tys", &self.tys_p), ("apps", &self.apps_p), ("lifts", &self.lifts_p), ("binders", &self.binders_p), ("impls", &self.impls_p), ("file", &self.file_p), ("home", &self.home_p), ("site", &self.site_p), ("rsMods", &self.rs_mods_p), ("modSegments", &self.mod_segments_p), ("rsNames", &self.rs_names_p), ("layouts", &self.layouts_p), ("unbs", &self.unbs_p), ("notes", &self.notes_p), ("globals", &self.globals_p), ("inNode", &self.in_node_p), ("whole", &self.whole_p), ("wholeFns", &self.whole_fns_p), ("noCx", &self.no_cx_p), ("unshrunk", &self.unshrunk_p), ("gens", &self.gens_p), ("insts", &self.insts_p), ("quants", &self.quants_p), ("genOfQ", &self.gen_of_q_p), ("useInsts", &self.use_insts_p), ("localIds", &self.local_ids_p), ("useIds", &self.use_ids_p), ("useNames", &self.use_names_p), ("callIds", &self.call_ids_p), ("inlined", &self.inlined_p), ("subst", &self.subst_p), ("csubst", &self.csubst_p), ("faults", &self.faults_p), ("plains", &self.plains_p), ("shared", &self.shared_p), ("recursing", &self.recursing_p), ("valued", &self.valued_p), ("valuedAt", &self.valued_at_p), ("inDefinition", &self.in_definition_p)]);
    }
}

impl crate::prelude::ToPod for Lx {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Lx", vec![("g", self.g_p.to_pod()), ("tys", self.tys_p.to_pod()), ("apps", self.apps_p.to_pod()), ("lifts", self.lifts_p.to_pod()), ("binders", self.binders_p.to_pod()), ("impls", self.impls_p.to_pod()), ("file", self.file_p.to_pod()), ("home", self.home_p.to_pod()), ("site", self.site_p.to_pod()), ("rsMods", self.rs_mods_p.to_pod()), ("modSegments", self.mod_segments_p.to_pod()), ("rsNames", self.rs_names_p.to_pod()), ("layouts", self.layouts_p.to_pod()), ("unbs", self.unbs_p.to_pod()), ("notes", self.notes_p.to_pod()), ("globals", self.globals_p.to_pod()), ("inNode", self.in_node_p.to_pod()), ("whole", self.whole_p.to_pod()), ("wholeFns", self.whole_fns_p.to_pod()), ("noCx", self.no_cx_p.to_pod()), ("unshrunk", self.unshrunk_p.to_pod()), ("gens", self.gens_p.to_pod()), ("insts", self.insts_p.to_pod()), ("quants", self.quants_p.to_pod()), ("genOfQ", self.gen_of_q_p.to_pod()), ("useInsts", self.use_insts_p.to_pod()), ("localIds", self.local_ids_p.to_pod()), ("useIds", self.use_ids_p.to_pod()), ("useNames", self.use_names_p.to_pod()), ("callIds", self.call_ids_p.to_pod()), ("inlined", self.inlined_p.to_pod()), ("subst", self.subst_p.to_pod()), ("csubst", self.csubst_p.to_pod()), ("faults", self.faults_p.to_pod()), ("plains", self.plains_p.to_pod()), ("shared", self.shared_p.to_pod()), ("recursing", self.recursing_p.to_pod()), ("valued", self.valued_p.to_pod()), ("valuedAt", self.valued_at_p.to_pod()), ("inDefinition", self.in_definition_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Lx {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Lx { g_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "g")?)?, tys_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tys")?)?, apps_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "apps")?)?, lifts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "lifts")?)?, binders_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "binders")?)?, impls_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "impls")?)?, file_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "file")?)?, home_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "home")?)?, site_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "site")?)?, rs_mods_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rsMods")?)?, mod_segments_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "modSegments")?)?, rs_names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "rsNames")?)?, layouts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "layouts")?)?, unbs_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "unbs")?)?, notes_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "notes")?)?, globals_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "globals")?)?, in_node_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inNode")?)?, whole_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "whole")?)?, whole_fns_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "wholeFns")?)?, no_cx_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "noCx")?)?, unshrunk_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "unshrunk")?)?, gens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "gens")?)?, insts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "insts")?)?, quants_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "quants")?)?, gen_of_q_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "genOfQ")?)?, use_insts_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "useInsts")?)?, local_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "localIds")?)?, use_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "useIds")?)?, use_names_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "useNames")?)?, call_ids_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "callIds")?)?, inlined_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inlined")?)?, subst_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "subst")?)?, csubst_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "csubst")?)?, faults_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "faults")?)?, plains_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "plains")?)?, shared_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "shared")?)?, recursing_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "recursing")?)?, valued_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "valued")?)?, valued_at_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "valuedAt")?)?, in_definition_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "inDefinition")?)? })
    }
}

/// ```prism
/// PlaceKey: fn Lx, Range -> Text
/// ```
pub fn place_key_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}:{}:{}", &lx_p0.file_p, &r_p1.start_p, &r_p1.end_p))
}

/// ```prism
/// TypeAt: fn Lx, Range -> Ty
/// ```
pub fn type_at_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    subst_ty_f(lx_p0, &crate::prelude::or(&crate::prelude::get(&lx_p0.tys_p, &place_key_f(lx_p0, r_p1)), &crate::check::types::Ty::TyErr))
}

/// ```prism
/// BinderTy: fn Lx, Range -> Ty
/// ```
pub fn binder_ty_f(lx_p0: &Lx, r_p1: &crate::syntax::Range) -> crate::check::types::Ty {
    match crate::prelude::get(&lx_p0.binders_p, &place_key_f(lx_p0, r_p1)) {
        ::std::option::Option::Some(t_p2) => subst_ty_f(lx_p0, &t_p2),
        ::std::option::Option::None => type_at_f(lx_p0, r_p1),
    }
}

/// ```prism
/// SubstTy: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_f(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    if (&crate::prelude::len(&crate::prelude::keys(&lx_p0.subst_p)) == &crate::prelude::Nat::from(0u32)) && (&crate::prelude::len(&crate::prelude::keys(&lx_p0.csubst_p)) == &crate::prelude::Nat::from(0u32)) {
        t_p1.clone()
    } else {
        subst_ty_in_f(lx_p0, t_p1)
    }
}

/// ```prism
/// SubstTyIn: fn Lx, Ty -> Ty
/// ```
pub fn subst_ty_in_f(lx_p0: &Lx, t_p1: &crate::check::types::Ty) -> crate::check::types::Ty {
    match t_p1 {
        crate::check::types::Ty::TyFlex(n_p2) => crate::prelude::or(&crate::prelude::get(&lx_p0.subst_p, &crate::prelude::Text::from(format!("\'{}", n_p2))), t_p1),
        crate::check::types::Ty::TyQ(n_p3) => crate::prelude::or(&crate::prelude::get(&lx_p0.subst_p, n_p3), t_p1),
        crate::check::types::Ty::TyRigid(n_p4) => crate::prelude::or(&crate::prelude::get(&lx_p0.subst_p, n_p4), t_p1),
        crate::check::types::Ty::TyCon(n_p5, args_p6) => crate::check::types::Ty::TyCon(n_p5.clone(), crate::prelude::each(args_p6, &(|a_p7: &crate::check::types::Ty| subst_ty_in_f(lx_p0, a_p7)))),
        crate::check::types::Ty::TyFn(c_p8, ps_p9, res_pa) => crate::check::types::Ty::TyFn(inst_col_f(lx_p0, c_p8), crate::prelude::each(ps_p9, &(|p_pb: &crate::check::types::Ty| subst_ty_in_f(lx_p0, p_pb))), ::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**res_pa))),
        crate::check::types::Ty::TyTuple(ts_pc) => crate::check::types::Ty::TyTuple(crate::prelude::each(ts_pc, &(|a_pd: &crate::check::types::Ty| subst_ty_in_f(lx_p0, a_pd)))),
        crate::check::types::Ty::TyArray(e_pe) => crate::check::types::Ty::TyArray(::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**e_pe))),
        crate::check::types::Ty::TyMap(k_pf, v_pg) => crate::check::types::Ty::TyMap(::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**k_pf)), ::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**v_pg))),
        crate::check::types::Ty::TySig(s_ph, i_pi) => crate::check::types::Ty::TySig(s_ph.clone(), ::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**i_pi))),
        crate::check::types::Ty::TyAt(i_pj, rw_pk) => crate::check::types::Ty::TyAt(::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**i_pj)), rw_pk.clone()),
        crate::check::types::Ty::TyElem(rw_pl, o_pm) => crate::check::types::Ty::TyElem(rw_pl.clone(), ::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**o_pm))),
        crate::check::types::Ty::TyAssoc(tr_pn, n_po, a_pp) => crate::check::types::Ty::TyAssoc(tr_pn.clone(), n_po.clone(), ::std::rc::Rc::new(subst_ty_in_f(lx_p0, &**a_pp))),
        other_pq => other_pq.clone(),
    }
}

/// ```prism
/// InstCol: fn Lx, Col -> Col
/// ```
pub fn inst_col_f(lx_p0: &Lx, col1: &crate::check::types::Col) -> crate::check::types::Col {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => crate::prelude::or(&crate::prelude::get(&lx_p0.csubst_p, q_p1), &crate::check::types::Col::CQ(q_p1.clone())),
        c_p3 => c_p3.clone(),
    }
}

/// ```prism
/// IsQuantCol: fn Lx, Col -> Bool
/// ```
pub fn is_quant_col_f(lx_p0: &Lx, col1: &crate::check::types::Col) -> bool {
    match col1 {
        crate::check::types::Col::CQ(q_p1) => crate::check::env::has_key_f(&lx_p0.quants_p, q_p1),
        c_p3 => false,
    }
}

/// ```prism
/// TypedTables: unbounded fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub fn typed_tables_f(tp_p0: &crate::check::typed::TProgram) -> (crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>) {
    let tys_p1 = crate::prelude::fold(&tp_p0.exprs_p, &crate::prelude::Map::new(), &(|m_p5: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_p6: &crate::check::typed::TyNote| crate::prelude::insert(m_p5, &crate::check::typed::at_key_f(&n_p6.at_p), &n_p6.ty_p)));
    let apps_p2 = crate::prelude::fold(&tp_p0.apps_p, &crate::prelude::Map::new(), &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, n_p8: &crate::check::typed::AppNote| crate::prelude::insert(m_p7, &crate::check::typed::at_key_f(&n_p8.at_p), n_p8)));
    let bs_p3 = crate::prelude::fold(&tp_p0.binders_p, &crate::prelude::Map::new(), &(|m_p9: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_pa: &crate::check::typed::BinderNote| crate::prelude::insert(m_p9, &crate::check::typed::at_key_f(&n_pa.at_p), &n_pa.ty_p)));
    let ims_p4 = crate::prelude::fold(&tp_p0.impls_p, &crate::prelude::Map::new(), &(|m_pb: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>, n_pc: &crate::check::typed::ImplNote| crate::prelude::insert(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p)), &crate::prelude::Array::new()), n_pc))));
    (tys_p1.clone(), apps_p2.clone(), bs_p3.clone(), ims_p4.clone())
}

/// The step machine of `TypedTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedTables: unbounded fn TProgram -> (((Text ==> Ty), (Text ==> AppNote), (Text ==> Ty), (Text ==> [ImplNote])))
/// ```
pub struct TypedTables {
    pub tp_p0: crate::check::typed::TProgram,
}

impl ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>)> for TypedTables {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>)> {
        let tp_p0 = &self.tp_p0;
        let tys_p1 = crate::prelude::fold(&tp_p0.exprs_p, &crate::prelude::Map::new(), &(|m_p5: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_p6: &crate::check::typed::TyNote| crate::prelude::insert(m_p5, &crate::check::typed::at_key_f(&n_p6.at_p), &n_p6.ty_p)));
        let apps_p2 = crate::prelude::fold(&tp_p0.apps_p, &crate::prelude::Map::new(), &(|m_p7: &crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, n_p8: &crate::check::typed::AppNote| crate::prelude::insert(m_p7, &crate::check::typed::at_key_f(&n_p8.at_p), n_p8)));
        let bs_p3 = crate::prelude::fold(&tp_p0.binders_p, &crate::prelude::Map::new(), &(|m_p9: &crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, n_pa: &crate::check::typed::BinderNote| crate::prelude::insert(m_p9, &crate::check::typed::at_key_f(&n_pa.at_p), &n_pa.ty_p)));
        let ims_p4 = crate::prelude::fold(&tp_p0.impls_p, &crate::prelude::Map::new(), &(|m_pb: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>, n_pc: &crate::check::typed::ImplNote| crate::prelude::insert(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_pb, &crate::check::typed::at_key_f(&n_pc.at_p)), &crate::prelude::Array::new()), n_pc))));
        ::prism_rtl::Turn::Finished((tys_p1.clone(), apps_p2.clone(), bs_p3.clone(), ims_p4.clone()))
    }
}

/// `Start TypedTables, x`: what the function value is when passed to `@Run`.
pub fn start_typed_tables_f(tp_p0: crate::check::typed::TProgram) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::check::typed::AppNote>, crate::prelude::Map<crate::prelude::Text, crate::check::types::Ty>, crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::check::typed::ImplNote>>)>> {
    ::std::rc::Rc::new(TypedTables { tp_p0 })
}

/// ```prism
/// let rustKeywords
/// ```
pub fn rust_keywords_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("as"), crate::prelude::Text::lit("async"), crate::prelude::Text::lit("await"), crate::prelude::Text::lit("box"), crate::prelude::Text::lit("break"), crate::prelude::Text::lit("const"), crate::prelude::Text::lit("continue"), crate::prelude::Text::lit("crate"), crate::prelude::Text::lit("do"), crate::prelude::Text::lit("dyn"), crate::prelude::Text::lit("else"), crate::prelude::Text::lit("enum"), crate::prelude::Text::lit("extern"), crate::prelude::Text::lit("false"), crate::prelude::Text::lit("final"), crate::prelude::Text::lit("fn"), crate::prelude::Text::lit("for"), crate::prelude::Text::lit("gen"), crate::prelude::Text::lit("if"), crate::prelude::Text::lit("impl"), crate::prelude::Text::lit("in"), crate::prelude::Text::lit("let"), crate::prelude::Text::lit("loop"), crate::prelude::Text::lit("macro"), crate::prelude::Text::lit("match"), crate::prelude::Text::lit("mod"), crate::prelude::Text::lit("move"), crate::prelude::Text::lit("mut"), crate::prelude::Text::lit("override"), crate::prelude::Text::lit("priv"), crate::prelude::Text::lit("pub"), crate::prelude::Text::lit("ref"), crate::prelude::Text::lit("return"), crate::prelude::Text::lit("self"), crate::prelude::Text::lit("static"), crate::prelude::Text::lit("struct"), crate::prelude::Text::lit("super"), crate::prelude::Text::lit("trait"), crate::prelude::Text::lit("true"), crate::prelude::Text::lit("try"), crate::prelude::Text::lit("type"), crate::prelude::Text::lit("typeof"), crate::prelude::Text::lit("unsafe"), crate::prelude::Text::lit("unsized"), crate::prelude::Text::lit("use"), crate::prelude::Text::lit("virtual"), crate::prelude::Text::lit("where"), crate::prelude::Text::lit("while"), crate::prelude::Text::lit("yield"), crate::prelude::Text::lit("u8"), crate::prelude::Text::lit("u16"), crate::prelude::Text::lit("u32"), crate::prelude::Text::lit("u64"), crate::prelude::Text::lit("i8"), crate::prelude::Text::lit("i16"), crate::prelude::Text::lit("i32"), crate::prelude::Text::lit("i64"), crate::prelude::Text::lit("f32"), crate::prelude::Text::lit("f64"), crate::prelude::Text::lit("bool"), crate::prelude::Text::lit("char"), crate::prelude::Text::lit("str"), crate::prelude::Text::lit("usize"), crate::prelude::Text::lit("isize"), crate::prelude::Text::lit("cx"), crate::prelude::Text::lit("node"), crate::prelude::Text::lit("path"), crate::prelude::Text::lit("v"), crate::prelude::Text::lit("p")])
}

/// ```prism
/// Base: fn Text -> Text
/// ```
pub fn base_f(name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::drop_prefix_f(name_p0, &crate::check::types::unify::marks_of_f(name_p0))
}

/// ```prism
/// Snake: fn Text -> Text
/// ```
pub fn snake_f(name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let (out_p6, _) = crate::syntax::lexer::chars::fold_chars_f(&base_f(name_p0), &(crate::prelude::Text::lit(""), crate::prelude::Text::lit("")), &(::std::rc::Rc::new(move |(p0, p1): ((crate::prelude::Text, crate::prelude::Text), crate::prelude::Text)| crate::prelude::once_job(move || {
        let (acc_p2, prev_p3) = p0;
        let c_p4 = p1;
        {
            let sep_p5 = if crate::syntax::lexer::chars::is_upper_f(&c_p4) && (crate::syntax::lexer::chars::is_lower_f(&prev_p3) || crate::syntax::lexer::chars::is_digit_f(&prev_p3)) {
                crate::prelude::Text::lit("_")
            } else {
                crate::prelude::Text::lit("")
            };
            ::prism_rtl::Turn::Finished((crate::prelude::Text::from(format!("{}{}{}", &acc_p2, &sep_p5, &lower_char_f(&c_p4))), c_p4.clone()))
        }
    })) as ::std::rc::Rc<dyn ::std::ops::Fn(((crate::prelude::Text, crate::prelude::Text), crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::prelude::Text)>>>));
    let plain_p1 = if &out_p6 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("x")
    } else {
        out_p6.clone()
    };
    if crate::check::types::has_text_f(&rust_keywords_p(), &plain_p1) {
        crate::prelude::Text::from(format!("{}_", &plain_p1))
    } else {
        plain_p1.clone()
    }
}

/// ```prism
/// LowerChar: fn Text -> Text
/// ```
pub fn lower_char_f(c_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::is_upper_f(c_p0) {
        crate::prelude::lower(c_p0)
    } else {
        c_p0.clone()
    }
}

/// ```prism
/// Camel: fn Text -> Text
/// ```
pub fn camel_f(name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let b_p1 = base_f(name_p0);
    let first_p2 = crate::syntax::lexer::chars::head_f(&b_p1);
    let fixed_p3 = if crate::syntax::lexer::chars::is_lower_f(&first_p2) {
        crate::prelude::Text::from(format!("{}{}", &crate::prelude::upper(&first_p2), &crate::syntax::lexer::chars::after_first_f(&b_p1)))
    } else {
        b_p1.clone()
    };
    if &fixed_p3 == &crate::prelude::Text::lit("Self") {
        crate::prelude::Text::from(format!("{}_", &fixed_p3))
    } else {
        fixed_p3.clone()
    }
}

/// ```prism
/// RustModName: fn Text -> Text
/// ```
pub fn rust_mod_name_f(m_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if m_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("program")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::each(&crate::prelude::split_on(m_p0, &crate::prelude::Text::lit(".")), &(|s_p1: &crate::prelude::Text| mod_segment_f(s_p1))), &crate::prelude::Text::lit("::"))
    }
}

/// ```prism
/// ModSegment: fn Text -> Text
/// ```
pub fn mod_segment_f(s_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let n_p1 = snake_f(s_p0);
    if crate::check::types::has_text_f(&cpp_keywords_p(), &n_p1) {
        crate::prelude::Text::from(format!("{}_", &n_p1))
    } else {
        n_p1.clone()
    }
}

/// ```prism
/// let cppKeywords
/// ```
pub fn cpp_keywords_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("explicit"), crate::prelude::Text::lit("and"), crate::prelude::Text::lit("and_eq"), crate::prelude::Text::lit("asm"), crate::prelude::Text::lit("auto"), crate::prelude::Text::lit("bitand"), crate::prelude::Text::lit("bitor"), crate::prelude::Text::lit("bool"), crate::prelude::Text::lit("case"), crate::prelude::Text::lit("catch"), crate::prelude::Text::lit("char"), crate::prelude::Text::lit("char8_t"), crate::prelude::Text::lit("char16_t"), crate::prelude::Text::lit("char32_t"), crate::prelude::Text::lit("class"), crate::prelude::Text::lit("compl"), crate::prelude::Text::lit("concept"), crate::prelude::Text::lit("const_cast"), crate::prelude::Text::lit("consteval"), crate::prelude::Text::lit("constexpr"), crate::prelude::Text::lit("constinit"), crate::prelude::Text::lit("co_await"), crate::prelude::Text::lit("co_return"), crate::prelude::Text::lit("co_yield"), crate::prelude::Text::lit("decltype"), crate::prelude::Text::lit("default"), crate::prelude::Text::lit("delete"), crate::prelude::Text::lit("double"), crate::prelude::Text::lit("dynamic_cast"), crate::prelude::Text::lit("explicit"), crate::prelude::Text::lit("export"), crate::prelude::Text::lit("extern"), crate::prelude::Text::lit("float"), crate::prelude::Text::lit("friend"), crate::prelude::Text::lit("goto"), crate::prelude::Text::lit("inline"), crate::prelude::Text::lit("int"), crate::prelude::Text::lit("long"), crate::prelude::Text::lit("mutable"), crate::prelude::Text::lit("namespace"), crate::prelude::Text::lit("new"), crate::prelude::Text::lit("noexcept"), crate::prelude::Text::lit("not"), crate::prelude::Text::lit("not_eq"), crate::prelude::Text::lit("nullptr"), crate::prelude::Text::lit("operator"), crate::prelude::Text::lit("or"), crate::prelude::Text::lit("or_eq"), crate::prelude::Text::lit("private"), crate::prelude::Text::lit("protected"), crate::prelude::Text::lit("public"), crate::prelude::Text::lit("register"), crate::prelude::Text::lit("reinterpret_cast"), crate::prelude::Text::lit("requires"), crate::prelude::Text::lit("short"), crate::prelude::Text::lit("signed"), crate::prelude::Text::lit("sizeof"), crate::prelude::Text::lit("static_assert"), crate::prelude::Text::lit("static_cast"), crate::prelude::Text::lit("switch"), crate::prelude::Text::lit("template"), crate::prelude::Text::lit("this"), crate::prelude::Text::lit("thread_local"), crate::prelude::Text::lit("throw"), crate::prelude::Text::lit("try"), crate::prelude::Text::lit("typedef"), crate::prelude::Text::lit("typeid"), crate::prelude::Text::lit("typename"), crate::prelude::Text::lit("union"), crate::prelude::Text::lit("unsigned"), crate::prelude::Text::lit("using"), crate::prelude::Text::lit("virtual"), crate::prelude::Text::lit("void"), crate::prelude::Text::lit("volatile"), crate::prelude::Text::lit("wchar_t"), crate::prelude::Text::lit("xor"), crate::prelude::Text::lit("xor_eq"), crate::prelude::Text::lit("errno"), crate::prelude::Text::lit("assert"), crate::prelude::Text::lit("NULL"), crate::prelude::Text::lit("EOF"), crate::prelude::Text::lit("stdin"), crate::prelude::Text::lit("stdout"), crate::prelude::Text::lit("stderr"), crate::prelude::Text::lit("major"), crate::prelude::Text::lit("minor")])
}

/// ```prism
/// PathIn: fn Lx, Text, Text -> Text
/// ```
pub fn path_in_f(lx_p0: &Lx, owner_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text) -> crate::prelude::Text {
    if owner_p1 == &lx_p0.site_p {
        name_p2.clone()
    } else {
        if owner_p1 == &crate::prelude::Text::lit("Prelude") {
            prelude_path_f(lx_p0, name_p2)
        } else {
            crate::prelude::Text::from(format!("crate::{}::{}", &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_mods_p, owner_p1), &rust_mod_name_f(owner_p1)), name_p2))
        }
    }
}

/// ```prism
/// PreludePath: fn Lx, Text -> Text
/// ```
pub fn prelude_path_f(lx0: &Lx, name_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match lx0 {
        _ => helper_f(name_p0),
    }
}

/// ```prism
/// Helper: fn Text -> Text
/// ```
pub fn helper_f(n_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("crate::prelude::{}", n_p0))
}

/// ```prism
/// NodeName: fn Text -> Text
/// ```
pub fn node_name_f(qk_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}_w", &camel_f(&crate::check::types::bare_name_f(qk_p0))))
}

/// ```prism
/// TraitName: fn Text -> Text
/// ```
pub fn trait_name_f(cls_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if crate::syntax::lexer::chars::has_prefix_f(cls_p0, &crate::prelude::Text::lit("Prelude.")) {
        camel_f(&crate::check::types::bare_name_f(cls_p0))
    } else {
        crate::prelude::Text::from(format!("{}_t", &camel_f(&crate::check::types::bare_name_f(cls_p0))))
    }
}

/// ```prism
/// RefIn: fn Lx, Text, Text -> Ref
/// ```
pub fn ref_in_f(lx_p0: &Lx, owner_p1: &crate::prelude::Text, name_p2: &crate::prelude::Text) -> crate::lower::model::Ref {
    crate::lower::model::Ref::RefItem(crate::prelude::or(&crate::prelude::get(&lx_p0.rs_mods_p, owner_p1), &rust_mod_name_f(owner_p1)), name_p2.clone(), path_in_f(lx_p0, owner_p1, name_p2))
}

/// ```prism
/// TypeItemName: fn Text -> Text
/// ```
pub fn type_item_name_f(n_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if n_p0 == &crate::prelude::Text::lit("Prelude.Turn") {
        crate::prelude::Text::lit("PreludeTurn")
    } else {
        camel_f(&crate::check::types::bare_name_f(n_p0))
    }
}

/// ```prism
/// SiteRef: fn Lx, Text -> Ref
/// ```
pub fn site_ref_f(lx_p0: &Lx, name_p1: &crate::prelude::Text) -> crate::lower::model::Ref {
    ref_in_f(lx_p0, &lx_p0.site_p, name_p1)
}

/// ```prism
/// HelperRef: fn Text -> Ref
/// ```
pub fn helper_ref_f(n_p0: &crate::prelude::Text) -> crate::lower::model::Ref {
    crate::lower::model::Ref::RefItem(crate::prelude::Text::lit("prelude"), n_p0.clone(), helper_f(n_p0))
}

/// ```prism
/// ValueNames: unbounded fn G -> (Text ==> Text)
/// ```
pub fn value_names_f(g_p0: &crate::check::env::G) -> crate::prelude::Map<crate::prelude::Text, crate::prelude::Text> {
    let lets_p1 = crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::prelude::Text>, d_p5: &crate::check::env::Def| match &d_p5.body_p {
        crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text_f(acc_p4, &d_p5.qk_p),
        _ => acc_p4.clone(),
    }));
    let keys_p2 = crate::check::types::union_texts_f(&crate::prelude::keys(&g_p0.vals_p), &lets_p1);
    let bases_p3 = crate::prelude::fold(&keys_p2, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, k_p7: &crate::prelude::Text| crate::prelude::insert(m_p6, &base_key_f(k_p7), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p6, &base_key_f(k_p7)), &crate::prelude::Array::new()), k_p7))));
    crate::prelude::run_to_end(crate::prelude::fold_job(keys_p2.clone(), crate::prelude::Map::new(), {
        let g_p0x = g_p0.clone();
        let bases_p3x = bases_p3.clone();
        ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)| {
            let g_p0xy = g_p0x.clone();
            let bases_p3xy = bases_p3x.clone();
            crate::prelude::entered(crate::prelude::once_job(move || {
                let m_p8 = p0;
                let k_p9 = p1;
                {
                    let runtimes_pa = (&owner_of_f(&k_p9) == &crate::prelude::Text::lit("Prelude")) || match crate::prelude::get(&g_p0xy.vals_p, &k_p9) {
                        ::std::option::Option::Some(v_pb) => (&v_pb.sort_p == &crate::prelude::Text::lit("builtin")) || (&v_pb.home_p == &crate::prelude::Text::lit("Prelude")),
                        ::std::option::Option::None => false,
                    };
                    ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &k_p9, &(if runtimes_pa {
                        value_name_f(&k_p9, &crate::prelude::len(&crate::prelude::or(&crate::prelude::get(&bases_p3xy, &base_key_f(&k_p9)), &crate::prelude::Array::new())))
                    } else {
                        crate::prelude::Text::from(format!("{}_{}", &global_base_f(&k_p9), &global_letter_f(&g_p0xy, &k_p9)))
                    })))
                }
            }))
        }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>>>>
    }))
}

/// The step machine of `ValueNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ValueNames: unbounded fn G -> (Text ==> Text)
/// ```
pub struct ValueNames {
    pub g_p0: crate::check::env::G,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>> for ValueNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>> {
        let g_p0 = &self.g_p0;
        let lets_p1 = crate::prelude::fold(&g_p0.defs_p, &crate::prelude::Array::new(), &(|acc_p4: &crate::prelude::Array<crate::prelude::Text>, d_p5: &crate::check::env::Def| match &d_p5.body_p {
            crate::check::env::DefBody::DbLet(_) => crate::check::types::add_text_f(acc_p4, &d_p5.qk_p),
            _ => acc_p4.clone(),
        }));
        let keys_p2 = crate::check::types::union_texts_f(&crate::prelude::keys(&g_p0.vals_p), &lets_p1);
        let bases_p3 = crate::prelude::fold(&keys_p2, &crate::prelude::Map::new(), &(|m_p6: &crate::prelude::Map<crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>>, k_p7: &crate::prelude::Text| crate::prelude::insert(m_p6, &base_key_f(k_p7), &crate::prelude::push(&crate::prelude::or(&crate::prelude::get(m_p6, &base_key_f(k_p7)), &crate::prelude::Array::new()), k_p7))));
        crate::prelude::fold_job(keys_p2.clone(), crate::prelude::Map::new(), {
            let g_p0x = g_p0.clone();
            let bases_p3x = bases_p3.clone();
            ::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)| {
                let g_p0xy = g_p0x.clone();
                let bases_p3xy = bases_p3x.clone();
                crate::prelude::entered(crate::prelude::once_job(move || {
                    let m_p8 = p0;
                    let k_p9 = p1;
                    {
                        let runtimes_pa = (&owner_of_f(&k_p9) == &crate::prelude::Text::lit("Prelude")) || match crate::prelude::get(&g_p0xy.vals_p, &k_p9) {
                            ::std::option::Option::Some(v_pb) => (&v_pb.sort_p == &crate::prelude::Text::lit("builtin")) || (&v_pb.home_p == &crate::prelude::Text::lit("Prelude")),
                            ::std::option::Option::None => false,
                        };
                        ::prism_rtl::Turn::Finished(crate::prelude::insert(&m_p8, &k_p9, &(if runtimes_pa {
                            value_name_f(&k_p9, &crate::prelude::len(&crate::prelude::or(&crate::prelude::get(&bases_p3xy, &base_key_f(&k_p9)), &crate::prelude::Array::new())))
                        } else {
                            crate::prelude::Text::from(format!("{}_{}", &global_base_f(&k_p9), &global_letter_f(&g_p0xy, &k_p9)))
                        })))
                    }
                }))
            }) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>>>>
        }).cycle()
    }
}

/// `Start ValueNames, x`: what the function value is when passed to `@Run`.
pub fn start_value_names_f(g_p0: crate::check::env::G) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>>> {
    ::std::rc::Rc::new(ValueNames { g_p0 })
}

/// ```prism
/// GlobalBase: unbounded fn Text -> Text
/// ```
pub fn global_base_f(k_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let base_p1 = trim_underscores_f(&snake_f(&crate::check::types::bare_name_f(k_p0)));
    if &base_p1 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("topic")
    } else {
        base_p1.clone()
    }
}

/// The step machine of `GlobalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalBase: unbounded fn Text -> Text
/// ```
pub struct GlobalBase {
    pub k_p0: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for GlobalBase {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let k_p0 = &self.k_p0;
        let k_p0x = k_p0.clone();
        crate::prelude::call_then(start_trim_underscores_f(snake_f(&crate::check::types::bare_name_f(&k_p0x))), move |trim_underscores_f_16659: crate::prelude::Text| {
            let base_p1 = trim_underscores_f_16659;
            if &base_p1 == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("topic"))
            } else {
                ::prism_rtl::Turn::Finished(base_p1.clone())
            }
        })
    }
}

/// `Start GlobalBase, x`: what the function value is when passed to `@Run`.
pub fn start_global_base_f(k_p0: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(GlobalBase { k_p0 })
}

/// ```prism
/// FieldSpell: unbounded fn Text, Text, Ty -> Text
/// ```
pub fn field_spell_f(text0: &crate::prelude::Text, fname_p0: &crate::prelude::Text, ft_p1: &crate::check::types::Ty) -> crate::prelude::Text {
    match text0 {
        _ => crate::prelude::Text::from(format!("{}_{}", &global_base_f(fname_p0), &sigil_or_kind_f(fname_p0, ft_p1))),
    }
}

/// The step machine of `FieldSpell`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldSpell: unbounded fn Text, Text, Ty -> Text
/// ```
pub struct FieldSpell {
    pub text0: crate::prelude::Text,
    pub fname_p0: crate::prelude::Text,
    pub ft_p1: crate::check::types::Ty,
}

impl ::prism_rtl::Job<crate::prelude::Text> for FieldSpell {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let text0 = &self.text0;
        let fname_p0 = &self.fname_p0;
        let ft_p1 = &self.ft_p1;
        match text0 {
            _ => {
                let fname_p0x = fname_p0.clone();
                let ft_p1x = ft_p1.clone();
                crate::prelude::call_then(start_global_base_f(fname_p0x.clone()), move |global_base_f_17234: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}_{}", &global_base_f_17234, &sigil_or_kind_f(&fname_p0x, &ft_p1x)))))
            },
        }
    }
}

/// `Start FieldSpell, x`: what the function value is when passed to `@Run`.
pub fn start_field_spell_f(text0: crate::prelude::Text, fname_p0: crate::prelude::Text, ft_p1: crate::check::types::Ty) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(FieldSpell { text0, fname_p0, ft_p1 })
}

/// ```prism
/// SigilOrKind: fn Text, Ty -> Text
/// ```
pub fn sigil_or_kind_f(name_p0: &crate::prelude::Text, t_p1: &crate::check::types::Ty) -> crate::prelude::Text {
    let marks_p2 = crate::check::types::unify::marks_of_f(name_p0);
    if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("&")) {
        crate::prelude::Text::lit("l")
    } else {
        if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("?")) {
            crate::prelude::Text::lit("o")
        } else {
            if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("~")) {
                crate::prelude::Text::lit("r")
            } else {
                if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("!")) {
                    crate::prelude::Text::lit("e")
                } else {
                    if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("$")) {
                        crate::prelude::Text::lit("d")
                    } else {
                        if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("@")) {
                            crate::prelude::Text::lit("b")
                        } else {
                            kind_letter_f(t_p1)
                        }
                    }
                }
            }
        }
    }
}

/// ```prism
/// GlobalLetter: fn G, Text -> Text
/// ```
pub fn global_letter_f(g_p0: &crate::check::env::G, k_p1: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::prelude::get(&g_p0.vals_p, k_p1) {
        ::std::option::Option::Some(v_p2) => sigil_or_kind_f(&crate::check::types::bare_name_f(k_p1), &v_p2.scheme_p.ty_p),
        ::std::option::Option::None => sigil_or_kind_f(&crate::check::types::bare_name_f(k_p1), &(if crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&base_f(&crate::check::types::bare_name_f(k_p1)))) {
            crate::check::types::Ty::TyFn(crate::check::types::Col::CBound, crate::prelude::Array::new(), ::std::rc::Rc::new(crate::check::types::Ty::TyErr))
        } else {
            crate::check::types::Ty::TyErr
        })),
    }
}

/// ```prism
/// GlobalNames: unbounded fn G -> (Text ==> Bool)
/// ```
pub fn global_names_f(g_p0: &crate::check::env::G) -> crate::prelude::Map<crate::prelude::Text, bool> {
    let names_p1 = value_names_f(g_p0);
    crate::prelude::fold(&crate::prelude::keys(&names_p1), &crate::prelude::Map::new(), &(|m_p2: &crate::prelude::Map<crate::prelude::Text, bool>, k_p3: &crate::prelude::Text| crate::prelude::insert(m_p2, &crate::prelude::Text::from(format!("{}.{}", &owner_of_f(k_p3), &crate::prelude::or(&crate::prelude::get(&names_p1, k_p3), &crate::prelude::Text::lit("")))), &true)))
}

/// The step machine of `GlobalNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GlobalNames: unbounded fn G -> (Text ==> Bool)
/// ```
pub struct GlobalNames {
    pub g_p0: crate::check::env::G,
}

impl ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, bool>> for GlobalNames {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Map<crate::prelude::Text, bool>> {
        let g_p0 = &self.g_p0;
        let g_p0x = g_p0.clone();
        crate::prelude::call_then(start_value_names_f(g_p0x.clone()), move |value_names_f_17981: crate::prelude::Map<crate::prelude::Text, crate::prelude::Text>| {
            let names_p1 = value_names_f_17981;
            ::prism_rtl::Turn::Finished(crate::prelude::fold(&crate::prelude::keys(&names_p1), &crate::prelude::Map::new(), &(|m_p2: &crate::prelude::Map<crate::prelude::Text, bool>, k_p3: &crate::prelude::Text| crate::prelude::insert(m_p2, &crate::prelude::Text::from(format!("{}.{}", &owner_of_f(k_p3), &crate::prelude::or(&crate::prelude::get(&names_p1, k_p3), &crate::prelude::Text::lit("")))), &true))))
        })
    }
}

/// `Start GlobalNames, x`: what the function value is when passed to `@Run`.
pub fn start_global_names_f(g_p0: crate::check::env::G) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Map<crate::prelude::Text, bool>>> {
    ::std::rc::Rc::new(GlobalNames { g_p0 })
}

/// ```prism
/// LocalName: fn Lx, Text -> Text
/// ```
pub fn local_name_f(lx_p0: &Lx, nkey_p1: &crate::prelude::Text) -> crate::prelude::Text {
    let marks_p2 = crate::check::types::unify::marks_of_f(nkey_p1);
    let base_p3 = snake_f(nkey_p1);
    let bare_p4 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p1, &marks_p2);
    let s0_p5 = if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("?")) {
        crate::prelude::Text::from(format!("{}_opt", &base_p3))
    } else {
        if crate::syntax::lexer::chars::contains_f(&marks_p2, &crate::prelude::Text::lit("~")) {
            crate::prelude::Text::from(format!("{}_try", &base_p3))
        } else {
            base_p3.clone()
        }
    };
    let s1_p6 = if crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&bare_p4)) {
        crate::prelude::Text::from(format!("{}_fn", &s0_p5))
    } else {
        s0_p5.clone()
    };
    if crate::check::env::has_key_f(&lx_p0.globals_p, &crate::prelude::Text::from(format!("{}.{}", &lx_p0.site_p, &s1_p6))) || crate::check::env::has_key_f(&lx_p0.globals_p, &crate::prelude::Text::from(format!("Prelude.{}", &s1_p6))) {
        crate::prelude::Text::from(format!("{}_", &s1_p6))
    } else {
        s1_p6.clone()
    }
}

/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub fn local_name_at_f(lx_p0: &Lx, nkey_p1: &crate::prelude::Text, span_p2: &crate::syntax::Range) -> crate::prelude::Text {
    match crate::prelude::get(&lx_p0.local_ids_p, &place_key_f(lx_p0, span_p2)) {
        ::std::option::Option::Some(id_p3) => crate::prelude::Text::from(format!("{}_{}{}{}", &local_base_f(nkey_p1), &kind_letter_f(&binder_ty_f(lx_p0, span_p2)), &base32_f(&id_p3), &lx_p0.inlined_p)),
        ::std::option::Option::None => local_name_f(lx_p0, nkey_p1),
    }
}

/// The step machine of `LocalNameAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalNameAt: unbounded fn Lx, Text, Range -> Text
/// ```
pub struct LocalNameAt {
    pub lx_p0: Lx,
    pub nkey_p1: crate::prelude::Text,
    pub span_p2: crate::syntax::Range,
}

impl ::prism_rtl::Job<crate::prelude::Text> for LocalNameAt {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let lx_p0 = &self.lx_p0;
        let nkey_p1 = &self.nkey_p1;
        let span_p2 = &self.span_p2;
        match crate::prelude::get(&lx_p0.local_ids_p, &place_key_f(lx_p0, span_p2)) {
            ::std::option::Option::Some(id_p3) => {
                let lx_p0x = lx_p0.clone();
                let nkey_p1x = nkey_p1.clone();
                let span_p2x = span_p2.clone();
                crate::prelude::call_then(start_local_base_f(nkey_p1x.clone()), move |local_base_f_19371: crate::prelude::Text| crate::prelude::call_then(start_base32_f(id_p3.clone()), move |base32_f_19420: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}_{}{}{}", &local_base_f_19371, &kind_letter_f(&binder_ty_f(&lx_p0x, &span_p2x)), &base32_f_19420, &lx_p0x.inlined_p)))))
            },
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(local_name_f(lx_p0, nkey_p1)),
        }
    }
}

/// `Start LocalNameAt, x`: what the function value is when passed to `@Run`.
pub fn start_local_name_at_f(lx_p0: Lx, nkey_p1: crate::prelude::Text, span_p2: crate::syntax::Range) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(LocalNameAt { lx_p0, nkey_p1, span_p2 })
}

/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub fn local_base_f(nkey_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let bare_p1 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p0, &crate::check::types::unify::marks_of_f(nkey_p0));
    let base_p2 = snake_f(&bare_p1);
    let trimmed_p3 = trim_underscores_f(&base_p2);
    if &trimmed_p3 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("topic")
    } else {
        trimmed_p3.clone()
    }
}

/// The step machine of `LocalBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LocalBase: unbounded fn Text -> Text
/// ```
pub struct LocalBase {
    pub nkey_p0: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for LocalBase {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let nkey_p0 = &self.nkey_p0;
        let bare_p1 = crate::syntax::lexer::chars::drop_prefix_f(nkey_p0, &crate::check::types::unify::marks_of_f(nkey_p0));
        let base_p2 = snake_f(&bare_p1);
        crate::prelude::call_then(start_trim_underscores_f(base_p2.clone()), move |trim_underscores_f_19757: crate::prelude::Text| {
            let trimmed_p3 = trim_underscores_f_19757;
            if &trimmed_p3 == &crate::prelude::Text::lit("") {
                ::prism_rtl::Turn::Finished(crate::prelude::Text::lit("topic"))
            } else {
                ::prism_rtl::Turn::Finished(trimmed_p3.clone())
            }
        })
    }
}

/// `Start LocalBase, x`: what the function value is when passed to `@Run`.
pub fn start_local_base_f(nkey_p0: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(LocalBase { nkey_p0 })
}

/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub fn trim_underscores_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    match crate::syntax::lexer::chars::before_suffix_o(t_p0, &crate::prelude::Text::lit("_")) {
        ::std::option::Option::Some(s_p1) => trim_underscores_f(&s_p1),
        ::std::option::Option::None => t_p0.clone(),
    }
}

/// The step machine of `TrimUnderscores`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TrimUnderscores: unbounded fn Text -> Text
/// ```
pub struct TrimUnderscores {
    pub t_p0: crate::prelude::Text,
}

impl ::prism_rtl::Job<crate::prelude::Text> for TrimUnderscores {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let t_p0 = &self.t_p0;
        match crate::syntax::lexer::chars::before_suffix_o(t_p0, &crate::prelude::Text::lit("_")) {
            ::std::option::Option::Some(s_p1) => ::prism_rtl::Turn::More(::std::rc::Rc::new(TrimUnderscores { t_p0: s_p1.clone() })),
            ::std::option::Option::None => ::prism_rtl::Turn::Finished(t_p0.clone()),
        }
    }
}

/// `Start TrimUnderscores, x`: what the function value is when passed to `@Run`.
pub fn start_trim_underscores_f(t_p0: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(TrimUnderscores { t_p0 })
}

/// ```prism
/// KindLetter: fn Ty -> Text
/// ```
pub fn kind_letter_f(t_p0: &crate::check::types::Ty) -> crate::prelude::Text {
    match t_p0 {
        crate::check::types::Ty::TySig(m20163_0_0, _) if (m20163_0_0 == &crate::prelude::Text::lit("!")) => crate::prelude::Text::lit("e"),
        crate::check::types::Ty::TySig(m20163_1_0, _) if (m20163_1_0 == &crate::prelude::Text::lit("$")) => crate::prelude::Text::lit("d"),
        crate::check::types::Ty::TySig(m20163_2_0, _) if (m20163_2_0 == &crate::prelude::Text::lit("?")) => crate::prelude::Text::lit("o"),
        crate::check::types::Ty::TySig(m20163_3_0, _) if (m20163_3_0 == &crate::prelude::Text::lit("~")) => crate::prelude::Text::lit("r"),
        crate::check::types::Ty::TySig(m20163_4_0, i_p1) if (m20163_4_0 == &crate::prelude::Text::lit("&")) => kind_letter_f(&**i_p1),
        crate::check::types::Ty::TyAt(_, _) => crate::prelude::Text::lit("b"),
        crate::check::types::Ty::TyFn(_, _, _) => crate::prelude::Text::lit("f"),
        _ => crate::prelude::Text::lit("p"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub fn base32_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    let digit_p1 = crate::syntax::lexer::chars::char_at_byte_f(&crate::prelude::Text::lit("0123456789abcdefghijklmnopqrstuv"), &crate::prelude::or(&crate::prelude::mod_(n_p0, &crate::prelude::Nat::from(32u32)), &crate::prelude::Nat::from(0u32)));
    match crate::prelude::div(n_p0, &crate::prelude::Nat::from(32u32)) {
        ::std::option::Option::Some(q_p2) if (&q_p2 > &crate::prelude::Nat::from(0u32)) => crate::prelude::Text::from(format!("{}{}", &base32_f(&q_p2), &digit_p1)),
        _ => digit_p1.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Base32`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Base32: unbounded fn Nat -> Text
/// ```
pub struct Base32 {
    pub n_p0: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::prelude::Text> for Base32 {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::prelude::Text> {
        let n_p0 = &self.n_p0;
        let digit_p1 = crate::syntax::lexer::chars::char_at_byte_f(&crate::prelude::Text::lit("0123456789abcdefghijklmnopqrstuv"), &crate::prelude::or(&crate::prelude::mod_(n_p0, &crate::prelude::Nat::from(32u32)), &crate::prelude::Nat::from(0u32)));
        match crate::prelude::div(n_p0, &crate::prelude::Nat::from(32u32)) {
            ::std::option::Option::Some(q_p2) if (&q_p2 > &crate::prelude::Nat::from(0u32)) => crate::prelude::call_then(start_base32_f(q_p2.clone()), move |base32_f_20629: crate::prelude::Text| ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("{}{}", &base32_f_20629, &digit_p1)))),
            _ => ::prism_rtl::Turn::Finished(digit_p1.clone()),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Base32, x`: what the function value is when passed to `@Run`.
pub fn start_base32_f(n_p0: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>> {
    ::std::rc::Rc::new(Base32 { n_p0 })
}

/// ```prism
/// BaseKey: fn Text -> Text
/// ```
pub fn base_key_f(k_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let parts_p1 = crate::prelude::split_on(k_p0, &crate::prelude::Text::lit("."));
    let last_p2 = crate::prelude::or(&crate::syntax::lexer::chars::last_o(&parts_p1), k_p0);
    crate::prelude::Text::from(format!("{}.{}", &crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p1))), &crate::prelude::Text::lit(".")), &snake_f(&last_p2)))
}

/// ```prism
/// ValueName: fn Text, Nat -> Text
/// ```
pub fn value_name_f(k_p0: &crate::prelude::Text, count_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    let last_p2 = crate::check::types::bare_name_f(k_p0);
    let marks_p3 = crate::check::types::unify::marks_of_f(&last_p2);
    let base_p4 = snake_f(&last_p2);
    if (count_p1 > &crate::prelude::Nat::from(1u32)) && (&marks_p3 != &crate::prelude::Text::lit("")) {
        crate::prelude::Text::from(format!("{}_{}", &base_p4, &sigil_word_f(&crate::syntax::lexer::chars::head_f(&marks_p3))))
    } else {
        if (count_p1 > &crate::prelude::Nat::from(1u32)) && !crate::check::env::is_upper_text_f(&crate::syntax::lexer::chars::head_f(&last_p2)) {
            crate::prelude::Text::from(format!("{}_value", &base_p4))
        } else {
            base_p4.clone()
        }
    }
}

/// ```prism
/// SigilWord: fn Text -> Text
/// ```
pub fn sigil_word_f(text0: &crate::prelude::Text) -> crate::prelude::Text {
    match text0 {
        c0_0 if (c0_0 == &crate::prelude::Text::lit("?")) => crate::prelude::Text::lit("opt"),
        c1_0 if (c1_0 == &crate::prelude::Text::lit("~")) => crate::prelude::Text::lit("try"),
        c2_0 if (c2_0 == &crate::prelude::Text::lit("!")) => crate::prelude::Text::lit("ev"),
        c3_0 if (c3_0 == &crate::prelude::Text::lit("$")) => crate::prelude::Text::lit("dyn"),
        c4_0 if (c4_0 == &crate::prelude::Text::lit("@")) => crate::prelude::Text::lit("widget"),
        c5_0 if (c5_0 == &crate::prelude::Text::lit("&")) => crate::prelude::Text::lit("ref"),
        other_p0 => crate::prelude::Text::lit("x"),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ValueRef: fn Lx, Text -> Ref
/// ```
pub fn value_ref_f(lx_p0: &Lx, qk_p1: &crate::prelude::Text) -> crate::lower::model::Ref {
    let owner_p2 = match crate::prelude::get(&lx_p0.g_p.vals_p, qk_p1) {
        ::std::option::Option::Some(v_p3) => v_p3.home_p.clone(),
        ::std::option::Option::None => owner_of_f(qk_p1),
    };
    ref_in_f(lx_p0, &owner_p2, &crate::prelude::or(&crate::prelude::get(&lx_p0.rs_names_p, qk_p1), &snake_f(&crate::check::types::bare_name_f(qk_p1))))
}

/// ```prism
/// OwnerOf: fn Text -> Text
/// ```
pub fn owner_of_f(qk_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let parts_p1 = crate::prelude::split_on(qk_p0, &crate::prelude::Text::lit("."));
    crate::syntax::lexer::chars::join_f(&crate::prelude::take(&parts_p1, &crate::syntax::lexer::chars::dec_f(&crate::prelude::len(&parts_p1))), &crate::prelude::Text::lit("."))
}

/// ```prism
/// TagStruct: fn Text -> Text
/// ```
pub fn tag_struct_f(tn_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::split_on(tn_p0, &crate::prelude::Text::lit(".")), &(|p_p1: &crate::prelude::Text| camel_f(p_p1))))
}

/// ```prism
/// DescStructOf: fn TagInfo -> Text
/// ```
pub fn desc_struct_of_f(tg_p0: &crate::check::env::TagInfo) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("{}_desc", &tag_struct_f(&tg_p0.name_p)))
}

/// ```prism
/// TagStructOf: fn TagInfo -> Text
/// ```
pub fn tag_struct_of_f(tg_p0: &crate::check::env::TagInfo) -> crate::prelude::Text {
    if &tg_p0.home_p == &crate::prelude::Text::lit("Prelude") {
        tag_struct_f(&tg_p0.name_p)
    } else {
        crate::prelude::Text::from(format!("{}_g", &tag_struct_f(&tg_p0.name_p)))
    }
}
