//! The module `Checking`, from `target/bootstrap/src/prismc/checking.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckJob {
    pub read: crate::reading::ReadInput,
    pub world: Array<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckJob {
    fn show(&self, p: &mut Printer) {
        p.record("CheckJob", &[("read", &self.read), ("world", &self.world), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckJob", vec![("read", self.read.to_pod()), ("world", self.world.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckJob { read: FromPod::from_pod(field(p, "read")?)?, world: FromPod::from_pod(field(p, "world")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub fn check_files(job_p0: &CheckJob) -> crate::program::Outcome_ {
    let read_p1 = crate::reading::assemble(&job_p0.read);
    if &len(&read_p1.errors) > &Nat::from(0u32) {
        {
            let report_p2 = crate::reading::tree_report(&job_p0.read, &read_p1.errors);
            crate::program::Outcome_ { text: Text::from(format!("{}\n", &report_p2)), failed: true, report: report_p2.clone() }
        }
    } else {
        {
            let pp_p3 = crate::reading::parse_program(&read_p1);
            if &pp_p3.errors != &Text::lit("") {
                crate::program::Outcome_ { text: Text::from(format!("{}parse errors\n", &pp_p3.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp_p3.errors)) }
            } else {
                {
                    let pre_p4 = crate::reading::tree_decl_diags(&pp_p3);
                    let checked_p5 = each(&pp_p3.trees, &(|t_p9: &crate::syntax::Module| crate::compile::without_tests(t_p9)));
                    let report_p6 = crate::check::check_program(&pp_p3.srcs, &checked_p5, &job_p0.world, &pp_p3.shown, &job_p0.typed, &job_p0.unused, &pre_p4);
                    let summary_p7 = if &report_p6.errors == &Nat::from(0u32) {
                        Text::lit("no errors\n")
                    } else {
                        Text::from(format!("{} error{}\n", &report_p6.errors, &(if &report_p6.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                    };
                    let shown_p8 = if job_p0.typed {
                        Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp(&pp_p3.srcs, &checked_p5, &pp_p3.shown, &report_p6.typed), &commented(&Text::from(format!("{}{}", &report_p6.text, &summary_p7)))))
                    } else {
                        Text::from(format!("{}{}", &report_p6.text, &summary_p7))
                    };
                    crate::program::Outcome_ { text: shown_p8.clone(), failed: &report_p6.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report_p6.text, &summary_p7)) }
                }
            }
        }
    }
}

/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub struct CheckFiles {
    pub job_p0: CheckJob,
}

impl prism_rtl::Job<crate::program::Outcome_> for CheckFiles {
    fn cycle(&self) -> prism_rtl::Turn<crate::program::Outcome_> {
        let job_p0 = &self.job_p0;
        let job_p0 = job_p0.clone();
        call_then(crate::reading::start_assemble(job_p0.read.clone()), move |assemble_1698: crate::reading::Assembled| {
            let read_p1 = assemble_1698;
            if &len(&read_p1.errors) > &Nat::from(0u32) {
                {
                    let report_p2 = crate::reading::tree_report(&job_p0.read, &read_p1.errors);
                    prism_rtl::Turn::Finished(crate::program::Outcome_ { text: Text::from(format!("{}\n", &report_p2)), failed: true, report: report_p2.clone() })
                }
            } else {
                call_then(crate::reading::start_parse_program(read_p1.clone()), move |parse_program_1890: crate::reading::ParsedProgram| {
                    let pp_p3 = parse_program_1890;
                    if &pp_p3.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(crate::program::Outcome_ { text: Text::from(format!("{}parse errors\n", &pp_p3.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp_p3.errors)) })
                    } else {
                        {
                            let pre_p4 = crate::reading::tree_decl_diags(&pp_p3);
                            let checked_p5 = each(&pp_p3.trees, &(|t_p9: &crate::syntax::Module| crate::compile::without_tests(t_p9)));
                            call_then(crate::check::start_check_program(pp_p3.srcs.clone(), checked_p5.clone(), job_p0.world.clone(), pp_p3.shown.clone(), job_p0.typed, job_p0.unused, pre_p4.clone()), move |check_program_2313: crate::check::Report_| {
                                let report_p6 = check_program_2313;
                                let summary_p7 = if &report_p6.errors == &Nat::from(0u32) {
                                    Text::lit("no errors\n")
                                } else {
                                    Text::from(format!("{} error{}\n", &report_p6.errors, &(if &report_p6.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                                };
                                let shown_p8 = if job_p0.typed {
                                    Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp(&pp_p3.srcs, &checked_p5, &pp_p3.shown, &report_p6.typed), &commented(&Text::from(format!("{}{}", &report_p6.text, &summary_p7)))))
                                } else {
                                    Text::from(format!("{}{}", &report_p6.text, &summary_p7))
                                };
                                prism_rtl::Turn::Finished(crate::program::Outcome_ { text: shown_p8.clone(), failed: &report_p6.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report_p6.text, &summary_p7)) })
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
pub fn start_check_files(job_p0: CheckJob) -> Rc<dyn prism_rtl::Job<crate::program::Outcome_>> {
    Rc::new(CheckFiles { job_p0 })
}

/// ```prism
/// Commented: fn Text -> Text
/// ```
pub fn commented(t_p0: &Text) -> Text {
    concat(&each(&filter(&split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| l_p1 != &Text::lit(""))), &(|l_p2: &Text| Text::from(format!("; {}\n", l_p2)))))
}

// `@CheckMain` is inlined where it is applied.

/// ```prism
/// let checkValued
/// ```
pub fn check_valued() -> Array<Text> {
    Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")])
}

// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.
