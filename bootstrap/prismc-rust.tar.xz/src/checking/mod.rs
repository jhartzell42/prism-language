//! The module `Checking`, from `target/bootstrap/src/prismc/checking.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckJob {
    pub read: crate::reading::ReadInput,
    pub world: Array<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckJob {
    fn show(&self, p: &mut Printer) {
        p.record("CheckJob", &[("read", &self.read), ("world", &self.world), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckJob", vec![("read", self.read.to_pod()), ("world", self.world.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckJob { read: FromPod::from_pod(field(p, "read")?)?, world: FromPod::from_pod(field(p, "world")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub fn check_files(job: &CheckJob) -> crate::program::Outcome_ {
    let read = crate::reading::assemble(&job.read);
    if &len(&read.errors) > &Nat::from(0u32) {
        {
            let report = crate::reading::tree_report(&job.read, &read.errors);
            crate::program::Outcome_ { text: Text::from(format!("{}\n", &report)), failed: true, report: report.clone() }
        }
    } else {
        {
            let pp = crate::reading::parse_program(&read);
            if &pp.errors != &Text::lit("") {
                crate::program::Outcome_ { text: Text::from(format!("{}parse errors\n", &pp.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) }
            } else {
                {
                    let pre = crate::reading::tree_decl_diags(&pp);
                    let checked = each(&pp.trees, &(|t: &crate::syntax::Module| crate::compile::without_tests(t)));
                    let report = crate::check::check_program(&pp.srcs, &checked, &job.world, &pp.shown, &job.typed, &job.unused, &pre);
                    let summary = if &report.errors == &Nat::from(0u32) {
                        Text::lit("no errors\n")
                    } else {
                        Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                    };
                    let shown = if job.typed {
                        Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp(&pp.srcs, &checked, &pp.shown, &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
                    } else {
                        Text::from(format!("{}{}", &report.text, &summary))
                    };
                    crate::program::Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) }
                }
            }
        }
    }
}

/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub struct CheckFiles {
    pub job: CheckJob,
}

impl prism_rtl::Job<crate::program::Outcome_> for CheckFiles {
    fn cycle(&self) -> prism_rtl::Turn<crate::program::Outcome_> {
        let job = &self.job;
        let job = job.clone();
        call_then(crate::reading::start_assemble(job.read.clone()), move |assemble_1698: crate::reading::Assembled| {
            let read = assemble_1698;
            if &len(&read.errors) > &Nat::from(0u32) {
                {
                    let report = crate::reading::tree_report(&job.read, &read.errors);
                    prism_rtl::Turn::Finished(crate::program::Outcome_ { text: Text::from(format!("{}\n", &report)), failed: true, report: report.clone() })
                }
            } else {
                call_then(crate::reading::start_parse_program(read.clone()), move |parse_program_1890: crate::reading::ParsedProgram| {
                    let pp = parse_program_1890;
                    if &pp.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(crate::program::Outcome_ { text: Text::from(format!("{}parse errors\n", &pp.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) })
                    } else {
                        {
                            let pre = crate::reading::tree_decl_diags(&pp);
                            let checked = each(&pp.trees, &(|t: &crate::syntax::Module| crate::compile::without_tests(t)));
                            call_then(crate::check::start_check_program(pp.srcs.clone(), checked.clone(), job.world.clone(), pp.shown.clone(), job.typed, job.unused, pre.clone()), move |check_program_2311: crate::check::Report_| {
                                let report = check_program_2311;
                                let summary = if &report.errors == &Nat::from(0u32) {
                                    Text::lit("no errors\n")
                                } else {
                                    Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                                };
                                let shown = if job.typed {
                                    Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp(&pp.srcs, &checked, &pp.shown, &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
                                } else {
                                    Text::from(format!("{}{}", &report.text, &summary))
                                };
                                prism_rtl::Turn::Finished(crate::program::Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) })
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
pub fn start_check_files(job: CheckJob) -> Rc<dyn prism_rtl::Job<crate::program::Outcome_>> {
    Rc::new(CheckFiles { job })
}

/// ```prism
/// Commented: fn Text -> Text
/// ```
pub fn commented(t: &Text) -> Text {
    concat(&each(&filter(&split(t, &Text::lit("\n")), &(|l: &Text| l != &Text::lit(""))), &(|l: &Text| Text::from(format!("; {}\n", l)))))
}

// `@CheckMain` is inlined where it is applied.

/// ```prism
/// let checkValued
/// ```
pub fn check_valued() -> Array<Text> {
    Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")])
}

// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.
