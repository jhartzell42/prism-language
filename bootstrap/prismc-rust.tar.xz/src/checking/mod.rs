//! The module `Checking`, from `target/bootstrap/src/prismc/checking.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckJob {
    pub read_p: crate::reading::ReadInput,
    pub world_p: Array<Text>,
    pub typed_p: bool,
    pub unused_p: bool,
}

impl Show for CheckJob {
    fn show(&self, p: &mut Printer) {
        p.record("CheckJob", &[("read", &self.read_p), ("world", &self.world_p), ("typed", &self.typed_p), ("unused", &self.unused_p)]);
    }
}

impl ToPod for CheckJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckJob", vec![("read", self.read_p.to_pod()), ("world", self.world_p.to_pod()), ("typed", self.typed_p.to_pod()), ("unused", self.unused_p.to_pod())])
    }
}

impl FromPod for CheckJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckJob { read_p: FromPod::from_pod(field(p, "read")?)?, world_p: FromPod::from_pod(field(p, "world")?)?, typed_p: FromPod::from_pod(field(p, "typed")?)?, unused_p: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub fn check_files_f(job_p0: &CheckJob) -> crate::program::Outcome_ {
    let read_p1 = crate::reading::assemble_f(&job_p0.read_p);
    if &crate::prelude::len(&read_p1.errors_p) > &Nat::from(0u32) {
        {
            let report_p2 = crate::reading::tree_report_f(&job_p0.read_p, &read_p1.errors_p);
            crate::program::Outcome_ { text_p: Text::from(format!("{}\n", &report_p2)), failed_p: true, report_p: report_p2.clone() }
        }
    } else {
        {
            let pp_p3 = crate::reading::parse_program_f(&read_p1);
            if &pp_p3.errors_p != &Text::lit("") {
                crate::program::Outcome_ { text_p: Text::from(format!("{}parse errors\n", &pp_p3.errors_p)), failed_p: true, report_p: Text::from(format!("{}parse errors", &pp_p3.errors_p)) }
            } else {
                {
                    let pre_p4 = crate::reading::tree_decl_diags_f(&pp_p3);
                    let checked_p5 = crate::prelude::each(&pp_p3.trees_p, &(|t_p9: &crate::syntax::Module| crate::compile::without_tests_f(t_p9)));
                    let report_p6 = crate::check::check_program_f(&pp_p3.srcs_p, &checked_p5, &job_p0.world_p, &pp_p3.shown_p, &job_p0.typed_p, &job_p0.unused_p, &pre_p4);
                    let summary_p7 = if &report_p6.errors_p == &Nat::from(0u32) {
                        Text::lit("no errors\n")
                    } else {
                        Text::from(format!("{} error{}\n", &report_p6.errors_p, &(if &report_p6.errors_p == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                    };
                    let shown_p8 = if job_p0.typed_p {
                        Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp_f(&pp_p3.srcs_p, &checked_p5, &pp_p3.shown_p, &report_p6.typed_p), &commented_f(&Text::from(format!("{}{}", &report_p6.text_p, &summary_p7)))))
                    } else {
                        Text::from(format!("{}{}", &report_p6.text_p, &summary_p7))
                    };
                    crate::program::Outcome_ { text_p: shown_p8.clone(), failed_p: &report_p6.errors_p > &Nat::from(0u32), report_p: Text::from(format!("{}{}", &report_p6.text_p, &summary_p7)) }
                }
            }
        }
    }
}

/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub struct CheckFiles {
    pub job_p0: CheckJob,
}

impl prism_rtl::Job<crate::program::Outcome_> for CheckFiles {
    fn cycle(&self) -> prism_rtl::Turn<crate::program::Outcome_> {
        let job_p0 = &self.job_p0;
        let job_p0x = job_p0.clone();
        crate::prelude::call_then(crate::reading::start_assemble_f(job_p0x.read_p.clone()), move |assemble_f_1698: crate::reading::Assembled| {
            let read_p1 = assemble_f_1698;
            if &crate::prelude::len(&read_p1.errors_p) > &Nat::from(0u32) {
                {
                    let report_p2 = crate::reading::tree_report_f(&job_p0x.read_p, &read_p1.errors_p);
                    prism_rtl::Turn::Finished(crate::program::Outcome_ { text_p: Text::from(format!("{}\n", &report_p2)), failed_p: true, report_p: report_p2.clone() })
                }
            } else {
                crate::prelude::call_then(crate::reading::start_parse_program_f(read_p1.clone()), move |parse_program_f_1890: crate::reading::ParsedProgram| {
                    let pp_p3 = parse_program_f_1890;
                    if &pp_p3.errors_p != &Text::lit("") {
                        prism_rtl::Turn::Finished(crate::program::Outcome_ { text_p: Text::from(format!("{}parse errors\n", &pp_p3.errors_p)), failed_p: true, report_p: Text::from(format!("{}parse errors", &pp_p3.errors_p)) })
                    } else {
                        {
                            let pre_p4 = crate::reading::tree_decl_diags_f(&pp_p3);
                            let checked_p5 = crate::prelude::each(&pp_p3.trees_p, &(|t_p9: &crate::syntax::Module| crate::compile::without_tests_f(t_p9)));
                            crate::prelude::call_then(crate::check::start_check_program_f(pp_p3.srcs_p.clone(), checked_p5.clone(), job_p0x.world_p.clone(), pp_p3.shown_p.clone(), job_p0x.typed_p, job_p0x.unused_p, pre_p4.clone()), move |check_program_f_2313: crate::check::Report_| {
                                let report_p6 = check_program_f_2313;
                                let summary_p7 = if &report_p6.errors_p == &Nat::from(0u32) {
                                    Text::lit("no errors\n")
                                } else {
                                    Text::from(format!("{} error{}\n", &report_p6.errors_p, &(if &report_p6.errors_p == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                                };
                                let shown_p8 = if job_p0x.typed_p {
                                    Text::from(format!("{}{}", &crate::check::typed::print::typed_sexp_f(&pp_p3.srcs_p, &checked_p5, &pp_p3.shown_p, &report_p6.typed_p), &commented_f(&Text::from(format!("{}{}", &report_p6.text_p, &summary_p7)))))
                                } else {
                                    Text::from(format!("{}{}", &report_p6.text_p, &summary_p7))
                                };
                                prism_rtl::Turn::Finished(crate::program::Outcome_ { text_p: shown_p8.clone(), failed_p: &report_p6.errors_p > &Nat::from(0u32), report_p: Text::from(format!("{}{}", &report_p6.text_p, &summary_p7)) })
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
pub fn start_check_files_f(job_p0: CheckJob) -> Rc<dyn prism_rtl::Job<crate::program::Outcome_>> {
    Rc::new(CheckFiles { job_p0 })
}

/// ```prism
/// Commented: fn Text -> Text
/// ```
pub fn commented_f(t_p0: &Text) -> Text {
    crate::prelude::concat(&crate::prelude::each(&crate::prelude::filter(&crate::prelude::split_on(t_p0, &Text::lit("\n")), &(|l_p1: &Text| l_p1 != &Text::lit(""))), &(|l_p2: &Text| Text::from(format!("; {}\n", l_p2)))))
}

// `@CheckMain` is inlined where it is applied.

/// ```prism
/// let checkValued
/// ```
pub fn check_valued_p() -> Array<Text> {
    Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")])
}

// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.
