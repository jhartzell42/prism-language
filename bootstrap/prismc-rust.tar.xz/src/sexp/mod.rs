//! The module `Sexp`, from `target/bootstrap/src/prismc/sexp.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// Nl: fn Nat -> Text
/// ```
pub fn nl(d: &Nat) -> Text {
    Text::from(format!("\n{}", &indent(d)))
}

/// ```prism
/// Indent: fn Nat -> Text
/// ```
pub fn indent(d: &Nat) -> Text {
    match d.checked_sub(&Nat::from(1u32)) {
        Some(m) => Text::from(format!("  {}", &indent(&m))),
        None => Text::lit(""),
    }
}

/// ```prism
/// Spaced: fn [a], (fn a -> Text) -> Text
/// ```
pub fn spaced<A: Clone + 'static>(xs: &Array<A>, f_fn: &Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>) -> Text {
    concat(&run_to_end(each_job(xs.clone(), {
        let f_fn = f_fn.clone();
        Rc::new(move |p0: A| {
            let f_fn = f_fn.clone();
            entered(once_job(move || {
                let x = p0;
                call_value((&f_fn)(x.clone()), move |f_1096: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &f_1096))))
            }))
        }) as Rc<dyn Fn(A) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// Path: fn [Text] -> Text
/// ```
pub fn path_(p_: &Array<Text>) -> Text {
    crate::lexer::join(p_, &Text::lit("."))
}

/// ```prism
/// SNameText: fn SName -> Text
/// ```
pub fn sname_text(n: &crate::ast::SName) -> Text {
    Text::from(format!("{}{}", &n.sigils, &path_(&n.path_)))
}

/// ```prism
/// SexpModule: fn Module -> Text
/// ```
pub fn sexp_module(m: &crate::ast::Module) -> Text {
    let name = match &m.name {
        Some(n) => Text::from(format!("{}(name {})", &nl(&Nat::from(1u32)), &path_(&n.path_))),
        None => Text::lit(""),
    };
    let emits = match &m.emit_row {
        Some(r) => Text::from(format!("{}(emit {})", &nl(&Nat::from(1u32)), &sexp_row(r))),
        None => Text::lit(""),
    };
    let mods = concat(&each(&m.mods, &(|l: &crate::ast::ModLine| Text::from(format!("{}({} {})", &nl(&Nat::from(1u32)), &(if l.is_test { Text::lit("test-mod") } else { Text::lit("mod") }), &l.name.name)))));
    let uses = concat(&each(&m.uses, &(|u: &crate::ast::Use| Text::from(format!("{}(use {}{})", &nl(&Nat::from(1u32)), &path_(&u.target.path_), &(if u.star { Text::lit(".*") } else { Text::lit("") }))))));
    let template = match &m.template {
        Some(t) => Text::from(format!("{}{}", &nl(&Nat::from(1u32)), &sexp_template(t, &Nat::from(1u32)))),
        None => Text::lit(""),
    };
    let decls = concat(&each(&m.decls, &(|d: &crate::ast::Decl| Text::from(format!("{}{}", &nl(&Nat::from(1u32)), &sexp_decl(d, &Nat::from(1u32)))))));
    Text::from(format!("(module{}{}{}{}{}{})\n", &name, &emits, &mods, &uses, &template, &decls))
}

/// ```prism
/// SexpRow: fn Row -> Text
/// ```
pub fn sexp_row(r: &crate::ast::Row_) -> Text {
    Text::from(format!("(row{})", &spaced(&r.terms, &{
        let f = Rc::new(sexp_row_term);
        Rc::new(move |a0: crate::ast::RowTerm| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(crate::ast::RowTerm) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// ```prism
/// SexpRowTerm: fn RowTerm -> Text
/// ```
pub fn sexp_row_term(row_term0: &crate::ast::RowTerm) -> Text {
    match row_term0 {
        crate::ast::RowTerm::RFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
        crate::ast::RowTerm::RVar(v_) => Text::from(format!("(var {})", &v_.name)),
        crate::ast::RowTerm::RType(t) => sexp_type(t),
    }
}

/// ```prism
/// SexpDecl: fn Decl, Nat -> Text
/// ```
pub fn sexp_decl(d: &crate::ast::Decl, depth: &Nat) -> Text {
    match &d.kind {
        crate::ast::DeclKind::DSignature(s) => sexp_signature(s),
        crate::ast::DeclKind::DFn(f) => sexp_fn(f, depth),
        crate::ast::DeclKind::DLet(l) => Text::from(format!("(let {}{} {})", &sexp_pattern(&l.pattern, depth), &opt_type(&l.ty), &sexp_expr(&l.value, depth))),
        crate::ast::DeclKind::DWidget(w) => Text::from(format!("(widget {}{})", &sname_text(&w.name), &sexp_block(&w.body, depth))),
        crate::ast::DeclKind::DType(t) => Text::from(format!("(type {}{}{})", &path_(&t.name.path_), &concat(&each(&t.params, &(|p_: &crate::ast::Ident| Text::from(format!(" {}", &p_.name))))), &sexp_type_body(&t.body, depth))),
        crate::ast::DeclKind::DTag(t) => Text::from(format!("(tag {} {}{}{})", &path_(&t.name.path_), &sexp_type(&t.of_type), &sexp_bounds(&t.bounds), &sexp_fields(&t.fields, depth))),
        crate::ast::DeclKind::DDerive(ts) => Text::from(format!("(derive{})", &concat(&each(ts, &(|t: &crate::ast::TraitRef| Text::from(format!(" ^{}", &path_(&t.path_)))))))),
        crate::ast::DeclKind::DTrait(t) => Text::from(format!("(trait ^{}{}{}{})", &path_(&t.name.path_), &concat(&each(&t.params, &(|p_: &crate::ast::Ident| Text::from(format!(" {}", &p_.name))))), &sexp_bounds(&t.bounds), &sexp_items(&t.items, depth))),
        crate::ast::DeclKind::DImpl(i) => Text::from(format!("(impl ^{} {}{}{})", &path_(&i.trait_ref.path_), &sexp_type(&i.ty), &sexp_bounds(&i.bounds), &sexp_items(&i.items, depth))),
        crate::ast::DeclKind::DCheck(c) => Text::from(format!("(check {}{})", &c.name.name, &concat(&each(&c.lines, &(|l: &crate::ast::CheckLine| Text::from(format!("{}(line {}{})", &nl(&(depth + &Nat::from(1u32))), &sexp_expr(&l.expr, &(depth + &Nat::from(1u32))), &check_pattern(&l.pattern, &(depth + &Nat::from(1u32)))))))))),
        crate::ast::DeclKind::DTest(t) => sexp_test(t, depth),
        crate::ast::DeclKind::DStmt(s) => sexp_stmt(s, depth),
    }
}

/// ```prism
/// OptType: fn ?Type -> Text
/// ```
pub fn opt_type(opt0: &Option<crate::ast::Type>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(t) => Text::from(format!(" {}", &sexp_type(t))),
    }
}

/// ```prism
/// CheckPattern: fn ?Pattern, Nat -> Text
/// ```
pub fn check_pattern(opt0: &Option<crate::ast::Pattern_>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(p_), d) => Text::from(format!(" => {}", &sexp_pattern(p_, d))),
    }
}

/// ```prism
/// SexpTypeBody: fn ?TypeBody, Nat -> Text
/// ```
pub fn sexp_type_body(opt0: &Option<crate::ast::TypeBody>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" opaque"),
        (Some(b), depth) => match b {
            crate::ast::TypeBody::TbRecord(fs) => Text::from(format!(" record{}", &sexp_fields(fs, depth))),
            crate::ast::TypeBody::TbChoice(cs) => Text::from(format!(" choice{}", &concat(&each(cs, &(|c: &crate::ast::Case_| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_case(c)))))))),
            crate::ast::TypeBody::TbRow => Text::lit(" row"),
            crate::ast::TypeBody::TbNewtype(c) => Text::from(format!(" newtype {}", &sexp_case(c))),
            crate::ast::TypeBody::TbUnit(i) => Text::from(format!(" unit {}", &i.name)),
            crate::ast::TypeBody::TbAlias(t) => Text::from(format!(" alias {}", &sexp_type(t))),
        },
    }
}

/// ```prism
/// SexpSignature: fn Signature -> Text
/// ```
pub fn sexp_signature(s: &crate::ast::Signature) -> Text {
    Text::from(format!("(sig {} {}{})", &sexp_def_name(&s.name), &sexp_type(&s.ty), &sexp_bounds(&s.bounds)))
}

/// ```prism
/// SexpDefName: fn DefName -> Text
/// ```
pub fn sexp_def_name(def_name0: &crate::ast::DefName) -> Text {
    match def_name0 {
        crate::ast::DefName::DefSName(n) => sname_text(n),
        crate::ast::DefName::DefOp(o, _) => Text::from(format!("(op {})", o)),
    }
}

/// ```prism
/// SexpBounds: fn [Bound] -> Text
/// ```
pub fn sexp_bounds(bs: &Array<crate::ast::Bound>) -> Text {
    concat(&each(bs, &(|b: &crate::ast::Bound| Text::from(format!(" (where {}{})", &b.var.name, &concat(&each(&b.traits, &(|t: &crate::ast::TraitRef| Text::from(format!(" ^{}", &path_(&t.path_)))))))))))
}

/// ```prism
/// SexpFn: fn FnClause, Nat -> Text
/// ```
pub fn sexp_fn(f: &crate::ast::FnClause, depth: &Nat) -> Text {
    let body = match &f.body {
        crate::ast::FnBody::BodyExpr(e) => Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_expr(e, &(depth + &Nat::from(1u32))))),
        crate::ast::FnBody::BodyBlock(b) => sexp_block(b, depth),
    };
    Text::from(format!("(fn {} (params{}){})", &sexp_def_name(&f.name), &concat(&each(&f.params, &(|p_: &crate::ast::Pattern_| Text::from(format!(" {}", &sexp_pattern(p_, depth)))))), &body))
}

/// ```prism
/// SexpFields: fn [Field], Nat -> Text
/// ```
pub fn sexp_fields(fs: &Array<crate::ast::Field>, depth: &Nat) -> Text {
    concat(&each(fs, &(|f: &crate::ast::Field| Text::from(format!("{}(field {} {})", &nl(&(depth + &Nat::from(1u32))), &f.name.name, &sexp_type(&f.ty))))))
}

/// ```prism
/// SexpCase: fn Case -> Text
/// ```
pub fn sexp_case(c: &crate::ast::Case_) -> Text {
    let indexed = match &c.indexed {
        Some(r) => Text::from(format!(" -> {}", &sexp_type(r))),
        None => Text::lit(""),
    };
    Text::from(format!("(case {}{}{})", &sname_text(&c.name), &spaced(&c.args, &{
        let f = Rc::new(sexp_type);
        Rc::new(move |a0: crate::ast::Type| {
            let f = f.clone();
            once_job(move || prism_rtl::Turn::Finished(f(&a0)))
        }) as Rc<dyn Fn(crate::ast::Type) -> Rc<dyn prism_rtl::Job<Text>>>
    }), &indexed))
}

/// ```prism
/// SexpItems: fn [TraitItem], Nat -> Text
/// ```
pub fn sexp_items(items: &Array<crate::ast::TraitItem>, depth: &Nat) -> Text {
    concat(&each(items, &(|it: &crate::ast::TraitItem| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_item(it, &(depth + &Nat::from(1u32))))))))
}

/// ```prism
/// SexpItem: fn TraitItem, Nat -> Text
/// ```
pub fn sexp_item(trait_item0: &crate::ast::TraitItem, n1: &Nat) -> Text {
    match (trait_item0, n1) {
        (crate::ast::TraitItem::TiSignature(s), _) => sexp_signature(s),
        (crate::ast::TraitItem::TiFn(f), d) => sexp_fn(f, d),
        (crate::ast::TraitItem::TiAssocType(name, params, value_opt, _), _) => Text::from(format!("(assoc-type {}{}{})", &name.name, &concat(&each(params, &(|p_: &crate::ast::Ident| Text::from(format!(" {}", &p_.name))))), &opt_type(value_opt))),
        (crate::ast::TraitItem::TiAssocRow(name, _), _) => Text::from(format!("(assoc-row {})", &sname_text(name))),
    }
}

/// ```prism
/// SexpTest: fn TestDecl, Nat -> Text
/// ```
pub fn sexp_test(t: &crate::ast::TestDecl, depth: &Nat) -> Text {
    let seed = match &t.seed {
        Some(s) => Text::from(format!(" (seed {})", s)),
        None => Text::lit(""),
    };
    Text::from(format!("(test {} {}{}{})", &t.name.name, &sexp_expr(&t.blueprint, depth), &seed, &concat(&each(&t.steps, &(|s: &crate::ast::TestStep| Text::from(format!("{}{}", &nl(&(depth + &Nat::from(1u32))), &sexp_step(s, &(depth + &Nat::from(1u32))))))))))
}

/// ```prism
/// SexpStep: fn TestStep, Nat -> Text
/// ```
pub fn sexp_step(s: &crate::ast::TestStep, d: &Nat) -> Text {
    let withs = concat(&each(&s.withs, &(|w: &crate::ast::Entry| Text::from(format!(" (with {} {})", &sexp_expr(&w.element, d), &sexp_expr(&w.value, d))))));
    let checks = concat(&each(&s.checks, &(|c: &crate::ast::TestCheck| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_check(c, &(d + &Nat::from(1u32))))))));
    Text::from(format!("(step{} {}{})", &withs, &sexp_action(&s.action, d), &checks))
}

/// ```prism
/// SexpAction: fn StepAction, Nat -> Text
/// ```
pub fn sexp_action(step_action0: &crate::ast::StepAction, n1: &Nat) -> Text {
    match (step_action0, n1) {
        (crate::ast::StepAction::SaBuild, _) => Text::lit("build"),
        (crate::ast::StepAction::SaTick, _) => Text::lit("tick"),
        (crate::ast::StepAction::SaCompute(true), _) => Text::lit("compute-until-idle"),
        (crate::ast::StepAction::SaCompute(false), _) => Text::lit("compute"),
        (crate::ast::StepAction::SaWithOnly, _) => Text::lit("with-only"),
        (crate::ast::StepAction::SaPush(e), d) => Text::from(format!("(push {} {})", &sexp_expr(&e.element, d), &sexp_expr(&e.value, d))),
        (crate::ast::StepAction::SaDeliver(ds), d) => crate::lexer::join(&each(ds, &(|x: &crate::ast::Delivery| sexp_delivery(x, d))), &Text::lit(" ")),
    }
}

/// ```prism
/// SexpDelivery: fn Delivery, Nat -> Text
/// ```
pub fn sexp_delivery(x: &crate::ast::Delivery, d: &Nat) -> Text {
    let word = match &x.kind {
        crate::ast::DeliveryKind::DkSend(_) => Text::lit("send"),
        crate::ast::DeliveryKind::DkClick => Text::lit("click"),
        crate::ast::DeliveryKind::DkAnswer => Text::lit("answer"),
    };
    let value = match &x.kind {
        crate::ast::DeliveryKind::DkSend(v_) => Text::from(format!(" {}", &sexp_expr(v_, d))),
        _ => Text::lit(""),
    };
    Text::from(format!("({} {}{})", &word, &sexp_target(&x.target, d), &value))
}

/// ```prism
/// SexpTarget: fn Target, Nat -> Text
/// ```
pub fn sexp_target(target0: &crate::ast::Target, d: &Nat) -> Text {
    match target0 {
        crate::ast::Target::TgPattern(p_) => sexp_pattern(p_, d),
        crate::ast::Target::TgPath(p_) => sexp_path(&Text::lit("at"), p_, d),
        crate::ast::Target::TgElement(p_) => sexp_path(&Text::lit("element"), p_, d),
    }
}

/// ```prism
/// SexpPath: fn Text, TestPath, Nat -> Text
/// ```
pub fn sexp_path(word: &Text, p_: &crate::ast::TestPath, d: &Nat) -> Text {
    Text::from(format!("({}{})", word, &concat(&each(&p_.segments, &(|s: &crate::ast::PathSeg| sexp_path_seg(s, d))))))
}

/// ```prism
/// SexpPathSeg: fn PathSeg, Nat -> Text
/// ```
pub fn sexp_path_seg(path_seg0: &crate::ast::PathSeg, n1: &Nat) -> Text {
    match (path_seg0, n1) {
        (crate::ast::PathSeg::PsNum(n), _) => Text::from(format!(" {}", n)),
        (crate::ast::PathSeg::PsGen(n), _) => Text::from(format!(" #{}", n)),
        (crate::ast::PathSeg::PsKey(e), d) => Text::from(format!(" [{}]", &sexp_expr(e, d))),
    }
}

/// ```prism
/// SexpCheck: fn TestCheck, Nat -> Text
/// ```
pub fn sexp_check(c: &crate::ast::TestCheck, d: &Nat) -> Text {
    match &c.kind {
        crate::ast::TestCheckKind::CkExpect(p_) => Text::from(format!("(=> expect {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkExpectNone(p_) => Text::from(format!("(=> expect_none {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkExpectCount(p_, n) => Text::from(format!("(=> expect_count {} {})", &sexp_pattern(p_, d), n)),
        crate::ast::TestCheckKind::CkExpectTop(p_) => Text::from(format!("(=> expect_top {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkExpectTopNone(p_) => Text::from(format!("(=> expect_top_none {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkRequested(p_, v_) => Text::from(format!("(=> requested {} {})", &sexp_pattern(p_, d), &sexp_pattern(v_, d))),
        crate::ast::TestCheckKind::CkUnrequested(p_) => Text::from(format!("(=> unrequested {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkReturns(p_) => Text::from(format!("(=> returns {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkFired(p_) => Text::from(format!("(=> fired {})", &sexp_pattern(p_, d))),
        crate::ast::TestCheckKind::CkQuiet => Text::lit("(=> quiet)"),
        crate::ast::TestCheckKind::CkSettles => Text::lit("(=> settles)"),
        crate::ast::TestCheckKind::CkAborted => Text::lit("(=> aborted)"),
        crate::ast::TestCheckKind::CkSnapshot(s) => Text::from(format!("(=> snapshot {})", &crate::lexer::debug_text(s))),
    }
}

/// ```prism
/// SexpBlock: fn Block, Nat -> Text
/// ```
pub fn sexp_block(b: &crate::ast::Block, d: &Nat) -> Text {
    if b.inline {
        Text::from(format!(" (inline{})", &concat(&each(&b.stmts, &(|s: &crate::ast::Stmt| Text::from(format!(" {}", &sexp_stmt(s, d))))))))
    } else {
        concat(&each(&b.stmts, &(|s: &crate::ast::Stmt| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_stmt(s, &(d + &Nat::from(1u32))))))))
    }
}

/// ```prism
/// SexpStmt: fn Stmt, Nat -> Text
/// ```
pub fn sexp_stmt(s: &crate::ast::Stmt, d: &Nat) -> Text {
    match &s.kind {
        crate::ast::StmtKind::SEmit(r) => Text::from(format!("(emit {})", &sexp_row(r))),
        crate::ast::StmtKind::SBind(p_, v_, None) => Text::from(format!("(bind {} {})", &sexp_pattern(p_, d), &sexp_expr(v_, d))),
        crate::ast::StmtKind::SBind(p_, v_, Some(t)) => Text::from(format!("(hold {} {} then {})", &sexp_pattern(p_, d), &sexp_expr(v_, d), &sexp_expr(t, d))),
        crate::ast::StmtKind::SIgnore(e) => Text::from(format!("(ignore {})", &sexp_expr(e, d))),
        crate::ast::StmtKind::SLet(p_, ty_opt, v_) => Text::from(format!("(let {}{} {})", &sexp_pattern(p_, d), &opt_type(ty_opt), &sexp_expr(v_, d))),
        crate::ast::StmtKind::SSignature(sg) => sexp_signature(sg),
        crate::ast::StmtKind::SFn(f) => sexp_fn(f, d),
        crate::ast::StmtKind::SWidget(w) => Text::from(format!("(widget {}{})", &sname_text(&w.name), &sexp_block(&w.body, d))),
        crate::ast::StmtKind::SSet(t, v_) => Text::from(format!("(set {} {})", &sexp_expr(t, d), &sexp_expr(v_, d))),
        crate::ast::StmtKind::SAccum(t, op, v_) => Text::from(format!("({} {} {})", op, &sexp_expr(t, d), &sexp_expr(v_, d))),
        crate::ast::StmtKind::SRequire(c) => Text::from(format!("(require {})", &sexp_expr(c, d))),
        crate::ast::StmtKind::SForbid(c) => Text::from(format!("(forbid {})", &sexp_expr(c, d))),
        crate::ast::StmtKind::SWhile(c, body) => Text::from(format!("(while {}{})", &sexp_cond(c, d), &sexp_block(body, d))),
        crate::ast::StmtKind::SReturn(e) => Text::from(format!("(return {})", &sexp_expr(e, d))),
        crate::ast::StmtKind::SExpr(e) => sexp_expr(e, d),
    }
}

/// ```prism
/// SexpCond: fn Cond, Nat -> Text
/// ```
pub fn sexp_cond(cond0: &crate::ast::Cond, d: &Nat) -> Text {
    match cond0 {
        crate::ast::Cond::CondExpr(e) => sexp_expr(&**e, d),
        crate::ast::Cond::CondBind(p_, v_, g_opt) => Text::from(format!("(<- {} {}{})", &sexp_pattern(p_, d), &sexp_expr(&**v_, d), &sexp_guard(&**g_opt, d))),
    }
}

/// ```prism
/// SexpGuard: fn ?Expr, Nat -> Text
/// ```
pub fn sexp_guard(opt0: &Option<crate::ast::Expr>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(g), d) => Text::from(format!(" (if {})", &sexp_expr(g, d))),
    }
}

/// ```prism
/// SexpLiteral: fn Literal, Nat -> Text
/// ```
pub fn sexp_literal(l: &crate::ast::Literal, d: &Nat) -> Text {
    match &l.kind {
        crate::ast::LitKind::LInt(s) => Text::from(format!("{}{}", &l.marks, s)),
        crate::ast::LitKind::LFloat(s) => Text::from(format!("{}{}", &l.marks, s)),
        crate::ast::LitKind::LDuration(digits, u) => Text::from(format!("{}{}{}", &l.marks, digits, u)),
        crate::ast::LitKind::LChar(c) => Text::from(format!("{}{}", &l.marks, &crate::lexer::debug_char(c))),
        crate::ast::LitKind::LText(segs) => if all_plain_segs(segs) {
            Text::from(format!("{}{}", &l.marks, &crate::lexer::debug_text(&concat(&each(segs, &plain_seg_text)))))
        } else {
            Text::from(format!("({}text{})", &l.marks, &concat(&each(segs, &(|s: &crate::ast::TextSeg| Text::from(format!(" {}", &sexp_seg(s, d))))))))
        },
    }
}

/// ```prism
/// AllPlainSegs: fn [TextSeg] -> Bool
/// ```
pub fn all_plain_segs(segs: &Array<crate::ast::TextSeg>) -> bool {
    fold(segs, &true, &(|ok: &bool, s: &crate::ast::TextSeg| *ok && is_plain_text_seg(s)))
}

/// ```prism
/// IsPlainTextSeg: fn TextSeg -> Bool
/// ```
pub fn is_plain_text_seg(text_seg0: &crate::ast::TextSeg) -> bool {
    match text_seg0 {
        crate::ast::TextSeg::SegPlain(_) => true,
        _ => false,
    }
}

/// ```prism
/// PlainSegText: fn TextSeg -> Text
/// ```
pub fn plain_seg_text(text_seg0: &crate::ast::TextSeg) -> Text {
    match text_seg0 {
        crate::ast::TextSeg::SegPlain(s) => s.clone(),
        _ => Text::lit(""),
    }
}

/// ```prism
/// SexpSeg: fn TextSeg, Nat -> Text
/// ```
pub fn sexp_seg(text_seg0: &crate::ast::TextSeg, n1: &Nat) -> Text {
    match (text_seg0, n1) {
        (crate::ast::TextSeg::SegPlain(p_), _) => crate::lexer::debug_text(p_),
        (crate::ast::TextSeg::SegPlaceholder(e), d) => Text::from(format!("{{{}}}", &sexp_expr(e, d))),
    }
}

/// ```prism
/// SexpArgs: fn [Arg], Nat -> Text
/// ```
pub fn sexp_args(args: &Array<crate::ast::Arg>, d: &Nat) -> Text {
    concat(&each(args, &(|a: &crate::ast::Arg| Text::from(format!(" {}{}", &arg_name(&a.name), &sexp_expr(&a.value, d))))))
}

/// ```prism
/// ArgName: fn ?Ident -> Text
/// ```
pub fn arg_name(opt0: &Option<crate::ast::Ident>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(n) => Text::from(format!("{}=", &n.name)),
    }
}

/// ```prism
/// SexpExprs: fn [Expr], Nat -> Text
/// ```
pub fn sexp_exprs(es: &Array<crate::ast::Expr>, d: &Nat) -> Text {
    concat(&each(es, &(|x: &crate::ast::Expr| Text::from(format!(" {}", &sexp_expr(x, d))))))
}

/// ```prism
/// SexpExpr: fn Expr, Nat -> Text
/// ```
pub fn sexp_expr(e: &crate::ast::Expr, d: &Nat) -> Text {
    match &*e.kind {
        crate::ast::ExprKind::EName(n) => sname_text(n),
        crate::ast::ExprKind::ELit(l) => sexp_literal(l, d),
        crate::ast::ExprKind::EUnit(s) => Text::from(format!("{}unit", s)),
        crate::ast::ExprKind::ENil(s) => Text::from(format!("{}nil", s)),
        crate::ast::ExprKind::EBound(b) => b.clone(),
        crate::ast::ExprKind::ETuple(es) => Text::from(format!("(tuple{})", &sexp_exprs(es, d))),
        crate::ast::ExprKind::EArray(es) => Text::from(format!("(array{})", &sexp_exprs(es, d))),
        crate::ast::ExprKind::EMap(es) => Text::from(format!("(map{})", &concat(&each(es, &(|(k, v_): &(crate::ast::Expr, crate::ast::Expr)| Text::from(format!(" ({}: {})", &sexp_expr(k, d), &sexp_expr(v_, d)))))))),
        crate::ast::ExprKind::EGroup(x) => Text::from(format!("(group {})", &sexp_expr(&**x, d))),
        crate::ast::ExprKind::ECall(callee, args, parens, rest) => Text::from(format!("({} {}{}{})", &(if *parens { Text::lit("call()") } else { Text::lit("call") }), &sexp_expr(&**callee, d), &sexp_args(args, d), &(if *rest { Text::lit(" ..") } else { Text::lit("") }))),
        crate::ast::ExprKind::EBinary(op, lhs, rhs) => Text::from(format!("({} {} {})", op, &sexp_expr(&**lhs, d), &sexp_expr(&**rhs, d))),
        crate::ast::ExprKind::ESuffixed(op, ty, lhs, rhs) => Text::from(format!("({}{} {} {})", op, &path_(&ty.path_), &sexp_expr(&**lhs, d), &sexp_expr(&**rhs, d))),
        crate::ast::ExprKind::EUnary(op, operand) => Text::from(format!("({} {})", op, &sexp_expr(&**operand, d))),
        crate::ast::ExprKind::EFreeSigil(s, operand) => Text::from(format!("(free{} {})", s, &sexp_expr(&**operand, d))),
        crate::ast::ExprKind::EField(recv, sigils, name) => Text::from(format!("(. {} {}{})", &sexp_expr(&**recv, d), sigils, &name.name)),
        crate::ast::ExprKind::EIndex(recv, index) => Text::from(format!("(index {} {})", &sexp_expr(&**recv, d), &sexp_expr(&**index, d))),
        crate::ast::ExprKind::ETopicField(n) => Text::from(format!("(. _ {})", &n.name)),
        crate::ast::ExprKind::ETopicIndex(i) => Text::from(format!("(index _ {})", &sexp_expr(&**i, d))),
        crate::ast::ExprKind::EMethod(recv, method, args) => Text::from(format!("(.{} {}{})", &sname_text(method), &sexp_expr(&**recv, d), &sexp_args(args, d))),
        crate::ast::ExprKind::ETypeArgs(target, types) => Text::from(format!("(<<>> {}{})", &sexp_expr(&**target, d), &spaced(types, &{
            let f = Rc::new(sexp_type);
            Rc::new(move |a0: crate::ast::Type| {
                let f = f.clone();
                once_job(move || prism_rtl::Turn::Finished(f(&a0)))
            }) as Rc<dyn Fn(crate::ast::Type) -> Rc<dyn prism_rtl::Job<Text>>>
        }))),
        crate::ast::ExprKind::ECast(x, ty, checked) => Text::from(format!("({} {} {})", &(if *checked { Text::lit("as?") } else { Text::lit("as") }), &sexp_expr(&**x, d), &sexp_type(ty))),
        crate::ast::ExprKind::ENonEmpty(x) => Text::from(format!("(nonempty {})", &sexp_expr(&**x, d))),
        crate::ast::ExprKind::EAbsent => Text::lit("absent"),
        crate::ast::ExprKind::ERest => Text::lit(".."),
        crate::ast::ExprKind::ELambda(params_opt, body) => Text::from(format!("(lambda{}{})", &sexp_lambda_params(params_opt, d), &sexp_lambda_body(&**body, d))),
        crate::ast::ExprKind::EIf(c, then_block, else_block_opt) => Text::from(format!("(if {}{}{})", &sexp_cond(&**c, d), &sexp_block(then_block, d), &sexp_else(else_block_opt, d))),
        crate::ast::ExprKind::EMatch(scrutinee, arms) => Text::from(format!("(match {}{})", &sexp_expr(&**scrutinee, d), &concat(&each(arms, &(|a: &crate::ast::Arm| Text::from(format!("{}{}", &nl(&(d + &Nat::from(1u32))), &sexp_arm(a, &(d + &Nat::from(1u32)))))))))),
        crate::ast::ExprKind::ERebuild(scrutinee, body) => Text::from(format!("(rebuild {}{})", &sexp_expr(&**scrutinee, d), &sexp_block(body, d))),
        crate::ast::ExprKind::EFor(binders_opt, source, body) => Text::from(format!("(for{} {}{})", &sexp_binders(binders_opt, d), &sexp_expr(&**source, d), &sexp_block(body, d))),
        crate::ast::ExprKind::EGiven(b) => Text::from(format!("(given{})", &sexp_block(b, d))),
        crate::ast::ExprKind::EUpdate(target, body) => Text::from(format!("(update {}{})", &sexp_expr(&**target, d), &sexp_block(body, d))),
        crate::ast::ExprKind::EWidgetBlock(b) => Text::from(format!("(@widget{})", &sexp_block(b, d))),
        crate::ast::ExprKind::EMonad(m, body) => Text::from(format!("(monad {}{})", &sexp_expr(&**m, d), &sexp_block(body, d))),
        crate::ast::ExprKind::ETemplate(t) => sexp_template(t, d),
        crate::ast::ExprKind::EAny(x) => Text::from(format!("(any {})", &sexp_expr(&**x, d))),
        crate::ast::ExprKind::ELens(path__) => Text::from(format!("(lens {})", &crate::lexer::join(&each(path__, &(|i: &crate::ast::Ident| i.name.clone())), &Text::lit(".")))),
        crate::ast::ExprKind::EError => Text::lit("<error>"),
    }
}

/// ```prism
/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
/// ```
pub fn sexp_lambda_params(opt0: &Option<Array<crate::ast::Pattern_>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(" topic"),
        (Some(ps), d) => Text::from(format!(" (params{})", &concat(&each(ps, &(|p_: &crate::ast::Pattern_| Text::from(format!(" {}", &sexp_pattern(p_, d)))))))),
    }
}

/// ```prism
/// SexpLambdaBody: fn LambdaBody, Nat -> Text
/// ```
pub fn sexp_lambda_body(lambda_body0: &crate::ast::LambdaBody, d: &Nat) -> Text {
    match lambda_body0 {
        crate::ast::LambdaBody::LbExpr(e) => Text::from(format!(" {}", &sexp_expr(&**e, d))),
        crate::ast::LambdaBody::LbBlock(b) => sexp_block(b, d),
    }
}

/// ```prism
/// SexpElse: fn ?Block, Nat -> Text
/// ```
pub fn sexp_else(opt0: &Option<crate::ast::Block>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b), d) => Text::from(format!("{} else{}", &(if b.inline { Text::lit("") } else { nl(d) }), &sexp_block(b, d))),
    }
}

/// ```prism
/// SexpArm: fn Arm, Nat -> Text
/// ```
pub fn sexp_arm(a: &crate::ast::Arm, d: &Nat) -> Text {
    let pattern = match &a.pattern {
        Some(p_) => sexp_pattern(p_, d),
        None => Text::lit("otherwise"),
    };
    Text::from(format!("(arm {}{}{})", &pattern, &sexp_guard(&a.guard, d), &sexp_block(&a.body, d)))
}

/// ```prism
/// SexpBinders: fn ?ForBinders, Nat -> Text
/// ```
pub fn sexp_binders(opt0: &Option<crate::ast::ForBinders>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(b), d) => {
            let second = match &b.second {
                Some(s) => Text::from(format!(", {}", &sexp_pattern(s, d))),
                None => Text::lit(""),
            };
            Text::from(format!(" {}{} <-", &sexp_pattern(&b.first, d), &second))
        },
    }
}

/// ```prism
/// SexpTemplate: fn Template, Nat -> Text
/// ```
pub fn sexp_template(t: &crate::ast::Template, d: &Nat) -> Text {
    Text::from(format!("(template {} <{}>{})", &t.keyword, &t.lang, &sexp_parts(&t.parts, &(d + &Nat::from(1u32)))))
}

/// ```prism
/// SexpParts: fn [TemplatePart], Nat -> Text
/// ```
pub fn sexp_parts(parts: &Array<crate::ast::TemplatePart>, d: &Nat) -> Text {
    concat(&each(parts, &(|p_: &crate::ast::TemplatePart| Text::from(format!("{}{}", &nl(d), &sexp_part(p_, d))))))
}

/// ```prism
/// SexpPart: fn TemplatePart, Nat -> Text
/// ```
pub fn sexp_part(template_part0: &crate::ast::TemplatePart, n1: &Nat) -> Text {
    match (template_part0, n1) {
        (crate::ast::TemplatePart::TpText(s), _) => crate::lexer::debug_text(s),
        (crate::ast::TemplatePart::TpPlaceholder(e, col_opt), d) => Text::from(format!("{{{{{}}}}}{}", &sexp_expr(e, d), &column_text(col_opt))),
        (crate::ast::TemplatePart::TpBlock(b), d) => Text::from(format!("(brace-block{})", &sexp_block(b, d))),
        (crate::ast::TemplatePart::TpCall(name, attrs, body_opt, _), d) => Text::from(format!("(call {}{}{})", &sname_text(name), &sexp_args(attrs, d), &call_parts(body_opt, d))),
    }
}

/// ```prism
/// ColumnText: fn ?Nat -> Text
/// ```
pub fn column_text(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c) => Text::from(format!(" @col {}", c)),
    }
}

/// ```prism
/// CallParts: fn ?[TemplatePart], Nat -> Text
/// ```
pub fn call_parts(opt0: &Option<Array<crate::ast::TemplatePart>>, n1: &Nat) -> Text {
    match (opt0, n1) {
        (None, _) => Text::lit(""),
        (Some(parts), d) => sexp_parts(parts, &(d + &Nat::from(1u32))),
    }
}

/// ```prism
/// SexpPattern: fn Pattern, Nat -> Text
/// ```
pub fn sexp_pattern(p_: &crate::ast::Pattern_, d: &Nat) -> Text {
    match &*p_.kind {
        crate::ast::PatternKind::PName(n) => sname_text(n),
        crate::ast::PatternKind::PIgnore => Text::lit("ignore"),
        crate::ast::PatternKind::PLit(l) => sexp_literal(l, d),
        crate::ast::PatternKind::PNeg(l) => Text::from(format!("-{}", &sexp_literal(l, d))),
        crate::ast::PatternKind::PUnit => Text::lit("unit"),
        crate::ast::PatternKind::PNil => Text::lit("nil"),
        crate::ast::PatternKind::PCtor(name, args) => Text::from(format!("(ctor {}{})", &sname_text(name), &concat(&each(args, &(|a: &crate::ast::Pattern_| Text::from(format!(" {}", &sexp_pattern(a, d)))))))),
        crate::ast::PatternKind::PRecord(name, fields, rest) => Text::from(format!("(record {}{}{})", &sname_text(name), &concat(&each(fields, &(|f: &crate::ast::FieldPat| Text::from(format!(" {}{}", &arg_name(&f.name), &sexp_pattern(&f.pattern, d)))))), &(if *rest { Text::lit(" ..") } else { Text::lit("") }))),
        crate::ast::PatternKind::PSigil(s, inner) => Text::from(format!("(free{} {})", s, &sexp_pattern(&**inner, d))),
        crate::ast::PatternKind::PTuple(ps) => Text::from(format!("(tuple{})", &concat(&each(ps, &(|x: &crate::ast::Pattern_| Text::from(format!(" {}", &sexp_pattern(x, d)))))))),
        crate::ast::PatternKind::PArray(ps) => Text::from(format!("(array{})", &concat(&each(ps, &(|x: &crate::ast::Pattern_| Text::from(format!(" {}", &sexp_pattern(x, d)))))))),
        crate::ast::PatternKind::PGroup(x) => Text::from(format!("(group {})", &sexp_pattern(&**x, d))),
        crate::ast::PatternKind::PFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
    }
}

/// ```prism
/// SexpType: fn Type -> Text
/// ```
pub fn sexp_type(t: &crate::ast::Type) -> Text {
    match &*t.kind {
        crate::ast::TypeKind::TName(name, m16205_0_1) if (m16205_0_1.len() == 0) => sname_text(name),
        crate::ast::TypeKind::TName(name, args) => Text::from(format!("({}{})", &sname_text(name), &concat(&each(args, &(|a: &crate::ast::Type| Text::from(format!(" {}", &sexp_type(a)))))))),
        crate::ast::TypeKind::TSigiled(sigils, inner) => Text::from(format!("(free{} {})", sigils, &sexp_type(&**inner))),
        crate::ast::TypeKind::TArray(elem, true) => Text::from(format!("[[{}]]", &sexp_type(&**elem))),
        crate::ast::TypeKind::TArray(elem, false) => Text::from(format!("[{}]", &sexp_type(&**elem))),
        crate::ast::TypeKind::TTuple(ts) => Text::from(format!("(tuple{})", &concat(&each(ts, &(|x: &crate::ast::Type| Text::from(format!(" {}", &sexp_type(x)))))))),
        crate::ast::TypeKind::TGroup(x) => Text::from(format!("(group {})", &sexp_type(&**x))),
        crate::ast::TypeKind::TMap(k, v_) => Text::from(format!("(==> {} {})", &sexp_type(&**k), &sexp_type(&**v_))),
        crate::ast::TypeKind::TFn(color, params, result) => Text::from(format!("({}fn{} -> {})", &color_text(color), &concat(&each(params, &(|x: &crate::ast::Type| Text::from(format!(" {}", &sexp_type(x)))))), &sexp_type(&**result))),
        crate::ast::TypeKind::TEmit(ty, r) => Text::from(format!("(emit {} {})", &sexp_type(&**ty), &sexp_type(&**r))),
        crate::ast::TypeKind::TRowUnion(ts) => Text::from(format!("(|{})", &concat(&each(ts, &(|x: &crate::ast::Type| Text::from(format!(" {}", &sexp_type(x)))))))),
        crate::ast::TypeKind::TFamily(q) => Text::from(format!("{}.*", &path_(&q.path_))),
        crate::ast::TypeKind::TAny(tr) => Text::from(format!("(any ^{})", &path_(&tr.path_))),
        crate::ast::TypeKind::TUnit(s) => Text::from(format!("{}unit", s)),
        crate::ast::TypeKind::THole(n) => sname_text(n),
        crate::ast::TypeKind::TAbsent => Text::lit("absent"),
        crate::ast::TypeKind::TNonEmpty(x) => Text::from(format!("(nonempty {})", &sexp_type(&**x))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ColorText: fn Color -> Text
/// ```
pub fn color_text(color0: &crate::ast::Color) -> Text {
    match color0 {
        crate::ast::Color::Bounded => Text::lit(""),
        crate::ast::Color::Unbounded => Text::lit("unbounded "),
        crate::ast::Color::ColorVar(v_) => Text::from(format!("{} ", &v_.name)),
    }
}
