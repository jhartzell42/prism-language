//! The module `Emit`, from `target/bootstrap/src/prismc/emit.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_(t: &lower::OutTy) -> Text {
    'm1006: {
        if let lower::OutTy::OutNat = t {
            break 'm1006 Text::from("Nat");
        }
        if let lower::OutTy::OutInt = t {
            break 'm1006 Text::from("Int");
        }
        if let lower::OutTy::OutU8 = t {
            break 'm1006 Text::from("u8");
        }
        if let lower::OutTy::OutFloat = t {
            break 'm1006 Text::from("f64");
        }
        if let lower::OutTy::OutBool = t {
            break 'm1006 Text::from("bool");
        }
        if let lower::OutTy::OutChar = t {
            break 'm1006 Text::from("char");
        }
        if let lower::OutTy::OutText = t {
            break 'm1006 Text::from("Text");
        }
        if let lower::OutTy::OutUnit = t {
            break 'm1006 Text::from("()");
        }
        if let lower::OutTy::OutPath = t {
            break 'm1006 Text::from("Path");
        }
        if let lower::OutTy::OutDuration = t {
            break 'm1006 Text::from("Duration");
        }
        if let lower::OutTy::OutError = t {
            break 'm1006 Text::from("Error");
        }
        if let lower::OutTy::OutNamed(n, m1006_11_1) = t && (m1006_11_1.len() == 0) {
            break 'm1006 n.clone();
        }
        if let lower::OutTy::OutNamed(n, args_) = t {
            break 'm1006 Text::from(format!("{}<{}>", n, &types(args_)));
        }
        if let lower::OutTy::OutOpt(i) = t {
            break 'm1006 Text::from(format!("Option<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutRes(i) = t {
            break 'm1006 Text::from(format!("Result<{}, Error>", &type_(&**i)));
        }
        if let lower::OutTy::OutTuple(m1006_15_0) = t && (m1006_15_0.len() == 1) && let Some(one) = index(m1006_15_0, &Nat::from(0u32)) {
            break 'm1006 Text::from(format!("({},)", &type_(&one)));
        }
        if let lower::OutTy::OutTuple(ts) = t {
            break 'm1006 Text::from(format!("({})", &types(ts)));
        }
        if let lower::OutTy::OutArray(e) = t {
            break 'm1006 Text::from(format!("Array<{}>", &type_(&**e)));
        }
        if let lower::OutTy::OutMap(k, v_) = t {
            break 'm1006 Text::from(format!("Map<{}, {}>", &type_(&**k), &type_(&**v_)));
        }
        if let lower::OutTy::OutFn(ps, r) = t {
            break 'm1006 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types(ps), &type_(&**r)));
        }
        if let lower::OutTy::OutRef(m1006_20_0) = t && let lower::OutTy::OutFn(ps, r) = &**m1006_20_0 {
            break 'm1006 Text::from(format!("&dyn Fn({}) -> {}", &ref_types(ps), &type_(&**r)));
        }
        if let lower::OutTy::OutRef(i) = t {
            break 'm1006 Text::from(format!("&{}", &type_(&**i)));
        }
        if let lower::OutTy::OutJobFn(a, b) = t {
            break 'm1006 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_(&**a), &type_(&**b)));
        }
        if let lower::OutTy::OutJob(b) = t {
            break 'm1006 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_(&**b)));
        }
        if let lower::OutTy::OutEvent(i) = t {
            break 'm1006 Text::from(format!("Event<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutDyn(i) = t {
            break 'm1006 Text::from(format!("Dynamic<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutGen(n) = t {
            break 'm1006 n.clone();
        }
        if let lower::OutTy::OutRc(i) = t {
            break 'm1006 Text::from(format!("Rc<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutPod = t {
            break 'm1006 Text::from("Pod");
        }
        if let lower::OutTy::OutShowAny = t {
            break 'm1006 Text::from("Rc<dyn Show>");
        }
        if let lower::OutTy::OutHold(i) = t {
            break 'm1006 Text::from(format!("Hold<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutStamped(i) = t {
            break 'm1006 Text::from(format!("Stamped<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutSnapshot(i) = t {
            break 'm1006 Text::from(format!("Snapshot<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutDefer(i) = t {
            break 'm1006 Text::from(format!("Defer<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutWeak(n) = t {
            break 'm1006 Text::from(format!("Weak<{}>", n));
        }
        if let lower::OutTy::OutCell(i) = t {
            break 'm1006 Text::from(format!("RefCell<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutWakes = t {
            break 'm1006 Text::from("Wakes");
        }
        if let lower::OutTy::OutCount = t {
            break 'm1006 Text::from("u32");
        }
        if let lower::OutTy::OutObj(i) = t {
            break 'm1006 Text::from(format!("Rc<dyn {}>", &type_(&**i)));
        }
        if let lower::OutTy::OutSlice(i) = t {
            break 'm1006 Text::from(format!("[{}]", &type_(&**i)));
        }
        if let lower::OutTy::OutPort(i) = t {
            break 'm1006 Text::from(format!("Port<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutLive(i) = t {
            break 'm1006 Text::from(format!("Live<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutUnknown(what) = t {
            break 'm1006 Text::from(format!("() /* {} */", what));
        }
        if let lower::OutTy::OutQuantified(b) = t {
            break 'm1006 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        'm1006: {
            if let lower::OutTy::OutNat = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Nat"));
            }
            if let lower::OutTy::OutInt = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Int"));
            }
            if let lower::OutTy::OutU8 = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("u8"));
            }
            if let lower::OutTy::OutFloat = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("f64"));
            }
            if let lower::OutTy::OutBool = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("bool"));
            }
            if let lower::OutTy::OutChar = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("char"));
            }
            if let lower::OutTy::OutText = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Text"));
            }
            if let lower::OutTy::OutUnit = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("()"));
            }
            if let lower::OutTy::OutPath = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Path"));
            }
            if let lower::OutTy::OutDuration = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Duration"));
            }
            if let lower::OutTy::OutError = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Error"));
            }
            if let lower::OutTy::OutNamed(n, m1006_11_1) = t && (m1006_11_1.len() == 0) {
                break 'm1006 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::OutTy::OutNamed(n, args_) = t {
                break 'm1006 {
                    let args_ = args_.clone();
                    let n = n.clone();
                    call_then(start_types(args_.clone()), move |types_1287: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n, &types_1287))))
                };
            }
            if let lower::OutTy::OutOpt(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1324: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type__1324))))
                };
            }
            if let lower::OutTy::OutRes(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1357: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type__1357))))
                };
            }
            if let lower::OutTy::OutTuple(m1006_15_0) = t && (m1006_15_0.len() == 1) && let Some(one) = index(m1006_15_0, &Nat::from(0u32)) {
                break 'm1006 call_then(start_type_(one.clone()), move |type__1399: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type__1399))));
            }
            if let lower::OutTy::OutTuple(ts) = t {
                break 'm1006 {
                    let ts = ts.clone();
                    call_then(start_types(ts.clone()), move |types_1432: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_1432))))
                };
            }
            if let lower::OutTy::OutArray(e) = t {
                break 'm1006 {
                    let e = (**e).clone();
                    call_then(start_type_(e.clone()), move |type__1468: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type__1468))))
                };
            }
            if let lower::OutTy::OutMap(k, v_) = t {
                break 'm1006 {
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_type_(k.clone()), move |type__1501: Text| call_then(start_type_(v_.clone()), move |type__1511: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type__1501, &type__1511)))))
                };
            }
            if let lower::OutTy::OutFn(ps, r) = t {
                break 'm1006 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1550: Text| call_then(start_type_(r.clone()), move |type__1568: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_1550, &type__1568)))))
                };
            }
            if let lower::OutTy::OutRef(m1006_20_0) = t && let lower::OutTy::OutFn(ps, r) = &**m1006_20_0 {
                break 'm1006 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1614: Text| call_then(start_type_(r.clone()), move |type__1632: Text| prism_rtl::Turn::Finished(Text::from(format!("&dyn Fn({}) -> {}", &ref_types_1614, &type__1632)))))
                };
            }
            if let lower::OutTy::OutRef(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1658: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__1658))))
                };
            }
            if let lower::OutTy::OutJobFn(a, b) = t {
                break 'm1006 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    call_then(start_type_(a.clone()), move |type__1698: Text| call_then(start_type_(b.clone()), move |type__1733: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type__1698, &type__1733)))))
                };
            }
            if let lower::OutTy::OutJob(b) = t {
                break 'm1006 {
                    let b = (**b).clone();
                    call_then(start_type_(b.clone()), move |type__1783: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type__1783))))
                };
            }
            if let lower::OutTy::OutEvent(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1818: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type__1818))))
                };
            }
            if let lower::OutTy::OutDyn(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1852: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type__1852))))
                };
            }
            if let lower::OutTy::OutGen(n) = t {
                break 'm1006 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::OutTy::OutRc(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1896: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type__1896))))
                };
            }
            if let lower::OutTy::OutPod = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Pod"));
            }
            if let lower::OutTy::OutShowAny = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Rc<dyn Show>"));
            }
            if let lower::OutTy::OutHold(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1977: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type__1977))))
                };
            }
            if let lower::OutTy::OutStamped(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2015: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type__2015))))
                };
            }
            if let lower::OutTy::OutSnapshot(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2055: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type__2055))))
                };
            }
            if let lower::OutTy::OutDefer(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2089: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type__2089))))
                };
            }
            if let lower::OutTy::OutWeak(n) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n)));
            }
            if let lower::OutTy::OutCell(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2151: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type__2151))))
                };
            }
            if let lower::OutTy::OutWakes = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("Wakes"));
            }
            if let lower::OutTy::OutCount = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from("u32"));
            }
            if let lower::OutTy::OutObj(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2226: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type__2226))))
                };
            }
            if let lower::OutTy::OutSlice(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2255: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type__2255))))
                };
            }
            if let lower::OutTy::OutPort(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2287: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type__2287))))
                };
            }
            if let lower::OutTy::OutLive(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2319: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type__2319))))
                };
            }
            if let lower::OutTy::OutUnknown(what) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("() /* {} */", what)));
            }
            if let lower::OutTy::OutQuantified(b) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_(t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types(ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
        let t = p0;
        prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
    }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
            let t = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
        }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2555: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_2555, &Text::from(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types(ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types(ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
        let t = p0;
        call_then(start_type_(t.clone()), move |type__2663: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2663))))
    }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
            let t = p0;
            call_then(start_type_(t.clone()), move |type__2663: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2663))))
        }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2646: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_2646, &Text::from(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types(ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose(x: &lower::Ex) -> bool {
    match x {
        lower::Ex::XBlock(m2988_0_0, inner) if (m2988_0_0.len() == 0) => is_loose(&**inner),
        lower::Ex::XTyped(inner, _) => is_loose(&**inner),
        lower::Ex::XBin(_, _, _) => true,
        lower::Ex::XUnary(_, _) => true,
        lower::Ex::XClosure(_, _, _) => true,
        lower::Ex::XIf(_, _, _) => true,
        lower::Ex::XMatch(_, _, _, _) => true,
        lower::Ex::XChain(_, _, _, _) => true,
        lower::Ex::XCast(_, _) => true,
        lower::Ex::XRef(_) => true,
        lower::Ex::XRefMut(_) => true,
        lower::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight(x: &lower::Ex) -> Text {
    if is_loose(x) { Text::from(format!("({})", &expression(x))) } else { expression(x) }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        if is_loose(x) {
            {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3505: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3505))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand(x: &lower::Ex) -> Text {
    match x {
        lower::Ex::XBlock(m3589_0_0, inner) if (m3589_0_0.len() == 0) => operand(&**inner),
        lower::Ex::XTyped(inner, _) => operand(&**inner),
        lower::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XCast(_, _) => Text::from(format!("({})", &expression(x))),
        _ => expression(x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        match x {
            lower::Ex::XBlock(m3589_0_0, inner) if (m3589_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            lower::Ex::XTyped(inner, _) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            lower::Ex::XBin(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3712: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3712))))
            },
            lower::Ex::XClosure(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3768: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3768))))
            },
            lower::Ex::XIf(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3819: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3819))))
            },
            lower::Ex::XCast(_, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3864: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3864))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args(xs: &Array<lower::Ex>) -> Text {
    lexer::join(&run_to_end(each_job(xs.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
        let x = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
    }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs = &self.xs;
        let xs = xs.clone();
        call_value(each_job(xs.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let x = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3960: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_3960, &Text::from(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args(xs: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression(x: &lower::Ex) -> Text {
    'm4049: {
        if let lower::Ex::XVar(n) = x {
            break 'm4049 n.clone();
        }
        if let lower::Ex::XPath(p_) = x {
            break 'm4049 p_.clone();
        }
        if let lower::Ex::XSelf = x {
            break 'm4049 Text::from("self");
        }
        if let lower::Ex::XCx = x {
            break 'm4049 Text::from("cx");
        }
        if let lower::Ex::XConst(n) = x {
            break 'm4049 Text::from(format!("Self::{}", n));
        }
        if let lower::Ex::XUnit = x {
            break 'm4049 Text::from("()");
        }
        if let lower::Ex::XNone = x {
            break 'm4049 Text::from("None");
        }
        if let lower::Ex::XBool(b) = x {
            break 'm4049 if *b { Text::from("true") } else { Text::from("false") };
        }
        if let lower::Ex::XNat(d) = x {
            break 'm4049 if &len_text(d) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d))
            } else {
                Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d))
            };
        }
        if let lower::Ex::XInt(d) = x {
            break 'm4049 if &len_text(&(if &take_text(d, &Nat::from(1u32)) == &Text::from("-") {
                drop_text(d, &Nat::from(1u32))
            } else {
                d.clone()
            })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d))
            } else {
                Text::from(format!("Int::from({}i64)", d))
            };
        }
        if let lower::Ex::XByte(d) = x {
            break 'm4049 Text::from(format!("{}u8", d));
        }
        if let lower::Ex::XFloat(d) = x {
            break 'm4049 d.clone();
        }
        if let lower::Ex::XIndex(n) = x {
            break 'm4049 Text::from(format!("{}", n));
        }
        if let lower::Ex::XChar(c) = x {
            break 'm4049 Text::from(format!("'{}'", &lower::char_escape(c)));
        }
        if let lower::Ex::XStr(t) = x {
            break 'm4049 Text::from(format!("\"{}\"", &lower::escape(t)));
        }
        if let lower::Ex::XRef(y) = x {
            break 'm4049 Text::from(format!("&{}", &operand(&**y)));
        }
        if let lower::Ex::XRefMut(y) = x {
            break 'm4049 Text::from(format!("&mut {}", &operand(&**y)));
        }
        if let lower::Ex::XDeref(y) = x {
            break 'm4049 Text::from(format!("*{}", &operand(&**y)));
        }
        if let lower::Ex::XTarget(y) = x {
            break 'm4049 Text::from(format!("(*{})", &expression(&**y)));
        }
        if let lower::Ex::XClone(y) = x {
            break 'm4049 Text::from(format!("{}.clone()", &tight(&**y)));
        }
        if let lower::Ex::XWeak(y) = x {
            break 'm4049 Text::from(format!("Rc::downgrade({})", &expression(&**y)));
        }
        if let lower::Ex::XUpgrade(y) = x {
            break 'm4049 Text::from(format!("{}.upgrade()", &tight(&**y)));
        }
        if let lower::Ex::XBreak(l, y) = x {
            break 'm4049 Text::from(format!("break {} {}", &label(l), &expression(&**y)));
        }
        if let lower::Ex::XBreakLoop = x {
            break 'm4049 Text::from("break");
        }
        if let lower::Ex::XLater(y) = x {
            break 'm4049 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression(&**y)));
        }
        if let lower::Ex::XFormatStr(parts) = x {
            break 'm4049 format_str(parts);
        }
        if let lower::Ex::XIsCase(y, m4049_26_1) = x && (m4049_26_1.len() == 0) {
            break 'm4049 Text::from("false");
        }
        if let lower::Ex::XIsCase(y, cs) = x {
            break 'm4049 Text::from(format!("matches!({}, {})", &expression(&**y), &lexer::join(&each(cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::from(" | "))));
        }
        if let lower::Ex::XRefusal(what) = x {
            break 'm4049 Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what)));
        }
        if let lower::Ex::XUnreachable = x {
            break 'm4049 Text::from("unreachable!()");
        }
        if let lower::Ex::XCall(f, args_) = x {
            break 'm4049 Text::from(format!("{}({})", f, &args(args_)));
        }
        if let lower::Ex::XApply(f, args_) = x {
            break 'm4049 Text::from(format!("{}({})", &tight(&**f), &args(args_)));
        }
        if let lower::Ex::XMethod(r, m, args_) = x {
            break 'm4049 Text::from(format!("{}.{}({})", &tight(&**r), m, &args(args_)));
        }
        if let lower::Ex::XBin(op, l, r) = x {
            break 'm4049 Text::from(format!("{} {} {}", &operand(&**l), op, &operand(&**r)));
        }
        if let lower::Ex::XUnary(op, y) = x {
            break 'm4049 Text::from(format!("{}{}", op, &operand(&**y)));
        }
        if let lower::Ex::XCtor(p_, args_) = x {
            break 'm4049 Text::from(format!("{}({})", p_, &args(args_)));
        }
        if let lower::Ex::XRecord(p_, fs) = x {
            break 'm4049 Text::from(format!("{} {{ {} }}", p_, &lexer::join(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                let (f, v_) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
            }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))));
        }
        if let lower::Ex::XTuple(m4049_37_0) = x && (m4049_37_0.len() == 1) && let Some(one) = index(m4049_37_0, &Nat::from(0u32)) {
            break 'm4049 Text::from(format!("({},)", &expression(&one)));
        }
        if let lower::Ex::XTuple(xs) = x {
            break 'm4049 Text::from(format!("({})", &args(xs)));
        }
        if let lower::Ex::XVec(xs) = x {
            break 'm4049 Text::from(format!("vec![{}]", &args(xs)));
        }
        if let lower::Ex::XText(t) = x {
            break 'm4049 Text::from(format!("Text::from(\"{}\")", &lower::escape(t)));
        }
        if let lower::Ex::XFormat(parts) = x {
            break 'm4049 format(parts);
        }
        if let lower::Ex::XMatch(s, arms_, fallback, _) = x {
            break 'm4049 rust_templates::match_(&expression(&**s), &arms(arms_, fallback));
        }
        if let lower::Ex::XChain(label_, s, arms_, _) = x {
            break 'm4049 chain(&label(label_), &**s, arms_);
        }
        if let lower::Ex::XIf(c, t, e) = x {
            break 'm4049 if_expression(&**c, &**t, &**e);
        }
        if let lower::Ex::XBlock(m4049_45_0, e) = x && (m4049_45_0.len() == 0) {
            break 'm4049 expression(&**e);
        }
        if let lower::Ex::XBlock(dos, e) = x {
            break 'm4049 rust_templates::block(&statements(dos), &expression(&**e));
        }
        if let lower::Ex::XLabeled(label_, dos, e, _) = x {
            break 'm4049 rust_templates::labeled(&label(label_), &statements(dos), &expression(&**e));
        }
        if let lower::Ex::XClosure(mv, ps, body) = x {
            break 'm4049 Text::from(format!("{}|{}| {}", &(if *mv { Text::from("move ") } else { Text::from("") }), &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", ")), &expression(&**body)));
        }
        if let lower::Ex::XTry(y) = x {
            break 'm4049 Text::from(format!("{}?", &tight(&**y)));
        }
        if let lower::Ex::XField(r, f) = x {
            break 'm4049 Text::from(format!("{}.{}", &tight(&**r), f));
        }
        if let lower::Ex::XPart(r, k) = x {
            break 'm4049 Text::from(format!("{}.{}", &tight(&**r), k));
        }
        if let lower::Ex::XDecode(t, y) = x {
            break 'm4049 Text::from(format!("{}::from_pod({})?", &decode_head(t), &expression(&**y)));
        }
        if let lower::Ex::XCast(y, t) = x {
            break 'm4049 Text::from(format!("{} as {}", &tight(&**y), &type_(t)));
        }
        if let lower::Ex::XTyped(y, _) = x {
            break 'm4049 expression(&**y);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        'm4049: {
            if let lower::Ex::XVar(n) = x {
                break 'm4049 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::Ex::XPath(p_) = x {
                break 'm4049 prism_rtl::Turn::Finished(p_.clone());
            }
            if let lower::Ex::XSelf = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("self"));
            }
            if let lower::Ex::XCx = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("cx"));
            }
            if let lower::Ex::XConst(n) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let lower::Ex::XUnit = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("()"));
            }
            if let lower::Ex::XNone = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("None"));
            }
            if let lower::Ex::XBool(b) = x {
                break 'm4049 if *b {
                    prism_rtl::Turn::Finished(Text::from("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::from("false"))
                };
            }
            if let lower::Ex::XNat(d) = x {
                break 'm4049 if &len_text(d) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d)))
                };
            }
            if let lower::Ex::XInt(d) = x {
                break 'm4049 if &len_text(&(if &take_text(d, &Nat::from(1u32)) == &Text::from("-") {
                    drop_text(d, &Nat::from(1u32))
                } else {
                    d.clone()
                })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({}i64)", d)))
                };
            }
            if let lower::Ex::XByte(d) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d)));
            }
            if let lower::Ex::XFloat(d) = x {
                break 'm4049 prism_rtl::Turn::Finished(d.clone());
            }
            if let lower::Ex::XIndex(n) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let lower::Ex::XChar(c) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &lower::char_escape(c))));
            }
            if let lower::Ex::XStr(t) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lower::escape(t))));
            }
            if let lower::Ex::XRef(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4565: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_4565))))
                };
            }
            if let lower::Ex::XRefMut(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4599: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_4599))))
                };
            }
            if let lower::Ex::XDeref(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4628: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_4628))))
                };
            }
            if let lower::Ex::XTarget(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4659: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_4659))))
                };
            }
            if let lower::Ex::XClone(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4691: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_4691))))
                };
            }
            if let lower::Ex::XWeak(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4738: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_4738))))
                };
            }
            if let lower::Ex::XUpgrade(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4772: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_4772))))
                };
            }
            if let lower::Ex::XBreak(l, y) = x {
                break 'm4049 {
                    let l = l.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4827: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label(&l), &expression_4827))))
                };
            }
            if let lower::Ex::XBreakLoop = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("break"));
            }
            if let lower::Ex::XLater(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4904: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_4904))))
                };
            }
            if let lower::Ex::XFormatStr(parts) = x {
                break 'm4049 prism_rtl::Turn::More(Rc::new(FormatStr { parts: parts.clone() }));
            }
            if let lower::Ex::XIsCase(y, m4049_26_1) = x && (m4049_26_1.len() == 0) {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("false"));
            }
            if let lower::Ex::XIsCase(y, cs) = x {
                break 'm4049 {
                    let cs = cs.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5028: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_5028, &lexer::join(&each(&cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::from(" | "))))))
                };
            }
            if let lower::Ex::XRefusal(what) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what))));
            }
            if let lower::Ex::XUnreachable = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from("unreachable!()"));
            }
            if let lower::Ex::XCall(f, args_) = x {
                break 'm4049 {
                    let args_ = args_.clone();
                    let f = f.clone();
                    call_then(start_args(args_.clone()), move |args_5217: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f, &args_5217))))
                };
            }
            if let lower::Ex::XApply(f, args_) = x {
                break 'm4049 {
                    let args_ = args_.clone();
                    let f = (**f).clone();
                    call_then(start_tight(f.clone()), move |tight_5252: Text| call_then(start_args(args_.clone()), move |args_5262: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_5252, &args_5262)))))
                };
            }
            if let lower::Ex::XMethod(r, m, args_) = x {
                break 'm4049 {
                    let args_ = args_.clone();
                    let m = m.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_5301: Text| call_then(start_args(args_.clone()), move |args_5315: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_5301, &m, &args_5315)))))
                };
            }
            if let lower::Ex::XBin(op, l, r) = x {
                break 'm4049 {
                    let l = (**l).clone();
                    let op = op.clone();
                    let r = (**r).clone();
                    call_then(start_operand(l.clone()), move |operand_5349: Text| call_then(start_operand(r.clone()), move |operand_5366: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_5349, &op, &operand_5366)))))
                };
            }
            if let lower::Ex::XUnary(op, y) = x {
                break 'm4049 {
                    let op = op.clone();
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5402: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &operand_5402))))
                };
            }
            if let lower::Ex::XCtor(p_, args_) = x {
                break 'm4049 {
                    let args_ = args_.clone();
                    let p_ = p_.clone();
                    call_then(start_args(args_.clone()), move |args_5439: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_, &args_5439))))
                };
            }
            if let lower::Ex::XRecord(p_, fs) = x {
                break 'm4049 {
                    let fs = fs.clone();
                    let p_ = p_.clone();
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                        let (f, v_) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                    }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5486: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_, &lexer::join(&each_5486, &Text::from(", "))))))
                };
            }
            if let lower::Ex::XTuple(m4049_37_0) = x && (m4049_37_0.len() == 1) && let Some(one) = index(m4049_37_0, &Nat::from(0u32)) {
                break 'm4049 call_then(start_expression(one.clone()), move |expression_5557: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_5557))));
            }
            if let lower::Ex::XTuple(xs) = x {
                break 'm4049 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5594: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_5594))))
                };
            }
            if let lower::Ex::XVec(xs) = x {
                break 'm4049 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5625: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_5625))))
                };
            }
            if let lower::Ex::XText(t) = x {
                break 'm4049 prism_rtl::Turn::Finished(Text::from(format!("Text::from(\"{}\")", &lower::escape(t))));
            }
            if let lower::Ex::XFormat(parts) = x {
                break 'm4049 prism_rtl::Turn::More(Rc::new(Format { parts: parts.clone() }));
            }
            if let lower::Ex::XMatch(s, arms_, fallback, _) = x {
                break 'm4049 {
                    let arms_ = arms_.clone();
                    let fallback = *fallback;
                    let s = (**s).clone();
                    call_then(start_expression(s.clone()), move |expression_5755: Text| call_then(start_arms(arms_.clone(), fallback), move |arms_5771: Text| prism_rtl::Turn::Finished(rust_templates::match_(&expression_5755, &arms_5771))))
                };
            }
            if let lower::Ex::XChain(label_, s, arms_, _) = x {
                break 'm4049 prism_rtl::Turn::More(Rc::new(Chain { label_: label(label_), s: (**s).clone(), arms_: arms_.clone() }));
            }
            if let lower::Ex::XIf(c, t, e) = x {
                break 'm4049 prism_rtl::Turn::More(Rc::new(IfExpression { c: (**c).clone(), t: (**t).clone(), e: (**e).clone() }));
            }
            if let lower::Ex::XBlock(m4049_45_0, e) = x && (m4049_45_0.len() == 0) {
                break 'm4049 prism_rtl::Turn::More(Rc::new(Expression { x: (**e).clone() }));
            }
            if let lower::Ex::XBlock(dos, e) = x {
                break 'm4049 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_5953: Text| call_then(start_expression(e.clone()), move |expression_5971: Text| prism_rtl::Turn::Finished(rust_templates::block(&statements_5953, &expression_5971))))
                };
            }
            if let lower::Ex::XLabeled(label_, dos, e, _) = x {
                break 'm4049 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    let label_ = label_.clone();
                    call_then(start_statements(dos.clone()), move |statements_6045: Text| call_then(start_expression(e.clone()), move |expression_6063: Text| prism_rtl::Turn::Finished(rust_templates::labeled(&label(&label_), &statements_6045, &expression_6063))))
                };
            }
            if let lower::Ex::XClosure(mv, ps, body) = x {
                break 'm4049 {
                    let body = (**body).clone();
                    let mv = *mv;
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6138: Array<Text>| call_then(start_expression(body.clone()), move |expression_6172: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv { Text::from("move ") } else { Text::from("") }), &lexer::join(&each_6138, &Text::from(", ")), &expression_6172)))))
                };
            }
            if let lower::Ex::XTry(y) = x {
                break 'm4049 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6204: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_6204))))
                };
            }
            if let lower::Ex::XField(r, f) = x {
                break 'm4049 {
                    let f = f.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6234: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6234, &f))))
                };
            }
            if let lower::Ex::XPart(r, k) = x {
                break 'm4049 {
                    let k = k.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6266: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6266, &k))))
                };
            }
            if let lower::Ex::XDecode(t, y) = x {
                break 'm4049 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_decode_head(t.clone()), move |decode_head_6300: Text| call_then(start_expression(y.clone()), move |expression_6325: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_6300, &expression_6325)))))
                };
            }
            if let lower::Ex::XCast(y, t) = x {
                break 'm4049 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6360: Text| call_then(start_type_(t.clone()), move |type__6373: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_6360, &type__6373)))))
                };
            }
            if let lower::Ex::XTyped(y, _) = x {
                break 'm4049 prism_rtl::Turn::More(Rc::new(Expression { x: (**y).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init(f: &Text, ex1: &lower::Ex) -> Text {
    match ex1 {
        lower::Ex::XVar(v_) => if v_ == f { f.clone() } else { Text::from(format!("{}: {}", f, v_)) },
        v_ => Text::from(format!("{}: {}", f, &expression(v_))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f: Text,
    pub ex1: lower::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ex1 = &self.ex1;
        match ex1 {
            lower::Ex::XVar(v_) => if v_ == f {
                prism_rtl::Turn::Finished(f.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f, v_)))
            },
            v_ => {
                let f = f.clone();
                let v_ = v_.clone();
                call_then(start_expression(v_.clone()), move |expression_6543: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &expression_6543))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init(f: Text, ex1: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head(t: &lower::OutTy) -> Text {
    match t {
        lower::OutTy::OutNamed(n, m6616_0_1) if (m6616_0_1.len() == 0) => n.clone(),
        lower::OutTy::OutNat => Text::from("Nat"),
        lower::OutTy::OutInt => Text::from("Int"),
        lower::OutTy::OutText => Text::from("Text"),
        _ => Text::from(format!("<{}>", &type_(t))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            lower::OutTy::OutNamed(n, m6616_0_1) if (m6616_0_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            lower::OutTy::OutNat => prism_rtl::Turn::Finished(Text::from("Nat")),
            lower::OutTy::OutInt => prism_rtl::Turn::Finished(Text::from("Int")),
            lower::OutTy::OutText => prism_rtl::Turn::Finished(Text::from("Text")),
            _ => {
                let t = t.clone();
                call_then(start_type_(t.clone()), move |type__6723: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type__6723))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head(t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label(l: &Text) -> Text {
    if &take_text(l, &Nat::from(1u32)) == &Text::from("'") {
        l.clone()
    } else {
        Text::from(format!("'{}", l))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format(parts: &Array<lower::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &lower::Ex| format_piece(p_))));
    let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("Text::from(\"{}\")", &lit))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args(&vals)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &lower::Ex| format_piece(p_))));
        let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::from(\"{}\")", &lit)))
        } else {
            call_then(start_args(vals.clone()), move |args_7144: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args_7144))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format(parts: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts })
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str(parts: &Array<lower::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &lower::Ex| str_piece(p_))));
    let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_) && !is_var(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit, &args(&vals)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &lower::Ex| str_piece(p_))));
        let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_) && !is_var(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit)))
        } else {
            call_then(start_args(vals.clone()), move |args_7529: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit, &args_7529))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str(parts: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var(ex0: &lower::Ex) -> bool {
    match ex0 {
        lower::Ex::XVar(_) => true,
        other => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XVar(n) => Text::from(format!("{{{}}}", n)),
        other => format_piece(other),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text(ex0: &lower::Ex) -> bool {
    match ex0 {
        lower::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XText(t) => format_escape(&lower::escape(t)),
        other => Text::from("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape(t: &Text) -> Text {
    concat(&each(&lexer::chars(t), &(|c: &Text| format_escape_char(c))))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::from("{")) => Text::from("{{"),
        c1_0 if (c1_0 == &Text::from("}")) => Text::from("}}"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression(c: &lower::Ex, t: &lower::Ex, e: &lower::Ex) -> Text {
    let ct = expression(c);
    let tt = expression(t);
    let et = expression(e);
    let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::from("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et))
    } else {
        rust_templates::if_(&ct, &tt, &et)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c: lower::Ex,
    pub t: lower::Ex,
    pub e: lower::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_expression(c.clone()), move |expression_8280: Text| {
            let ct = expression_8280;
            call_then(start_expression(t.clone()), move |expression_8306: Text| {
                let tt = expression_8306;
                call_then(start_expression(e.clone()), move |expression_8332: Text| {
                    let et = expression_8332;
                    let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::from("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
                    if short {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et)))
                    } else {
                        prism_rtl::Turn::Finished(rust_templates::if_(&ct, &tt, &et))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression(c: lower::Ex, t: lower::Ex, e: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c, t, e })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms(arms_: &Array<lower::XArm>, fallback: &bool) -> Text {
    let lines = run_to_end(each_job(arms_.clone(), Rc::new(move |p0: lower::XArm| entered(once_job(move || {
        let a = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
    }))) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all = if *fallback {
        push(&lines, &Text::from("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines.clone()
    };
    lexer::join(&all, &Text::from("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_: Array<lower::XArm>,
    pub fallback: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_ = &self.arms_;
        let fallback = &self.fallback;
        let arms_ = arms_.clone();
        let fallback = *fallback;
        call_value(each_job(arms_.clone(), Rc::new(move |p0: lower::XArm| entered(once_job(move || {
            let a = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
        }))) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_8663: Array<Text>| {
            let lines = each_8663;
            let all = if fallback {
                push(&lines, &Text::from("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines.clone()
            };
            prism_rtl::Turn::Finished(lexer::join(&all, &Text::from("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms(arms_: Array<lower::XArm>, fallback: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_, fallback })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm(a: &lower::XArm) -> Text {
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Text::from("")
    } else {
        Text::from(format!(" if {}", &lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
        }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(" && "))))
    };
    let body = expression(&a.body);
    Text::from(format!("{}{} => {},", &pattern(&a.pat), &guard, &body))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a: lower::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let guard = if &len(&a.conds) == &Nat::from(0u32) {
            Text::from("")
        } else {
            Text::from(format!(" if {}", &lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
            }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(" && "))))
        };
        let a = a.clone();
        call_then(start_expression(a.body.clone()), move |expression_8955: Text| {
            let body = expression_8955;
            call_then(start_pattern(a.pat.clone()), move |pattern_8979: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_8979, &guard, &body))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm(a: lower::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition(cc0: &lower::Cc) -> Text {
    match cc0 {
        lower::Cc::CcIf(x) => operand(x),
        lower::Cc::CcLet(p_, x) => Text::from(format!("let {} = {}", &pattern(p_), &expression(x))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: lower::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            lower::Cc::CcIf(x) => prism_rtl::Turn::More(Rc::new(Operand { x: x.clone() })),
            lower::Cc::CcLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_9117: Text| call_then(start_expression(x.clone()), move |expression_9131: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_9117, &expression_9131)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition(cc0: lower::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain(label_: &Text, s: &lower::Ex, arms_: &Array<lower::XArm>) -> Text {
    let in_place = match s {
        lower::Ex::XRef(y) => is_bound(&**y),
        _ => is_bound(s),
    };
    let (bind, scrut) = if in_place {
        (Array::new(), expression(s))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::from("scrutinee"))
    };
    let n = len(arms_);
    let lines = run_to_end(each_job(check_errors::range0(&n), {
        let arms_ = arms_.clone();
        let scrut = scrut.clone();
        let label_ = label_.clone();
        Rc::new(move |p0: Nat| {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&arms_, &i), &lower::XArm { pat: lower::Pa::PaWild, conds: Array::new(), body: lower::Ex::XUnit });
                    let catch_all = (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                    if catch_all {
                        prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                    } else {
                        call_then(start_pattern(a.pat.clone()), move |pattern_9844: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                        }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9874: Array<Text>| {
                            let head = lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_9844, &scrut))]), &each_9874), &Text::from(" && "));
                            call_then(start_expression(a.body.clone()), move |expression_9961: Text| prism_rtl::Turn::Finished(rust_templates::chain_arm(&head, &label_, &continued(&expression_9961, &Text::from("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends = match lexer::last(arms_) {
        Some(a) => (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    let tail = if ends {
        Array::new()
    } else {
        Array::from(vec![Text::from("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_, &indent(&lexer::join(&append(&append(&bind, &lines), &tail), &Text::from("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_: Text,
    pub s: lower::Ex,
    pub arms_: Array<lower::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_ = &self.label_;
        let s = &self.s;
        let arms_ = &self.arms_;
        let in_place = match s {
            lower::Ex::XRef(y) => is_bound(&**y),
            _ => is_bound(s),
        };
        let (bind, scrut) = if in_place {
            (Array::new(), expression(s))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::from("scrutinee"))
        };
        let n = len(arms_);
        let arms_ = arms_.clone();
        let label_ = label_.clone();
        let s = s.clone();
        call_value(each_job(check_errors::range0(&n), {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            Rc::new(move |p0: Nat| {
                let arms_ = arms_.clone();
                let scrut = scrut.clone();
                let label_ = label_.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&arms_, &i), &lower::XArm { pat: lower::Pa::PaWild, conds: Array::new(), body: lower::Ex::XUnit });
                        let catch_all = (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                        if catch_all {
                            prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                        } else {
                            call_then(start_pattern(a.pat.clone()), move |pattern_9844: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                            }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9874: Array<Text>| {
                                let head = lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_9844, &scrut))]), &each_9874), &Text::from(" && "));
                                call_then(start_expression(a.body.clone()), move |expression_9961: Text| prism_rtl::Turn::Finished(rust_templates::chain_arm(&head, &label_, &continued(&expression_9961, &Text::from("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_9590: Array<Text>| {
            let lines = each_9590;
            let ends = match lexer::last(&arms_) {
                Some(a) => (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail = if ends {
                Array::new()
            } else {
                Array::from(vec![Text::from("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_, &indent(&lexer::join(&append(&append(&bind, &lines), &tail), &Text::from("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain(label_: Text, s: lower::Ex, arms_: Array<lower::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_, s, arms_ })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound(x: &lower::Ex) -> bool {
    'm10465: {
        if let lower::Ex::XVar(_) = x {
            break 'm10465 true;
        }
        if let lower::Ex::XField(m10465_1_0, _) = x && let lower::Ex::XSelf = &**m10465_1_0 {
            break 'm10465 true;
        }
        if let lower::Ex::XField(m10465_2_0, _) = x && let lower::Ex::XMethod(m10465_2_0_r_0, _, _) = &**m10465_2_0 && let lower::Ex::XUpgrade(_) = &**m10465_2_0_r_0 {
            break 'm10465 true;
        }
        if let lower::Ex::XTarget(_) = x {
            break 'm10465 true;
        }
        if let lower::Ex::XPart(m10465_4_0, _) = x && let lower::Ex::XVar(_) = &**m10465_4_0 {
            break 'm10465 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued(t: &Text, pad: &Text) -> Text {
    let ls = split(t, &Text::from("\n"));
    lexer::join(&each(&check_errors::range0(&len(&ls)), &(|i: &Nat| if (i == &Nat::from(0u32)) || (&or(&index(&ls, i), &Text::from("")) == &Text::from("")) {
        or(&index(&ls, i), &Text::from(""))
    } else {
        Text::from(format!("{}{}", pad, &or(&index(&ls, i), &Text::from(""))))
    })), &Text::from("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
            body_lines(&**e)
        } else {
            Text::from(format!("{}\n{}", &statements(dos), &body_lines(&**e)))
        },
        x => expression(x),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: lower::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            lower::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e).clone() }))
            } else {
                {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_11149: Text| call_then(start_body_lines(e.clone()), move |body_lines_11167: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_11149, &body_lines_11167)))))
                }
            },
            x => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines(ex0: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent(t: &Text) -> Text {
    lexer::join(&each(&split(t, &Text::from("\n")), &(|l: &Text| if l == &Text::from("") { Text::from("") } else { Text::from(format!("    {}", l)) })), &Text::from("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern(p_: &lower::Pa) -> Text {
    'm11616: {
        if let lower::Pa::PaWild = p_ {
            break 'm11616 Text::from("_");
        }
        if let lower::Pa::PaBind(n) = p_ {
            break 'm11616 n.clone();
        }
        if let lower::Pa::PaMut(n) = p_ {
            break 'm11616 Text::from(format!("mut {}", n));
        }
        if let lower::Pa::PaCtor(c, ps) = p_ {
            break 'm11616 Text::from(format!("{}({})", c, &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))));
        }
        if let lower::Pa::PaUnit(c) = p_ {
            break 'm11616 c.clone();
        }
        if let lower::Pa::PaRecord(c, fs, rest) = p_ {
            break 'm11616 {
                let parts = run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
                    let (f, q) = p0;
                    match &q {
                        lower::Pa::PaBind(n) => if n == &f {
                            prism_rtl::Turn::Finished(f.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                        },
                        _ => call_then(start_pattern(q.clone()), move |pattern_11918: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_11918)))),
                    }
                }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all = if *rest { push(&parts, &Text::from("..")) } else { parts.clone() };
                Text::from(format!("{} {{ {} }}", c, &lexer::join(&all, &Text::from(", "))))
            };
        }
        if let lower::Pa::PaTuple(m11616_6_0) = p_ && (m11616_6_0.len() == 1) && let Some(one) = index(m11616_6_0, &Nat::from(0u32)) {
            break 'm11616 Text::from(format!("({},)", &pattern(&one)));
        }
        if let lower::Pa::PaTuple(ps) = p_ {
            break 'm11616 Text::from(format!("({})", &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))));
        }
        if let lower::Pa::PaChar(c) = p_ {
            break 'm11616 Text::from(format!("'{}'", &lower::char_escape(c)));
        }
        if let lower::Pa::PaBool(b) = p_ {
            break 'm11616 if *b { Text::from("true") } else { Text::from("false") };
        }
        if let lower::Pa::PaIndex(n) = p_ {
            break 'm11616 Text::from(format!("{}", n));
        }
        if let lower::Pa::PaConst(n) = p_ {
            break 'm11616 Text::from(format!("Self::{}", n));
        }
        if let lower::Pa::PaSlice(ps) = p_ {
            break 'm11616 Text::from(format!("[{}]", &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))));
        }
        if let lower::Pa::PaRest(m11616_13_0) = p_ && (m11616_13_0 == &Text::from("")) {
            break 'm11616 Text::from("..");
        }
        if let lower::Pa::PaRest(n) = p_ {
            break 'm11616 Text::from(format!("{} @ ..", n));
        }
        if let lower::Pa::PaTyped(q, t) = p_ {
            break 'm11616 Text::from(format!("{}: {}", &pattern(&**q), &type_(t)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_: lower::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        'm11616: {
            if let lower::Pa::PaWild = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from("_"));
            }
            if let lower::Pa::PaBind(n) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::Pa::PaMut(n) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n)));
            }
            if let lower::Pa::PaCtor(c, ps) = p_ {
                break 'm11616 {
                    let c = c.clone();
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11710: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c, &lexer::join(&each_11710, &Text::from(", "))))))
                };
            }
            if let lower::Pa::PaUnit(c) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(c.clone());
            }
            if let lower::Pa::PaRecord(c, fs, rest) = p_ {
                break 'm11616 {
                    let c = c.clone();
                    let fs = fs.clone();
                    let rest = *rest;
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
                        let (f, q) = p0;
                        match &q {
                            lower::Pa::PaBind(n) => if n == &f {
                                prism_rtl::Turn::Finished(f.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                            },
                            _ => call_then(start_pattern(q.clone()), move |pattern_11918: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_11918)))),
                        }
                    }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11806: Array<Text>| {
                        let parts = each_11806;
                        let all = if rest { push(&parts, &Text::from("..")) } else { parts.clone() };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c, &lexer::join(&all, &Text::from(", ")))))
                    })
                };
            }
            if let lower::Pa::PaTuple(m11616_6_0) = p_ && (m11616_6_0.len() == 1) && let Some(one) = index(m11616_6_0, &Nat::from(0u32)) {
                break 'm11616 call_then(start_pattern(one.clone()), move |pattern_12047: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_12047))));
            }
            if let lower::Pa::PaTuple(ps) = p_ {
                break 'm11616 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12088: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &lexer::join(&each_12088, &Text::from(", "))))))
                };
            }
            if let lower::Pa::PaChar(c) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &lower::char_escape(c))));
            }
            if let lower::Pa::PaBool(b) = p_ {
                break 'm11616 if *b {
                    prism_rtl::Turn::Finished(Text::from("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::from("false"))
                };
            }
            if let lower::Pa::PaIndex(n) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let lower::Pa::PaConst(n) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let lower::Pa::PaSlice(ps) = p_ {
                break 'm11616 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12269: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &lexer::join(&each_12269, &Text::from(", "))))))
                };
            }
            if let lower::Pa::PaRest(m11616_13_0) = p_ && (m11616_13_0 == &Text::from("")) {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(".."));
            }
            if let lower::Pa::PaRest(n) = p_ {
                break 'm11616 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n)));
            }
            if let lower::Pa::PaTyped(q, t) = p_ {
                break 'm11616 {
                    let q = (**q).clone();
                    let t = t.clone();
                    call_then(start_pattern(q.clone()), move |pattern_12368: Text| call_then(start_type_(t.clone()), move |type__12381: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_12368, &type__12381)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern(p_: lower::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_ })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements(dos: &Array<lower::Do>) -> Text {
    lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
    }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
        }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12455: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_12455, &Text::from("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements(dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement(d: &lower::Do) -> Text {
    match d {
        lower::Do::DoLet(p_, x) => Text::from(format!("let {} = {};", &pattern(p_), &expression(x))),
        lower::Do::DoLetElse(p_, x, e) => Text::from(format!("let {} = {} else {{ {} }};", &pattern(p_), &expression(x), &expression(e))),
        lower::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &expression(p_), &expression(x))),
        lower::Do::DoWhile(c, body) => rust_templates::if_stmt(&Text::from(format!("while {}", &expression(c))), &statements(body)),
        lower::Do::DoWhileLet(p_, x, body) => rust_templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern(p_), &expression(x))), &statements(body)),
        lower::Do::DoFor(p_, x, body) => rust_templates::if_stmt(&Text::from(format!("for {} in {}", &pattern(p_), &expression(x))), &statements(body)),
        lower::Do::DoExpr(x) => Text::from(format!("{};", &expression(x))),
        lower::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if {}", &expression(c))), &statements(t)), &else_branch(e))),
        lower::Do::DoIfLet(p_, x, t, e) => Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern(p_), &expression(x))), &statements(t)), &else_branch(e))),
        lower::Do::DoMatch(x, cases) => rust_templates::match_(&expression(x), &lexer::join(&run_to_end(each_job(cases.clone(), Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| entered(once_job(move || {
            let (p_, body) = p0;
            call_then(start_pattern(p_.clone()), move |pattern_13292: Text| call_then(start_statements(body.clone()), move |statements_13305: Text| prism_rtl::Turn::Finished(rust_templates::arm_block(&pattern_13292, &statements_13305))))
        }))) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))),
        lower::Do::DoReturn(x) => Text::from(format!("return {};", &expression(x))),
        lower::Do::DoScope(body) => Text::from(format!("{{ {} }};", &inline_statements(body))),
        lower::Do::DoLine(body) => Text::from(format!("{};", &inline_statements(body))),
        lower::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d: lower::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d = &self.d;
        match d {
            lower::Do::DoLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12573: Text| call_then(start_expression(x.clone()), move |expression_12587: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_12573, &expression_12587)))))
            },
            lower::Do::DoLetElse(p_, x, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12632: Text| call_then(start_expression(x.clone()), move |expression_12646: Text| call_then(start_expression(e.clone()), move |expression_12669: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_12632, &expression_12646, &expression_12669))))))
            },
            lower::Do::DoAssign(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_expression(p_.clone()), move |expression_12709: Text| call_then(start_expression(x.clone()), move |expression_12726: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_12709, &expression_12726)))))
            },
            lower::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                call_then(start_expression(c.clone()), move |expression_12778: Text| call_then(start_statements(body.clone()), move |statements_12795: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("while {}", &expression_12778)), &statements_12795))))
            },
            lower::Do::DoWhileLet(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12858: Text| call_then(start_expression(x.clone()), move |expression_12872: Text| call_then(start_statements(body.clone()), move |statements_12889: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern_12858, &expression_12872)), &statements_12889)))))
            },
            lower::Do::DoFor(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12941: Text| call_then(start_expression(x.clone()), move |expression_12956: Text| call_then(start_statements(body.clone()), move |statements_12973: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("for {} in {}", &pattern_12941, &expression_12956)), &statements_12973)))))
            },
            lower::Do::DoExpr(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13006: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_13006))))
            },
            lower::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_13054: Text| call_then(start_statements(t.clone()), move |statements_13071: Text| call_then(start_else_branch(e.clone()), move |else_branch_13086: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if {}", &expression_13054)), &statements_13071), &else_branch_13086))))))
            },
            lower::Do::DoIfLet(p_, x, t, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13143: Text| call_then(start_expression(x.clone()), move |expression_13157: Text| call_then(start_statements(t.clone()), move |statements_13174: Text| call_then(start_else_branch(e.clone()), move |else_branch_13189: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern_13143, &expression_13157)), &statements_13174), &else_branch_13189)))))))
            },
            lower::Do::DoMatch(x, cases) => {
                let cases = cases.clone();
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13233: Text| call_value(each_job(cases.clone(), Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pattern(p_.clone()), move |pattern_13292: Text| call_then(start_statements(body.clone()), move |statements_13305: Text| prism_rtl::Turn::Finished(rust_templates::arm_block(&pattern_13292, &statements_13305))))
                }))) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13255: Array<Text>| prism_rtl::Turn::Finished(rust_templates::match_(&expression_13233, &lexer::join(&each_13255, &Text::from("\n"))))))
            },
            lower::Do::DoReturn(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13355: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_13355))))
            },
            lower::Do::DoScope(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13394: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_13394))))
            },
            lower::Do::DoLine(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13441: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_13441))))
            },
            lower::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement(d: lower::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements(dos: &Array<lower::Do>) -> Text {
    lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
    }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
        }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13614: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_13614, &Text::from(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements(dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement(do_0: &lower::Do) -> Text {
    match do_0 {
        lower::Do::DoIf(c, t, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression(c), &inline_statements(t))),
        d => statement(d),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: lower::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            lower::Do::DoIf(c, t, j0_0_2) if (j0_0_2.len() == 0) => {
                let c = c.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_13739: Text| call_then(start_inline_statements(t.clone()), move |inline_statements_13757: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_13739, &inline_statements_13757)))))
            },
            d => prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement(do_0: lower::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch(xs0: &Array<lower::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::from("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&lower::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs0 {
            break 'c rust_templates::else_(&statements(body));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::from(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(j1_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(lower::Do::DoIf(c.clone(), t.clone(), e.clone())), move |statement_13969: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_13969))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(j2_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |statement_14045: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_14045))));
            }
            if let body = xs0 {
                break 'j {
                    let body = body.clone();
                    call_then(start_statements(body.clone()), move |statements_14105: Text| prism_rtl::Turn::Finished(rust_templates::else_(&statements_14105)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch(xs0: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics(xs0: &Array<(Text, Array<Text>)>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::from(""),
        gs => Text::from(format!("<{}>", &lexer::join(&each(gs, &(|(g, bs): &(Text, Array<Text>)| if &len(bs) == &Nat::from(0u32) {
            g.clone()
        } else {
            Text::from(format!("{}: {}", g, &lexer::join(bs, &Text::from(" + "))))
        })), &Text::from(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::from(""),
        ps => Text::from(format!("<{}>", &lexer::join(ps, &Text::from(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded(xs0: &Array<Text>, text1: &Text) -> Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => Text::from(""),
        (ps, tr) => Text::from(format!("<{}>", &lexer::join(&each(ps, &(|p_: &Text| Text::from(format!("{}: {}", p_, tr)))), &Text::from(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item(it: &lower::Item) -> Text {
    match it {
        lower::Item::ItTrait(t) => rust_trait(t),
        lower::Item::ItImpl(i) => rust_impl(i),
        lower::Item::ItType(t) => type_decl(t),
        lower::Item::ItTag(t) => rust_tag(t),
        lower::Item::ItRow(r) => rust_row(r),
        lower::Item::ItFn(f) => rust_fn(f),
        lower::Item::ItJob(j) => rust_job(j),
        lower::Item::ItNode(n) => rust_node(n),
        lower::Item::ItNote(t) => Text::from(format!("// {}\n", t)),
        lower::Item::ItRefused(t) => Text::from(format!("compile_error!(\"{}{}\");\n", &lower::lowering_refusal(), &lower::escape(t))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it: lower::Item,
}

impl prism_rtl::Job<Text> for RustItem {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let it = &self.it;
        match it {
            lower::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(RustTrait { t: t.clone() })),
            lower::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(RustImpl { i: i.clone() })),
            lower::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeDecl { t: t.clone() })),
            lower::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(RustTag { t: t.clone() })),
            lower::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RustRow { r: r.clone() })),
            lower::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() })),
            lower::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(RustJob { j: j.clone() })),
            lower::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(RustNode { n: n.clone() })),
            lower::Item::ItNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}\n", t))),
            lower::Item::ItRefused(t) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\");\n", &lower::lowering_refusal(), &lower::escape(t)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item(it: lower::Item) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustItem { it })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait(t: &lower::TraitDef) -> Text {
    let ms = lexer::join(&run_to_end(each_job(t.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
        let f = p0;
        prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
    }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &rust_templates::source_doc(&Text::from(""), &t.doc), &t.name, &indent(&ms)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t: lower::TraitDef,
}

impl prism_rtl::Job<Text> for RustTrait {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
            let f = p0;
            prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
        }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15138: Array<Text>| {
            let ms = lexer::join(&each_15138, &Text::from("\n"));
            prism_rtl::Turn::Finished(Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &rust_templates::source_doc(&Text::from(""), &t.doc), &t.name, &indent(&ms))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait(t: lower::TraitDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTrait { t })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature(f: &lower::FnDef, vis: &Text) -> Text {
    let params = lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__15371: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15371))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "));
    Text::from(format!("{}fn {}{}({}) -> {}", vis, &f.name, &generics(&f.generics), &params, &type_(&f.ret)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f: lower::FnDef,
    pub vis: Text,
}

impl prism_rtl::Job<Text> for Signature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let vis = &self.vis;
        let f = f.clone();
        let vis = vis.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__15371: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15371))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15337: Array<Text>| {
            let params = lexer::join(&each_15337, &Text::from(", "));
            call_then(start_type_(f.ret.clone()), move |type__15444: Text| prism_rtl::Turn::Finished(Text::from(format!("{}fn {}{}({}) -> {}", &vis, &f.name, &generics(&f.generics), &params, &type__15444))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature(f: lower::FnDef, vis: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Signature { f, vis })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method(f: &lower::FnDef) -> Text {
    if f.public {
        rust_templates::fn_(&Text::from(""), &signature(f, &Text::from("")), &body_lines(&f.body))
    } else {
        Text::from(format!("{};", &signature(f, &Text::from(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for TraitMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        if f.public {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::from("")), move |signature_15538: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_15557: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::from(""), &signature_15538, &body_lines_15557))))
            }
        } else {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::from("")), move |signature_15583: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &signature_15583))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method(f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TraitMethod { f })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl(i: &lower::ImplDef) -> Text {
    let head = type_(&i.head);
    let gens = generics(&i.generics);
    match &i.cls {
        m15858_0 if (m15858_0 == &Text::from("Prelude.Show")) => {
            let fns = lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
            let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::from("show"));
            Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::from("Show"), &head, &Text::from("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown)))))
        },
        m15858_1 if (m15858_1 == &Text::from("Prelude.Eq")) => {
            let fns = lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
            let eq = fold(&i.methods, &Text::from(""), &(|acc: &Text, f: &lower::FnDef| if (&take_text(&f.name, &Nat::from(2u32)) != &Text::from("ne")) && (acc == &Text::from("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::from("PartialEq"), &head, &Text::from("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq)))))
        },
        _ => Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
            let f = p0;
            call_then(start_signature(f.clone(), Text::from("")), move |signature_16554: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_16573: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::from(""), &signature_16554, &body_lines_16573))))
        }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i: lower::ImplDef,
}

impl prism_rtl::Job<Text> for RustImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let i = &self.i;
        let i = i.clone();
        call_then(start_type_(i.head.clone()), move |type__15807: Text| {
            let head = type__15807;
            let gens = generics(&i.generics);
            match &i.cls {
                m15858_0 if (m15858_0 == &Text::from("Prelude.Show")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15923: Array<Text>| {
                    let fns = lexer::join(&each_15923, &Text::from("\n"));
                    let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::from("show"));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::from("Show"), &head, &Text::from("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown))))))
                }),
                m15858_1 if (m15858_1 == &Text::from("Prelude.Eq")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16198: Array<Text>| {
                    let fns = lexer::join(&each_16198, &Text::from("\n"));
                    let eq = fold(&i.methods, &Text::from(""), &(|acc: &Text, f: &lower::FnDef| if (&take_text(&f.name, &Nat::from(2u32)) != &Text::from("ne")) && (acc == &Text::from("")) {
                        f.name.clone()
                    } else {
                        acc.clone()
                    }));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::from("PartialEq"), &head, &Text::from("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq))))))
                }),
                _ => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    call_then(start_signature(f.clone(), Text::from("")), move |signature_16554: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_16573: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::from(""), &signature_16554, &body_lines_16573))))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16525: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&lexer::join(&each_16525, &Text::from("\n"))))))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl(i: lower::ImplDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustImpl { i })
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn(f: &lower::FnDef) -> Text {
    let params = lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__16713: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__16713))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "));
    let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type_(&f.ret)));
    rust_templates::fn_(&rust_templates::source_doc(&Text::from(""), &f.doc), &sig, &body_lines(&f.body))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for RustFn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let f = f.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__16713: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__16713))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16679: Array<Text>| {
            let params = lexer::join(&each_16679, &Text::from(", "));
            call_then(start_type_(f.ret.clone()), move |type__16943: Text| {
                let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type__16943));
                call_then(start_body_lines(f.body.clone()), move |body_lines_16992: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&rust_templates::source_doc(&Text::from(""), &f.doc), &sig, &body_lines_16992)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn(f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustFn { f })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics(gs: &Array<(Text, Array<Text>)>) -> Text {
    generics(&each(gs, &(|(g, bs): &(Text, Array<Text>)| (g.clone(), push(bs, &Text::from("'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job(j: &lower::JobDef) -> Text {
    let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
    let fields = lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17398: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17398))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let params = lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17472: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17472))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "));
    let bounded_ = static_generics(&j.generics);
    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type_(&j.ret)));
    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| n.clone())), &Text::from(", "))));
    rust_templates::job(&rust_templates::source_doc(&Text::from(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type_(&j.ret), &body_lines(&j.body), &start, &start_body)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j: lower::JobDef,
}

impl prism_rtl::Job<Text> for RustJob {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let j = &self.j;
        let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
        let j = j.clone();
        call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__17398: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17398))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17360: Array<Text>| {
            let fields = lexer::join(&each_17360, &Text::from("\n"));
            call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_type_(t.clone()), move |type__17472: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17472))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17438: Array<Text>| {
                let params = lexer::join(&each_17438, &Text::from(", "));
                let bounded_ = static_generics(&j.generics);
                call_then(start_type_(j.ret.clone()), move |type__17696: Text| {
                    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type__17696));
                    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| n.clone())), &Text::from(", "))));
                    call_then(start_type_(j.ret.clone()), move |type__17871: Text| call_then(start_body_lines(j.body.clone()), move |body_lines_17885: Text| prism_rtl::Turn::Finished(rust_templates::job(&rust_templates::source_doc(&Text::from(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type__17871, &body_lines_17885, &start, &start_body))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job(j: lower::JobDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustJob { j })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl(t: &lower::TyDef) -> Text {
    let eq = t.eq && !t.floaty;
    let ord = t.ord && !t.floaty;
    let derives = lexer::join(&filter(&Array::from(vec![Text::from("Clone"), if t.eq || t.ord { Text::from("PartialEq") } else { Text::from("") }, if eq || ord { Text::from("Eq") } else { Text::from("") }, if t.ord { Text::from("PartialOrd") } else { Text::from("") }, if ord { Text::from("Ord") } else { Text::from("") }]), &(|d: &Text| d != &Text::from(""))), &Text::from(", "));
    let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
    let doc = rust_templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let decl = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            rust_templates::struct_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (f, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__18643: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__18643))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
        },
        lower::TyShape::ShapeUnit => rust_templates::tuple_struct(&doc, &derives, &head, &Text::from("")),
        lower::TyShape::ShapeNewtype => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            rust_templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (_, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__18907: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__18907))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", ")))))
        },
        _ => rust_templates::enum_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: lower::CaseDef| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
        }))) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))),
    };
    let show_ = if &t.show == &lower::Shown::ShownDerived {
        Text::from(format!("\n{}", &show_impl(t, &head)))
    } else {
        Text::from("")
    };
    let pod = if t.pod {
        Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
    } else {
        Text::from("")
    };
    Text::from(format!("{}{}{}", &decl, &show_, &pod))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t: lower::TyDef,
}

impl prism_rtl::Job<Text> for TypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let eq = t.eq && !t.floaty;
        let ord = t.ord && !t.floaty;
        let derives = lexer::join(&filter(&Array::from(vec![Text::from("Clone"), if t.eq || t.ord { Text::from("PartialEq") } else { Text::from("") }, if eq || ord { Text::from("Eq") } else { Text::from("") }, if t.ord { Text::from("PartialOrd") } else { Text::from("") }, if ord { Text::from("Ord") } else { Text::from("") }]), &(|d: &Text| d != &Text::from(""))), &Text::from(", "));
        let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
        let doc = rust_templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let decl = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                rust_templates::struct_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (f, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__18643: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__18643))))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
            },
            lower::TyShape::ShapeUnit => rust_templates::tuple_struct(&doc, &derives, &head, &Text::from("")),
            lower::TyShape::ShapeNewtype => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                rust_templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__18907: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__18907))))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", ")))))
            },
            _ => rust_templates::enum_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: lower::CaseDef| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
            }))) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))),
        };
        let show_ = if &t.show == &lower::Shown::ShownDerived {
            Text::from(format!("\n{}", &show_impl(t, &head)))
        } else {
            Text::from("")
        };
        let pod = if t.pod {
            Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
        } else {
            Text::from("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &decl, &show_, &pod)))
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl(t: lower::TyDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDecl { t })
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case(c: &lower::CaseDef) -> Text {
    if &len(&c.fields) == &Nat::from(0u32) {
        Text::from(format!("{},", &c.name))
    } else {
        Text::from(format!("{}({}),", &c.name, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (_, ft) = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c: lower::CaseDef,
}

impl prism_rtl::Job<Text> for EnumCase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        if &len(&c.fields) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("{},", &c.name)))
        } else {
            {
                let c = c.clone();
                call_value(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_19309: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.name, &lexer::join(&each_19309, &Text::from(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case(c: lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(EnumCase { c })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders(n: &Nat) -> Array<Text> {
    each(&check_errors::range0(n), &(|i: &Nat| Text::from(format!("a{}", i))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern(t: &lower::TyDef, c: &lower::CaseDef) -> Text {
    match &t.shape {
        lower::TyShape::ShapeNewtype => Text::from(format!("{}({})", &t.name, &lexer::join(&binders(&len(&c.fields)), &Text::from(", ")))),
        lower::TyShape::ShapeUnit => t.name.clone(),
        _ => if &len(&c.fields) == &Nat::from(0u32) {
            Text::from(format!("{}::{}", &t.name, &c.name))
        } else {
            Text::from(format!("{}::{}({})", &t.name, &c.name, &lexer::join(&binders(&len(&c.fields)), &Text::from(", "))))
        },
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::from(", "))))
        },
        _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&binders(&len(&c.fields)), &Text::from(", ")))))), &Text::from("\n"))),
    };
    rust_templates::impl_(&bounded(&t.params, &Text::from("Show")), &Text::from("Show"), head, &Text::from("fn show(&self, p: &mut Printer)"), &body)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ShowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::from(", "))))
            },
            _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&binders(&len(&c.fields)), &Text::from(", ")))))), &Text::from("\n"))),
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::from("Show")), &Text::from("Show"), head, &Text::from("fn show(&self, p: &mut Printer)"), &body))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowImpl { t, head })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &drop_text(f, &lexer::dec(&len_text(f))) == &Text::from("_") {
        take_text(f, &lexer::dec(&len_text(f)))
    } else {
        f.clone()
    }
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::from(", "))))
        },
        _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::from(", ")))))), &Text::from("\n"))),
    };
    let shown = if &t.show == &lower::Shown::ShownOwn {
        rust_templates::shown_pod(&body)
    } else {
        body.clone()
    };
    rust_templates::impl_(&bounded(&t.params, &Text::from("ToPod")), &Text::from("ToPod"), head, &Text::from("fn to_pod(&self) -> Pod"), &shown)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ToPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::from(", "))))
            },
            _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::from(", ")))))), &Text::from("\n"))),
        };
        let shown = if &t.show == &lower::Shown::ShownOwn {
            rust_templates::shown_pod(&body)
        } else {
            body.clone()
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::from("ToPod")), &Text::from("ToPod"), head, &Text::from("fn to_pod(&self) -> Pod"), &shown))
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodImpl { t, head })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
            Text::from(format!("Ok({} {{ {} }})", &t.name, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::from(", "))))
        },
        _ => {
            let arms_ = each(&t.cases, &(|c: &lower::CaseDef| {
                let n = len(&c.fields);
                let made = if &n == &Nat::from(0u32) {
                    if &t.shape == &lower::TyShape::ShapeUnit {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }
                } else {
                    Text::from(format!("{}({})", &(if &t.shape == &lower::TyShape::ShapeNewtype {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }), &lexer::join(&each(&check_errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::from(", "))))
                };
                Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
            }));
            rust_templates::from_pod_body(&lexer::join(&arms_, &Text::from("\n")), &Text::from(format!("a {}", &t.prism)))
        },
    };
    rust_templates::impl_(&bounded(&t.params, &Text::from("FromPod")), &Text::from("FromPod"), head, &Text::from("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for FromPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::from(""), prism: Text::from(""), fields: Array::new() });
                Text::from(format!("Ok({} {{ {} }})", &t.name, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::from(", "))))
            },
            _ => {
                let arms_ = each(&t.cases, &(|c: &lower::CaseDef| {
                    let n = len(&c.fields);
                    let made = if &n == &Nat::from(0u32) {
                        if &t.shape == &lower::TyShape::ShapeUnit {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }
                    } else {
                        Text::from(format!("{}({})", &(if &t.shape == &lower::TyShape::ShapeNewtype {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }), &lexer::join(&each(&check_errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::from(", "))))
                    };
                    Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
                }));
                rust_templates::from_pod_body(&lexer::join(&arms_, &Text::from("\n")), &Text::from(format!("a {}", &t.prism)))
            },
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::from("FromPod")), &Text::from("FromPod"), head, &Text::from("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodImpl { t, head })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag(t: &lower::TagDef) -> Text {
    let fields = lexer::join(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, lower::OutTy)| entered(once_job(move || {
        let (_, f, ft) = p0;
        call_then(start_type_(ft.clone()), move |type__22336: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22336))))
    }))) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::from(", "));
    let derives = if t.pod { Text::from("Clone, PartialEq") } else { Text::from("Clone") };
    let reads = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::from(", "));
    let back = if t.pod {
        Text::from(format!("\n{}", &rust_templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
    } else {
        Text::from("")
    };
    Text::from(format!("{}{}", &rust_templates::tag(&rust_templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t: lower::TagDef,
}

impl prism_rtl::Job<Text> for RustTag {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, lower::OutTy)| entered(once_job(move || {
            let (_, f, ft) = p0;
            call_then(start_type_(ft.clone()), move |type__22336: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22336))))
        }))) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_22289: Array<Text>| {
            let fields = lexer::join(&each_22289, &Text::from("\n"));
            let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::from(", "));
            let derives = if t.pod { Text::from("Clone, PartialEq") } else { Text::from("Clone") };
            let reads = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::from(", "));
            let back = if t.pod {
                Text::from(format!("\n{}", &rust_templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
            } else {
                Text::from("")
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::tag(&rust_templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back)))
        })
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag(t: lower::TagDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTag { t })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row(r: &lower::RowDef) -> Text {
    let derives = if r.pod { Text::from("Clone, PartialEq") } else { Text::from("Clone") };
    let cases = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::from("\n"));
    let pods = lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::from("\n"));
    let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::from("\n"));
    let back = if r.pod {
        Text::from(format!("\n{}", &rust_templates::row_from_pod(&r.name, &reads)))
    } else {
        Text::from("")
    };
    let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
        Text::from("_ => unreachable!(),")
    } else {
        pods.clone()
    };
    Text::from(format!("{}{}", &rust_templates::row(&rust_templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r: lower::RowDef,
}

impl prism_rtl::Job<Text> for RustRow {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let r = &self.r;
        let derives = if r.pod { Text::from("Clone, PartialEq") } else { Text::from("Clone") };
        let cases = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::from("\n"));
        let pods = lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::from("\n"));
        let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::from("\n"));
        let back = if r.pod {
            Text::from(format!("\n{}", &rust_templates::row_from_pod(&r.name, &reads)))
        } else {
            Text::from("")
        };
        let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
            Text::from("_ => unreachable!(),")
        } else {
            pods.clone()
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::row(&rust_templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row(r: lower::RowDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRow { r })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer(a: &lower::AnswerDef) -> Text {
    let cases = lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__23993: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__23993))))
    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let tags = if &len(&a.cases) == &Nat::from(0u32) {
        Text::from("_ => unreachable!(),")
    } else {
        lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::from("\n"))
    };
    let accessors = lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__24255: Text| prism_rtl::Turn::Finished(rust_templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24255)))
    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let decodes = if &len(&a.cases) == &Nat::from(0u32) {
        Text::from("_ => unreachable!(),")
    } else {
        lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_decode_head(c.ty.clone()), move |decode_head_24418: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24418))))
        }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))
    };
    rust_templates::answer_type(&cases, &tags, &accessors, &decodes)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a: lower::AnswerDef,
}

impl prism_rtl::Job<Text> for RustAnswer {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let a = a.clone();
        call_value(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_type_(c.ty.clone()), move |type__23993: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__23993))))
        }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_23960: Array<Text>| {
            let cases = lexer::join(&each_23960, &Text::from("\n"));
            let tags = if &len(&a.cases) == &Nat::from(0u32) {
                Text::from("_ => unreachable!(),")
            } else {
                lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::from("\n"))
            };
            call_value(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
                let c = p0;
                call_then(start_type_(c.ty.clone()), move |type__24255: Text| prism_rtl::Turn::Finished(rust_templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24255)))
            }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24188: Array<Text>| {
                let accessors = lexer::join(&each_24188, &Text::from("\n"));
                let decodes = if &len(&a.cases) == &Nat::from(0u32) {
                    Text::from("_ => unreachable!(),")
                } else {
                    lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
                        let c = p0;
                        call_then(start_decode_head(c.ty.clone()), move |decode_head_24418: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24418))))
                    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"))
                };
                prism_rtl::Turn::Finished(rust_templates::answer_type(&cases, &tags, &accessors, &decodes))
            })
        })
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer(a: lower::AnswerDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustAnswer { a })
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node(n: &lower::NodeDef) -> Text {
    let fields = lexer::join(&run_to_end(each_job(n.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy, Text)| entered(once_job(move || {
        let (f, t, doc) = p0;
        call_then(start_type_(t.clone()), move |type__24835: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &rust_templates::doc(&doc), &f, &type__24835))))
    }))) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &rust_templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
    let params = concat(&run_to_end(each_job(n.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__25013: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25013))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if n.fallible {
        Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
    } else {
        Text::from(format!("Rc<{}>", &n.name))
    };
    let inits = lexer::join(&append(&Array::from(vec![Text::from("path")]), &run_to_end(each_job(n.inits.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
        let (f, v_) = p0;
        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
    }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::from(", "));
    let tail = if n.fallible { Text::from("Ok(node)") } else { Text::from("node") };
    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
        tail.clone()
    } else {
        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
    };
    let build = rust_templates::build(&n.name, &params, &ret, &statements(&n.lets), &inits, &rest_text);
    let methods = lexer::join(&run_to_end(each_job(n.methods.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Text::from("")
    } else {
        rust_templates::answer(&lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (lower::Pa, lower::Ex)| entered(once_job(move || {
            let (pat, call) = p0;
            call_then(start_pattern(pat.clone()), move |pattern_25579: Text| call_then(start_expression(call.clone()), move |expression_25596: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_25579, &expression_25596)))))
        }))) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
    };
    let builders = concat(&append(&run_to_end(each_job(n.builders.clone(), Rc::new(move |p0: lower::ForDef| entered(once_job(move || {
        let b = p0;
        call_then(start_for_builder(b.clone()), move |for_builder_25684: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_25684))))
    }))) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &run_to_end(each_job(n.gens.clone(), Rc::new(move |p0: lower::GenDef| entered(once_job(move || {
        let gd = p0;
        call_then(start_gen_builder(gd.clone()), move |gen_builder_25725: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_25725))))
    }))) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>))));
    let row_impl = if &n.row_kind == &lower::RowKind::NotARow {
        Text::from("")
    } else {
        Text::from(format!("\n{}", &rust_row_impl(n)))
    };
    let hooks = lexer::join(&run_to_end(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<lower::Do>)| entered(once_job(move || {
        let (h, body) = p0;
        if &h == &Text::from("push") {
            call_then(start_statements(body.clone()), move |statements_25892: Text| prism_rtl::Turn::Finished(rust_templates::push_hook(&statements_25892)))
        } else {
            call_then(start_statements(body.clone()), move |statements_25924: Text| prism_rtl::Turn::Finished(rust_templates::hook(&h, &statements_25924)))
        }
    }))) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n"));
    let doc = rust_templates::source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    Text::from(format!("{}{}", &rust_templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for RustNode {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let n = n.clone();
        call_value(each_job(n.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy, Text)| entered(once_job(move || {
            let (f, t, doc) = p0;
            call_then(start_type_(t.clone()), move |type__24835: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &rust_templates::doc(&doc), &f, &type__24835))))
        }))) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24787: Array<Text>| {
            let fields = lexer::join(&each_24787, &Text::from("\n"));
            let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &rust_templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
            call_value(each_job(n.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_type_(t.clone()), move |type__25013: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25013))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24979: Array<Text>| {
                let params = concat(&each_24979);
                let ret = if n.fallible {
                    Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
                } else {
                    Text::from(format!("Rc<{}>", &n.name))
                };
                call_value(each_job(n.inits.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                    let (f, v_) = p0;
                    prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25147: Array<Text>| {
                    let inits = lexer::join(&append(&Array::from(vec![Text::from("path")]), &each_25147), &Text::from(", "));
                    let tail = if n.fallible { Text::from("Ok(node)") } else { Text::from("node") };
                    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
                        tail.clone()
                    } else {
                        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
                    };
                    call_then(start_statements(n.lets.clone()), move |statements_25378: Text| {
                        let build = rust_templates::build(&n.name, &params, &ret, &statements_25378, &inits, &rest_text);
                        call_value(each_job(n.methods.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
                        }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25438: Array<Text>| {
                            let methods = lexer::join(&each_25438, &Text::from("\n"));
                            let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                Text::from("")
                            } else {
                                rust_templates::answer(&lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (lower::Pa, lower::Ex)| entered(once_job(move || {
                                    let (pat, call) = p0;
                                    call_then(start_pattern(pat.clone()), move |pattern_25579: Text| call_then(start_expression(call.clone()), move |expression_25596: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_25579, &expression_25596)))))
                                }))) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
                            };
                            call_value(each_job(n.builders.clone(), Rc::new(move |p0: lower::ForDef| entered(once_job(move || {
                                let b = p0;
                                call_then(start_for_builder(b.clone()), move |for_builder_25684: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_25684))))
                            }))) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25658: Array<Text>| call_value(each_job(n.gens.clone(), Rc::new(move |p0: lower::GenDef| entered(once_job(move || {
                                let gd = p0;
                                call_then(start_gen_builder(gd.clone()), move |gen_builder_25725: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_25725))))
                            }))) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25702: Array<Text>| {
                                let builders = concat(&append(&each_25658, &each_25702));
                                let row_impl = if &n.row_kind == &lower::RowKind::NotARow {
                                    Text::from("")
                                } else {
                                    Text::from(format!("\n{}", &rust_row_impl(&n)))
                                };
                                call_value(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<lower::Do>)| entered(once_job(move || {
                                    let (h, body) = p0;
                                    if &h == &Text::from("push") {
                                        call_then(start_statements(body.clone()), move |statements_25892: Text| prism_rtl::Turn::Finished(rust_templates::push_hook(&statements_25892)))
                                    } else {
                                        call_then(start_statements(body.clone()), move |statements_25924: Text| prism_rtl::Turn::Finished(rust_templates::hook(&h, &statements_25924)))
                                    }
                                }))) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25837: Array<Text>| {
                                    let hooks = lexer::join(&each_25837, &Text::from("\n"));
                                    let doc = rust_templates::source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                                    prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl)))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node(n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustNode { n })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder(b: &lower::ForDef) -> Text {
    rust_templates::for_build(&b.name, &expression(&b.at), &type_(&b.key_ty), &type_(&b.value_ty), &b.row_node, &b.source, &expression(&b.parent), &concat(&run_to_end(each_job(b.passed.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
        let x = p0;
        call_then(start_expression(x.clone()), move |expression_26415: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26415))))
    }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>))))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b: lower::ForDef,
}

impl prism_rtl::Job<Text> for ForBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let b = &self.b;
        let b = b.clone();
        call_then(start_expression(b.at.clone()), move |expression_26286: Text| call_then(start_type_(b.key_ty.clone()), move |type__26305: Text| call_then(start_type_(b.value_ty.clone()), move |type__26321: Text| call_then(start_expression(b.parent.clone()), move |expression_26360: Text| call_value(each_job(b.passed.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let x = p0;
            call_then(start_expression(x.clone()), move |expression_26415: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26415))))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26391: Array<Text>| prism_rtl::Turn::Finished(rust_templates::for_build(&b.name, &expression_26286, &type__26305, &type__26321, &b.row_node, &b.source, &expression_26360, &concat(&each_26391))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder(b: lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuilder { b })
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder(gd: &lower::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::from("self.path.clone()")
    } else {
        Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
    };
    rust_templates::gen_build(&gd.name, &expression(&gd.at), &path_, &expression(&gd.source), &type_(&gd.value_ty), &expression(&gd.select))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd: lower::GenDef,
}

impl prism_rtl::Job<Text> for GenBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::from("self.path.clone()")
        } else {
            Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
        };
        let gd = gd.clone();
        call_then(start_expression(gd.at.clone()), move |expression_26809: Text| call_then(start_expression(gd.source.clone()), move |expression_26835: Text| call_then(start_type_(gd.value_ty.clone()), move |type__26859: Text| call_then(start_expression(gd.select.clone()), move |expression_26878: Text| prism_rtl::Turn::Finished(rust_templates::gen_build(&gd.name, &expression_26809, &path_, &expression_26835, &type__26859, &expression_26878))))))
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder(gd: lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuilder { gd })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl(n: &lower::NodeDef) -> Text {
    let kept = if &n.row_kind == &lower::RowKind::ForRow {
        Array::from(vec![Text::from("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
    rust_templates::row_impl(&n.name, &lexer::join(&append(&push(&kept, &Text::from("self.remove_places(cx);")), &unsubscribe), &Text::from("\n")), &lexer::join(&run_to_end(each_job(n.hosted.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for RustRowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let kept = if &n.row_kind == &lower::RowKind::ForRow {
            Array::from(vec![Text::from("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
        let n = n.clone();
        call_value(each_job(n.hosted.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
            let m = p0;
            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
        }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_27576: Array<Text>| prism_rtl::Turn::Finished(rust_templates::row_impl(&n.name, &lexer::join(&append(&push(&kept, &Text::from("self.remove_places(cx);")), &unsubscribe), &Text::from("\n")), &lexer::join(&each_27576, &Text::from("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl(n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRowImpl { n })
}

/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub fn rust_method(m: &lower::MethDef) -> Text {
    let recv = match &m.recv {
        lower::Recv::RecvRc => Text::from("self: &Rc<Self>"),
        lower::Recv::RecvRef => Text::from("&self"),
        lower::Recv::RecvOwned => Text::from("self: Rc<Self>"),
    };
    let cx_ = match &m.cx_ {
        lower::CxArg::CxMut => Text::from(", cx: &mut Cx"),
        lower::CxArg::CxRef => Text::from(", cx: &Cx"),
        lower::CxArg::CxNone => Text::from(""),
    };
    let params = concat(&run_to_end(each_job(m.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__27963: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__27963))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if &m.ret == &lower::OutTy::OutUnit {
        Text::from("")
    } else {
        Text::from(format!(" -> {}", &type_(&m.ret)))
    };
    let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
    let body = if &m.ret == &lower::OutTy::OutUnit {
        statements(&m.body)
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            body_lines(&m.tail)
        } else {
            Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
        }
    };
    rust_templates::method(&rust_templates::doc(&m.doc), &sig, &body)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub struct RustMethod {
    pub m: lower::MethDef,
}

impl prism_rtl::Job<Text> for RustMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let recv = match &m.recv {
            lower::Recv::RecvRc => Text::from("self: &Rc<Self>"),
            lower::Recv::RecvRef => Text::from("&self"),
            lower::Recv::RecvOwned => Text::from("self: Rc<Self>"),
        };
        let cx_ = match &m.cx_ {
            lower::CxArg::CxMut => Text::from(", cx: &mut Cx"),
            lower::CxArg::CxRef => Text::from(", cx: &Cx"),
            lower::CxArg::CxNone => Text::from(""),
        };
        let m = m.clone();
        call_value(each_job(m.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (p_, t) = p0;
            call_then(start_type_(t.clone()), move |type__27963: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__27963))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_27927: Array<Text>| {
            let params = concat(&each_27927);
            let ret = if &m.ret == &lower::OutTy::OutUnit {
                Text::from("")
            } else {
                Text::from(format!(" -> {}", &type_(&m.ret)))
            };
            let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
            let body = if &m.ret == &lower::OutTy::OutUnit {
                statements(&m.body)
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    body_lines(&m.tail)
                } else {
                    Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
                }
            };
            prism_rtl::Turn::Finished(rust_templates::method(&rust_templates::doc(&m.doc), &sig, &body))
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method(m: lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustMethod { m })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program(p_: &lower::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
    let decode = if &n == &Nat::from(0u32) {
        Text::from("let _ = args;")
    } else {
        decode_args(p_, &names)
    };
    let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::from("?") } else { Text::from("") })));
    rust_templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_: lower::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for RustProgram {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
        let decode = if &n == &Nat::from(0u32) {
            Text::from("let _ = args;")
        } else {
            decode_args(p_, &names)
        };
        let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::from("?") } else { Text::from("") })));
        prism_rtl::Turn::Finished(rust_templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call))
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program(p_: lower::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustProgram { p_, fallible })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args(p_: &lower::ProgDef, names: &Array<Text>) -> Text {
    let n = len(names);
    let plural = if &n == &Nat::from(1u32) { Text::from("") } else { Text::from("s") };
    let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &lexer::join(names, &Text::from(", ")), &p_.prism, &n, &plural));
    lexer::join(&append(&Array::from(vec![head.clone()]), &run_to_end(each_job(p_.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (a, t) = p0;
        call_then(start_decode_head(t.clone()), move |decode_head_28994: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_28994, &a))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::from("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_: lower::ProgDef,
    pub names: Array<Text>,
}

impl prism_rtl::Job<Text> for DecodeArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let names = &self.names;
        let n = len(names);
        let plural = if &n == &Nat::from(1u32) { Text::from("") } else { Text::from("s") };
        let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &lexer::join(names, &Text::from(", ")), &p_.prism, &n, &plural));
        let p_ = p_.clone();
        call_value(each_job(p_.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (a, t) = p0;
            call_then(start_decode_head(t.clone()), move |decode_head_28994: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_28994, &a))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_28955: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&append(&Array::from(vec![head.clone()]), &each_28955), &Text::from("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args(p_: lower::ProgDef, names: Array<Text>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArgs { p_, names })
}

/// ```prism
/// RustModule: unbounded fn ModDef -> Text
/// ```
pub fn rust_module(m: &lower::ModDef) -> Text {
    let uses = if &len(&m.uses) == &Nat::from(0u32) {
        Text::from("")
    } else {
        Text::from(format!("#[allow(unused_imports)]\nuse crate::{{{}}};", &lexer::join(&m.uses, &Text::from(", "))))
    };
    rust_templates::module(&(if &m.prism == &Text::from("") {
        Text::from("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    }), &m.path_, &uses, &lexer::join(&run_to_end(each_job(m.items.clone(), Rc::new(move |p0: lower::Item| entered(once_job(move || {
        let it = p0;
        prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
    }))) as Rc<dyn Fn(lower::Item) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::from("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef -> Text
/// ```
pub struct RustModule {
    pub m: lower::ModDef,
}

impl prism_rtl::Job<Text> for RustModule {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let uses = if &len(&m.uses) == &Nat::from(0u32) {
            Text::from("")
        } else {
            Text::from(format!("#[allow(unused_imports)]\nuse crate::{{{}}};", &lexer::join(&m.uses, &Text::from(", "))))
        };
        let m = m.clone();
        call_value(each_job(m.items.clone(), Rc::new(move |p0: lower::Item| entered(once_job(move || {
            let it = p0;
            prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
        }))) as Rc<dyn Fn(lower::Item) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_29497: Array<Text>| prism_rtl::Turn::Finished(rust_templates::module(&(if &m.prism == &Text::from("") {
            Text::from("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        }), &m.path_, &uses, &lexer::join(&each_29497, &Text::from("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module(m: lower::ModDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustModule { m })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible(model: &lower::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &lower::ModDef| fold(&m.items, f, &(|f2: &bool, it: &lower::Item| match it {
        lower::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate(model: &lower::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let gui = match &model.root {
        Some(r) => &r.world == &Text::from("canvas"),
        None => false,
    };
    let cargo = rust_templates::cargo(&model.name, runtime, &(if gui { Text::from("\"canvas\"") } else { Text::from("") }));
    let mods = concat(&each(&model.mods, &(|m: &lower::ModDef| Text::from(format!("mod {};\n", &m.name)))));
    let programs = lexer::join(&run_to_end(each_job(all_programs(model), {
        let model = model.clone();
        Rc::new(move |p0: lower::ProgDef| {
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::from("\n"));
    let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), Rc::new(move |p0: lower::CheckDef| entered(once_job(move || {
        let c = p0;
        call_value(each_job(c.lines.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let l = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30459: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &lexer::join(&each_30459, &Text::from(", "))))))
    }))) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let script_list = concat(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &lower::escape(s))))));
    let run_root = match &model.root {
        Some(r) => rust_templates::run_root(&r.name),
        None => rust_templates::no_root(&model.name),
    };
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::from("test"),
    };
    let main = rust_templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row(&model.elem), &rust_answer(&model.answer), &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
    let files = run_to_end(each_job(model.mods.clone(), Rc::new(move |p0: lower::ModDef| entered(once_job(move || {
        let m = p0;
        call_then(start_rust_module(m.clone()), move |rust_module_30970: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.rs", &m.name)), rust_module_30970)))
    }))) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    append(&Array::from(vec![(Text::from("Cargo.toml"), cargo.clone()), (Text::from("src/main.rs"), main.clone()), (Text::from("src/prelude.rs"), prelude_template::prelude_source(&Text::from("")))]), &files)
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model: lower::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCrate {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let gui = match &model.root {
            Some(r) => &r.world == &Text::from("canvas"),
            None => false,
        };
        let cargo = rust_templates::cargo(&model.name, runtime, &(if gui { Text::from("\"canvas\"") } else { Text::from("") }));
        let mods = concat(&each(&model.mods, &(|m: &lower::ModDef| Text::from(format!("mod {};\n", &m.name)))));
        let model = model.clone();
        let scripts = scripts.clone();
        call_value(each_job(all_programs(&model), {
            let model = model.clone();
            Rc::new(move |p0: lower::ProgDef| {
                let model = model.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
                }))
            }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_30201: Array<Text>| {
            let programs = lexer::join(&each_30201, &Text::from("\n"));
            let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
            call_value(each_job(model.checks.clone(), Rc::new(move |p0: lower::CheckDef| entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
                    let l = p0;
                    prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
                }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30459: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &lexer::join(&each_30459, &Text::from(", "))))))
            }))) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30398: Array<Text>| {
                let checks = concat(&each_30398);
                let script_list = concat(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &lower::escape(s))))));
                let run_root = match &model.root {
                    Some(r) => rust_templates::run_root(&r.name),
                    None => rust_templates::no_root(&model.name),
                };
                let world = match &model.root {
                    Some(r) => r.world.clone(),
                    None => Text::from("test"),
                };
                call_then(start_rust_row(model.elem.clone()), move |rust_row_30804: Text| call_then(start_rust_answer(model.answer.clone()), move |rust_answer_30826: Text| {
                    let main = rust_templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row_30804, &rust_answer_30826, &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
                    call_value(each_job(model.mods.clone(), Rc::new(move |p0: lower::ModDef| entered(once_job(move || {
                        let m = p0;
                        call_then(start_rust_module(m.clone()), move |rust_module_30970: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.rs", &m.name)), rust_module_30970)))
                    }))) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>), move |each_30926: Array<(Text, Text)>| {
                        let files = each_30926;
                        prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::from("Cargo.toml"), cargo.clone()), (Text::from("src/main.rs"), main.clone()), (Text::from("src/prelude.rs"), prelude_template::prelude_source(&Text::from("")))]), &files))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate(model: lower::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCrate { model, runtime, scripts })
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs(model: &lower::Model) -> Array<lower::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &lower::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}
