//! The module `Emit`, from `target/bootstrap/src/prismc/emit.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub fn type_(t: &lower::OutTy) -> Text {
    'm1006: {
        if let lower::OutTy::OutNat = t {
            break 'm1006 Text::lit("Nat");
        }
        if let lower::OutTy::OutInt = t {
            break 'm1006 Text::lit("Int");
        }
        if let lower::OutTy::OutU8 = t {
            break 'm1006 Text::lit("u8");
        }
        if let lower::OutTy::OutFloat = t {
            break 'm1006 Text::lit("f64");
        }
        if let lower::OutTy::OutBool = t {
            break 'm1006 Text::lit("bool");
        }
        if let lower::OutTy::OutChar = t {
            break 'm1006 Text::lit("char");
        }
        if let lower::OutTy::OutText = t {
            break 'm1006 Text::lit("Text");
        }
        if let lower::OutTy::OutCursor = t {
            break 'm1006 Text::lit("Cursor");
        }
        if let lower::OutTy::OutUnit = t {
            break 'm1006 Text::lit("()");
        }
        if let lower::OutTy::OutPath = t {
            break 'm1006 Text::lit("Path");
        }
        if let lower::OutTy::OutDuration = t {
            break 'm1006 Text::lit("Duration");
        }
        if let lower::OutTy::OutError = t {
            break 'm1006 Text::lit("Error");
        }
        if let lower::OutTy::OutNamed(n, m1006_12_1) = t && (m1006_12_1.len() == 0) {
            break 'm1006 n.clone();
        }
        if let lower::OutTy::OutNamed(n, args_) = t {
            break 'm1006 Text::from(format!("{}<{}>", n, &types(args_)));
        }
        if let lower::OutTy::OutOpt(i) = t {
            break 'm1006 Text::from(format!("Option<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutRes(i) = t {
            break 'm1006 Text::from(format!("Result<{}, Error>", &type_(&**i)));
        }
        if let lower::OutTy::OutTuple(m1006_16_0) = t && (m1006_16_0.len() == 1) && let Some(one) = index(m1006_16_0, &Nat::from(0u32)) {
            break 'm1006 Text::from(format!("({},)", &type_(&one)));
        }
        if let lower::OutTy::OutTuple(ts) = t {
            break 'm1006 Text::from(format!("({})", &types(ts)));
        }
        if let lower::OutTy::OutArray(e) = t {
            break 'm1006 Text::from(format!("Array<{}>", &type_(&**e)));
        }
        if let lower::OutTy::OutMap(k, v_) = t {
            break 'm1006 Text::from(format!("Map<{}, {}>", &type_(&**k), &type_(&**v_)));
        }
        if let lower::OutTy::OutFn(ps, r) = t {
            break 'm1006 Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types(ps), &type_(&**r)));
        }
        if let lower::OutTy::OutRef(m1006_21_0) = t && let lower::OutTy::OutFn(ps, r) = &**m1006_21_0 {
            break 'm1006 Text::from(format!("&dyn Fn({}) -> {}", &ref_types(ps), &type_(&**r)));
        }
        if let lower::OutTy::OutRef(i) = t {
            break 'm1006 Text::from(format!("&{}", &type_(&**i)));
        }
        if let lower::OutTy::OutJobFn(a, b) = t {
            break 'm1006 Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type_(&**a), &type_(&**b)));
        }
        if let lower::OutTy::OutJob(b) = t {
            break 'm1006 Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type_(&**b)));
        }
        if let lower::OutTy::OutEvent(i) = t {
            break 'm1006 Text::from(format!("Event<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutDyn(i) = t {
            break 'm1006 Text::from(format!("Dynamic<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutGen(n) = t {
            break 'm1006 n.clone();
        }
        if let lower::OutTy::OutRc(i) = t {
            break 'm1006 Text::from(format!("Rc<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutPod = t {
            break 'm1006 Text::lit("Pod");
        }
        if let lower::OutTy::OutShowAny = t {
            break 'm1006 Text::lit("Rc<dyn Show>");
        }
        if let lower::OutTy::OutHold(i) = t {
            break 'm1006 Text::from(format!("Hold<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutStamped(i) = t {
            break 'm1006 Text::from(format!("Stamped<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutSnapshot(i) = t {
            break 'm1006 Text::from(format!("Snapshot<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutDefer(i) = t {
            break 'm1006 Text::from(format!("Defer<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutWeak(n) = t {
            break 'm1006 Text::from(format!("Weak<{}>", n));
        }
        if let lower::OutTy::OutCell(i) = t {
            break 'm1006 Text::from(format!("RefCell<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutWakes = t {
            break 'm1006 Text::lit("Wakes");
        }
        if let lower::OutTy::OutCount = t {
            break 'm1006 Text::lit("u32");
        }
        if let lower::OutTy::OutObj(i) = t {
            break 'm1006 Text::from(format!("Rc<dyn {}>", &type_(&**i)));
        }
        if let lower::OutTy::OutSlice(i) = t {
            break 'm1006 Text::from(format!("[{}]", &type_(&**i)));
        }
        if let lower::OutTy::OutPort(i) = t {
            break 'm1006 Text::from(format!("Port<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutLive(i) = t {
            break 'm1006 Text::from(format!("Live<{}>", &type_(&**i)));
        }
        if let lower::OutTy::OutUnknown(what) = t {
            break 'm1006 Text::from(format!("() /* {} */", what));
        }
        if let lower::OutTy::OutQuantified(b) = t {
            break 'm1006 Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Type: unbounded fn OutTy -> Text
/// ```
pub struct Type {
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for Type {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        'm1006: {
            if let lower::OutTy::OutNat = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Nat"));
            }
            if let lower::OutTy::OutInt = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Int"));
            }
            if let lower::OutTy::OutU8 = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("u8"));
            }
            if let lower::OutTy::OutFloat = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("f64"));
            }
            if let lower::OutTy::OutBool = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("bool"));
            }
            if let lower::OutTy::OutChar = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("char"));
            }
            if let lower::OutTy::OutText = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Text"));
            }
            if let lower::OutTy::OutCursor = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Cursor"));
            }
            if let lower::OutTy::OutUnit = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let lower::OutTy::OutPath = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Path"));
            }
            if let lower::OutTy::OutDuration = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Duration"));
            }
            if let lower::OutTy::OutError = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Error"));
            }
            if let lower::OutTy::OutNamed(n, m1006_12_1) = t && (m1006_12_1.len() == 0) {
                break 'm1006 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::OutTy::OutNamed(n, args_) = t {
                break 'm1006 {
                    let args_ = args_.clone();
                    let n = n.clone();
                    call_then(start_types(args_.clone()), move |types_1311: Text| prism_rtl::Turn::Finished(Text::from(format!("{}<{}>", &n, &types_1311))))
                };
            }
            if let lower::OutTy::OutOpt(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1348: Text| prism_rtl::Turn::Finished(Text::from(format!("Option<{}>", &type__1348))))
                };
            }
            if let lower::OutTy::OutRes(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1381: Text| prism_rtl::Turn::Finished(Text::from(format!("Result<{}, Error>", &type__1381))))
                };
            }
            if let lower::OutTy::OutTuple(m1006_16_0) = t && (m1006_16_0.len() == 1) && let Some(one) = index(m1006_16_0, &Nat::from(0u32)) {
                break 'm1006 call_then(start_type_(one.clone()), move |type__1423: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &type__1423))));
            }
            if let lower::OutTy::OutTuple(ts) = t {
                break 'm1006 {
                    let ts = ts.clone();
                    call_then(start_types(ts.clone()), move |types_1456: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &types_1456))))
                };
            }
            if let lower::OutTy::OutArray(e) = t {
                break 'm1006 {
                    let e = (**e).clone();
                    call_then(start_type_(e.clone()), move |type__1492: Text| prism_rtl::Turn::Finished(Text::from(format!("Array<{}>", &type__1492))))
                };
            }
            if let lower::OutTy::OutMap(k, v_) = t {
                break 'm1006 {
                    let k = (**k).clone();
                    let v_ = (**v_).clone();
                    call_then(start_type_(k.clone()), move |type__1525: Text| call_then(start_type_(v_.clone()), move |type__1535: Text| prism_rtl::Turn::Finished(Text::from(format!("Map<{}, {}>", &type__1525, &type__1535)))))
                };
            }
            if let lower::OutTy::OutFn(ps, r) = t {
                break 'm1006 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1574: Text| call_then(start_type_(r.clone()), move |type__1592: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> {}>", &ref_types_1574, &type__1592)))))
                };
            }
            if let lower::OutTy::OutRef(m1006_21_0) = t && let lower::OutTy::OutFn(ps, r) = &**m1006_21_0 {
                break 'm1006 {
                    let ps = ps.clone();
                    let r = (**r).clone();
                    call_then(start_ref_types(ps.clone()), move |ref_types_1638: Text| call_then(start_type_(r.clone()), move |type__1656: Text| prism_rtl::Turn::Finished(Text::from(format!("&dyn Fn({}) -> {}", &ref_types_1638, &type__1656)))))
                };
            }
            if let lower::OutTy::OutRef(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1682: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__1682))))
                };
            }
            if let lower::OutTy::OutJobFn(a, b) = t {
                break 'm1006 {
                    let a = (**a).clone();
                    let b = (**b).clone();
                    call_then(start_type_(a.clone()), move |type__1722: Text| call_then(start_type_(b.clone()), move |type__1757: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn Fn({}) -> Rc<dyn prism_rtl::Job<{}>>>", &type__1722, &type__1757)))))
                };
            }
            if let lower::OutTy::OutJob(b) = t {
                break 'm1006 {
                    let b = (**b).clone();
                    call_then(start_type_(b.clone()), move |type__1807: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn prism_rtl::Job<{}>>", &type__1807))))
                };
            }
            if let lower::OutTy::OutEvent(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1842: Text| prism_rtl::Turn::Finished(Text::from(format!("Event<{}>", &type__1842))))
                };
            }
            if let lower::OutTy::OutDyn(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1876: Text| prism_rtl::Turn::Finished(Text::from(format!("Dynamic<{}>", &type__1876))))
                };
            }
            if let lower::OutTy::OutGen(n) = t {
                break 'm1006 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::OutTy::OutRc(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__1920: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<{}>", &type__1920))))
                };
            }
            if let lower::OutTy::OutPod = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Pod"));
            }
            if let lower::OutTy::OutShowAny = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Rc<dyn Show>"));
            }
            if let lower::OutTy::OutHold(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2001: Text| prism_rtl::Turn::Finished(Text::from(format!("Hold<{}>", &type__2001))))
                };
            }
            if let lower::OutTy::OutStamped(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2039: Text| prism_rtl::Turn::Finished(Text::from(format!("Stamped<{}>", &type__2039))))
                };
            }
            if let lower::OutTy::OutSnapshot(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2079: Text| prism_rtl::Turn::Finished(Text::from(format!("Snapshot<{}>", &type__2079))))
                };
            }
            if let lower::OutTy::OutDefer(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2113: Text| prism_rtl::Turn::Finished(Text::from(format!("Defer<{}>", &type__2113))))
                };
            }
            if let lower::OutTy::OutWeak(n) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("Weak<{}>", n)));
            }
            if let lower::OutTy::OutCell(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2175: Text| prism_rtl::Turn::Finished(Text::from(format!("RefCell<{}>", &type__2175))))
                };
            }
            if let lower::OutTy::OutWakes = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("Wakes"));
            }
            if let lower::OutTy::OutCount = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::lit("u32"));
            }
            if let lower::OutTy::OutObj(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2250: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc<dyn {}>", &type__2250))))
                };
            }
            if let lower::OutTy::OutSlice(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2279: Text| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &type__2279))))
                };
            }
            if let lower::OutTy::OutPort(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2311: Text| prism_rtl::Turn::Finished(Text::from(format!("Port<{}>", &type__2311))))
                };
            }
            if let lower::OutTy::OutLive(i) = t {
                break 'm1006 {
                    let i = (**i).clone();
                    call_then(start_type_(i.clone()), move |type__2343: Text| prism_rtl::Turn::Finished(Text::from(format!("Live<{}>", &type__2343))))
                };
            }
            if let lower::OutTy::OutUnknown(what) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("() /* {} */", what)));
            }
            if let lower::OutTy::OutQuantified(b) = t {
                break 'm1006 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}a quantified type variable of `{}`: no instantiation gives it a type\")", &lower::lowering_refusal(), b)));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Type, x`: what the function value is when passed to `@Run`.
pub fn start_type_(t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Type { t })
}

/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub fn types(ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
        let t = p0;
        prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
    }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Types: unbounded fn [OutTy] -> Text
/// ```
pub struct Types {
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for Types {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
            let t = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: t.clone() }))
        }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2579: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_2579, &Text::lit(", "))))
    }
}

/// `Start Types, x`: what the function value is when passed to `@Run`.
pub fn start_types(ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Types { ts })
}

/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub fn ref_types(ts: &Array<lower::OutTy>) -> Text {
    lexer::join(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
        let t = p0;
        call_then(start_type_(t.clone()), move |type__2687: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2687))))
    }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RefTypes: unbounded fn [OutTy] -> Text
/// ```
pub struct RefTypes {
    pub ts: Array<lower::OutTy>,
}

impl prism_rtl::Job<Text> for RefTypes {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ts = &self.ts;
        let ts = ts.clone();
        call_value(each_job(ts.clone(), Rc::new(move |p0: lower::OutTy| entered(once_job(move || {
            let t = p0;
            call_then(start_type_(t.clone()), move |type__2687: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &type__2687))))
        }))) as Rc<dyn Fn(lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_2670: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_2670, &Text::lit(", "))))
    }
}

/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
pub fn start_ref_types(ts: Array<lower::OutTy>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RefTypes { ts })
}

/// ```prism
/// IsLoose: fn Ex -> Bool
/// ```
pub fn is_loose(x: &lower::Ex) -> bool {
    match x {
        lower::Ex::XBlock(m3012_0_0, inner) if (m3012_0_0.len() == 0) => is_loose(&**inner),
        lower::Ex::XTyped(inner, _) => is_loose(&**inner),
        lower::Ex::XBin(_, _, _) => true,
        lower::Ex::XUnary(_, _) => true,
        lower::Ex::XClosure(_, _, _) => true,
        lower::Ex::XIf(_, _, _) => true,
        lower::Ex::XMatch(_, _, _, _) => true,
        lower::Ex::XChain(_, _, _, _) => true,
        lower::Ex::XCast(_, _) => true,
        lower::Ex::XRef(_) => true,
        lower::Ex::XRefMut(_) => true,
        lower::Ex::XDeref(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub fn tight(x: &lower::Ex) -> Text {
    if is_loose(x) { Text::from(format!("({})", &expression(x))) } else { expression(x) }
}

/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Tight: unbounded fn Ex -> Text
/// ```
pub struct Tight {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Tight {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        if is_loose(x) {
            {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3529: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3529))))
            }
        } else {
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }
    }
}

/// `Start Tight, x`: what the function value is when passed to `@Run`.
pub fn start_tight(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Tight { x })
}

/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub fn operand(x: &lower::Ex) -> Text {
    match x {
        lower::Ex::XBlock(m3613_0_0, inner) if (m3613_0_0.len() == 0) => operand(&**inner),
        lower::Ex::XTyped(inner, _) => operand(&**inner),
        lower::Ex::XBin(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XClosure(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XIf(_, _, _) => Text::from(format!("({})", &expression(x))),
        lower::Ex::XCast(_, _) => Text::from(format!("({})", &expression(x))),
        _ => expression(x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Operand: unbounded fn Ex -> Text
/// ```
pub struct Operand {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Operand {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        match x {
            lower::Ex::XBlock(m3613_0_0, inner) if (m3613_0_0.len() == 0) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            lower::Ex::XTyped(inner, _) => prism_rtl::Turn::More(Rc::new(Operand { x: (**inner).clone() })),
            lower::Ex::XBin(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3736: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3736))))
            },
            lower::Ex::XClosure(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3792: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3792))))
            },
            lower::Ex::XIf(_, _, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3843: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3843))))
            },
            lower::Ex::XCast(_, _) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_3888: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &expression_3888))))
            },
            _ => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start Operand, x`: what the function value is when passed to `@Run`.
pub fn start_operand(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Operand { x })
}

/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub fn args(xs: &Array<lower::Ex>) -> Text {
    lexer::join(&run_to_end(each_job(xs.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
        let x = p0;
        prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
    }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))
}

/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Args: unbounded fn [Ex] -> Text
/// ```
pub struct Args {
    pub xs: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for Args {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs = &self.xs;
        let xs = xs.clone();
        call_value(each_job(xs.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let x = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() }))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_3984: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_3984, &Text::lit(", "))))
    }
}

/// `Start Args, x`: what the function value is when passed to `@Run`.
pub fn start_args(xs: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Args { xs })
}

/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub fn expression(x: &lower::Ex) -> Text {
    'm4073: {
        if let lower::Ex::XVar(n) = x {
            break 'm4073 n.clone();
        }
        if let lower::Ex::XPath(p_) = x {
            break 'm4073 p_.clone();
        }
        if let lower::Ex::XSelf = x {
            break 'm4073 Text::lit("self");
        }
        if let lower::Ex::XCx = x {
            break 'm4073 Text::lit("cx");
        }
        if let lower::Ex::XConst(n) = x {
            break 'm4073 Text::from(format!("Self::{}", n));
        }
        if let lower::Ex::XUnit = x {
            break 'm4073 Text::lit("()");
        }
        if let lower::Ex::XNone = x {
            break 'm4073 Text::lit("None");
        }
        if let lower::Ex::XBool(b) = x {
            break 'm4073 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let lower::Ex::XNat(d) = x {
            break 'm4073 if &len_text(d) <= &Nat::from(9u32) {
                Text::from(format!("Nat::from({}u32)", d))
            } else {
                if &len_text(d) <= &Nat::from(18u32) {
                    Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d))
                } else {
                    Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d))
                }
            };
        }
        if let lower::Ex::XInt(d) = x {
            break 'm4073 if &len_text(&(if lexer::has_prefix(d, &Text::lit("-")) { lexer::after_first(d) } else { d.clone() })) <= &Nat::from(18u32) {
                Text::from(format!("Int::from({})", d))
            } else {
                Text::from(format!("Int::parse(\"{}\").unwrap()", d))
            };
        }
        if let lower::Ex::XByte(d) = x {
            break 'm4073 Text::from(format!("{}u8", d));
        }
        if let lower::Ex::XFloat(d) = x {
            break 'm4073 d.clone();
        }
        if let lower::Ex::XIndex(n) = x {
            break 'm4073 Text::from(format!("{}", n));
        }
        if let lower::Ex::XChar(c) = x {
            break 'm4073 Text::from(format!("'{}'", &lower::char_escape(c)));
        }
        if let lower::Ex::XStr(t) = x {
            break 'm4073 Text::from(format!("\"{}\"", &lower::escape(t)));
        }
        if let lower::Ex::XRef(y) = x {
            break 'm4073 Text::from(format!("&{}", &operand(&**y)));
        }
        if let lower::Ex::XRefMut(y) = x {
            break 'm4073 Text::from(format!("&mut {}", &operand(&**y)));
        }
        if let lower::Ex::XDeref(y) = x {
            break 'm4073 Text::from(format!("*{}", &operand(&**y)));
        }
        if let lower::Ex::XTarget(y) = x {
            break 'm4073 Text::from(format!("(*{})", &expression(&**y)));
        }
        if let lower::Ex::XClone(y) = x {
            break 'm4073 Text::from(format!("{}.clone()", &tight(&**y)));
        }
        if let lower::Ex::XWeak(y) = x {
            break 'm4073 Text::from(format!("Rc::downgrade({})", &expression(&**y)));
        }
        if let lower::Ex::XUpgrade(y) = x {
            break 'm4073 Text::from(format!("{}.upgrade()", &tight(&**y)));
        }
        if let lower::Ex::XBreak(l, y) = x {
            break 'm4073 Text::from(format!("break {} {}", &label(l), &expression(&**y)));
        }
        if let lower::Ex::XBreakLoop = x {
            break 'm4073 Text::lit("break");
        }
        if let lower::Ex::XLater(y) = x {
            break 'm4073 Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression(&**y)));
        }
        if let lower::Ex::XFormatStr(parts) = x {
            break 'm4073 format_str(parts);
        }
        if let lower::Ex::XIsCase(y, m4073_26_1) = x && (m4073_26_1.len() == 0) {
            break 'm4073 Text::lit("false");
        }
        if let lower::Ex::XIsCase(y, cs) = x {
            break 'm4073 Text::from(format!("matches!({}, {})", &expression(&**y), &lexer::join(&each(cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))));
        }
        if let lower::Ex::XRefusal(what) = x {
            break 'm4073 Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what)));
        }
        if let lower::Ex::XUnreachable = x {
            break 'm4073 Text::lit("unreachable!()");
        }
        if let lower::Ex::XCall(f, args_) = x {
            break 'm4073 Text::from(format!("{}({})", f, &args(args_)));
        }
        if let lower::Ex::XApply(f, args_) = x {
            break 'm4073 Text::from(format!("{}({})", &tight(&**f), &args(args_)));
        }
        if let lower::Ex::XMethod(r, m, args_) = x {
            break 'm4073 Text::from(format!("{}.{}({})", &tight(&**r), m, &args(args_)));
        }
        if let lower::Ex::XBin(op, l, r) = x {
            break 'm4073 Text::from(format!("{} {} {}", &operand(&**l), op, &operand(&**r)));
        }
        if let lower::Ex::XUnary(op, y) = x {
            break 'm4073 Text::from(format!("{}{}", op, &operand(&**y)));
        }
        if let lower::Ex::XCtor(p_, args_) = x {
            break 'm4073 Text::from(format!("{}({})", p_, &args(args_)));
        }
        if let lower::Ex::XRecord(p_, fs) = x {
            break 'm4073 Text::from(format!("{} {{ {} }}", p_, &lexer::join(&run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                let (f, v_) = p0;
                prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
            }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let lower::Ex::XTuple(m4073_37_0) = x && (m4073_37_0.len() == 1) && let Some(one) = index(m4073_37_0, &Nat::from(0u32)) {
            break 'm4073 Text::from(format!("({},)", &expression(&one)));
        }
        if let lower::Ex::XTuple(xs) = x {
            break 'm4073 Text::from(format!("({})", &args(xs)));
        }
        if let lower::Ex::XVec(xs) = x {
            break 'm4073 Text::from(format!("vec![{}]", &args(xs)));
        }
        if let lower::Ex::XText(t) = x {
            break 'm4073 Text::from(format!("Text::lit(\"{}\")", &lower::escape(t)));
        }
        if let lower::Ex::XFormat(parts) = x {
            break 'm4073 format(parts);
        }
        if let lower::Ex::XMatch(s, arms_, fallback, _) = x {
            break 'm4073 rust_templates::match_(&expression(&**s), &arms(arms_, fallback));
        }
        if let lower::Ex::XChain(label_, s, arms_, _) = x {
            break 'm4073 chain(&label(label_), &**s, arms_);
        }
        if let lower::Ex::XIf(c, t, e) = x {
            break 'm4073 if_expression(&**c, &**t, &**e);
        }
        if let lower::Ex::XBlock(m4073_45_0, e) = x && (m4073_45_0.len() == 0) {
            break 'm4073 expression(&**e);
        }
        if let lower::Ex::XBlock(dos, e) = x {
            break 'm4073 rust_templates::block(&statements(dos), &expression(&**e));
        }
        if let lower::Ex::XLabeled(label_, dos, e, _) = x {
            break 'm4073 rust_templates::labeled(&label(label_), &statements(dos), &expression(&**e));
        }
        if let lower::Ex::XClosure(mv, ps, body) = x {
            break 'm4073 Text::from(format!("{}|{}| {}", &(if *mv { Text::lit("move ") } else { Text::lit("") }), &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")), &expression(&**body)));
        }
        if let lower::Ex::XTry(y) = x {
            break 'm4073 Text::from(format!("{}?", &tight(&**y)));
        }
        if let lower::Ex::XField(r, f) = x {
            break 'm4073 Text::from(format!("{}.{}", &tight(&**r), f));
        }
        if let lower::Ex::XPart(r, k) = x {
            break 'm4073 Text::from(format!("{}.{}", &tight(&**r), k));
        }
        if let lower::Ex::XDecode(t, y) = x {
            break 'm4073 Text::from(format!("{}::from_pod({})?", &decode_head(t), &expression(&**y)));
        }
        if let lower::Ex::XCast(y, t) = x {
            break 'm4073 Text::from(format!("{} as {}", &tight(&**y), &type_(t)));
        }
        if let lower::Ex::XTyped(y, _) = x {
            break 'm4073 expression(&**y);
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Expression: unbounded fn Ex -> Text
/// ```
pub struct Expression {
    pub x: lower::Ex,
}

impl prism_rtl::Job<Text> for Expression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let x = &self.x;
        'm4073: {
            if let lower::Ex::XVar(n) = x {
                break 'm4073 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::Ex::XPath(p_) = x {
                break 'm4073 prism_rtl::Turn::Finished(p_.clone());
            }
            if let lower::Ex::XSelf = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("self"));
            }
            if let lower::Ex::XCx = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("cx"));
            }
            if let lower::Ex::XConst(n) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let lower::Ex::XUnit = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("()"));
            }
            if let lower::Ex::XNone = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("None"));
            }
            if let lower::Ex::XBool(b) = x {
                break 'm4073 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let lower::Ex::XNat(d) = x {
                break 'm4073 if &len_text(d) <= &Nat::from(9u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Nat::from({}u32)", d)))
                } else {
                    if &len_text(d) <= &Nat::from(18u32) {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::from({}i64)).unwrap()", d)))
                    } else {
                        prism_rtl::Turn::Finished(Text::from(format!("Nat::from_int(Int::parse(\"{}\").unwrap()).unwrap()", d)))
                    }
                };
            }
            if let lower::Ex::XInt(d) = x {
                break 'm4073 if &len_text(&(if lexer::has_prefix(d, &Text::lit("-")) { lexer::after_first(d) } else { d.clone() })) <= &Nat::from(18u32) {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::from({})", d)))
                } else {
                    prism_rtl::Turn::Finished(Text::from(format!("Int::parse(\"{}\").unwrap()", d)))
                };
            }
            if let lower::Ex::XByte(d) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("{}u8", d)));
            }
            if let lower::Ex::XFloat(d) = x {
                break 'm4073 prism_rtl::Turn::Finished(d.clone());
            }
            if let lower::Ex::XIndex(n) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let lower::Ex::XChar(c) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &lower::char_escape(c))));
            }
            if let lower::Ex::XStr(t) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lower::escape(t))));
            }
            if let lower::Ex::XRef(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4682: Text| prism_rtl::Turn::Finished(Text::from(format!("&{}", &operand_4682))))
                };
            }
            if let lower::Ex::XRefMut(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4716: Text| prism_rtl::Turn::Finished(Text::from(format!("&mut {}", &operand_4716))))
                };
            }
            if let lower::Ex::XDeref(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_4745: Text| prism_rtl::Turn::Finished(Text::from(format!("*{}", &operand_4745))))
                };
            }
            if let lower::Ex::XTarget(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4776: Text| prism_rtl::Turn::Finished(Text::from(format!("(*{})", &expression_4776))))
                };
            }
            if let lower::Ex::XClone(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4808: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.clone()", &tight_4808))))
                };
            }
            if let lower::Ex::XWeak(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4855: Text| prism_rtl::Turn::Finished(Text::from(format!("Rc::downgrade({})", &expression_4855))))
                };
            }
            if let lower::Ex::XUpgrade(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_4889: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.upgrade()", &tight_4889))))
                };
            }
            if let lower::Ex::XBreak(l, y) = x {
                break 'm4073 {
                    let l = l.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_4944: Text| prism_rtl::Turn::Finished(Text::from(format!("break {} {}", &label(&l), &expression_4944))))
                };
            }
            if let lower::Ex::XBreakLoop = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("break"));
            }
            if let lower::Ex::XLater(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5021: Text| prism_rtl::Turn::Finished(Text::from(format!("Box::new(move |cx| {{ {}; Ok(()) }})", &expression_5021))))
                };
            }
            if let lower::Ex::XFormatStr(parts) = x {
                break 'm4073 prism_rtl::Turn::More(Rc::new(FormatStr { parts: parts.clone() }));
            }
            if let lower::Ex::XIsCase(y, m4073_26_1) = x && (m4073_26_1.len() == 0) {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("false"));
            }
            if let lower::Ex::XIsCase(y, cs) = x {
                break 'm4073 {
                    let cs = cs.clone();
                    let y = (**y).clone();
                    call_then(start_expression(y.clone()), move |expression_5145: Text| prism_rtl::Turn::Finished(Text::from(format!("matches!({}, {})", &expression_5145, &lexer::join(&each(&cs, &(|c: &Text| Text::from(format!("{}(..)", c)))), &Text::lit(" | "))))))
                };
            }
            if let lower::Ex::XRefusal(what) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\")", &lower::lowering_refusal(), &lower::escape(what))));
            }
            if let lower::Ex::XUnreachable = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::lit("unreachable!()"));
            }
            if let lower::Ex::XCall(f, args_) = x {
                break 'm4073 {
                    let args_ = args_.clone();
                    let f = f.clone();
                    call_then(start_args(args_.clone()), move |args_5334: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &f, &args_5334))))
                };
            }
            if let lower::Ex::XApply(f, args_) = x {
                break 'm4073 {
                    let args_ = args_.clone();
                    let f = (**f).clone();
                    call_then(start_tight(f.clone()), move |tight_5369: Text| call_then(start_args(args_.clone()), move |args_5379: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &tight_5369, &args_5379)))))
                };
            }
            if let lower::Ex::XMethod(r, m, args_) = x {
                break 'm4073 {
                    let args_ = args_.clone();
                    let m = m.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_5418: Text| call_then(start_args(args_.clone()), move |args_5432: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}({})", &tight_5418, &m, &args_5432)))))
                };
            }
            if let lower::Ex::XBin(op, l, r) = x {
                break 'm4073 {
                    let l = (**l).clone();
                    let op = op.clone();
                    let r = (**r).clone();
                    call_then(start_operand(l.clone()), move |operand_5466: Text| call_then(start_operand(r.clone()), move |operand_5483: Text| prism_rtl::Turn::Finished(Text::from(format!("{} {} {}", &operand_5466, &op, &operand_5483)))))
                };
            }
            if let lower::Ex::XUnary(op, y) = x {
                break 'm4073 {
                    let op = op.clone();
                    let y = (**y).clone();
                    call_then(start_operand(y.clone()), move |operand_5519: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &op, &operand_5519))))
                };
            }
            if let lower::Ex::XCtor(p_, args_) = x {
                break 'm4073 {
                    let args_ = args_.clone();
                    let p_ = p_.clone();
                    call_then(start_args(args_.clone()), move |args_5556: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &p_, &args_5556))))
                };
            }
            if let lower::Ex::XRecord(p_, fs) = x {
                break 'm4073 {
                    let fs = fs.clone();
                    let p_ = p_.clone();
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                        let (f, v_) = p0;
                        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                    }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5603: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &p_, &lexer::join(&each_5603, &Text::lit(", "))))))
                };
            }
            if let lower::Ex::XTuple(m4073_37_0) = x && (m4073_37_0.len() == 1) && let Some(one) = index(m4073_37_0, &Nat::from(0u32)) {
                break 'm4073 call_then(start_expression(one.clone()), move |expression_5674: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &expression_5674))));
            }
            if let lower::Ex::XTuple(xs) = x {
                break 'm4073 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5711: Text| prism_rtl::Turn::Finished(Text::from(format!("({})", &args_5711))))
                };
            }
            if let lower::Ex::XVec(xs) = x {
                break 'm4073 {
                    let xs = xs.clone();
                    call_then(start_args(xs.clone()), move |args_5742: Text| prism_rtl::Turn::Finished(Text::from(format!("vec![{}]", &args_5742))))
                };
            }
            if let lower::Ex::XText(t) = x {
                break 'm4073 prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &lower::escape(t))));
            }
            if let lower::Ex::XFormat(parts) = x {
                break 'm4073 prism_rtl::Turn::More(Rc::new(Format { parts: parts.clone() }));
            }
            if let lower::Ex::XMatch(s, arms_, fallback, _) = x {
                break 'm4073 {
                    let arms_ = arms_.clone();
                    let fallback = *fallback;
                    let s = (**s).clone();
                    call_then(start_expression(s.clone()), move |expression_5871: Text| call_then(start_arms(arms_.clone(), fallback), move |arms_5887: Text| prism_rtl::Turn::Finished(rust_templates::match_(&expression_5871, &arms_5887))))
                };
            }
            if let lower::Ex::XChain(label_, s, arms_, _) = x {
                break 'm4073 prism_rtl::Turn::More(Rc::new(Chain { label_: label(label_), s: (**s).clone(), arms_: arms_.clone() }));
            }
            if let lower::Ex::XIf(c, t, e) = x {
                break 'm4073 prism_rtl::Turn::More(Rc::new(IfExpression { c: (**c).clone(), t: (**t).clone(), e: (**e).clone() }));
            }
            if let lower::Ex::XBlock(m4073_45_0, e) = x && (m4073_45_0.len() == 0) {
                break 'm4073 prism_rtl::Turn::More(Rc::new(Expression { x: (**e).clone() }));
            }
            if let lower::Ex::XBlock(dos, e) = x {
                break 'm4073 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_6069: Text| call_then(start_expression(e.clone()), move |expression_6087: Text| prism_rtl::Turn::Finished(rust_templates::block(&statements_6069, &expression_6087))))
                };
            }
            if let lower::Ex::XLabeled(label_, dos, e, _) = x {
                break 'm4073 {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    let label_ = label_.clone();
                    call_then(start_statements(dos.clone()), move |statements_6161: Text| call_then(start_expression(e.clone()), move |expression_6179: Text| prism_rtl::Turn::Finished(rust_templates::labeled(&label(&label_), &statements_6161, &expression_6179))))
                };
            }
            if let lower::Ex::XClosure(mv, ps, body) = x {
                break 'm4073 {
                    let body = (**body).clone();
                    let mv = *mv;
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let p_ = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: p_.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_6254: Array<Text>| call_then(start_expression(body.clone()), move |expression_6288: Text| prism_rtl::Turn::Finished(Text::from(format!("{}|{}| {}", &(if mv { Text::lit("move ") } else { Text::lit("") }), &lexer::join(&each_6254, &Text::lit(", ")), &expression_6288)))))
                };
            }
            if let lower::Ex::XTry(y) = x {
                break 'm4073 {
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6320: Text| prism_rtl::Turn::Finished(Text::from(format!("{}?", &tight_6320))))
                };
            }
            if let lower::Ex::XField(r, f) = x {
                break 'm4073 {
                    let f = f.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6350: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6350, &f))))
                };
            }
            if let lower::Ex::XPart(r, k) = x {
                break 'm4073 {
                    let k = k.clone();
                    let r = (**r).clone();
                    call_then(start_tight(r.clone()), move |tight_6382: Text| prism_rtl::Turn::Finished(Text::from(format!("{}.{}", &tight_6382, &k))))
                };
            }
            if let lower::Ex::XDecode(t, y) = x {
                break 'm4073 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_decode_head(t.clone()), move |decode_head_6416: Text| call_then(start_expression(y.clone()), move |expression_6441: Text| prism_rtl::Turn::Finished(Text::from(format!("{}::from_pod({})?", &decode_head_6416, &expression_6441)))))
                };
            }
            if let lower::Ex::XCast(y, t) = x {
                break 'm4073 {
                    let t = t.clone();
                    let y = (**y).clone();
                    call_then(start_tight(y.clone()), move |tight_6476: Text| call_then(start_type_(t.clone()), move |type__6489: Text| prism_rtl::Turn::Finished(Text::from(format!("{} as {}", &tight_6476, &type__6489)))))
                };
            }
            if let lower::Ex::XTyped(y, _) = x {
                break 'm4073 prism_rtl::Turn::More(Rc::new(Expression { x: (**y).clone() }));
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Expression, x`: what the function value is when passed to `@Run`.
pub fn start_expression(x: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Expression { x })
}

/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub fn field_init(f: &Text, ex1: &lower::Ex) -> Text {
    match ex1 {
        lower::Ex::XVar(v_) => if v_ == f { f.clone() } else { Text::from(format!("{}: {}", f, v_)) },
        v_ => Text::from(format!("{}: {}", f, &expression(v_))),
    }
}

/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldInit: unbounded fn Text, Ex -> Text
/// ```
pub struct FieldInit {
    pub f: Text,
    pub ex1: lower::Ex,
}

impl prism_rtl::Job<Text> for FieldInit {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let ex1 = &self.ex1;
        match ex1 {
            lower::Ex::XVar(v_) => if v_ == f {
                prism_rtl::Turn::Finished(f.clone())
            } else {
                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", f, v_)))
            },
            v_ => {
                let f = f.clone();
                let v_ = v_.clone();
                call_then(start_expression(v_.clone()), move |expression_6659: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &expression_6659))))
            },
        }
    }
}

/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
pub fn start_field_init(f: Text, ex1: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FieldInit { f, ex1 })
}

/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub fn decode_head(t: &lower::OutTy) -> Text {
    match t {
        lower::OutTy::OutNamed(n, m6732_0_1) if (m6732_0_1.len() == 0) => n.clone(),
        lower::OutTy::OutNat => Text::lit("Nat"),
        lower::OutTy::OutInt => Text::lit("Int"),
        lower::OutTy::OutText => Text::lit("Text"),
        _ => Text::from(format!("<{}>", &type_(t))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeHead: unbounded fn OutTy -> Text
/// ```
pub struct DecodeHead {
    pub t: lower::OutTy,
}

impl prism_rtl::Job<Text> for DecodeHead {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            lower::OutTy::OutNamed(n, m6732_0_1) if (m6732_0_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            lower::OutTy::OutNat => prism_rtl::Turn::Finished(Text::lit("Nat")),
            lower::OutTy::OutInt => prism_rtl::Turn::Finished(Text::lit("Int")),
            lower::OutTy::OutText => prism_rtl::Turn::Finished(Text::lit("Text")),
            _ => {
                let t = t.clone();
                call_then(start_type_(t.clone()), move |type__6839: Text| prism_rtl::Turn::Finished(Text::from(format!("<{}>", &type__6839))))
            },
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
pub fn start_decode_head(t: lower::OutTy) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeHead { t })
}

/// ```prism
/// Label: fn Text -> Text
/// ```
pub fn label(l: &Text) -> Text {
    if lexer::has_prefix(l, &Text::lit("'")) {
        l.clone()
    } else {
        Text::from(format!("'{}", l))
    }
}

/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub fn format(parts: &Array<lower::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &lower::Ex| format_piece(p_))));
    let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("Text::lit(\"{}\")", &lower::escape(&concat(&each(parts, &(|p_: &lower::Ex| plain_piece(p_)))))))
    } else {
        Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args(&vals)))
    }
}

/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Format: unbounded fn [Ex] -> Text
/// ```
pub struct Format {
    pub parts: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for Format {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &lower::Ex| format_piece(p_))));
        let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("Text::lit(\"{}\")", &lower::escape(&concat(&each(parts, &(|p_: &lower::Ex| plain_piece(p_))))))))
        } else {
            call_then(start_args(vals.clone()), move |args_7354: Text| prism_rtl::Turn::Finished(Text::from(format!("Text::from(format!(\"{}\", {}))", &lit, &args_7354))))
        }
    }
}

/// `Start Format, x`: what the function value is when passed to `@Run`.
pub fn start_format(parts: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Format { parts })
}

/// ```prism
/// PlainPiece: fn Ex -> Text
/// ```
pub fn plain_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XText(t) => t.clone(),
        other => Text::lit(""),
    }
}

/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub fn format_str(parts: &Array<lower::Ex>) -> Text {
    let lit = concat(&each(parts, &(|p_: &lower::Ex| str_piece(p_))));
    let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_) && !is_var(p_)));
    if &len(&vals) == &Nat::from(0u32) {
        Text::from(format!("\"{}\"", &lit))
    } else {
        Text::from(format!("format!(\"{}\", {})", &lit, &args(&vals)))
    }
}

/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FormatStr: unbounded fn [Ex] -> Text
/// ```
pub struct FormatStr {
    pub parts: Array<lower::Ex>,
}

impl prism_rtl::Job<Text> for FormatStr {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let parts = &self.parts;
        let lit = concat(&each(parts, &(|p_: &lower::Ex| str_piece(p_))));
        let vals = filter(parts, &(|p_: &lower::Ex| !is_text(p_) && !is_var(p_)));
        if &len(&vals) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("\"{}\"", &lit)))
        } else {
            call_then(start_args(vals.clone()), move |args_7819: Text| prism_rtl::Turn::Finished(Text::from(format!("format!(\"{}\", {})", &lit, &args_7819))))
        }
    }
}

/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
pub fn start_format_str(parts: Array<lower::Ex>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FormatStr { parts })
}

/// ```prism
/// IsVar: fn Ex -> Bool
/// ```
pub fn is_var(ex0: &lower::Ex) -> bool {
    match ex0 {
        lower::Ex::XVar(_) => true,
        other => false,
    }
}

/// ```prism
/// StrPiece: fn Ex -> Text
/// ```
pub fn str_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XVar(n) => Text::from(format!("{{{}}}", n)),
        other => format_piece(other),
    }
}

/// ```prism
/// IsText: fn Ex -> Bool
/// ```
pub fn is_text(ex0: &lower::Ex) -> bool {
    match ex0 {
        lower::Ex::XText(_) => true,
        other => false,
    }
}

/// ```prism
/// FormatPiece: fn Ex -> Text
/// ```
pub fn format_piece(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XText(t) => format_escape(&lower::escape(t)),
        other => Text::lit("{}"),
    }
}

/// ```prism
/// FormatEscape: fn Text -> Text
/// ```
pub fn format_escape(t: &Text) -> Text {
    lexer::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        prism_rtl::Turn::Finished(format_escape_char(&c))
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// FormatEscapeChar: fn Text -> Text
/// ```
pub fn format_escape_char(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("{")) => Text::lit("{{"),
        c1_0 if (c1_0 == &Text::lit("}")) => Text::lit("}}"),
        c => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub fn if_expression(c: &lower::Ex, t: &lower::Ex, e: &lower::Ex) -> Text {
    let ct = expression(c);
    let tt = expression(t);
    let et = expression(e);
    let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
    if short {
        Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et))
    } else {
        rust_templates::if_(&ct, &tt, &et)
    }
}

/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
/// ```
pub struct IfExpression {
    pub c: lower::Ex,
    pub t: lower::Ex,
    pub e: lower::Ex,
}

impl prism_rtl::Job<Text> for IfExpression {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        let t = &self.t;
        let e = &self.e;
        let c = c.clone();
        let e = e.clone();
        let t = t.clone();
        call_then(start_expression(c.clone()), move |expression_8557: Text| {
            let ct = expression_8557;
            call_then(start_expression(t.clone()), move |expression_8583: Text| {
                let tt = expression_8583;
                call_then(start_expression(e.clone()), move |expression_8609: Text| {
                    let et = expression_8609;
                    let short = !lexer::contains(&Text::from(format!("{}{}", &tt, &et)), &Text::lit("\n")) && (&len_text(&Text::from(format!("{}{}{}", &ct, &tt, &et))) < &Nat::from(70u32));
                    if short {
                        prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }} else {{ {} }}", &ct, &tt, &et)))
                    } else {
                        prism_rtl::Turn::Finished(rust_templates::if_(&ct, &tt, &et))
                    }
                })
            })
        })
    }
}

/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
pub fn start_if_expression(c: lower::Ex, t: lower::Ex, e: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(IfExpression { c, t, e })
}

/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub fn arms(arms_: &Array<lower::XArm>, fallback: &bool) -> Text {
    let lines = run_to_end(each_job(arms_.clone(), Rc::new(move |p0: lower::XArm| entered(once_job(move || {
        let a = p0;
        prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
    }))) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>));
    let all = if *fallback {
        push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
    } else {
        lines.clone()
    };
    lexer::join(&all, &Text::lit("\n"))
}

/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arms: unbounded fn [XArm], Bool -> Text
/// ```
pub struct Arms {
    pub arms_: Array<lower::XArm>,
    pub fallback: bool,
}

impl prism_rtl::Job<Text> for Arms {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let arms_ = &self.arms_;
        let fallback = &self.fallback;
        let arms_ = arms_.clone();
        let fallback = *fallback;
        call_value(each_job(arms_.clone(), Rc::new(move |p0: lower::XArm| entered(once_job(move || {
            let a = p0;
            prism_rtl::Turn::More(Rc::new(Arm { a: a.clone() }))
        }))) as Rc<dyn Fn(lower::XArm) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_8940: Array<Text>| {
            let lines = each_8940;
            let all = if fallback {
                push(&lines, &Text::lit("_ => unreachable!(\"no arm matched\"),"))
            } else {
                lines.clone()
            };
            prism_rtl::Turn::Finished(lexer::join(&all, &Text::lit("\n")))
        })
    }
}

/// `Start Arms, x`: what the function value is when passed to `@Run`.
pub fn start_arms(arms_: Array<lower::XArm>, fallback: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arms { arms_, fallback })
}

/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub fn arm(a: &lower::XArm) -> Text {
    let guard = if &len(&a.conds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" if {}", &lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
        }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
    };
    let body = expression(&a.body);
    Text::from(format!("{}{} => {},", &pattern(&a.pat), &guard, &body))
}

/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Arm: unbounded fn XArm -> Text
/// ```
pub struct Arm {
    pub a: lower::XArm,
}

impl prism_rtl::Job<Text> for Arm {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let guard = if &len(&a.conds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" if {}", &lexer::join(&run_to_end(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
            }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" && "))))
        };
        let a = a.clone();
        call_then(start_expression(a.body.clone()), move |expression_9232: Text| {
            let body = expression_9232;
            call_then(start_pattern(a.pat.clone()), move |pattern_9256: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{} => {},", &pattern_9256, &guard, &body))))
        })
    }
}

/// `Start Arm, x`: what the function value is when passed to `@Run`.
pub fn start_arm(a: lower::XArm) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Arm { a })
}

/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub fn condition(cc0: &lower::Cc) -> Text {
    match cc0 {
        lower::Cc::CcIf(x) => operand(x),
        lower::Cc::CcLet(p_, x) => Text::from(format!("let {} = {}", &pattern(p_), &expression(x))),
    }
}

/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Condition: unbounded fn Cc -> Text
/// ```
pub struct Condition {
    pub cc0: lower::Cc,
}

impl prism_rtl::Job<Text> for Condition {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let cc0 = &self.cc0;
        match cc0 {
            lower::Cc::CcIf(x) => prism_rtl::Turn::More(Rc::new(Operand { x: x.clone() })),
            lower::Cc::CcLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_9394: Text| call_then(start_expression(x.clone()), move |expression_9408: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}", &pattern_9394, &expression_9408)))))
            },
        }
    }
}

/// `Start Condition, x`: what the function value is when passed to `@Run`.
pub fn start_condition(cc0: lower::Cc) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Condition { cc0 })
}

/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub fn chain(label_: &Text, s: &lower::Ex, arms_: &Array<lower::XArm>) -> Text {
    let in_place = match s {
        lower::Ex::XRef(y) => is_bound(&**y),
        _ => is_bound(s),
    };
    let (bind, scrut) = if in_place {
        (Array::new(), expression(s))
    } else {
        (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
    };
    let n = len(arms_);
    let lines = run_to_end(each_job(check_errors::range0(&n), {
        let arms_ = arms_.clone();
        let scrut = scrut.clone();
        let label_ = label_.clone();
        Rc::new(move |p0: Nat| {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            entered(once_job(move || {
                let i = p0;
                {
                    let a = or(&index(&arms_, &i), &lower::XArm { pat: lower::Pa::PaWild, conds: Array::new(), body: lower::Ex::XUnit });
                    let catch_all = (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                    if catch_all {
                        prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                    } else {
                        call_then(start_pattern(a.pat.clone()), move |pattern_10121: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                            let c = p0;
                            prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                        }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10151: Array<Text>| {
                            let head = lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_10121, &scrut))]), &each_10151), &Text::lit(" && "));
                            call_then(start_expression(a.body.clone()), move |expression_10238: Text| prism_rtl::Turn::Finished(rust_templates::chain_arm(&head, &label_, &continued(&expression_10238, &Text::lit("    ")))))
                        }))
                    }
                }
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    }));
    let ends = match lexer::last(arms_) {
        Some(a) => (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
        None => false,
    };
    let tail = if ends {
        Array::new()
    } else {
        Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
    };
    Text::from(format!("{}: {{\n{}\n}}", label_, &indent(&lexer::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n")))))
}

/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
/// ```
pub struct Chain {
    pub label_: Text,
    pub s: lower::Ex,
    pub arms_: Array<lower::XArm>,
}

impl prism_rtl::Job<Text> for Chain {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let label_ = &self.label_;
        let s = &self.s;
        let arms_ = &self.arms_;
        let in_place = match s {
            lower::Ex::XRef(y) => is_bound(&**y),
            _ => is_bound(s),
        };
        let (bind, scrut) = if in_place {
            (Array::new(), expression(s))
        } else {
            (Array::from(vec![Text::from(format!("let scrutinee = {};", &expression(s)))]), Text::lit("scrutinee"))
        };
        let n = len(arms_);
        let arms_ = arms_.clone();
        let label_ = label_.clone();
        let s = s.clone();
        call_value(each_job(check_errors::range0(&n), {
            let arms_ = arms_.clone();
            let scrut = scrut.clone();
            let label_ = label_.clone();
            Rc::new(move |p0: Nat| {
                let arms_ = arms_.clone();
                let scrut = scrut.clone();
                let label_ = label_.clone();
                entered(once_job(move || {
                    let i = p0;
                    {
                        let a = or(&index(&arms_, &i), &lower::XArm { pat: lower::Pa::PaWild, conds: Array::new(), body: lower::Ex::XUnit });
                        let catch_all = (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32));
                        if catch_all {
                            prism_rtl::Turn::More(Rc::new(Expression { x: a.body.clone() }))
                        } else {
                            call_then(start_pattern(a.pat.clone()), move |pattern_10121: Text| call_value(each_job(a.conds.clone(), Rc::new(move |p0: lower::Cc| entered(once_job(move || {
                                let c = p0;
                                prism_rtl::Turn::More(Rc::new(Condition { cc0: c.clone() }))
                            }))) as Rc<dyn Fn(lower::Cc) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_10151: Array<Text>| {
                                let head = lexer::join(&append(&Array::from(vec![Text::from(format!("let {} = {}", &pattern_10121, &scrut))]), &each_10151), &Text::lit(" && "));
                                call_then(start_expression(a.body.clone()), move |expression_10238: Text| prism_rtl::Turn::Finished(rust_templates::chain_arm(&head, &label_, &continued(&expression_10238, &Text::lit("    ")))))
                            }))
                        }
                    }
                }))
            }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_9867: Array<Text>| {
            let lines = each_9867;
            let ends = match lexer::last(&arms_) {
                Some(a) => (&a.pat == &lower::Pa::PaWild) && (&len(&a.conds) == &Nat::from(0u32)),
                None => false,
            };
            let tail = if ends {
                Array::new()
            } else {
                Array::from(vec![Text::lit("unreachable!(\"no clause matched\")")])
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}: {{\n{}\n}}", &label_, &indent(&lexer::join(&append(&append(&bind, &lines), &tail), &Text::lit("\n"))))))
        })
    }
}

/// `Start Chain, x`: what the function value is when passed to `@Run`.
pub fn start_chain(label_: Text, s: lower::Ex, arms_: Array<lower::XArm>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Chain { label_, s, arms_ })
}

/// ```prism
/// IsBound: fn Ex -> Bool
/// ```
pub fn is_bound(x: &lower::Ex) -> bool {
    'm10742: {
        if let lower::Ex::XVar(_) = x {
            break 'm10742 true;
        }
        if let lower::Ex::XField(m10742_1_0, _) = x && let lower::Ex::XSelf = &**m10742_1_0 {
            break 'm10742 true;
        }
        if let lower::Ex::XField(m10742_2_0, _) = x && let lower::Ex::XMethod(m10742_2_0_r_0, _, _) = &**m10742_2_0 && let lower::Ex::XUpgrade(_) = &**m10742_2_0_r_0 {
            break 'm10742 true;
        }
        if let lower::Ex::XTarget(_) = x {
            break 'm10742 true;
        }
        if let lower::Ex::XPart(m10742_4_0, _) = x && let lower::Ex::XVar(_) = &**m10742_4_0 {
            break 'm10742 true;
        }
        false
    }
}

/// ```prism
/// Continued: fn Text, Text -> Text
/// ```
pub fn continued(t: &Text, pad: &Text) -> Text {
    let ls = split(t, &Text::lit("\n"));
    lexer::join(&each(&check_errors::range0(&len(&ls)), &(|i: &Nat| if (i == &Nat::from(0u32)) || (&or(&index(&ls, i), &Text::lit("")) == &Text::lit("")) {
        or(&index(&ls, i), &Text::lit(""))
    } else {
        Text::from(format!("{}{}", pad, &or(&index(&ls, i), &Text::lit(""))))
    })), &Text::lit("\n"))
}

/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub fn body_lines(ex0: &lower::Ex) -> Text {
    match ex0 {
        lower::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
            body_lines(&**e)
        } else {
            Text::from(format!("{}\n{}", &statements(dos), &body_lines(&**e)))
        },
        x => expression(x),
    }
}

/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyLines: unbounded fn Ex -> Text
/// ```
pub struct BodyLines {
    pub ex0: lower::Ex,
}

impl prism_rtl::Job<Text> for BodyLines {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let ex0 = &self.ex0;
        match ex0 {
            lower::Ex::XBlock(dos, e) => if &len(dos) == &Nat::from(0u32) {
                prism_rtl::Turn::More(Rc::new(BodyLines { ex0: (**e).clone() }))
            } else {
                {
                    let dos = dos.clone();
                    let e = (**e).clone();
                    call_then(start_statements(dos.clone()), move |statements_11426: Text| call_then(start_body_lines(e.clone()), move |body_lines_11444: Text| prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &statements_11426, &body_lines_11444)))))
                }
            },
            x => prism_rtl::Turn::More(Rc::new(Expression { x: x.clone() })),
        }
    }
}

/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
pub fn start_body_lines(ex0: lower::Ex) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(BodyLines { ex0 })
}

/// ```prism
/// Indent: fn Text -> Text
/// ```
pub fn indent(t: &Text) -> Text {
    lexer::join(&each(&split(t, &Text::lit("\n")), &(|l: &Text| if l == &Text::lit("") { Text::lit("") } else { Text::from(format!("    {}", l)) })), &Text::lit("\n"))
}

/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub fn pattern(p_: &lower::Pa) -> Text {
    'm11893: {
        if let lower::Pa::PaWild = p_ {
            break 'm11893 Text::lit("_");
        }
        if let lower::Pa::PaBind(n) = p_ {
            break 'm11893 n.clone();
        }
        if let lower::Pa::PaMut(n) = p_ {
            break 'm11893 Text::from(format!("mut {}", n));
        }
        if let lower::Pa::PaCtor(c, ps) = p_ {
            break 'm11893 Text::from(format!("{}({})", c, &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let lower::Pa::PaUnit(c) = p_ {
            break 'm11893 c.clone();
        }
        if let lower::Pa::PaRecord(c, fs, rest) = p_ {
            break 'm11893 {
                let parts = run_to_end(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
                    let (f, q) = p0;
                    match &q {
                        lower::Pa::PaBind(n) => if n == &f {
                            prism_rtl::Turn::Finished(f.clone())
                        } else {
                            prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                        },
                        _ => call_then(start_pattern(q.clone()), move |pattern_12195: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_12195)))),
                    }
                }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>));
                let all = if *rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                Text::from(format!("{} {{ {} }}", c, &lexer::join(&all, &Text::lit(", "))))
            };
        }
        if let lower::Pa::PaTuple(m11893_6_0) = p_ && (m11893_6_0.len() == 1) && let Some(one) = index(m11893_6_0, &Nat::from(0u32)) {
            break 'm11893 Text::from(format!("({},)", &pattern(&one)));
        }
        if let lower::Pa::PaTuple(ps) = p_ {
            break 'm11893 Text::from(format!("({})", &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let lower::Pa::PaChar(c) = p_ {
            break 'm11893 Text::from(format!("'{}'", &lower::char_escape(c)));
        }
        if let lower::Pa::PaBool(b) = p_ {
            break 'm11893 if *b { Text::lit("true") } else { Text::lit("false") };
        }
        if let lower::Pa::PaIndex(n) = p_ {
            break 'm11893 Text::from(format!("{}", n));
        }
        if let lower::Pa::PaConst(n) = p_ {
            break 'm11893 Text::from(format!("Self::{}", n));
        }
        if let lower::Pa::PaSlice(ps) = p_ {
            break 'm11893 Text::from(format!("[{}]", &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                let q = p0;
                prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
            }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))));
        }
        if let lower::Pa::PaRest(m11893_13_0) = p_ && (m11893_13_0 == &Text::lit("")) {
            break 'm11893 Text::lit("..");
        }
        if let lower::Pa::PaRest(n) = p_ {
            break 'm11893 Text::from(format!("{} @ ..", n));
        }
        if let lower::Pa::PaTyped(q, t) = p_ {
            break 'm11893 Text::from(format!("{}: {}", &pattern(&**q), &type_(t)));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Pattern: unbounded fn Pa -> Text
/// ```
pub struct Pattern_ {
    pub p_: lower::Pa,
}

impl prism_rtl::Job<Text> for Pattern_ {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        'm11893: {
            if let lower::Pa::PaWild = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::lit("_"));
            }
            if let lower::Pa::PaBind(n) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(n.clone());
            }
            if let lower::Pa::PaMut(n) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::from(format!("mut {}", n)));
            }
            if let lower::Pa::PaCtor(c, ps) = p_ {
                break 'm11893 {
                    let c = c.clone();
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_11987: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({})", &c, &lexer::join(&each_11987, &Text::lit(", "))))))
                };
            }
            if let lower::Pa::PaUnit(c) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(c.clone());
            }
            if let lower::Pa::PaRecord(c, fs, rest) = p_ {
                break 'm11893 {
                    let c = c.clone();
                    let fs = fs.clone();
                    let rest = *rest;
                    call_value(each_job(fs.clone(), Rc::new(move |p0: (Text, lower::Pa)| entered(once_job(move || {
                        let (f, q) = p0;
                        match &q {
                            lower::Pa::PaBind(n) => if n == &f {
                                prism_rtl::Turn::Finished(f.clone())
                            } else {
                                prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, n)))
                            },
                            _ => call_then(start_pattern(q.clone()), move |pattern_12195: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &f, &pattern_12195)))),
                        }
                    }))) as Rc<dyn Fn((Text, lower::Pa)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12083: Array<Text>| {
                        let parts = each_12083;
                        let all = if rest { push(&parts, &Text::lit("..")) } else { parts.clone() };
                        prism_rtl::Turn::Finished(Text::from(format!("{} {{ {} }}", &c, &lexer::join(&all, &Text::lit(", ")))))
                    })
                };
            }
            if let lower::Pa::PaTuple(m11893_6_0) = p_ && (m11893_6_0.len() == 1) && let Some(one) = index(m11893_6_0, &Nat::from(0u32)) {
                break 'm11893 call_then(start_pattern(one.clone()), move |pattern_12324: Text| prism_rtl::Turn::Finished(Text::from(format!("({},)", &pattern_12324))));
            }
            if let lower::Pa::PaTuple(ps) = p_ {
                break 'm11893 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12365: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({})", &lexer::join(&each_12365, &Text::lit(", "))))))
                };
            }
            if let lower::Pa::PaChar(c) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::from(format!("'{}'", &lower::char_escape(c))));
            }
            if let lower::Pa::PaBool(b) = p_ {
                break 'm11893 if *b {
                    prism_rtl::Turn::Finished(Text::lit("true"))
                } else {
                    prism_rtl::Turn::Finished(Text::lit("false"))
                };
            }
            if let lower::Pa::PaIndex(n) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::from(format!("{}", n)));
            }
            if let lower::Pa::PaConst(n) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::from(format!("Self::{}", n)));
            }
            if let lower::Pa::PaSlice(ps) = p_ {
                break 'm11893 {
                    let ps = ps.clone();
                    call_value(each_job(ps.clone(), Rc::new(move |p0: lower::Pa| entered(once_job(move || {
                        let q = p0;
                        prism_rtl::Turn::More(Rc::new(Pattern_ { p_: q.clone() }))
                    }))) as Rc<dyn Fn(lower::Pa) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12546: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("[{}]", &lexer::join(&each_12546, &Text::lit(", "))))))
                };
            }
            if let lower::Pa::PaRest(m11893_13_0) = p_ && (m11893_13_0 == &Text::lit("")) {
                break 'm11893 prism_rtl::Turn::Finished(Text::lit(".."));
            }
            if let lower::Pa::PaRest(n) = p_ {
                break 'm11893 prism_rtl::Turn::Finished(Text::from(format!("{} @ ..", n)));
            }
            if let lower::Pa::PaTyped(q, t) = p_ {
                break 'm11893 {
                    let q = (**q).clone();
                    let t = t.clone();
                    call_then(start_pattern(q.clone()), move |pattern_12645: Text| call_then(start_type_(t.clone()), move |type__12658: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &pattern_12645, &type__12658)))))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
pub fn start_pattern(p_: lower::Pa) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Pattern_ { p_ })
}

/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub fn statements(dos: &Array<lower::Do>) -> Text {
    lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
    }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
}

/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statements: unbounded fn [Do] -> Text
/// ```
pub struct Statements {
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for Statements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() }))
        }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_12732: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_12732, &Text::lit("\n"))))
    }
}

/// `Start Statements, x`: what the function value is when passed to `@Run`.
pub fn start_statements(dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statements { dos })
}

/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub fn statement(d: &lower::Do) -> Text {
    match d {
        lower::Do::DoLet(p_, x) => Text::from(format!("let {} = {};", &pattern(p_), &expression(x))),
        lower::Do::DoLetElse(p_, x, e) => Text::from(format!("let {} = {} else {{ {} }};", &pattern(p_), &expression(x), &expression(e))),
        lower::Do::DoAssign(p_, x) => Text::from(format!("{} = {};", &expression(p_), &expression(x))),
        lower::Do::DoWhile(c, body) => rust_templates::if_stmt(&Text::from(format!("while {}", &expression(c))), &statements(body)),
        lower::Do::DoWhileLet(p_, x, body) => rust_templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern(p_), &expression(x))), &statements(body)),
        lower::Do::DoFor(p_, x, body) => rust_templates::if_stmt(&Text::from(format!("for {} in {}", &pattern(p_), &expression(x))), &statements(body)),
        lower::Do::DoExpr(x) => Text::from(format!("{};", &expression(x))),
        lower::Do::DoIf(c, t, e) => Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if {}", &expression(c))), &statements(t)), &else_branch(e))),
        lower::Do::DoIfLet(p_, x, t, e) => Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern(p_), &expression(x))), &statements(t)), &else_branch(e))),
        lower::Do::DoMatch(x, cases) => rust_templates::match_(&expression(x), &lexer::join(&run_to_end(each_job(cases.clone(), Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| entered(once_job(move || {
            let (p_, body) = p0;
            call_then(start_pattern(p_.clone()), move |pattern_13569: Text| call_then(start_statements(body.clone()), move |statements_13582: Text| prism_rtl::Turn::Finished(rust_templates::arm_block(&pattern_13569, &statements_13582))))
        }))) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        lower::Do::DoReturn(x) => Text::from(format!("return {};", &expression(x))),
        lower::Do::DoBlock(body) => rust_templates::scope(&statements(body)),
        lower::Do::DoScope(body) => Text::from(format!("{{ {} }};", &inline_statements(body))),
        lower::Do::DoLine(body) => Text::from(format!("{};", &inline_statements(body))),
        lower::Do::DoNote(t) => Text::from(format!("// {}", t)),
    }
}

/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Statement: unbounded fn Do -> Text
/// ```
pub struct Statement {
    pub d: lower::Do,
}

impl prism_rtl::Job<Text> for Statement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let d = &self.d;
        match d {
            lower::Do::DoLet(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12850: Text| call_then(start_expression(x.clone()), move |expression_12864: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {};", &pattern_12850, &expression_12864)))))
            },
            lower::Do::DoLetElse(p_, x, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_12909: Text| call_then(start_expression(x.clone()), move |expression_12923: Text| call_then(start_expression(e.clone()), move |expression_12946: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {} else {{ {} }};", &pattern_12909, &expression_12923, &expression_12946))))))
            },
            lower::Do::DoAssign(p_, x) => {
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_expression(p_.clone()), move |expression_12986: Text| call_then(start_expression(x.clone()), move |expression_13003: Text| prism_rtl::Turn::Finished(Text::from(format!("{} = {};", &expression_12986, &expression_13003)))))
            },
            lower::Do::DoWhile(c, body) => {
                let body = body.clone();
                let c = c.clone();
                call_then(start_expression(c.clone()), move |expression_13055: Text| call_then(start_statements(body.clone()), move |statements_13072: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("while {}", &expression_13055)), &statements_13072))))
            },
            lower::Do::DoWhileLet(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13135: Text| call_then(start_expression(x.clone()), move |expression_13149: Text| call_then(start_statements(body.clone()), move |statements_13166: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("while let {} = {}", &pattern_13135, &expression_13149)), &statements_13166)))))
            },
            lower::Do::DoFor(p_, x, body) => {
                let body = body.clone();
                let p_ = p_.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13218: Text| call_then(start_expression(x.clone()), move |expression_13233: Text| call_then(start_statements(body.clone()), move |statements_13250: Text| prism_rtl::Turn::Finished(rust_templates::if_stmt(&Text::from(format!("for {} in {}", &pattern_13218, &expression_13233)), &statements_13250)))))
            },
            lower::Do::DoExpr(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13283: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &expression_13283))))
            },
            lower::Do::DoIf(c, t, e) => {
                let c = c.clone();
                let e = e.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_13331: Text| call_then(start_statements(t.clone()), move |statements_13348: Text| call_then(start_else_branch(e.clone()), move |else_branch_13363: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if {}", &expression_13331)), &statements_13348), &else_branch_13363))))))
            },
            lower::Do::DoIfLet(p_, x, t, e) => {
                let e = e.clone();
                let p_ = p_.clone();
                let t = t.clone();
                let x = x.clone();
                call_then(start_pattern(p_.clone()), move |pattern_13420: Text| call_then(start_expression(x.clone()), move |expression_13434: Text| call_then(start_statements(t.clone()), move |statements_13451: Text| call_then(start_else_branch(e.clone()), move |else_branch_13466: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::if_stmt(&Text::from(format!("if let {} = {}", &pattern_13420, &expression_13434)), &statements_13451), &else_branch_13466)))))))
            },
            lower::Do::DoMatch(x, cases) => {
                let cases = cases.clone();
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13510: Text| call_value(each_job(cases.clone(), Rc::new(move |p0: (lower::Pa, Array<lower::Do>)| entered(once_job(move || {
                    let (p_, body) = p0;
                    call_then(start_pattern(p_.clone()), move |pattern_13569: Text| call_then(start_statements(body.clone()), move |statements_13582: Text| prism_rtl::Turn::Finished(rust_templates::arm_block(&pattern_13569, &statements_13582))))
                }))) as Rc<dyn Fn((lower::Pa, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13532: Array<Text>| prism_rtl::Turn::Finished(rust_templates::match_(&expression_13510, &lexer::join(&each_13532, &Text::lit("\n"))))))
            },
            lower::Do::DoReturn(x) => {
                let x = x.clone();
                call_then(start_expression(x.clone()), move |expression_13632: Text| prism_rtl::Turn::Finished(Text::from(format!("return {};", &expression_13632))))
            },
            lower::Do::DoBlock(body) => {
                let body = body.clone();
                call_then(start_statements(body.clone()), move |statements_13673: Text| prism_rtl::Turn::Finished(rust_templates::scope(&statements_13673)))
            },
            lower::Do::DoScope(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13713: Text| prism_rtl::Turn::Finished(Text::from(format!("{{ {} }};", &inline_statements_13713))))
            },
            lower::Do::DoLine(body) => {
                let body = body.clone();
                call_then(start_inline_statements(body.clone()), move |inline_statements_13760: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &inline_statements_13760))))
            },
            lower::Do::DoNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}", t))),
        }
    }
}

/// `Start Statement, x`: what the function value is when passed to `@Run`.
pub fn start_statement(d: lower::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Statement { d })
}

/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub fn inline_statements(dos: &Array<lower::Do>) -> Text {
    lexer::join(&run_to_end(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
        let d = p0;
        prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
    }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" "))
}

/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatements: unbounded fn [Do] -> Text
/// ```
pub struct InlineStatements {
    pub dos: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for InlineStatements {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let dos = &self.dos;
        let dos = dos.clone();
        call_value(each_job(dos.clone(), Rc::new(move |p0: lower::Do| entered(once_job(move || {
            let d = p0;
            prism_rtl::Turn::More(Rc::new(InlineStatement { do_0: d.clone() }))
        }))) as Rc<dyn Fn(lower::Do) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_13933: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&each_13933, &Text::lit(" "))))
    }
}

/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statements(dos: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatements { dos })
}

/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub fn inline_statement(do_0: &lower::Do) -> Text {
    match do_0 {
        lower::Do::DoIf(c, t, c0_0_2) if (c0_0_2.len() == 0) => Text::from(format!("if {} {{ {} }}", &expression(c), &inline_statements(t))),
        d => statement(d),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InlineStatement: unbounded fn Do -> Text
/// ```
pub struct InlineStatement {
    pub do_0: lower::Do,
}

impl prism_rtl::Job<Text> for InlineStatement {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let do_0 = &self.do_0;
        match do_0 {
            lower::Do::DoIf(c, t, j0_0_2) if (j0_0_2.len() == 0) => {
                let c = c.clone();
                let t = t.clone();
                call_then(start_expression(c.clone()), move |expression_14058: Text| call_then(start_inline_statements(t.clone()), move |inline_statements_14076: Text| prism_rtl::Turn::Finished(Text::from(format!("if {} {{ {} }}", &expression_14058, &inline_statements_14076)))))
            },
            d => prism_rtl::Turn::More(Rc::new(Statement { d: d.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
pub fn start_inline_statement(do_0: lower::Do) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(InlineStatement { do_0 })
}

/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub fn else_branch(xs0: &Array<lower::Do>) -> Text {
    'c: {
        if let c0_0 = xs0 && (c0_0.len() == 0) {
            break 'c Text::lit("");
        }
        if let c1_0 = xs0 && (c1_0.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(c1_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&lower::Do::DoIf(c.clone(), t.clone(), e.clone()))));
        }
        if let c2_0 = xs0 && (c2_0.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(c2_0, &Nat::from(0u32)) {
            break 'c Text::from(format!(" else {}", &statement(&lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone()))));
        }
        if let body = xs0 {
            break 'c rust_templates::else_(&statements(body));
        }
        unreachable!("no clause matched")
    }
}

/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ElseBranch: unbounded fn [Do] -> Text
/// ```
pub struct ElseBranch {
    pub xs0: Array<lower::Do>,
}

impl prism_rtl::Job<Text> for ElseBranch {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let xs0 = &self.xs0;
        'j: {
            if let j0_0 = xs0 && (j0_0.len() == 0) {
                break 'j prism_rtl::Turn::Finished(Text::lit(""));
            }
            if let j1_0 = xs0 && (j1_0.len() == 1) && let Some(lower::Do::DoIf(c, t, e)) = index(j1_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(lower::Do::DoIf(c.clone(), t.clone(), e.clone())), move |statement_14288: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_14288))));
            }
            if let j2_0 = xs0 && (j2_0.len() == 1) && let Some(lower::Do::DoIfLet(p_, x, t, e)) = index(j2_0, &Nat::from(0u32)) {
                break 'j call_then(start_statement(lower::Do::DoIfLet(p_.clone(), x.clone(), t.clone(), e.clone())), move |statement_14364: Text| prism_rtl::Turn::Finished(Text::from(format!(" else {}", &statement_14364))));
            }
            if let body = xs0 {
                break 'j {
                    let body = body.clone();
                    call_then(start_statements(body.clone()), move |statements_14424: Text| prism_rtl::Turn::Finished(rust_templates::else_(&statements_14424)))
                };
            }
            unreachable!("no clause matched")
        }
    }
}

/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
pub fn start_else_branch(xs0: Array<lower::Do>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ElseBranch { xs0 })
}

/// ```prism
/// Generics: fn [((Text, [Text]))] -> Text
/// ```
pub fn generics(xs0: &Array<(Text, Array<Text>)>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        gs => Text::from(format!("<{}>", &lexer::join(&each(gs, &(|(g, bs): &(Text, Array<Text>)| if &len(bs) == &Nat::from(0u32) {
            g.clone()
        } else {
            Text::from(format!("{}: {}", g, &lexer::join(bs, &Text::lit(" + "))))
        })), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// GenericNames: fn [Text] -> Text
/// ```
pub fn generic_names(xs0: &Array<Text>) -> Text {
    match xs0 {
        c0_0 if (c0_0.len() == 0) => Text::lit(""),
        ps => Text::from(format!("<{}>", &lexer::join(ps, &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// Bounded: fn [Text], Text -> Text
/// ```
pub fn bounded(xs0: &Array<Text>, text1: &Text) -> Text {
    match (xs0, text1) {
        (c0_0, _) if (c0_0.len() == 0) => Text::lit(""),
        (ps, tr) => Text::from(format!("<{}>", &lexer::join(&each(ps, &(|p_: &Text| Text::from(format!("{}: {}", p_, tr)))), &Text::lit(", ")))),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub fn rust_item(it: &lower::Item) -> Text {
    match it {
        lower::Item::ItTrait(t) => rust_trait(t),
        lower::Item::ItImpl(i) => rust_impl(i),
        lower::Item::ItType(t) => type_decl(t),
        lower::Item::ItTag(t) => rust_tag(t),
        lower::Item::ItRow(r) => rust_row(r),
        lower::Item::ItFn(f) => rust_fn(f),
        lower::Item::ItJob(j) => rust_job(j),
        lower::Item::ItNode(n) => rust_node(n),
        lower::Item::ItNote(t) => Text::from(format!("// {}\n", t)),
        lower::Item::ItRefused(t) => Text::from(format!("compile_error!(\"{}{}\");\n", &lower::lowering_refusal(), &lower::escape(t))),
    }
}

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustItem: unbounded fn Item -> Text
/// ```
pub struct RustItem {
    pub it: lower::Item,
}

impl prism_rtl::Job<Text> for RustItem {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let it = &self.it;
        match it {
            lower::Item::ItTrait(t) => prism_rtl::Turn::More(Rc::new(RustTrait { t: t.clone() })),
            lower::Item::ItImpl(i) => prism_rtl::Turn::More(Rc::new(RustImpl { i: i.clone() })),
            lower::Item::ItType(t) => prism_rtl::Turn::More(Rc::new(TypeDecl { t: t.clone() })),
            lower::Item::ItTag(t) => prism_rtl::Turn::More(Rc::new(RustTag { t: t.clone() })),
            lower::Item::ItRow(r) => prism_rtl::Turn::More(Rc::new(RustRow { r: r.clone() })),
            lower::Item::ItFn(f) => prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() })),
            lower::Item::ItJob(j) => prism_rtl::Turn::More(Rc::new(RustJob { j: j.clone() })),
            lower::Item::ItNode(n) => prism_rtl::Turn::More(Rc::new(RustNode { n: n.clone() })),
            lower::Item::ItNote(t) => prism_rtl::Turn::Finished(Text::from(format!("// {}\n", t))),
            lower::Item::ItRefused(t) => prism_rtl::Turn::Finished(Text::from(format!("compile_error!(\"{}{}\");\n", &lower::lowering_refusal(), &lower::escape(t)))),
        }
    }
}

/// `Start RustItem, x`: what the function value is when passed to `@Run`.
pub fn start_rust_item(it: lower::Item) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustItem { it })
}

/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub fn rust_trait(t: &lower::TraitDef) -> Text {
    let ms = lexer::join(&run_to_end(each_job(t.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
        let f = p0;
        prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
    }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &rust_templates::source_doc(&Text::lit(""), &t.doc), &t.name, &indent(&ms)))
}

/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTrait: unbounded fn TraitDef -> Text
/// ```
pub struct RustTrait {
    pub t: lower::TraitDef,
}

impl prism_rtl::Job<Text> for RustTrait {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
            let f = p0;
            prism_rtl::Turn::More(Rc::new(TraitMethod { f: f.clone() }))
        }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15457: Array<Text>| {
            let ms = lexer::join(&each_15457, &Text::lit("\n"));
            prism_rtl::Turn::Finished(Text::from(format!("{}pub trait {} {{\n{}\n}}\n", &rust_templates::source_doc(&Text::lit(""), &t.doc), &t.name, &indent(&ms))))
        })
    }
}

/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
pub fn start_rust_trait(t: lower::TraitDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTrait { t })
}

/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub fn signature(f: &lower::FnDef, vis: &Text) -> Text {
    let params = lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__15690: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15690))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    Text::from(format!("{}fn {}{}({}) -> {}", vis, &f.name, &generics(&f.generics), &params, &type_(&f.ret)))
}

/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Signature: unbounded fn FnDef, Text -> Text
/// ```
pub struct Signature {
    pub f: lower::FnDef,
    pub vis: Text,
}

impl prism_rtl::Job<Text> for Signature {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let vis = &self.vis;
        let f = f.clone();
        let vis = vis.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__15690: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__15690))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_15656: Array<Text>| {
            let params = lexer::join(&each_15656, &Text::lit(", "));
            call_then(start_type_(f.ret.clone()), move |type__15763: Text| prism_rtl::Turn::Finished(Text::from(format!("{}fn {}{}({}) -> {}", &vis, &f.name, &generics(&f.generics), &params, &type__15763))))
        })
    }
}

/// `Start Signature, x`: what the function value is when passed to `@Run`.
pub fn start_signature(f: lower::FnDef, vis: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(Signature { f, vis })
}

/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub fn trait_method(f: &lower::FnDef) -> Text {
    if f.public {
        rust_templates::fn_(&Text::lit(""), &signature(f, &Text::lit("")), &body_lines(&f.body))
    } else {
        Text::from(format!("{};", &signature(f, &Text::lit(""))))
    }
}

/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TraitMethod: unbounded fn FnDef -> Text
/// ```
pub struct TraitMethod {
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for TraitMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        if f.public {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_15857: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_15876: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::lit(""), &signature_15857, &body_lines_15876))))
            }
        } else {
            {
                let f = f.clone();
                call_then(start_signature(f.clone(), Text::lit("")), move |signature_15902: Text| prism_rtl::Turn::Finished(Text::from(format!("{};", &signature_15902))))
            }
        }
    }
}

/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
pub fn start_trait_method(f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TraitMethod { f })
}

/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub fn rust_impl(i: &lower::ImplDef) -> Text {
    let head = type_(&i.head);
    let gens = generics(&i.generics);
    match &i.cls {
        m16177_0 if (m16177_0 == &Text::lit("Prelude.Show")) => {
            let fns = lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
            Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown)))))
        },
        m16177_1 if (m16177_1 == &Text::lit("Prelude.Eq")) => {
            let fns = lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                let f = p0;
                prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
            }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
            let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &lower::FnDef| if !lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                f.name.clone()
            } else {
                acc.clone()
            }));
            Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq)))))
        },
        _ => Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&lexer::join(&run_to_end(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
            let f = p0;
            call_then(start_signature(f.clone(), Text::lit("")), move |signature_16879: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_16898: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::lit(""), &signature_16879, &body_lines_16898))))
        }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustImpl: unbounded fn ImplDef -> Text
/// ```
pub struct RustImpl {
    pub i: lower::ImplDef,
}

impl prism_rtl::Job<Text> for RustImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let i = &self.i;
        let i = i.clone();
        call_then(start_type_(i.head.clone()), move |type__16126: Text| {
            let head = type__16126;
            let gens = generics(&i.generics);
            match &i.cls {
                m16177_0 if (m16177_0 == &Text::lit("Prelude.Show")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16242: Array<Text>| {
                    let fns = lexer::join(&each_16242, &Text::lit("\n"));
                    let shown = or(&index(&each(&i.methods, &(|f: &lower::FnDef| f.name.clone())), &Nat::from(0u32)), &Text::lit("show"));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::lit("Show"), &head, &Text::lit("fn show(&self, p: &mut Printer)"), &Text::from(format!("p.raw(&{}(self).to_string());", &shown))))))
                }),
                m16177_1 if (m16177_1 == &Text::lit("Prelude.Eq")) => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    prism_rtl::Turn::More(Rc::new(RustFn { f: f.clone() }))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16517: Array<Text>| {
                    let fns = lexer::join(&each_16517, &Text::lit("\n"));
                    let eq = fold(&i.methods, &Text::lit(""), &(|acc: &Text, f: &lower::FnDef| if !lexer::has_prefix(&f.name, &Text::lit("ne")) && (acc == &Text::lit("")) {
                        f.name.clone()
                    } else {
                        acc.clone()
                    }));
                    prism_rtl::Turn::Finished(Text::from(format!("{}\n{}", &fns, &rust_templates::impl_(&gens, &Text::lit("PartialEq"), &head, &Text::lit("fn eq(&self, other: &Self) -> bool"), &Text::from(format!("{}(self, other)", &eq))))))
                }),
                _ => call_value(each_job(i.methods.clone(), Rc::new(move |p0: lower::FnDef| entered(once_job(move || {
                    let f = p0;
                    call_then(start_signature(f.clone(), Text::lit("")), move |signature_16879: Text| call_then(start_body_lines(f.body.clone()), move |body_lines_16898: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&Text::lit(""), &signature_16879, &body_lines_16898))))
                }))) as Rc<dyn Fn(lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_16850: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("impl{} {} for {} {{\n{}\n}}\n", &gens, &i.tr, &head, &indent(&lexer::join(&each_16850, &Text::lit("\n"))))))),
                _ => unreachable!("no arm matched"),
            }
        })
    }
}

/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_impl(i: lower::ImplDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustImpl { i })
}

/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub fn rust_fn(f: &lower::FnDef) -> Text {
    let params = lexer::join(&run_to_end(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17038: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17038))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type_(&f.ret)));
    rust_templates::fn_(&rust_templates::source_doc(&Text::lit(""), &f.doc), &sig, &body_lines(&f.body))
}

/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustFn: unbounded fn FnDef -> Text
/// ```
pub struct RustFn {
    pub f: lower::FnDef,
}

impl prism_rtl::Job<Text> for RustFn {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let f = &self.f;
        let f = f.clone();
        call_value(each_job(f.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__17038: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17038))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17004: Array<Text>| {
            let params = lexer::join(&each_17004, &Text::lit(", "));
            call_then(start_type_(f.ret.clone()), move |type__17268: Text| {
                let sig = Text::from(format!("pub fn {}{}({}) -> {}", &f.name, &static_generics(&f.generics), &params, &type__17268));
                call_then(start_body_lines(f.body.clone()), move |body_lines_17317: Text| prism_rtl::Turn::Finished(rust_templates::fn_(&rust_templates::source_doc(&Text::lit(""), &f.doc), &sig, &body_lines_17317)))
            })
        })
    }
}

/// `Start RustFn, x`: what the function value is when passed to `@Run`.
pub fn start_rust_fn(f: lower::FnDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustFn { f })
}

/// ```prism
/// StaticGenerics: fn [((Text, [Text]))] -> Text
/// ```
pub fn static_generics(gs: &Array<(Text, Array<Text>)>) -> Text {
    generics(&each(gs, &(|(g, bs): &(Text, Array<Text>)| (g.clone(), push(bs, &Text::lit("'static"))))))
}

/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub fn rust_job(j: &lower::JobDef) -> Text {
    let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
    let fields = lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17723: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17723))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let params = lexer::join(&run_to_end(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (n, t) = p0;
        call_then(start_type_(t.clone()), move |type__17797: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17797))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "));
    let bounded_ = static_generics(&j.generics);
    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type_(&j.ret)));
    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| n.clone())), &Text::lit(", "))));
    rust_templates::job(&rust_templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type_(&j.ret), &body_lines(&j.body), &start, &start_body)
}

/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustJob: unbounded fn JobDef -> Text
/// ```
pub struct RustJob {
    pub j: lower::JobDef,
}

impl prism_rtl::Job<Text> for RustJob {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let j = &self.j;
        let gnames = generic_names(&each(&j.generics, &(|(g, _): &(Text, Array<Text>)| g.clone())));
        let j = j.clone();
        call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (n, t) = p0;
            call_then(start_type_(t.clone()), move |type__17723: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &n, &type__17723))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17685: Array<Text>| {
            let fields = lexer::join(&each_17685, &Text::lit("\n"));
            call_value(each_job(j.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (n, t) = p0;
                call_then(start_type_(t.clone()), move |type__17797: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}", &n, &type__17797))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_17763: Array<Text>| {
                let params = lexer::join(&each_17763, &Text::lit(", "));
                let bounded_ = static_generics(&j.generics);
                call_then(start_type_(j.ret.clone()), move |type__18021: Text| {
                    let start = Text::from(format!("pub fn {}{}({}) -> Rc<dyn prism_rtl::Job<{}>>", &j.start, &bounded_, &params, &type__18021));
                    let start_body = Text::from(format!("Rc::new({} {{ {} }})", &j.name, &lexer::join(&each(&j.fields, &(|(n, _): &(Text, lower::OutTy)| n.clone())), &Text::lit(", "))));
                    call_then(start_type_(j.ret.clone()), move |type__18196: Text| call_then(start_body_lines(j.body.clone()), move |body_lines_18210: Text| prism_rtl::Turn::Finished(rust_templates::job(&rust_templates::source_doc(&Text::lit(""), &j.doc), &j.name, &gnames, &bounded_, &fields, &type__18196, &body_lines_18210, &start, &start_body))))
                })
            })
        })
    }
}

/// `Start RustJob, x`: what the function value is when passed to `@Run`.
pub fn start_rust_job(j: lower::JobDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustJob { j })
}

/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub fn type_decl(t: &lower::TyDef) -> Text {
    let eq = t.eq && !t.floaty;
    let ord = t.ord && !t.floaty;
    let derives = lexer::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
    let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
    let doc = rust_templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
    let decl = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            rust_templates::struct_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (f, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__18968: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__18968))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
        },
        lower::TyShape::ShapeUnit => rust_templates::tuple_struct(&doc, &derives, &head, &Text::lit("")),
        lower::TyShape::ShapeNewtype => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            rust_templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (_, ft) = p0;
                call_then(start_type_(ft.clone()), move |type__19232: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__19232))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
        },
        _ => rust_templates::enum_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: lower::CaseDef| entered(once_job(move || {
            let c = p0;
            prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
        }))) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
    };
    let show_ = if &t.show == &lower::Shown::ShownDerived {
        Text::from(format!("\n{}", &show_impl(t, &head)))
    } else {
        Text::lit("")
    };
    let pod = if t.pod {
        Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}{}", &decl, &show_, &pod))
}

/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypeDecl: unbounded fn TyDef -> Text
/// ```
pub struct TypeDecl {
    pub t: lower::TyDef,
}

impl prism_rtl::Job<Text> for TypeDecl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let eq = t.eq && !t.floaty;
        let ord = t.ord && !t.floaty;
        let derives = lexer::join(&filter(&Array::from(vec![Text::lit("Clone"), if t.eq || t.ord { Text::lit("PartialEq") } else { Text::lit("") }, if eq || ord { Text::lit("Eq") } else { Text::lit("") }, if t.ord { Text::lit("PartialOrd") } else { Text::lit("") }, if ord { Text::lit("Ord") } else { Text::lit("") }]), &(|d: &Text| d != &Text::lit(""))), &Text::lit(", "));
        let head = Text::from(format!("{}{}", &t.name, &generic_names(&t.params)));
        let doc = rust_templates::source_doc(&Text::from(format!("`{}`:", &t.prism)), &t.doc);
        let decl = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                rust_templates::struct_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (f, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__18968: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__18968))))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
            },
            lower::TyShape::ShapeUnit => rust_templates::tuple_struct(&doc, &derives, &head, &Text::lit("")),
            lower::TyShape::ShapeNewtype => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                rust_templates::tuple_struct(&doc, &derives, &head, &Text::from(format!("({})", &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    call_then(start_type_(ft.clone()), move |type__19232: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}", &type__19232))))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", ")))))
            },
            _ => rust_templates::enum_(&doc, &derives, &head, &lexer::join(&run_to_end(each_job(t.cases.clone(), Rc::new(move |p0: lower::CaseDef| entered(once_job(move || {
                let c = p0;
                prism_rtl::Turn::More(Rc::new(EnumCase { c: c.clone() }))
            }))) as Rc<dyn Fn(lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))),
        };
        let show_ = if &t.show == &lower::Shown::ShownDerived {
            Text::from(format!("\n{}", &show_impl(t, &head)))
        } else {
            Text::lit("")
        };
        let pod = if t.pod {
            Text::from(format!("\n{}\n{}", &to_pod_impl(t, &head), &from_pod_impl(t, &head)))
        } else {
            Text::lit("")
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}{}", &decl, &show_, &pod)))
    }
}

/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
pub fn start_type_decl(t: lower::TyDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypeDecl { t })
}

/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub fn enum_case(c: &lower::CaseDef) -> Text {
    if &len(&c.fields) == &Nat::from(0u32) {
        Text::from(format!("{},", &c.name))
    } else {
        Text::from(format!("{}({}),", &c.name, &lexer::join(&run_to_end(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (_, ft) = p0;
            prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(", "))))
    }
}

/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EnumCase: unbounded fn CaseDef -> Text
/// ```
pub struct EnumCase {
    pub c: lower::CaseDef,
}

impl prism_rtl::Job<Text> for EnumCase {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let c = &self.c;
        if &len(&c.fields) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished(Text::from(format!("{},", &c.name)))
        } else {
            {
                let c = c.clone();
                call_value(each_job(c.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                    let (_, ft) = p0;
                    prism_rtl::Turn::More(Rc::new(Type { t: ft.clone() }))
                }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_19634: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.name, &lexer::join(&each_19634, &Text::lit(", "))))))
            }
        }
    }
}

/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
pub fn start_enum_case(c: lower::CaseDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(EnumCase { c })
}

/// ```prism
/// Binders: fn Nat -> [Text]
/// ```
pub fn binders(n: &Nat) -> Array<Text> {
    each(&check_errors::range0(n), &(|i: &Nat| Text::from(format!("a{}", i))))
}

/// ```prism
/// CasePattern: fn TyDef, CaseDef -> Text
/// ```
pub fn case_pattern(t: &lower::TyDef, c: &lower::CaseDef) -> Text {
    match &t.shape {
        lower::TyShape::ShapeNewtype => Text::from(format!("{}({})", &t.name, &lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))),
        lower::TyShape::ShapeUnit => t.name.clone(),
        _ => if &len(&c.fields) == &Nat::from(0u32) {
            Text::from(format!("{}::{}", &t.name, &c.name))
        } else {
            Text::from(format!("{}::{}({})", &t.name, &c.name, &lexer::join(&binders(&len(&c.fields)), &Text::lit(", "))))
        },
    }
}

/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn show_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    rust_templates::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body)
}

/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ShowImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ShowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("p.record(\"{}\", &[{}]);", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", &self.{})", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => p.choice(\"{}\", &[{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&binders(&len(&c.fields)), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::lit("Show")), &Text::lit("Show"), head, &Text::lit("fn show(&self, p: &mut Printer)"), &body))
    }
}

/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_show_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ShowImpl { t, head })
}

/// ```prism
/// PrismField: fn Text -> Text
/// ```
pub fn prism_field(f: &Text) -> Text {
    if &lexer::last_char(f) == &Text::lit("_") { lexer::before_last(f) } else { f.clone() }
}

/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn to_pod_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
        },
        _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
    };
    let shown = if &t.show == &lower::Shown::ShownOwn {
        rust_templates::shown_pod(&body)
    } else {
        body.clone()
    };
    rust_templates::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown)
}

/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ToPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct ToPodImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for ToPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Pod::record(\"{}\", vec![{}])", &t.prism, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", &prism_field(f), f)))), &Text::lit(", "))))
            },
            _ => rust_templates::match_self(&lexer::join(&each(&t.cases, &(|c: &lower::CaseDef| Text::from(format!("{} => Pod::Choice(\"{}\".into(), vec![{}]),", &case_pattern(t, c), &c.prism, &lexer::join(&each(&binders(&len(&c.fields)), &(|b: &Text| Text::from(format!("{}.to_pod()", b)))), &Text::lit(", ")))))), &Text::lit("\n"))),
        };
        let shown = if &t.show == &lower::Shown::ShownOwn {
            rust_templates::shown_pod(&body)
        } else {
            body.clone()
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::lit("ToPod")), &Text::lit("ToPod"), head, &Text::lit("fn to_pod(&self) -> Pod"), &shown))
    }
}

/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_to_pod_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ToPodImpl { t, head })
}

/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub fn from_pod_impl(t: &lower::TyDef, head: &Text) -> Text {
    let body = match &t.shape {
        lower::TyShape::ShapeRecord => {
            let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
            Text::from(format!("Ok({} {{ {} }})", &t.name, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
        },
        _ => {
            let arms_ = each(&t.cases, &(|c: &lower::CaseDef| {
                let n = len(&c.fields);
                let made = if &n == &Nat::from(0u32) {
                    if &t.shape == &lower::TyShape::ShapeUnit {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }
                } else {
                    Text::from(format!("{}({})", &(if &t.shape == &lower::TyShape::ShapeNewtype {
                        t.name.clone()
                    } else {
                        Text::from(format!("{}::{}", &t.name, &c.name))
                    }), &lexer::join(&each(&check_errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                };
                Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
            }));
            rust_templates::from_pod_body(&lexer::join(&arms_, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
        },
    };
    rust_templates::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body)
}

/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FromPodImpl: unbounded fn TyDef, Text -> Text
/// ```
pub struct FromPodImpl {
    pub t: lower::TyDef,
    pub head: Text,
}

impl prism_rtl::Job<Text> for FromPodImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let head = &self.head;
        let body = match &t.shape {
            lower::TyShape::ShapeRecord => {
                let c = or(&index(&t.cases, &Nat::from(0u32)), &lower::CaseDef { name: Text::lit(""), prism: Text::lit(""), fields: Array::new() });
                Text::from(format!("Ok({} {{ {} }})", &t.name, &lexer::join(&each(&c.fields, &(|(f, _): &(Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, &prism_field(f))))), &Text::lit(", "))))
            },
            _ => {
                let arms_ = each(&t.cases, &(|c: &lower::CaseDef| {
                    let n = len(&c.fields);
                    let made = if &n == &Nat::from(0u32) {
                        if &t.shape == &lower::TyShape::ShapeUnit {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }
                    } else {
                        Text::from(format!("{}({})", &(if &t.shape == &lower::TyShape::ShapeNewtype {
                            t.name.clone()
                        } else {
                            Text::from(format!("{}::{}", &t.name, &c.name))
                        }), &lexer::join(&each(&check_errors::range0(&n), &(|i: &Nat| Text::from(format!("FromPod::from_pod(&a[{}])?", i)))), &Text::lit(", "))))
                    };
                    Text::from(format!("Pod::Choice(c, a) if &**c == \"{}\" && a.len() == {} => Ok({}),", &c.prism, &n, &made))
                }));
                rust_templates::from_pod_body(&lexer::join(&arms_, &Text::lit("\n")), &Text::from(format!("a {}", &t.prism)))
            },
        };
        prism_rtl::Turn::Finished(rust_templates::impl_(&bounded(&t.params, &Text::lit("FromPod")), &Text::lit("FromPod"), head, &Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), &body))
    }
}

/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
pub fn start_from_pod_impl(t: lower::TyDef, head: Text) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(FromPodImpl { t, head })
}

/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub fn rust_tag(t: &lower::TagDef) -> Text {
    let fields = lexer::join(&run_to_end(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, lower::OutTy)| entered(once_job(move || {
        let (_, f, ft) = p0;
        call_then(start_type_(ft.clone()), move |type__22641: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22641))))
    }))) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
    let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let reads = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
    let back_ = if t.pod {
        Text::from(format!("\n{}", &rust_templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
    } else {
        Text::lit("")
    };
    Text::from(format!("{}{}", &rust_templates::tag(&rust_templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_))
}

/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustTag: unbounded fn TagDef -> Text
/// ```
pub struct RustTag {
    pub t: lower::TagDef,
}

impl prism_rtl::Job<Text> for RustTag {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        let t = t.clone();
        call_value(each_job(t.fields.clone(), Rc::new(move |p0: (Text, Text, lower::OutTy)| entered(once_job(move || {
            let (_, f, ft) = p0;
            call_then(start_type_(ft.clone()), move |type__22641: Text| prism_rtl::Turn::Finished(Text::from(format!("pub {}: {},", &f, &type__22641))))
        }))) as Rc<dyn Fn((Text, Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_22594: Array<Text>| {
            let fields = lexer::join(&each_22594, &Text::lit("\n"));
            let pods = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("(\"{}\", self.{}.to_pod())", p_, f)))), &Text::lit(", "));
            let derives = if t.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
            let reads = lexer::join(&each(&t.fields, &(|(p_, f, _): &(Text, Text, lower::OutTy)| Text::from(format!("{}: FromPod::from_pod(field(p, \"{}\")?)?", f, p_)))), &Text::lit(", "));
            let back_ = if t.pod {
                Text::from(format!("\n{}", &rust_templates::tag_from_pod(&t.name, &t.tag_name, &reads)))
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::tag(&rust_templates::source_doc(&Text::from(format!("The `Level` of `{}`:", &t.tag_name)), &t.doc), &derives, &t.name, &fields, &t.tag_name, &pods), &back_)))
        })
    }
}

/// `Start RustTag, x`: what the function value is when passed to `@Run`.
pub fn start_rust_tag(t: lower::TagDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustTag { t })
}

/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub fn rust_row(r: &lower::RowDef) -> Text {
    let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
    let cases = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
    let pods = lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
    let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
    let back_ = if r.pod {
        Text::from(format!("\n{}", &rust_templates::row_from_pod(&r.name, &reads)))
    } else {
        Text::lit("")
    };
    let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        pods.clone()
    };
    Text::from(format!("{}{}", &rust_templates::row(&rust_templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_))
}

/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRow: unbounded fn RowDef -> Text
/// ```
pub struct RustRow {
    pub r: lower::RowDef,
}

impl prism_rtl::Job<Text> for RustRow {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let r = &self.r;
        let derives = if r.pod { Text::lit("Clone, PartialEq") } else { Text::lit("Clone") };
        let cases = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("{}({}),", v_, st)))), &Text::lit("\n"));
        let pods = lexer::join(&each(&r.cases, &(|(v_, _): &(Text, Text)| Text::from(format!("{}::{}(x) => x.to_pod(),", &r.name, v_)))), &Text::lit("\n"));
        let reads = lexer::join(&each(&r.cases, &(|(v_, st): &(Text, Text)| Text::from(format!("Some(t) if t == {}::TAG => Ok({}::{}(FromPod::from_pod(p)?)),", st, &r.name, v_)))), &Text::lit("\n"));
        let back_ = if r.pod {
            Text::from(format!("\n{}", &rust_templates::row_from_pod(&r.name, &reads)))
        } else {
            Text::lit("")
        };
        let pods2 = if &len(&r.cases) == &Nat::from(0u32) {
            Text::lit("_ => unreachable!(),")
        } else {
            pods.clone()
        };
        prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::row(&rust_templates::source_doc(&Text::from(format!("`{}`, a row kind's values:", &r.prism)), &r.doc), &derives, &r.name, &cases, &pods2), &back_)))
    }
}

/// `Start RustRow, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row(r: lower::RowDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRow { r })
}

/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub fn rust_answer(a: &lower::AnswerDef) -> Text {
    let cases = lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__24298: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__24298))))
    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let tags = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
    };
    let accessors = lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
        let c = p0;
        call_then(start_type_(c.ty.clone()), move |type__24560: Text| prism_rtl::Turn::Finished(rust_templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24560)))
    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let decodes = if &len(&a.cases) == &Nat::from(0u32) {
        Text::lit("_ => unreachable!(),")
    } else {
        lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_decode_head(c.ty.clone()), move |decode_head_24723: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24723))))
        }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
    };
    rust_templates::answer_type(&cases, &tags, &accessors, &decodes)
}

/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustAnswer: unbounded fn AnswerDef -> Text
/// ```
pub struct RustAnswer {
    pub a: lower::AnswerDef,
}

impl prism_rtl::Job<Text> for RustAnswer {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let a = &self.a;
        let a = a.clone();
        call_value(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
            let c = p0;
            call_then(start_type_(c.ty.clone()), move |type__24298: Text| prism_rtl::Turn::Finished(Text::from(format!("{}({}),", &c.variant, &type__24298))))
        }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24265: Array<Text>| {
            let cases = lexer::join(&each_24265, &Text::lit("\n"));
            let tags = if &len(&a.cases) == &Nat::from(0u32) {
                Text::lit("_ => unreachable!(),")
            } else {
                lexer::join(&each(&a.cases, &(|c: &lower::AnswerCase| Text::from(format!("Answer::{}(_) => {}::TAG,", &c.variant, &c.struct_path)))), &Text::lit("\n"))
            };
            call_value(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
                let c = p0;
                call_then(start_type_(c.ty.clone()), move |type__24560: Text| prism_rtl::Turn::Finished(rust_templates::answer_getter(&c.accessor, &c.variant, &c.tag_name, &type__24560)))
            }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_24493: Array<Text>| {
                let accessors = lexer::join(&each_24493, &Text::lit("\n"));
                let decodes = if &len(&a.cases) == &Nat::from(0u32) {
                    Text::lit("_ => unreachable!(),")
                } else {
                    lexer::join(&run_to_end(each_job(a.cases.clone(), Rc::new(move |p0: lower::AnswerCase| entered(once_job(move || {
                        let c = p0;
                        call_then(start_decode_head(c.ty.clone()), move |decode_head_24723: Text| prism_rtl::Turn::Finished(Text::from(format!("Elem::{}(..) => Ok(Answer::{}({}::from_pod(v)?)),", &c.variant, &c.variant, &decode_head_24723))))
                    }))) as Rc<dyn Fn(lower::AnswerCase) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"))
                };
                prism_rtl::Turn::Finished(rust_templates::answer_type(&cases, &tags, &accessors, &decodes))
            })
        })
    }
}

/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
pub fn start_rust_answer(a: lower::AnswerDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustAnswer { a })
}

/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub fn rust_node(n: &lower::NodeDef) -> Text {
    let fields = lexer::join(&run_to_end(each_job(n.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy, Text)| entered(once_job(move || {
        let (f, t, doc) = p0;
        call_then(start_type_(t.clone()), move |type__25140: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &rust_templates::doc(&doc), &f, &type__25140))))
    }))) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &rust_templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
    let params = concat(&run_to_end(each_job(n.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__25318: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25318))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if n.fallible {
        Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
    } else {
        Text::from(format!("Rc<{}>", &n.name))
    };
    let inits = lexer::join(&append(&Array::from(vec![Text::lit("path")]), &run_to_end(each_job(n.inits.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
        let (f, v_) = p0;
        prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
    }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit(", "));
    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
        tail.clone()
    } else {
        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
    };
    let build = rust_templates::build(&n.name, &params, &ret, &statements(&n.lets), &inits, &rest_text);
    let methods = lexer::join(&run_to_end(each_job(n.methods.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let answer = if &len(&n.answers) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        rust_templates::answer(&lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (lower::Pa, lower::Ex)| entered(once_job(move || {
            let (pat, call) = p0;
            call_then(start_pattern(pat.clone()), move |pattern_25884: Text| call_then(start_expression(call.clone()), move |expression_25901: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_25884, &expression_25901)))))
        }))) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
    };
    let builders = concat(&append(&run_to_end(each_job(n.builders.clone(), Rc::new(move |p0: lower::ForDef| entered(once_job(move || {
        let b = p0;
        call_then(start_for_builder(b.clone()), move |for_builder_25989: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_25989))))
    }))) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &run_to_end(each_job(n.gens.clone(), Rc::new(move |p0: lower::GenDef| entered(once_job(move || {
        let gd = p0;
        call_then(start_gen_builder(gd.clone()), move |gen_builder_26030: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_26030))))
    }))) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>))));
    let row_impl = if &n.row_kind == &lower::RowKind::NotARow {
        Text::lit("")
    } else {
        Text::from(format!("\n{}", &rust_row_impl(n)))
    };
    let hooks = lexer::join(&run_to_end(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<lower::Do>)| entered(once_job(move || {
        let (h, body) = p0;
        if &h == &Text::lit("push") {
            call_then(start_statements(body.clone()), move |statements_26197: Text| prism_rtl::Turn::Finished(rust_templates::push_hook(&statements_26197)))
        } else {
            call_then(start_statements(body.clone()), move |statements_26229: Text| prism_rtl::Turn::Finished(rust_templates::hook(&h, &statements_26229)))
        }
    }))) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n"));
    let doc = rust_templates::source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
    Text::from(format!("{}{}", &rust_templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl))
}

/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustNode: unbounded fn NodeDef -> Text
/// ```
pub struct RustNode {
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for RustNode {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let n = n.clone();
        call_value(each_job(n.fields.clone(), Rc::new(move |p0: (Text, lower::OutTy, Text)| entered(once_job(move || {
            let (f, t, doc) = p0;
            call_then(start_type_(t.clone()), move |type__25140: Text| prism_rtl::Turn::Finished(Text::from(format!("{}{}: {},", &rust_templates::doc(&doc), &f, &type__25140))))
        }))) as Rc<dyn Fn((Text, lower::OutTy, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25092: Array<Text>| {
            let fields = lexer::join(&each_25092, &Text::lit("\n"));
            let consts = concat(&each(&n.consts, &(|(c, h, doc): &(Text, Nat, Text)| Text::from(format!("{}const {}: u32 = {};\n", &rust_templates::doc(&Text::from(format!("The {}.", doc))), c, h)))));
            call_value(each_job(n.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
                let (p_, t) = p0;
                call_then(start_type_(t.clone()), move |type__25318: Text| prism_rtl::Turn::Finished(Text::from(format!("{}: {}, ", &p_, &type__25318))))
            }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25284: Array<Text>| {
                let params = concat(&each_25284);
                let ret = if n.fallible {
                    Text::from(format!("Result<Rc<{}>, Fault>", &n.name))
                } else {
                    Text::from(format!("Rc<{}>", &n.name))
                };
                call_value(each_job(n.inits.clone(), Rc::new(move |p0: (Text, lower::Ex)| entered(once_job(move || {
                    let (f, v_) = p0;
                    prism_rtl::Turn::More(Rc::new(FieldInit { f: f.clone(), ex1: v_.clone() }))
                }))) as Rc<dyn Fn((Text, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25452: Array<Text>| {
                    let inits = lexer::join(&append(&Array::from(vec![Text::lit("path")]), &each_25452), &Text::lit(", "));
                    let tail = if n.fallible { Text::lit("Ok(node)") } else { Text::lit("node") };
                    let rest_text = if &len(&n.build) == &Nat::from(0u32) {
                        tail.clone()
                    } else {
                        Text::from(format!("{}\n{}", &statements(&n.build), &tail))
                    };
                    call_then(start_statements(n.lets.clone()), move |statements_25683: Text| {
                        let build = rust_templates::build(&n.name, &params, &ret, &statements_25683, &inits, &rest_text);
                        call_value(each_job(n.methods.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
                            let m = p0;
                            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
                        }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25743: Array<Text>| {
                            let methods = lexer::join(&each_25743, &Text::lit("\n"));
                            let answer = if &len(&n.answers) == &Nat::from(0u32) {
                                Text::lit("")
                            } else {
                                rust_templates::answer(&lexer::join(&run_to_end(each_job(n.answers.clone(), Rc::new(move |p0: (lower::Pa, lower::Ex)| entered(once_job(move || {
                                    let (pat, call) = p0;
                                    call_then(start_pattern(pat.clone()), move |pattern_25884: Text| call_then(start_expression(call.clone()), move |expression_25901: Text| prism_rtl::Turn::Finished(Text::from(format!("{} => {},", &pattern_25884, &expression_25901)))))
                                }))) as Rc<dyn Fn((lower::Pa, lower::Ex)) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
                            };
                            call_value(each_job(n.builders.clone(), Rc::new(move |p0: lower::ForDef| entered(once_job(move || {
                                let b = p0;
                                call_then(start_for_builder(b.clone()), move |for_builder_25989: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &for_builder_25989))))
                            }))) as Rc<dyn Fn(lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_25963: Array<Text>| call_value(each_job(n.gens.clone(), Rc::new(move |p0: lower::GenDef| entered(once_job(move || {
                                let gd = p0;
                                call_then(start_gen_builder(gd.clone()), move |gen_builder_26030: Text| prism_rtl::Turn::Finished(Text::from(format!("\n{}", &gen_builder_26030))))
                            }))) as Rc<dyn Fn(lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26007: Array<Text>| {
                                let builders = concat(&append(&each_25963, &each_26007));
                                let row_impl = if &n.row_kind == &lower::RowKind::NotARow {
                                    Text::lit("")
                                } else {
                                    Text::from(format!("\n{}", &rust_row_impl(&n)))
                                };
                                call_value(each_job(n.hooks.clone(), Rc::new(move |p0: (Text, Array<lower::Do>)| entered(once_job(move || {
                                    let (h, body) = p0;
                                    if &h == &Text::lit("push") {
                                        call_then(start_statements(body.clone()), move |statements_26197: Text| prism_rtl::Turn::Finished(rust_templates::push_hook(&statements_26197)))
                                    } else {
                                        call_then(start_statements(body.clone()), move |statements_26229: Text| prism_rtl::Turn::Finished(rust_templates::hook(&h, &statements_26229)))
                                    }
                                }))) as Rc<dyn Fn((Text, Array<lower::Do>)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26142: Array<Text>| {
                                    let hooks = lexer::join(&each_26142, &Text::lit("\n"));
                                    let doc = rust_templates::source_doc(&Text::from(format!("`{}`: a node of its own (docs/backend.md, \"A widget block\").", &n.prism)), &n.doc);
                                    prism_rtl::Turn::Finished(Text::from(format!("{}{}", &rust_templates::node_(&doc, &n.name, &fields, &consts, &build, &Text::from(format!("{}{}", &methods, &builders)), &hooks, &answer), &row_impl)))
                                })
                            }))
                        })
                    })
                })
            })
        })
    }
}

/// `Start RustNode, x`: what the function value is when passed to `@Run`.
pub fn start_rust_node(n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustNode { n })
}

/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub fn for_builder(b: &lower::ForDef) -> Text {
    rust_templates::for_build(&b.name, &expression(&b.at), &type_(&b.key_ty), &type_(&b.value_ty), &b.row_node, &b.source, &expression(&b.parent), &concat(&run_to_end(each_job(b.passed.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
        let x = p0;
        call_then(start_expression(x.clone()), move |expression_26720: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26720))))
    }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>))))
}

/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ForBuilder: unbounded fn ForDef -> Text
/// ```
pub struct ForBuilder {
    pub b: lower::ForDef,
}

impl prism_rtl::Job<Text> for ForBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let b = &self.b;
        let b = b.clone();
        call_then(start_expression(b.at.clone()), move |expression_26591: Text| call_then(start_type_(b.key_ty.clone()), move |type__26610: Text| call_then(start_type_(b.value_ty.clone()), move |type__26626: Text| call_then(start_expression(b.parent.clone()), move |expression_26665: Text| call_value(each_job(b.passed.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let x = p0;
            call_then(start_expression(x.clone()), move |expression_26720: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}", &expression_26720))))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_26696: Array<Text>| prism_rtl::Turn::Finished(rust_templates::for_build(&b.name, &expression_26591, &type__26610, &type__26626, &b.row_node, &b.source, &expression_26665, &concat(&each_26696))))))))
    }
}

/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_for_builder(b: lower::ForDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ForBuilder { b })
}

/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub fn gen_builder(gd: &lower::GenDef) -> Text {
    let path_ = if gd.transparent {
        Text::lit("self.path.clone()")
    } else {
        Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
    };
    rust_templates::gen_build(&gd.name, &expression(&gd.at), &path_, &expression(&gd.source), &type_(&gd.value_ty), &expression(&gd.select))
}

/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// GenBuilder: unbounded fn GenDef -> Text
/// ```
pub struct GenBuilder {
    pub gd: lower::GenDef,
}

impl prism_rtl::Job<Text> for GenBuilder {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let gd = &self.gd;
        let path_ = if gd.transparent {
            Text::lit("self.path.clone()")
        } else {
            Text::from(format!("{}.child(Segment::Gen(g))", &expression(&gd.at)))
        };
        let gd = gd.clone();
        call_then(start_expression(gd.at.clone()), move |expression_27114: Text| call_then(start_expression(gd.source.clone()), move |expression_27140: Text| call_then(start_type_(gd.value_ty.clone()), move |type__27164: Text| call_then(start_expression(gd.select.clone()), move |expression_27183: Text| prism_rtl::Turn::Finished(rust_templates::gen_build(&gd.name, &expression_27114, &path_, &expression_27140, &type__27164, &expression_27183))))))
    }
}

/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
pub fn start_gen_builder(gd: lower::GenDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(GenBuilder { gd })
}

/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub fn rust_row_impl(n: &lower::NodeDef) -> Text {
    let kept = if &n.row_kind == &lower::RowKind::ForRow {
        Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
    } else {
        Array::new()
    };
    let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
    rust_templates::row_impl(&n.name, &lexer::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &lexer::join(&run_to_end(each_job(n.hosted.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
        let m = p0;
        prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
    }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustRowImpl: unbounded fn NodeDef -> Text
/// ```
pub struct RustRowImpl {
    pub n: lower::NodeDef,
}

impl prism_rtl::Job<Text> for RustRowImpl {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let n = &self.n;
        let kept = if &n.row_kind == &lower::RowKind::ForRow {
            Array::from(vec![Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")])
        } else {
            Array::new()
        };
        let unsubscribe = each(&n.subs, &(|(ev, m, _): &(Text, Text, lower::OutTy)| Text::from(format!("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.{}_sub.take()) {{\n    p.{}_port.unsubscribe(h);\n}}", m, ev))));
        let n = n.clone();
        call_value(each_job(n.hosted.clone(), Rc::new(move |p0: lower::MethDef| entered(once_job(move || {
            let m = p0;
            prism_rtl::Turn::More(Rc::new(RustMethod { m: m.clone() }))
        }))) as Rc<dyn Fn(lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_27881: Array<Text>| prism_rtl::Turn::Finished(rust_templates::row_impl(&n.name, &lexer::join(&append(&push(&kept, &Text::lit("self.remove_places(cx);")), &unsubscribe), &Text::lit("\n")), &lexer::join(&each_27881, &Text::lit("\n")))))
    }
}

/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
pub fn start_rust_row_impl(n: lower::NodeDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustRowImpl { n })
}

/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub fn rust_method(m: &lower::MethDef) -> Text {
    let recv = match &m.recv {
        lower::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
        lower::Recv::RecvRef => Text::lit("&self"),
        lower::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
    };
    let cx_ = match &m.cx_ {
        lower::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
        lower::CxArg::CxRef => Text::lit(", cx: &Cx"),
        lower::CxArg::CxNone => Text::lit(""),
    };
    let params = concat(&run_to_end(each_job(m.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (p_, t) = p0;
        call_then(start_type_(t.clone()), move |type__28268: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__28268))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let ret = if &m.ret == &lower::OutTy::OutUnit {
        Text::lit("")
    } else {
        Text::from(format!(" -> {}", &type_(&m.ret)))
    };
    let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
    let body = if &m.ret == &lower::OutTy::OutUnit {
        statements(&m.body)
    } else {
        if &len(&m.body) == &Nat::from(0u32) {
            body_lines(&m.tail)
        } else {
            Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
        }
    };
    rust_templates::method(&rust_templates::doc(&m.doc), &sig, &body)
}

/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustMethod: unbounded fn MethDef -> Text
/// ```
pub struct RustMethod {
    pub m: lower::MethDef,
}

impl prism_rtl::Job<Text> for RustMethod {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let recv = match &m.recv {
            lower::Recv::RecvRc => Text::lit("self: &Rc<Self>"),
            lower::Recv::RecvRef => Text::lit("&self"),
            lower::Recv::RecvOwned => Text::lit("self: Rc<Self>"),
        };
        let cx_ = match &m.cx_ {
            lower::CxArg::CxMut => Text::lit(", cx: &mut Cx"),
            lower::CxArg::CxRef => Text::lit(", cx: &Cx"),
            lower::CxArg::CxNone => Text::lit(""),
        };
        let m = m.clone();
        call_value(each_job(m.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (p_, t) = p0;
            call_then(start_type_(t.clone()), move |type__28268: Text| prism_rtl::Turn::Finished(Text::from(format!(", {}: {}", &p_, &type__28268))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_28232: Array<Text>| {
            let params = concat(&each_28232);
            let ret = if &m.ret == &lower::OutTy::OutUnit {
                Text::lit("")
            } else {
                Text::from(format!(" -> {}", &type_(&m.ret)))
            };
            let sig = Text::from(format!("fn {}({}{}{}){}", &m.name, &recv, &params, &cx_, &ret));
            let body = if &m.ret == &lower::OutTy::OutUnit {
                statements(&m.body)
            } else {
                if &len(&m.body) == &Nat::from(0u32) {
                    body_lines(&m.tail)
                } else {
                    Text::from(format!("{}\n{}", &statements(&m.body), &body_lines(&m.tail)))
                }
            };
            prism_rtl::Turn::Finished(rust_templates::method(&rust_templates::doc(&m.doc), &sig, &body))
        })
    }
}

/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
pub fn start_rust_method(m: lower::MethDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustMethod { m })
}

/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub fn rust_program(p_: &lower::ProgDef, fallible: &bool) -> Text {
    let n = len(&p_.params);
    let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
    let decode = if &n == &Nat::from(0u32) {
        Text::lit("let _ = args;")
    } else {
        decode_args(p_, &names)
    };
    let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
    rust_templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call)
}

/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustProgram: unbounded fn ProgDef, Bool -> Text
/// ```
pub struct RustProgram {
    pub p_: lower::ProgDef,
    pub fallible: bool,
}

impl prism_rtl::Job<Text> for RustProgram {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let fallible = &self.fallible;
        let n = len(&p_.params);
        let names = each(&p_.params, &(|(a, _): &(Text, lower::OutTy)| a.clone()));
        let decode = if &n == &Nat::from(0u32) {
            Text::lit("let _ = args;")
        } else {
            decode_args(p_, &names)
        };
        let call = Text::from(format!("{}::build(Path::root(), {}&mut cx){}", &p_.node_, &concat(&each(&names, &(|a: &Text| Text::from(format!("{}, ", a))))), &(if *fallible { Text::lit("?") } else { Text::lit("") })));
        prism_rtl::Turn::Finished(rust_templates::program(&p_.name, &p_.prism, &p_.node_, &decode, &call))
    }
}

/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
pub fn start_rust_program(p_: lower::ProgDef, fallible: bool) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustProgram { p_, fallible })
}

/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub fn decode_args(p_: &lower::ProgDef, names: &Array<Text>) -> Text {
    let n = len(names);
    let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
    let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &lexer::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
    lexer::join(&append(&Array::from(vec![head.clone()]), &run_to_end(each_job(p_.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
        let (a, t) = p0;
        call_then(start_decode_head(t.clone()), move |decode_head_29299: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_29299, &a))))
    }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>))), &Text::lit("\n"))
}

/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
/// ```
pub struct DecodeArgs {
    pub p_: lower::ProgDef,
    pub names: Array<Text>,
}

impl prism_rtl::Job<Text> for DecodeArgs {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let p_ = &self.p_;
        let names = &self.names;
        let n = len(names);
        let plural = if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") };
        let head = Text::from(format!("let [{}] = args else {{ return Err(Fault::answer(\"@{} takes {} argument{}\")) }};", &lexer::join(names, &Text::lit(", ")), &p_.prism, &n, &plural));
        let p_ = p_.clone();
        call_value(each_job(p_.params.clone(), Rc::new(move |p0: (Text, lower::OutTy)| entered(once_job(move || {
            let (a, t) = p0;
            call_then(start_decode_head(t.clone()), move |decode_head_29299: Text| prism_rtl::Turn::Finished(Text::from(format!("let {} = {}::from_pod({})?;", &a, &decode_head_29299, &a))))
        }))) as Rc<dyn Fn((Text, lower::OutTy)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_29260: Array<Text>| prism_rtl::Turn::Finished(lexer::join(&append(&Array::from(vec![head.clone()]), &each_29260), &Text::lit("\n"))))
    }
}

/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
pub fn start_decode_args(p_: lower::ProgDef, names: Array<Text>) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(DecodeArgs { p_, names })
}

/// ```prism
/// RustModule: unbounded fn ModDef -> Text
/// ```
pub fn rust_module(m: &lower::ModDef) -> Text {
    let uses = if &len(&m.uses) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!("#[allow(unused_imports)]\nuse crate::{{{}}};", &lexer::join(&m.uses, &Text::lit(", "))))
    };
    rust_templates::module(&(if &m.prism == &Text::lit("") {
        Text::lit("The root module")
    } else {
        Text::from(format!("The module `{}`", &m.prism))
    }), &m.path_, &uses, &lexer::join(&run_to_end(each_job(m.items.clone(), Rc::new(move |p0: lower::Item| entered(once_job(move || {
        let it = p0;
        prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
    }))) as Rc<dyn Fn(lower::Item) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit("\n")))
}

/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RustModule: unbounded fn ModDef -> Text
/// ```
pub struct RustModule {
    pub m: lower::ModDef,
}

impl prism_rtl::Job<Text> for RustModule {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let m = &self.m;
        let uses = if &len(&m.uses) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!("#[allow(unused_imports)]\nuse crate::{{{}}};", &lexer::join(&m.uses, &Text::lit(", "))))
        };
        let m = m.clone();
        call_value(each_job(m.items.clone(), Rc::new(move |p0: lower::Item| entered(once_job(move || {
            let it = p0;
            prism_rtl::Turn::More(Rc::new(RustItem { it: it.clone() }))
        }))) as Rc<dyn Fn(lower::Item) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_29802: Array<Text>| prism_rtl::Turn::Finished(rust_templates::module(&(if &m.prism == &Text::lit("") {
            Text::lit("The root module")
        } else {
            Text::from(format!("The module `{}`", &m.prism))
        }), &m.path_, &uses, &lexer::join(&each_29802, &Text::lit("\n")))))
    }
}

/// `Start RustModule, x`: what the function value is when passed to `@Run`.
pub fn start_rust_module(m: lower::ModDef) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(RustModule { m })
}

/// ```prism
/// NodeFallible: fn Model, Text -> Bool
/// ```
pub fn node_fallible(model: &lower::Model, path_: &Text) -> bool {
    fold(&model.mods, &false, &(|f: &bool, m: &lower::ModDef| fold(&m.items, f, &(|f2: &bool, it: &lower::Item| match it {
        lower::Item::ItNode(n) => *f2 || ((&Text::from(format!("{}::{}", &m.name, &n.name)) == path_) && n.fallible),
        _ => *f2,
    }))))
}

/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub fn emit_crate(model: &lower::Model, runtime: &Text, scripts: &Array<Text>) -> Array<(Text, Text)> {
    let gui = match &model.root {
        Some(r) => &r.world == &Text::lit("canvas"),
        None => false,
    };
    let cargo = rust_templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
    let mods = concat(&each(&model.mods, &(|m: &lower::ModDef| Text::from(format!("mod {};\n", &m.name)))));
    let programs = lexer::join(&run_to_end(each_job(all_programs(model), {
        let model = model.clone();
        Rc::new(move |p0: lower::ProgDef| {
            let model = model.clone();
            entered(once_job(move || {
                let p_ = p0;
                prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
            }))
        }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
    })), &Text::lit("\n"));
    let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
    let checks = concat(&run_to_end(each_job(model.checks.clone(), Rc::new(move |p0: lower::CheckDef| entered(once_job(move || {
        let c = p0;
        call_value(each_job(c.lines.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
            let l = p0;
            prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
        }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30764: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &lexer::join(&each_30764, &Text::lit(", "))))))
    }))) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>)));
    let script_list = concat(&each(scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &lower::escape(s))))));
    let run_root = match &model.root {
        Some(r) => rust_templates::run_root(&r.name),
        None => rust_templates::no_root(&model.name),
    };
    let world = match &model.root {
        Some(r) => r.world.clone(),
        None => Text::lit("test"),
    };
    let main = rust_templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row(&model.elem), &rust_answer(&model.answer), &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
    let files = run_to_end(each_job(model.mods.clone(), Rc::new(move |p0: lower::ModDef| entered(once_job(move || {
        let m = p0;
        call_then(start_rust_module(m.clone()), move |rust_module_31275: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.rs", &m.name)), rust_module_31275)))
    }))) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), prelude_template::prelude_source(&Text::lit("")))]), &files)
}

/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
/// ```
pub struct EmitCrate {
    pub model: lower::Model,
    pub runtime: Text,
    pub scripts: Array<Text>,
}

impl prism_rtl::Job<Array<(Text, Text)>> for EmitCrate {
    fn cycle(&self) -> prism_rtl::Turn<Array<(Text, Text)>> {
        let model = &self.model;
        let runtime = &self.runtime;
        let scripts = &self.scripts;
        let gui = match &model.root {
            Some(r) => &r.world == &Text::lit("canvas"),
            None => false,
        };
        let cargo = rust_templates::cargo(&model.name, runtime, &(if gui { Text::lit("\"canvas\"") } else { Text::lit("") }));
        let mods = concat(&each(&model.mods, &(|m: &lower::ModDef| Text::from(format!("mod {};\n", &m.name)))));
        let model = model.clone();
        let scripts = scripts.clone();
        call_value(each_job(all_programs(&model), {
            let model = model.clone();
            Rc::new(move |p0: lower::ProgDef| {
                let model = model.clone();
                entered(once_job(move || {
                    let p_ = p0;
                    prism_rtl::Turn::More(Rc::new(RustProgram { p_: p_.clone(), fallible: node_fallible(&model, &p_.node_) }))
                }))
            }) as Rc<dyn Fn(lower::ProgDef) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_30506: Array<Text>| {
            let programs = lexer::join(&each_30506, &Text::lit("\n"));
            let regs = concat(&each(&model.programs, &(|p_: &lower::ProgDef| Text::from(format!(".program::<{}>(\"{}\")\n", &p_.name, &p_.prism)))));
            call_value(each_job(model.checks.clone(), Rc::new(move |p0: lower::CheckDef| entered(once_job(move || {
                let c = p0;
                call_value(each_job(c.lines.clone(), Rc::new(move |p0: lower::Ex| entered(once_job(move || {
                    let l = p0;
                    prism_rtl::Turn::More(Rc::new(Expression { x: l.clone() }))
                }))) as Rc<dyn Fn(lower::Ex) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30764: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!(".check(\"{}\", || vec![{}])\n", &c.name, &lexer::join(&each_30764, &Text::lit(", "))))))
            }))) as Rc<dyn Fn(lower::CheckDef) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_30703: Array<Text>| {
                let checks = concat(&each_30703);
                let script_list = concat(&each(&scripts, &(|s: &Text| Text::from(format!("\"{}\",\n", &lower::escape(s))))));
                let run_root = match &model.root {
                    Some(r) => rust_templates::run_root(&r.name),
                    None => rust_templates::no_root(&model.name),
                };
                let world = match &model.root {
                    Some(r) => r.world.clone(),
                    None => Text::lit("test"),
                };
                call_then(start_rust_row(model.elem.clone()), move |rust_row_31109: Text| call_then(start_rust_answer(model.answer.clone()), move |rust_answer_31131: Text| {
                    let main = rust_templates::main(&model.name, &Text::from(format!("mod prelude;\n{}", &mods)), &Text::from(format!("{}\n{}\n{}", &rust_row_31109, &rust_answer_31131, &programs)), &Text::from(format!("{}{}", &regs, &checks)), &script_list, &run_root, &world);
                    call_value(each_job(model.mods.clone(), Rc::new(move |p0: lower::ModDef| entered(once_job(move || {
                        let m = p0;
                        call_then(start_rust_module(m.clone()), move |rust_module_31275: Text| prism_rtl::Turn::Finished((Text::from(format!("src/{}.rs", &m.name)), rust_module_31275)))
                    }))) as Rc<dyn Fn(lower::ModDef) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>), move |each_31231: Array<(Text, Text)>| {
                        let files = each_31231;
                        prism_rtl::Turn::Finished(append(&Array::from(vec![(Text::lit("Cargo.toml"), cargo.clone()), (Text::lit("src/main.rs"), main.clone()), (Text::lit("src/prelude.rs"), prelude_template::prelude_source(&Text::lit("")))]), &files))
                    })
                }))
            })
        })
    }
}

/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
pub fn start_emit_crate(model: lower::Model, runtime: Text, scripts: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<(Text, Text)>>> {
    Rc::new(EmitCrate { model, runtime, scripts })
}

/// ```prism
/// AllPrograms: fn Model -> [ProgDef]
/// ```
pub fn all_programs(model: &lower::Model) -> Array<lower::ProgDef> {
    match &model.root {
        Some(r) => if fold(&model.programs, &false, &(|f: &bool, p_: &lower::ProgDef| *f || (&p_.name == &r.name))) {
            model.programs.clone()
        } else {
            push(&model.programs, r)
        },
        None => model.programs.clone(),
    }
}
